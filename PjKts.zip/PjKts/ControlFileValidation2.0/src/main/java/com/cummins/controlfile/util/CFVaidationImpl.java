package com.cummins.controlfile.util;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.cummins.controlfile.repository.CFValidationRepo;
import com.cummins.controlfile.request.dto.CalibrationDetails;
import com.cummins.controlfile.request.dto.MatchingDataDTO;
import com.cummins.controlfile.request.dto.Options;
import com.cummins.controlfile.request.dto.ParentClass;
import com.cummins.controlfile.request.dto.Partnumber;

import lombok.AllArgsConstructor;

@Component
@AllArgsConstructor
public class CFVaidationImpl {
	public CFVaidationImpl() {
		// TODO Auto-generated constructor stub
	}
	CFValidationRepo repo; 

	public static void main(String[] args) throws Exception {
		CFVaidationImpl  impl=new CFVaidationImpl();
		impl.startCFValidation("AAK", "C:\\Users\\vw596\\Desktop\\Cummins\\misc\\CONTROLFILE\\");
	}

	public void startCFValidation(String productId,String filePath) throws Exception {
		validateStructure(productId, filePath);
		CustomLogger.logInfo(productId+":Structure validated");
		validateCounts(productId);
	}

	private void validateStructure(String productId,String filePath) throws Exception {
		CFData cfData=new CFData();
		cfData.readControlFile(productId, filePath);

	}
	private void validateCounts(String productId) {
		CustomLogger.result("-------,-------,-------,-------,-------");
		CustomLogger.result("ProductId,FileType,EcmCode,Count,Values");
		
		System.out.println("validating counts");
		int profileCount=repo.getProfileCountCheck(productId);
		List<ParentClass> cfFiles=Arrays.asList(CFData.coeCFClass,CFData.engCFClass,CFData.mfgCFClass);
		int i=0;
		for (ParentClass parentClass : cfFiles) {
			String fileType=(i==0)?"COE":(i==1)?"ENG":"MFG";
			List<CalibrationDetails> calibrations=parentClass.getCalibrationDetails();
			for (CalibrationDetails calibrationDetails : calibrations) {
				System.out.println("Testing:"+fileType+":"+calibrationDetails.getEcmcode());
				CustomLogger.result(productId+","+fileType+","+calibrationDetails.getEcmcode()+","+compareCount(productId,  profileCount, calibrationDetails.getEcmcode())+",'"+matchKeyValue(productId, calibrationDetails.getEcmcode(), calibrationDetails)+"'");
			}
			i++;
		}
		System.out.println("Completed.");
	}
	private String compareCount(String productId,int profileCount,String ecmCode) {
		int ecmCount=repo.getControlFileCountCheck(productId, ecmCode);
		if(ecmCount==profileCount) {
			return "Matching";
		}else {
			return "NotMatching:"+repo.getNotMatchingDataKeys(productId, ecmCode).toString();
		}
	}
	private String matchKeyValue(String productId,String ecmCode,CalibrationDetails calibrationDetails) {
		List<MatchingDataDTO> matchingdtos=repo.getMatckingKeyValue(productId, ecmCode);
		Set<String> dbData=new TreeSet<>();
		Set<String> cfData=new TreeSet<>();
		//String regex = "\\d+";
		for (MatchingDataDTO dto : matchingdtos) {
			dbData.add(dto.getSUM_DESC_KEY().toUpperCase()+"-"+dto.getDDO_OPTION());
		}
		List<Partnumber> partNumbers=calibrationDetails.getPartnumbers();
		for (Partnumber partnumber : partNumbers) {
			cfData.add(partnumber.getType().toUpperCase()+"-"+(long)Double.parseDouble(partnumber.getValue()));
		}
		List<Options> options=calibrationDetails.getOptionSet().getOptions();
		cfData.add("ecmpartnumber".toUpperCase()+"-"+calibrationDetails.getEcmpartnumber().iterator().next());
		for (Options optn : options) {
			cfData.add(optn.getPrefix().toUpperCase()+"-"+optn.getValue().iterator().next());
		}
		return findDifferences(dbData, cfData);
	}

	private String findDifferences(Set<String> db,Set<String> cf) {
		System.out.println(db);
		System.out.println(cf);
		StringBuffer buf=new StringBuffer();
		List<String> dbDifferences = db.stream()
				.filter(element -> !cf.contains(element))
				.collect(Collectors.toList());
		if(!dbDifferences.isEmpty()) {
			CustomLogger.logInfo("Data present in DB not in CF:"+dbDifferences);
			buf.append("Data present in DB not in CF:"+dbDifferences);
		}

		List<String> cfDifferences = cf.stream()
				.filter(element -> !db.contains(element))
				.collect(Collectors.toList());
		if(!cfDifferences.isEmpty()) {
			CustomLogger.logInfo("Data present in CF, not in DB:"+cfDifferences);
			buf.append("Data present in DB not in CF:"+dbDifferences);
		}
		if(buf.length()>0) {
			return buf.toString();
		}else {
			return "Matching";
		}
	}
}
