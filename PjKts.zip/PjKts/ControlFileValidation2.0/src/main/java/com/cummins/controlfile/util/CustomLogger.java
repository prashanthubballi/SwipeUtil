package com.cummins.controlfile.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomLogger {
	private static String fileName="CF_JSON_Validation.log";
	private static String resultFileName="CF_Result.csv";
	private static final Logger logger = LoggerFactory.getLogger(CustomLogger.class);

	
public static void logInfo(String log) {
	logger.info(log);
	String date="[ "+new SimpleDateFormat("MMM-dd-yyyy-hh:mm:sss").format(new Date())+" ]  -";
	try(FileWriter fw = new FileWriter(new File("."+"\\"+fileName), true);
		    BufferedWriter bw = new BufferedWriter(fw);
		    PrintWriter out = new PrintWriter(bw))
		{
		    out.println(date+log);
		   
		} catch (IOException e) {
		    //exception handling left as an exercise for the reader
		}
}
public static void result(String result) {
	//String date="[ "+new SimpleDateFormat("MMM-dd-yyyy-hh:mm:sss").format(new Date())+" ]  -";
	try(FileWriter fw = new FileWriter(new File("."+"\\"+resultFileName), true);
		    BufferedWriter bw = new BufferedWriter(fw);
		    PrintWriter out = new PrintWriter(bw))
		{
		    out.println(result);
		   
		} catch (IOException e) {
		   e.printStackTrace();
		}
}
}
