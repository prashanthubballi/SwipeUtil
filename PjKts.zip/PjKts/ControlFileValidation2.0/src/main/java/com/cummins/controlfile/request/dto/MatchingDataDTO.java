package com.cummins.controlfile.request.dto;

public interface MatchingDataDTO {

	public String getSUM_DESC_KEY();
	public String getDDO_OPTION();
}
