package com.cummins.controlfile.util;

import java.io.BufferedReader;
import java.io.File;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import com.cummins.controlfile.request.dto.ParentClass;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CFData {
	
	public static ParentClass coeCFClass=null;
	public static ParentClass engCFClass=null;
	public static ParentClass mfgCFClass=null;
	
	ObjectMapper objectMapper=new ObjectMapper();
	
    
	public void readControlFile(String productId,String filePath) throws JsonMappingException, JsonProcessingException, Exception {
		String coeFilePath=filePath+"\\COE\\Cntl_"+productId+".json";
		String engFilePath=filePath+"\\ENG\\Cntl_"+productId+".json";
		String mfgFilePath=filePath+"\\MFG\\Cntl_"+productId+".json";
		//objectMapper.enable(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE);
		objectMapper.setVisibilityChecker(
				objectMapper.getSerializationConfig().getDefaultVisibilityChecker()
                      .withGetterVisibility(Visibility.PUBLIC_ONLY)
                      .withSetterVisibility(Visibility.PUBLIC_ONLY)
        );
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);
		objectMapper.configure(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE, true);
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNRESOLVED_OBJECT_IDS, true);
		//objectMapper.configure(DeserializationFeature., true);
		coeCFClass=objectMapper.readValue(getStringFileData(coeFilePath), ParentClass.class);
		engCFClass=objectMapper.readValue(getStringFileData(engFilePath), ParentClass.class);
		mfgCFClass=objectMapper.readValue(getStringFileData(mfgFilePath), ParentClass.class);
	}

	private String getStringFileData(String filePath) throws Exception {
		if(!new File(filePath).exists()) {
			throw new Exception("CONTROL File not present in path:"+filePath);
		}
		try (BufferedReader br = java.nio.file.Files.newBufferedReader(Paths.get(filePath))) {
			return br.lines().collect(Collectors.joining(System.lineSeparator()));
		}
	}
}
