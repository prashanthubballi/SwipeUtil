package com.cummins.controlfile.request.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
//@JsonInclude(Include.NON_NULL)
public class ParentClass implements Serializable {
  private static final long serialVersionUID = 1L;

  String productID;
  List<CalibrationDetails> calibrationDetails = new ArrayList<>();
  List<OptionNotes> optionNotes = new ArrayList<>();
  @JsonInclude(Include.NON_NULL)
  List<String> parts = null;

}
