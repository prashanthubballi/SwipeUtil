package com.cummins.controlfile;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Transactional;

import com.cummins.controlfile.repository.CFValidationRepo;
import com.cummins.controlfile.util.CFVaidationImpl;
import com.cummins.controlfile.util.CustomLogger;


@SpringBootApplication
public class MainClass implements CommandLineRunner {

	@Autowired
	CFValidationRepo repo;
	
	private static final Logger logger = LoggerFactory.getLogger(MainClass.class);
	public static void main(String[] args) {
		//logger.info("Started");
		CustomLogger.logInfo("Started...");
		ApplicationContext context=SpringApplication.run(MainClass.class,args);
		CustomLogger.logInfo("Complted...");
		logger.info("Ended");
		SpringApplication.exit(context);
		//
	}

	@Transactional(readOnly = true)
	@Override
	public void run(String... args) {
		String[] products= {"AAK"};//args[0].split(",");
		String filepath="C:\\Users\\vw596\\Desktop\\Cummins\\misc\\CONTROLFILE\\";
		for (String productId:products) {
			CustomLogger.logInfo("START:----------------["+productId+"]----------------");
			
			try {
				CFVaidationImpl  impl=new CFVaidationImpl(repo);
				impl.startCFValidation(productId, filepath);

				System.out.println("welcome");
			}catch (Exception e) {
				e.printStackTrace();
				CustomLogger.logInfo(e.getMessage());
			}
			CustomLogger.logInfo("END:----------------["+productId+"]----------------");
			
		}
		//exit(0);
	}
}
