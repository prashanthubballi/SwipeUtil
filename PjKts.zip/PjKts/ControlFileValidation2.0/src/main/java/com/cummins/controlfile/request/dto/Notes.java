package com.cummins.controlfile.request.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(builderClassName = "Builder", toBuilder = true)
@JsonDeserialize(builder = Notes.Builder.class)
public class Notes implements Serializable{
	private static final long serialVersionUID = 5262752359451832711L;
	@NonNull
	private String desc;
	@NonNull
	private String value;

	@JsonPOJOBuilder(withPrefix = "")
	public static class Builder {
	}

}
