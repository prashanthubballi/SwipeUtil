package com.cummins.controlfile.request.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(builderClassName = "Builder", toBuilder = true)
@JsonDeserialize(builder = CalibrationDetails.Builder.class)
public class CalibrationDetails implements Serializable {
  private static final long serialVersionUID = 1L;
  @NonNull
  String ecmcode;
  @NonNull
  Set<String> ecmpartnumber;
  @NonNull
  OptionSet optionSet;
  @NonNull
  List<Partnumber> partnumbers;
  @JsonPOJOBuilder(withPrefix = "")
  public static class Builder {
  }
}
