package com.cummins.controlfile.repository;

import java.util.List;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import com.cummins.controlfile.model.TD1D2OptionVO;
import com.cummins.controlfile.model.key.TD1D2OptionKey;
import com.cummins.controlfile.request.dto.MatchingDataDTO;

@Repository
public interface CFValidationRepo extends JpaRepository<TD1D2OptionVO, TD1D2OptionKey> {

	String profileCountCheck="SELECT COUNT(1) FROM  " + 
			" (SELECT DISTINCT B.SUM_DESC_KEY FROM T_OPTION_STRUCTURE_LEVEL A,T_SUBFILE_MASTER B" + 
			" WHERE B.SUM_DESCRIPTION = A.NOUN_NAME" + 
			"  AND A.PRODUCT_ID = ?1 " + 
			"  AND SUM_SUBFILE_TYPE NOT IN ('X','x')" + 
			" UNION" + 
			" SELECT DISTINCT A.POS_OPTION_ID FROM T_PRODUCT_OPTION_STRUCTURE_MAP A,T_SUBFILE_MASTER B" + 
			" WHERE A.POS_PRODUCT_ID = ?1 " + 
			" AND A.POS_OPTION_ID NOT IN ('SV'))";
	@Query(value = profileCountCheck, nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500000"))
	Integer getProfileCountCheck(String productId);


	String controlFileCountCheck="SELECT COUNT(1) FROM T_D1D2_OPTIONS A WHERE DDO_PRODUCT_ID = ?1" + 
			"  AND DDO_ECM_CODE = ?2" + 
			"  AND DDO_TYPE NOT IN 'C'";
	@Query(value = controlFileCountCheck, nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500000"))
	Integer getControlFileCountCheck(String productId,String ecmCode);

	String notMatchingDataKeys="SELECT DISTINCT D.SUM_DESC_KEY FROM" + 
			" (SELECT DISTINCT B.SUM_DESC_KEY FROM T_OPTION_STRUCTURE_LEVEL A,T_SUBFILE_MASTER B" + 
			" WHERE B.SUM_DESCRIPTION = A.NOUN_NAME" + 
			"  AND A.PRODUCT_ID = ?1" + 
			"  AND SUM_SUBFILE_TYPE NOT IN ('X','x')" + 
			" UNION" + 
			" SELECT DISTINCT A.POS_OPTION_ID FROM T_PRODUCT_OPTION_STRUCTURE_MAP A,T_SUBFILE_MASTER B" + 
			" WHERE A.POS_PRODUCT_ID = ?1" + 
			"  AND A.POS_OPTION_ID NOT IN ('SV')) D" + 
			" MINUS" + 
			" SELECT DISTINCT DDO_OPTION_PREFIX FROM T_D1D2_OPTIONS A WHERE DDO_PRODUCT_ID = ?1" + 
			"  AND DDO_ECM_CODE = ?2";
	@Query(value =notMatchingDataKeys , nativeQuery = true)
	List<String> getNotMatchingDataKeys(String productId,String ecmCode);

	String matckingKeyValue="SELECT DISTINCT B.SUM_DESC_KEY,C.DDO_OPTION FROM T_OPTION_STRUCTURE_LEVEL A,T_SUBFILE_MASTER B,T_D1D2_OPTIONS C" + 
			" WHERE B.SUM_DESCRIPTION = A.NOUN_NAME" + 
			"  AND C.DDO_LINK_SUBFILE_CODE = B.SUM_SUBFILE_CODE" + 
			"  AND C.DDO_LINK_SUBFILE_SUBCODE = B.SUM_SUBFILE_SUB_CODE" + 
			"  AND B.SUM_DESC_KEY(+) = C.DDO_OPTION_PREFIX" + 
			"  AND C.DDO_TYPE <> 'O'" + 
			"  AND C.DDO_ECM_CODE = ?2" + 
			"  AND C.DDO_PRODUCT_ID = ?1" + 
			" UNION" + 
			" SELECT DISTINCT A.POS_OPTION_ID,C.DDO_OPTION FROM T_PRODUCT_OPTION_STRUCTURE_MAP A,T_D1D2_OPTIONS C" + 
			" WHERE A.POS_OPTION_ID(+) = C.DDO_OPTION_PREFIX" + 
			"  AND C.DDO_TYPE = 'O'" + 
			"  AND C.DDO_ECM_CODE =?2" + 
			"  AND C.DDO_PRODUCT_ID = ?1";
	@Query(value =matckingKeyValue , nativeQuery = true)
	List<MatchingDataDTO> getMatckingKeyValue(String productId,String ecmCode);

}
