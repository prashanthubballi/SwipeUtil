package com.cummins.controlfile.request.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(builderClassName = "Builder", toBuilder = true)
@JsonDeserialize(builder = OptionNotes.Builder.class)
public class OptionNotes implements Serializable {
  private static final long serialVersionUID = 1L;
  @NonNull
  String item;
  // List<Map<String,String>> notes=new ArrayList<>();
  @NonNull
  List<Notes> notes;
  
  @JsonPOJOBuilder(withPrefix = "")
	public static class Builder {
	}
}
