package com.cummins.controlfile.request.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(builderClassName = "Builder", toBuilder = true)
@JsonDeserialize(builder = Options.Builder.class)
public class Options implements Serializable {

  private static final long serialVersionUID = 1L;
  @NonNull
  String prefix;
  @NonNull
  Set<String> value = new TreeSet<>();
  
  @JsonPOJOBuilder(withPrefix = "")
  public static class Builder {
  }
}
