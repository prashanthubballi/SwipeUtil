package com.cummins.postrp.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileSystemException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.PersistenceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cummins.postrp.common.CommonResponse;
import com.cummins.postrp.common.CommonResponseData;
import com.cummins.postrp.common.ResponseUtility;
import com.cummins.postrp.dto.ControlFileRequest;
import com.cummins.postrp.dto.ControlFileResponse;
import com.cummins.postrp.dto.DataplateRequestDTO;
import com.cummins.postrp.dto.DownloadOptionPartRequest;
import com.cummins.postrp.dto.DownloadOptionPartResponse;
import com.cummins.postrp.dto.ResponseDTO;
import com.cummins.postrp.exception.BadRequestException;
import com.cummins.postrp.exception.GenericException;
import com.cummins.postrp.fpeps.dto.ApiResponse;
import com.cummins.postrp.fpeps.dto.FpepsChildRequestDTO;
import com.cummins.postrp.genincalmeta.dto.CalibrationList;
import com.cummins.postrp.genincalmeta.dto.IncalDataDTO;
import com.cummins.postrp.genincalmeta.dto.IncalMetaDataResponseDTO;
import com.cummins.postrp.incalnonassembly.dto.InCalHistoryNonAssemblyRequestDTO;
import com.cummins.postrp.incalhistory.dto.InCalHistoryRequestDTO;
import com.cummins.postrp.service.impl.ControlFileServiceImpl;
import com.cummins.postrp.service.impl.DataPlateServiceImpl;
import com.cummins.postrp.service.impl.DownloadOptionPartServiceImpl;
import com.cummins.postrp.service.impl.IncalMetaDataServiceImpl;
import com.cummins.postrp.service.impl.IncalNonAssemblyServiceImp;
import com.cummins.postrp.service.impl.SpeedInCalHistoryServiceImpl;
import com.cummins.postrp.service.impl.TFcParameterServiceImpl;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("postrp")
public class PostRPController {

	private final Logger logger = LoggerFactory.getLogger(PostRPController.class);


	@Autowired
	private ControlFileServiceImpl controlFileServiceImpl;

	@Autowired
	private DataPlateServiceImpl dataplateImpl;

	@Autowired
	private TFcParameterServiceImpl tFcParameterServiceImpl;
	
	@Autowired
	private DownloadOptionPartServiceImpl downloadOptionPartServiceImpl;
	
	@Autowired
	private IncalMetaDataServiceImpl incalMetaDataServiceImpl;
	
	@Autowired
	private SpeedInCalHistoryServiceImpl inCalHistoryService;
	
	@Autowired
	private IncalNonAssemblyServiceImp incalNonAssembly;

	public static void main(String[] args) throws JsonProcessingException {
		System.out.println(new ObjectMapper().writeValueAsString(new InCalHistoryRequestDTO()));
	}
	
	//control file
	@PostMapping("/controlfilejson")
	private ResponseEntity<?> generateControlFile(@RequestBody ControlFileRequest controlFileRequest){
		try {
			ControlFileResponse  response=controlFileServiceImpl.fetchParentChild(controlFileRequest);
			response.setChildCorrelationGuid(controlFileRequest.getChildCorrelationGuid());
			response.setProductId(controlFileRequest.getProductId());
			return ResponseUtility.generateResponse(response,HttpStatus.OK);
		} catch (BadRequestException e) {
			Map<String,String> error=new HashMap<>();
			ControlFileResponse resp=new ControlFileResponse();
			resp.setChildCorrelationGuid(controlFileRequest.getChildCorrelationGuid());
			resp.setProductId(controlFileRequest.getProductId());
			error.put("ERROR", e.getMessage());
			resp.setResponse(error);
			return ResponseUtility.generateResponse(resp, HttpStatus.BAD_REQUEST);
		} catch(GenericException e){
			Map<String,String> error=new HashMap<>();
			ControlFileResponse resp=new ControlFileResponse();
			resp.setChildCorrelationGuid(controlFileRequest.getChildCorrelationGuid());
			resp.setProductId(controlFileRequest.getProductId());
			error.put("ERROR", e.getMessage());
			resp.setResponse(error);
			return ResponseUtility.generateResponse(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch(Exception e){
			Map<String,String> error=new HashMap<>();
			ControlFileResponse resp=new ControlFileResponse();
			resp.setChildCorrelationGuid(controlFileRequest.getChildCorrelationGuid());
			resp.setProductId(controlFileRequest.getProductId());
			error.put("ERROR", e.getMessage());
			resp.setResponse(error);
			return ResponseUtility.generateResponse(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//data plate
	@PostMapping("createCdfxFile")
	private ResponseEntity<CommonResponse<ResponseDTO>> createCdfxFile(@RequestBody DataplateRequestDTO requestDto){
		try {
			ResponseDTO response = dataplateImpl.createCdfxFile(requestDto.getEcmCode(), requestDto.getProductID(),
					requestDto.getProductFilePath());
			if (response.getResponse().equalsIgnoreCase("0")) {
				return ResponseUtility.generateResponse(response, HttpStatus.OK);
			} else {
				return ResponseUtility.generateResponse(response, HttpStatus.BAD_REQUEST);
			}
		} catch (BadRequestException e) {
			return ResponseUtility.generateResponse(new ResponseDTO("1", e.getMessage()), HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			return ResponseUtility.generateResponse(new ResponseDTO("1", e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	//download option
	@PostMapping("/copy")
	private ResponseEntity<?> copy(@RequestBody DownloadOptionPartRequest request) {
		DownloadOptionPartResponse response = null;
		try {
			response = downloadOptionPartServiceImpl.copyFiles(request);

			if (response.getErrorMessage() != null) {
				return ResponseUtility.generateResponse(response, HttpStatus.BAD_REQUEST);
			} else {
				return ResponseUtility.generateResponse(response, HttpStatus.OK);
			}
		} catch (SQLException e) {
			return ResponseUtility.generateResponse("DB not available", HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (FileSystemException e) {
			return ResponseUtility.generateResponse(e.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
		} catch (BadRequestException | FileNotFoundException e) {
			return ResponseUtility.generateResponse(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}
	
	//fpeps
	@PostMapping("/fpepsIntegration")
	private ResponseEntity<CommonResponse<ApiResponse>> fpepsIntegration(
			@RequestBody FpepsChildRequestDTO fpepsChildRequestDTO) throws Exception {
		System.out.println("Requested FC option size:"+fpepsChildRequestDTO.getFcCodeList().size());
		if (fpepsChildRequestDTO.getFcCodeList().size() > 0) {
			ApiResponse apiResponse = tFcParameterServiceImpl.fpepsIntegration(fpepsChildRequestDTO.getFcCodeList(),
					fpepsChildRequestDTO.getGuid());
			if (apiResponse.getSuccess() == true) {
				return ResponseUtility.generateResponse(apiResponse, HttpStatus.OK);
			} else {
				return ResponseUtility.generateResponse(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			return ResponseUtility.generateResponse(new ApiResponse(true, "Received Empty Data from Fpeps Master"),
					HttpStatus.OK);
		}
	}

	//generate in cal meta data
	@GetMapping("getIncalMetaData")
	private IncalMetaDataResponseDTO getIncalMetaData() throws IOException {
		printGCStatsAndClean();
		IncalMetaDataResponseDTO response=new IncalMetaDataResponseDTO();
		
		List<String> regularProducts=new ArrayList<String>();
		regularProducts=incalMetaDataServiceImpl.getRegularProducts();
		if(regularProducts.isEmpty()) {
			response.setCode(500);
			response.setSuccess(false);
			response.setMessage("Internal Server Error");
			return response;
		}
		printGCStatsAndClean();
		logger.info("Product fetched from DB");

		List<CalibrationList> totalIncalData = incalMetaDataServiceImpl.getInCalMetaData(regularProducts);
		if(null==totalIncalData || totalIncalData.isEmpty()) {
			logger.info("Internal Server Error");
			response.setCode(500);
			response.setSuccess(false);
			response.setMessage("Internal Server Error");
			return response;
		}
		IncalDataDTO incalData=new IncalDataDTO();
		incalData.setCalibrationList(totalIncalData);
		
		
		printGCStatsAndClean();
		String result=incalMetaDataServiceImpl.uploadToS3(incalData);
		
		if(result.equalsIgnoreCase("Success")) {
			//logger.info(GenerateIncalMetaDataConstant.incalMetaDataFileName + " file uploaded successfully to s3 bucket");
			response.setCode(200);
			response.setSuccess(true);
			response.setMessage("Success");
			printGCStatsAndClean();
			return response;
		}
		
		else {
			response.setCode(500);
			response.setSuccess(false);
			response.setMessage("Internal Server Error");
			return response;
		}
	}
	
	
	//incal history
	@PostMapping("/copyToInCal")
	@JsonIgnoreProperties(ignoreUnknown = false)
	private ResponseEntity<com.cummins.postrp.incalhistory.dto.CommonResponse<String>> copyToInCal(@RequestBody InCalHistoryRequestDTO inCalHistory)
			throws BadRequestException {
		try {
		
			inCalHistoryService.copyToInCalHistory(inCalHistory);
			CommonResponseData data = new CommonResponseData("0", null);
			return com.cummins.postrp.incalhistory.dto.ResponseUtility.generateResponse(data, HttpStatus.OK);
		} catch (SQLException | PersistenceException e) {
			CommonResponseData data = new CommonResponseData("1", e.getMessage());
			return com.cummins.postrp.incalhistory.dto.ResponseUtility.generateResponse(data, HttpStatus.INTERNAL_SERVER_ERROR, "Error");
		}
		catch (FileSystemException e) {
			CommonResponseData data = new CommonResponseData("1", e.getMessage());
			return com.cummins.postrp.incalhistory.dto.ResponseUtility.generateResponse(data, HttpStatus.SERVICE_UNAVAILABLE, "Network Drive not found");
		} catch (Exception e) {
			CommonResponseData data = new CommonResponseData("1", e.getMessage());
			return com.cummins.postrp.incalhistory.dto.ResponseUtility.generateResponse(data, HttpStatus.BAD_REQUEST, "Error");
		}
	}
	//incalHistory non assembly
	@PostMapping("/copyToInCalForNonAssembly")
	private ResponseEntity<com.cummins.postrp.incalnonassembly.dto.CommonResponse> copyToInCalForNonAssembly(@RequestBody InCalHistoryNonAssemblyRequestDTO nonassemblyProducts) {
		com.cummins.postrp.incalnonassembly.dto.CommonResponse<com.cummins.postrp.incalnonassembly.dto.CommonResponseData> response = incalNonAssembly.processIncalForNonAssemblyProducts(nonassemblyProducts);
		return com.cummins.postrp.incalnonassembly.dto.ResponseUtility.generateCommonResponse(response, HttpStatus.OK);
	}

	
	public  void printGCStatsAndClean() {
		//logger.info("GC called");
		System.gc();
		//logger.info("GC completed");
		

	}
}
