package com.cummins.postrp.fpeps.dto;

import lombok.Data;

@Data
public class DetailsDTO {
  private String fcCode;
  private String fpepsCode;
  private String minTorqPressure;
  private String maxTorqPressure;
  private String minRatedPressure;
  private String maxRatedPressure;
  private String minTorqFuelRate;
  private String maxTorqdFuelRate;
  private String minRatedFuelRate;
  private String maxRatedFuelRate;
  private String maxBlowByMax;
  private String minRailPressure;
  private String maxRailPressure;

}
