package com.cummins.postrp.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cummins.postrp.incalhistory.dto.ECMCodeDetailsDTO;
import com.cummins.postrp.model.TCalBuildDetails;
import com.cummins.postrp.model.TCalBuildKey;

@Repository
@Transactional
public interface TInCalHistoryRepository extends JpaRepository<TCalBuildDetails, TCalBuildKey> {
	//removing A.ECM_STATUS='Y' as Mani confirmed this condition is not required.
	@Query(value = "SELECT DISTINCT ECM_PRODUCT_ID as ecmProductID, ECM_CODE as ecmCode, ECM_RELEASE_PHASE_CODE  as ecmReleasePhaseCode,"
			+ " ECM_EFFECT_CODE as ecmEffectCode FROM T_ECM A WHERE A.ECM_CODE = ?1 ", nativeQuery = true)
	List<ECMCodeDetailsDTO> getCalDetails(String ecmCode);

	@Query(value = "select COUNT(*) from t_cal_build_details where CBD_ECM_CODE=?1", nativeQuery = true)
	String findTCalBuildDetails(String ecmCode);

	@Query(value = "select COUNT(*) from t_cvn_details where ECM_CODE=?1", nativeQuery = true)
	String findTCVNDetails(String ecmCode);

	@Query(value = "select COUNT(*) from t_calibration where CAL_ECM_CODE=?1 AND CAL_KEY_INDEX=?2", nativeQuery = true)
	String findTCalibration(String ecmCode, String keyIndex);

	@Query(value = "select COUNT(*) from t_calibration where CAL_ECM_CODE=?1 AND CAL_KEY_INDEX is null", nativeQuery = true)
	String findTCalibrationNullIndex(String ecmCode, String keyIndex);

	@Query(value = "select COUNT(*) from t_incal_history where INCAL_ECM_CODE= ?1", nativeQuery = true)
	String findTInCalHistory(String ecmCode);

	@Modifying
	@Query(value = "INSERT INTO t_cal_build_details (cbd_ecm_code,cbd_file_desc, cbd_build_id,cbd_build_name,cbd_prd_id,cbd_rpc,cbd_cal_rev_date, "
			+ "cbd_last_update_date, cbd_last_update_user) "
			+ "VALUES (?1 , ?2 , ?3 , ?4 , ?5, ?6 , to_date(?7,'dd-MM-yyyy'), to_date(?8,'dd-MM-yyyy') , ?9)", nativeQuery = true)
	void saveTCalBuildDetails(String ecmCode, String fileDesc, String buildId, String buildName, String prdId,
			String rpc, String calRevDate, String lastUpdateDate, String lastUpdateUser);

	@Modifying
	@Query(value = "INSERT INTO t_cvn_details (ecm_code, cvn_value, product_id, cal_assembly_date) "
			+ "VALUES (?1 , DECODE(?2,'0','0',UPPER(LPAD(?2,8,0))), ?3 , (select max(ERL_RELEASE_DATE) From T_ER_LIST where ERL_RELEASE_STATUS ='Y'))", nativeQuery = true)
	void saveTCVNDetails(String ecmCode, String value, String prodId, String assemblyDate);

	@Modifying
	@Query(value = "INSERT INTO t_calibration (cal_a_file_part_number, cal_product_id, cal_status, cal_ecm_code,"
			+ " cal_last_update_user, cal_last_update_date, cal_key_index , CAL_ECM_VERSION , CAL_INT_PATH) "
			+ "VALUES (?1 , ?2 , ?3 , ?4 , ?5, to_date(?6,'dd-MM-yyyy') , ?7, ?8 , ?9)", nativeQuery = true)
	void saveTCalibration(String filePartNumber, String prodId, String status, String ecmCode, String lastUpdateUser,
			String lastUpdateDate, String keyIndex, String calVersion, String incalIntPath);

	@Modifying
	@Query(value = "INSERT INTO t_incal_history (incal_prd_id, incal_ecm_code, incal_release_phase_code, incal_flag,  incal_key_index, INCAL_LAST_UPDATE_DATE) "
			+ "VALUES (?1 , ?2 , ?3 , ?4 , ?5, (select max(ERL_RELEASE_DATE) From T_ER_LIST where ERL_RELEASE_STATUS ='Y'))", nativeQuery = true)
	void saveTInCalHistory(String prodId, String ecmCode, String releasePhaseCode, String inCalFlag, String keyIndex);

	@Modifying
	@Query(value = "UPDATE  t_incal_history set incal_prd_id =?1, incal_release_phase_code=?3, incal_flag=?4,incal_key_index=?5, "
			+ "INCAL_LAST_UPDATE_DATE=(select max(ERL_RELEASE_DATE) From T_ER_LIST where ERL_RELEASE_STATUS ='Y') where INCAL_ECM_CODE= ?2", nativeQuery = true)
	void updateTInCalHistory(String prodId, String ecmCode, String releasePhaseCode, String string, String keyIndex);

	@Modifying
	@Query(value = "UPDATE t_calibration set cal_a_file_part_number=?1, cal_product_id=?2, cal_status=?3, "
			+ "cal_last_update_user= ?5 , cal_last_update_date=to_date(?6,'dd-MM-yyyy') , CAL_ECM_VERSION=?8 , CAL_INT_PATH =?9 where CAL_ECM_CODE=?4 AND cal_key_index=?7", nativeQuery = true)
	void updateTCalibration(String inCalHistoryFileName, String prodId, String string, String ecmCode,
			String lastUpdateUser, String startTime, String keyIndex, String calVersion, String incalIntPath);

	@Modifying
	@Query(value = "Delete from t_calibration where CAL_ECM_CODE=?1", nativeQuery = true)
	void deleteTCalibration(String ecmCode);
	
	@Modifying
	@Query(value = "Delete from t_calibration where CAL_ECM_CODE=?1 and cal_key_index in (?2)", nativeQuery = true)
	void deleteTCalibrationWithIndex(String ecmCode,List<Integer> indexes);

	@Modifying
	@Query(value = "UPDATE t_cvn_details set cvn_value = DECODE(?2,'0','0',UPPER(LPAD(?2,8,0))), product_id=?3,"
			+ " cal_assembly_date=(select max(ERL_RELEASE_DATE) From T_ER_LIST where ERL_RELEASE_STATUS ='Y') where ECM_CODE=?1", nativeQuery = true)
	void updateTCVNDetails(String ecmCode, String cvn, String prodId, String startTime);

	@Modifying
	@Query(value = "UPDATE t_cal_build_details set cbd_file_desc = ?2, cbd_build_id=?3,cbd_build_name = ?4 ,cbd_prd_id= ?5,cbd_rpc = ?6 ,cbd_cal_rev_date  = to_date(?7,'dd-MM-yyyy') , "
			+ " cbd_last_update_date  = to_date(?8,'dd-MM-yyyy') , cbd_last_update_user  = ?9  where CBD_ECM_CODE = ?1", nativeQuery = true)
	void updateTCalBuildDetails(String ecmCode, String fileDesrcriptor, String buildId, String buildName, String prodId,
			String releasePhaseCode, String startTime, String startTime2, String lastUpdateUser);

	@Modifying
	@Query(value = "INSERT INTO T_INCAL_HISTORY (INCAL_PRD_ID, INCAL_ECM_CODE, INCAL_RELEASE_PHASE_CODE, INCAL_KEY_INDEX, INCAL_ECM_VERSION, INCAL_ECM_FILE_NAME, INCAL_LAST_UPDATE_DATE) "
			+ " VALUES (?1, ?2, ?3, ?4, ?5, ?6, (select max(ERL_RELEASE_DATE) From T_ER_LIST where ERL_RELEASE_STATUS ='Y'))", nativeQuery = true)
	void insertIntoT_INCAL_HISTORY(String prodID, String ecmCode, String releasePhaseCode, String keyIndex, String calVersion, String fileName);
	
	@Modifying
	@Query(value = "Delete from T_INCAL_HISTORY where INCAL_PRD_ID = ?1 and INCAL_ECM_CODE = ?2 and INCAL_ECM_FILE_NAME =?3", nativeQuery = true)
	void deleteFrom_INCAL_HISTORY(String prodID, String ecmCode,String incalFileName);
	
	@Modifying
	@Query(value = "Delete from T_INCAL_HISTORY where INCAL_PRD_ID = ?1 and INCAL_ECM_CODE = ?2 and INCAL_RELEASE_PHASE_CODE = ?3 and INCAL_KEY_INDEX = ?4 and (INCAL_ECM_VERSION = ?5 or ?5 is null) and INCAL_ECM_FILE_NAME = ?6", nativeQuery = true)
	void deleteTIncalHistory(String prodID, String ecmCode, String releasePhaseCode, String keyIndex, String calVersion, String fileName);
	
	@Modifying
	@Query(value = "Delete from T_INCAL_HISTORY where INCAL_PRD_ID = ?1 and INCAL_ECM_CODE = ?2 and INCAL_RELEASE_PHASE_CODE = ?3 and (INCAL_ECM_VERSION = ?4 or ?4 is null) and INCAL_ECM_FILE_NAME = ?5", nativeQuery = true)
	void deleteTIncalHistoryForCSAR(String prodID, String ecmCode, String releasePhaseCode, String calVersion, String fileName);
	
	@Modifying
	@Query(value = "Delete from T_INCAL_HISTORY where INCAL_PRD_ID = ?1 and INCAL_ECM_CODE = ?2 and INCAL_RELEASE_PHASE_CODE = ?3 and (INCAL_ECM_VERSION = ?4 or ?4 is null) and INCAL_ECM_FILE_NAME = ?5 and INCAL_KEY_INDEX is null", nativeQuery = true)
	void deleteTIncalHistoryIfNull(String prodID, String ecmCode, String releasePhaseCode, String calVersion, String fileName);
	
	@Query(value = "select COUNT(*) from T_INCAL_HISTORY where INCAL_PRD_ID = ?1 and INCAL_ECM_CODE = ?2 and INCAL_RELEASE_PHASE_CODE = ?3 and INCAL_KEY_INDEX = ?4", nativeQuery = true)
	Integer countTIncalHistory(String prodID, String fileName, String releasePhaseCode, String keyIndex);
	
	@Query(value = "select user from dual", nativeQuery = true)
	public String getUserFromDB();

}