package com.cummins.postrp.incalnonassembly.dto;

import lombok.Data;

@Data
public class InCalHistoryNonAssemblyRequestDTO {
	String productId;
	String itemNumber;
	String rpCode;
	String efCode;
	String path;
}
