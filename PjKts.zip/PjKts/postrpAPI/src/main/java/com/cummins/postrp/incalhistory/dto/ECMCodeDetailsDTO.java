package com.cummins.postrp.incalhistory.dto;

public interface ECMCodeDetailsDTO {
  String getEcmProductID();

  String getEcmCode();

  String getEcmReleasePhaseCode();

  String getEcmEffectCode();

  String getKeyIndex();
}
