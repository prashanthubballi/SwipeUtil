package com.cummins.postrp.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ParamStore {

	@JsonProperty("mappedPath")
	private String mappedPath;
	@JsonProperty("mappedPathExp")
	private String mappedPathExp;
	@JsonProperty("headerFileSource")
	private String headerFileSource;
/*	@JsonProperty("serviceNowAPI")
	private String serviceNowAPI;
	@JsonProperty("serviceNowImpact")
	private String serviceNowImpact;
	@JsonProperty("serviceNowUrgency")
	private String serviceNowUrgency;
	@JsonProperty("serviceNowAssignmentGrp")
	private String serviceNowAssignmentGrp;
	*/
	@JsonProperty("clientId")
	private String clientId;
	
	@JsonProperty("client_secret")
	private String client_secret;
	
	@JsonProperty("resource")
	private String resource;
	
	@JsonProperty("authUrl")
	private String authUrl;
	
	@JsonProperty("fpepsURL")
	private String fpepsURL;

	@JsonProperty("incalMetaDataFilePath")
	private String incalMetaDataFilePath;
	@JsonProperty("incalMetaDataFileName")
	private String incalMetaDataFileName;


	@JsonProperty("incalFolder")
	private String incalFolder;
	@JsonProperty("calibrationFolder")
	private String calibrationFolder;
	@JsonProperty("pattern")
	private String pattern;
	@JsonProperty("ecmPattern")
	private String ecmPattern;
	@JsonProperty("signedEcmPattern")
	private String signedEcmPattern;
	
	@JsonProperty("outBoundSycUrl")
	private String outBoundSycUrl;

	

	@JsonProperty("resilience4j")
	private Resilience4j resilience4j;
}
