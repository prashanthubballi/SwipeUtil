package com.cummins.postrp.service.impl;

import java.io.File;

import org.apache.commons.io.FilenameUtils;

import com.cummins.postrp.exception.BadRequestException;
import com.cummins.postrp.incalhistory.dto.InCalHistoryRequestDTO;

public class InCalHistoryUtility {
	public static final String ERROR_MESSAGE_INVALID_PARAMETER = "Invalid Parameter";
	public static final String ERROR_MESSAGE_CALFILE_BLANK = "calibrationFile should not be blank or null";
	public static final String ERROR_MESSAGE_CALIBRATIONPath_BLANK = "calibration File Path should not be blank or null";
	public static final String ERROR_MESSAGE_CVN_BLANK = "CVN should not be blank or null";
	public static final String ERROR_MESSAGE_INCALFILEPATH_BLANK = "Output file should not be blank or null";
	public static final String ERROR_MESSAGE_CSAR_EXTENSION = "MODE CSAR Should have pdx extension file";
	public static final String ERROR_MESSAGE_KEYINDEX_PARAMETER_MISSING = "KeyIndex parameter is missing.";
	public static final String ERROR_MESSAGE_SCOPE_PARAM_MISSING = "Scope parameter is missing.";
	public static final String ERROR_MESSAGE_SCOPE_ERROR = "Scope should be either incal or regular.";
	public static final String ERROR_MESSAGE_FLAG_PARAM_MISSING = "Flag parameter is missing.";
	public static final String ERROR_MESSAGE_MODE_BLANK = "Mode should not be blank or null";

	public static void blankValidation(InCalHistoryRequestDTO inCalHistory) {

		if (inCalHistory.getMode() != null && inCalHistory.getMode().equalsIgnoreCase("CORE")
				&& inCalHistory.getKeyIndex() != null && inCalHistory.getKeyIndex().size() > 0) {
			for (Integer keyIndexFile : inCalHistory.getKeyIndex()) {
				File f = new File(inCalHistory.getCalibrationFilePath() + "\\" + inCalHistory.getCalibrationFile() + "."
						+ keyIndexFile);
				if (!f.exists()) {
					throw new BadRequestException(
							"FILE NOT FOUND" + ":" + inCalHistory.getCalibrationFile() + "." + keyIndexFile);
				}
			}
		}

		if (inCalHistory.getMode() != null && inCalHistory.getMode().equalsIgnoreCase("CSAR")
				&& !FilenameUtils
						.getExtension(inCalHistory.getCalibrationFilePath() + "\\" + inCalHistory.getCalibrationFile())
						.equalsIgnoreCase("pdx")) {
			throw new BadRequestException(ERROR_MESSAGE_CSAR_EXTENSION);
		}
		if (null == inCalHistory.getCalibrationFilePath()) {
			throw new BadRequestException(ERROR_MESSAGE_INVALID_PARAMETER);
		}
		if (inCalHistory.getCalibrationFilePath() != null && inCalHistory.getCalibrationFilePath().equals("")) {
			throw new BadRequestException(ERROR_MESSAGE_CALIBRATIONPath_BLANK);
		}
		if (null == inCalHistory.getCalibrationFile()) {
			throw new BadRequestException(ERROR_MESSAGE_INVALID_PARAMETER);
		}
		if (inCalHistory.getCalibrationFile() != null && inCalHistory.getCalibrationFile().equals("")) {
			throw new BadRequestException(ERROR_MESSAGE_CALFILE_BLANK);
		}
		if (null == inCalHistory.getCVN() && inCalHistory.getMode().equalsIgnoreCase("CORE")) {
			throw new BadRequestException(ERROR_MESSAGE_INVALID_PARAMETER);
		}
		if (inCalHistory.getCVN() != null && inCalHistory.getCVN().equals("")
				&& inCalHistory.getMode().equalsIgnoreCase("CORE")) {
			throw new BadRequestException(ERROR_MESSAGE_CVN_BLANK);
		}
		if (null == inCalHistory.getInCalPath()) {
			throw new BadRequestException(ERROR_MESSAGE_INVALID_PARAMETER);
		}
		if (inCalHistory.getInCalPath() != null && inCalHistory.getInCalPath().equals("")) {
			throw new BadRequestException(ERROR_MESSAGE_INCALFILEPATH_BLANK);
		}
		if (null == inCalHistory.getMode()) {
			throw new BadRequestException(ERROR_MESSAGE_INVALID_PARAMETER);
		}
		if (inCalHistory.getMode() != null && (inCalHistory.getMode().equals("")
				|| inCalHistory.getMode().trim().equals("") || inCalHistory.getMode().isEmpty())) {
			throw new BadRequestException(ERROR_MESSAGE_MODE_BLANK);
		}
		if (inCalHistory.getKeyIndex() == null) {
			throw new BadRequestException(ERROR_MESSAGE_KEYINDEX_PARAMETER_MISSING);
		}
//		if (inCalHistory.getScope() == null) {
//			throw new BadRequestException(ERROR_MESSAGE_SCOPE_PARAM_MISSING);
//		} else {
//			if (!inCalHistory.getScope().equalsIgnoreCase("incal") && !inCalHistory.getScope().equalsIgnoreCase("regular")) {
//				throw new BadRequestException(ERROR_MESSAGE_SCOPE_ERROR);
//			}
//		}
	}
}
