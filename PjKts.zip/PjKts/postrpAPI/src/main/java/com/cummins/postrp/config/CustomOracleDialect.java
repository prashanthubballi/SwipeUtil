package com.cummins.postrp.config;

import org.hibernate.dialect.Oracle12cDialect;
import org.hibernate.dialect.function.SQLFunctionTemplate;
import org.hibernate.type.StandardBasicTypes;

public class CustomOracleDialect extends Oracle12cDialect {

  public CustomOracleDialect() {
    super();
    registerFunction("LISTAGG",
      new SQLFunctionTemplate(StandardBasicTypes.STRING, "LISTAGG(?1,',') WITHIN GROUP(ORDER BY ?1)"));
  }

}
