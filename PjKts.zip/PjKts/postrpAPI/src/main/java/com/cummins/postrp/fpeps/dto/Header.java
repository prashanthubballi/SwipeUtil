package com.cummins.postrp.fpeps.dto;

import lombok.Data;

@Data
public class Header {

  private String messageIdentifier;
  private String success;
  private String code;
  private String message;
  private String messageType;
}
