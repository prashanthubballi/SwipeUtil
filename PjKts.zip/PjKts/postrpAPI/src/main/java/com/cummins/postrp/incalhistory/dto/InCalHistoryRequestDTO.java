package com.cummins.postrp.incalhistory.dto;

import java.util.List;
import lombok.Data;

@Data
public class InCalHistoryRequestDTO {
	public String calibrationFilePath;
	public String calibrationFile;
	public String inCalPath;
	public String CVN;
	public String mode;
	public List<Integer> keyIndex;
	public String flag;
}
