package com.cummins.postrp.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cummins.postrp.model.TSubfileCrcMapTable;
import com.cummins.postrp.model.TSubfileCrcMapTableKey;

@Repository
public interface INonAssemblyRepository extends JpaRepository<TSubfileCrcMapTable, TSubfileCrcMapTableKey> {

	@Query(value = "SELECT DISTINCT ECM_PRODUCT_ID as productId ,TRIM(ITM_NUMBER)||'.'||lpad(A.itm_revision_level,2,'0') itemNumber,\r\n"
			+ "ECM_RELEASE_PHASE_CODE as rpCode, ECM_EFFECT_CODE as efCode,\r\n"
			+ "ITM_INT_PATH path from t_ecm ,t_item A, T_SUBFILE_CRC_MAP\r\n"
			+ "WHERE ECM_PRODUCT_ID = SRC_PROD_ID AND ECM_PRODUCT_ID NOT IN (SELECT DISTINCT GH_PRODUCT_ID FROM T_GREENHOUSE_PRODUCTS)\r\n"
			+ "  AND ECM_STATUS = 'Y' AND SRC_ASSEMBLER NOT IN ('C','S','A','O','D')\r\n"
			+ "  AND (TO_CHAR(ECM_LAST_UPDATE_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS')  \r\n"
			+ " FROM T_ER_LIST where ERL_RELEASE_STATUS = 'Y' )\r\n"
			+ " OR TO_CHAR(ECM_CAL_SELECTION,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS')  \r\n"
			+ " FROM T_ER_LIST  where ERL_RELEASE_STATUS = 'Y' ))\r\n"
			+ "  AND A.ITM_NUMBER in (SELECT OPS_ITEM_PART_NUMBER FROM T_OPTION_STRUCTURE\r\n"
			+ "                        WHERE OPS_FILE_TYPE = 'A' AND  OPS_OPTION_NUMBER =  ECM_SC_OPTION\r\n"
			+ "                         AND TO_CHAR(OPS_STOP_DATE,'DD-MON-YYYY') = '31-DEC-2099'\r\n"
			+ "                      UNION\r\n"
			+ "                      SELECT OPS_ITEM_PART_NUMBER FROM T_OPTION_STRUCTURE  WHERE OPS_OPTION_NUMBER IN (SELECT OPS_ITEM_PART_NUMBER FROM T_OPTION_STRUCTURE\r\n"
			+ "      WHERE OPS_OPTION_NUMBER = ECM_SC_OPTION  AND OPS_FILE_TYPE ='X' AND TO_CHAR(OPS_STOP_DATE,'DD-MON-YYYY') = '31-DEC-2099')\r\n"
			+ "       AND OPS_FILE_TYPE = 'A' AND TO_CHAR(OPS_STOP_DATE,'DD-MON-YYYY') = '31-DEC-2099')  \r\n"
			+ "  AND ITM_REVISION_LEVEL = (SELECT MAX(B.ITM_REVISION_LEVEL)\r\n"
			+ "                                    FROM T_ITEM B\r\n"
			+ "                                    WHERE B.ITM_NUMBER = A.ITM_NUMBER\r\n"
			+ "                                       AND B.ITM_STATUS   = 'Y')\r\n"
			+ "ORDER by  ECM_PRODUCT_ID  ", nativeQuery = true)
	List<com.cummins.postrp.incalnonassembly.dto.INonAssemblyProductsDto> getNonAssemblyProducts();

	@Query(value = "Select BRE_JSON from T_DISTRIBUTION_RULE_SET where BRE_RULE_NAME = ?1", nativeQuery = true)
	String getDistributionRuleSetByName(String ruleName);

	@Transactional
	@Modifying
	@Query(value = "INSERT INTO t_incal_history (incal_prd_id, incal_ecm_code, incal_release_phase_code, INCAL_ECM_FILE_NAME,  incal_key_index, INCAL_LAST_UPDATE_DATE) "
			+ "VALUES (?1 , ?2 , ?3 , ?4 , ?5, SYSDATE)", nativeQuery = true)
	void saveTInCalHistory(String prodId, String ecmCode, String releasePhaseCode, String inCalFile, String keyIndex);

	@Transactional
	@Modifying
	@Query(value = "UPDATE  t_incal_history set incal_prd_id =?1, incal_release_phase_code=?3, INCAL_ECM_FILE_NAME=?4, incal_key_index=?5, INCAL_LAST_UPDATE_DATE=SYSDATE where INCAL_ECM_CODE= ?2", nativeQuery = true)
	void updateTInCalHistory(String prodId, String ecmCode, String releasePhaseCode, String string, String keyIndex);

	@Query(value = "select count(*) from t_incal_history where INCAL_PRD_ID= ?1 and INCAL_ECM_CODE=?2", nativeQuery = true)
	int findIncalHistory(String prodId, String ecmCode);
}
