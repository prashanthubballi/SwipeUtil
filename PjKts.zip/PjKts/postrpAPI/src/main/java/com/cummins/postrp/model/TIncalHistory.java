package com.cummins.postrp.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import lombok.Data;

/**
 * The persistent class for the T_INCAL_HISTORY database table.
 * 
 */

@Entity
@Data
@Table(name="T_INCAL_HISTORY")
@NamedQuery(name="TIncalHistory.findAll", query="SELECT t FROM TIncalHistory t")
public class TIncalHistory implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="INCAL_PRD_ID")
	private String productID;
	
	@Column(name="INCAL_ECM_CODE")
	private String ecmCode;
	
	@Column(name="INCAL_ECM_VERSION")
	private String version;
	
	@Column(name="INCAL_ECM_FILE_NAME")
	private String fileName;

}
