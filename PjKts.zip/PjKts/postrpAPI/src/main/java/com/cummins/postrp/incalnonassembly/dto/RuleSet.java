package com.cummins.postrp.incalnonassembly.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
public class RuleSet {

  @JsonProperty(value = "condition")
  private String condition;
  
  @JsonProperty(value="rules")
  private List<Rule> rules;
}
