package com.cummins.postrp.service;

import com.cummins.postrp.dto.ControlFileRequest;
import com.cummins.postrp.dto.ControlFileResponse;
import com.cummins.postrp.exception.BadRequestException;
import com.cummins.postrp.exception.GenericException;

public interface ControlFileService {

  ControlFileResponse fetchParentChild(ControlFileRequest controlFileRequest) throws GenericException,BadRequestException;
}
