package com.cummins.postrp.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "T_SUBFILE_CRC_MAP")
public class TSubfileCrcMapTable {
	
	@EmbeddedId
	private TSubfileCrcMapTableKey key;

}
