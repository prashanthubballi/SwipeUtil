package com.cummins.postrp.repository;

import java.util.List;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import com.cummins.postrp.dto.D1D2OptionDto;
import com.cummins.postrp.dto.OptionNotesDto;
import com.cummins.postrp.dto.PartsDTO;
import com.cummins.postrp.model.TD1D2OptionKey;
import com.cummins.postrp.model.TD1D2OptionVO;

@Repository
public interface TD1D2OptionRepository extends JpaRepository<TD1D2OptionVO, TD1D2OptionKey> {
	String CALIB_MAIN_QUERY_NEW = "SELECT ProductId, EcmCode, DDoption, OptionPrefix, OptionType , MFGGroup, ENGGroup, COEGroup" + 
	  		" from" + 
	  		" (SELECT DDO_PRODUCT_ID AS ProductId, DDO_ECM_CODE AS EcmCode, DDO_OPTION  AS DDoption, DDO_OPTION_PREFIX   AS OptionPrefix," + 
	  		" DDO_TYPE AS OptionType, DDO_MFG_GROUP  AS MFGGroup, DDO_ENG_GROUP AS ENGGroup, DDO_COE_GROUP AS COEGroup, POS_OPTION_PRIORITY FROM" + 
	  		" (SELECT DISTINCT a.DDO_PRODUCT_ID,a.DDO_ECM_CODE,a.DDO_OPTION,a.DDO_OPTION_PREFIX,a.DDO_MFG_GROUP,a.DDO_ENG_GROUP,a.DDO_COE_GROUP,a.DDO_TYPE,null POS_OPTION_PRIORITY" + 
	  		" FROM T_D1D2_OPTIONS a" + 
	  		" WHERE a.DDO_PRODUCT_ID= ?1" + 
	  		//"--AND a.DDO_TYPE IN ('O','C','H') /*Mani commented this to add priority on options*/" + 
	  		" AND a.DDO_TYPE IN ('C','H')" + 
	  		" AND a.DDO_PRINTED_FLAG = 'Y'" + 
	  		" UNION" + 
	  		" SELECT  DISTINCT a.DDO_PRODUCT_ID,a.DDO_ECM_CODE,a.DDO_OPTION,a.DDO_OPTION_PREFIX,a.DDO_MFG_GROUP,a.DDO_ENG_GROUP,a.DDO_COE_GROUP,a.DDO_TYPE ,POS_OPTION_PRIORITY" + 
	  		" FROM T_D1D2_OPTIONS a ,T_PRODUCT_OPTION_STRUCTURE_MAP" + 
	  		" WHERE a.DDO_PRODUCT_ID= ?1" + 
	  		" AND a.DDO_TYPE IN ('O') " + 
	  		//" /*Mani included this to add priority on options*/" + 
	  		" AND a.DDO_PRINTED_FLAG = 'Y'" + 
	  		" AND POS_PRODUCT_ID = a.DDO_PRODUCT_ID" + 
	  		" AND POS_OPTION_ID = a.DDO_OPTION_PREFIX" + 
	  		" AND POS_SERIAL_NUMBER = 0" + 
	  		" UNION" + 
	  		" SELECT  DISTINCT a.DDO_PRODUCT_ID,a.DDO_ECM_CODE,"+
	  		//"/*Mani included this to add DO option for PJ option products*/" + 
	  		" substr(PDF_DO_OPTION,1,7), substr(PDF_DO_OPTION,1,2)," + 
	  		" a.DDO_MFG_GROUP,a.DDO_ENG_GROUP,a.DDO_COE_GROUP,a.DDO_TYPE ,POS_OPTION_PRIORITY" + 
	  		" FROM T_D1D2_OPTIONS a ,T_PRODUCT_OPTION_STRUCTURE_MAP, t_pj_do_fr " + 
	  		" WHERE a.DDO_PRODUCT_ID= ?1" + 
	  		" AND a.DDO_TYPE IN ('O') " + 
	  		" AND a.DDO_PRINTED_FLAG = 'Y'" + 
	  		" AND a.DDO_OPTION = substr(PDF_PJ_OPTION,1,7)" + 
	  		" AND substr(PDF_DO_OPTION,1,2) ='DO'" + 
	  		" AND POS_PRODUCT_ID = a.DDO_PRODUCT_ID" + 
	  		" AND POS_OPTION_ID = a.DDO_OPTION_PREFIX" + 
	  		" AND POS_SERIAL_NUMBER = 0" + 
	  		" AND  a.DDO_PRODUCT_ID in (SELECT SRC_PROD_ID" + 
	  		" FROM  T_SUBFILE_CRC_MAP  " + 
	  		" WHERE SRC_PROD_ID IN (SELECT DISTINCT PNM_PRODUCT_ID FROM T_PARTNO_NOTES_MASTER" + 
	  		" WHERE PNM_PRODUCT_ID IN (SELECT DISTINCT POS_PRODUCT_ID FROM T_PRODUCT_OPTION_STRUCTURE_MAP WHERE POS_OPTION_ID = 'PJ')" + 
	  		" AND PNM_LINE_NUMBER = 9" + 
	  		" AND SUBSTR(PNM_DESCRIPTION,1,2) = 'DO')" + 
	  		" AND SRC_ETR_PREFIX ='J')" + 
	  		" UNION" + 
	  		" SELECT DISTINCT a.DDO_PRODUCT_ID,a.DDO_ECM_CODE,DECODE(a.DDO_TYPE,'P',(TRIM(a.DDO_OPTION)||'.'||DECODE(LENGTH(b.ITM_REVISION_LEVEL),1," + 
	  		" LPAD(b.ITM_REVISION_LEVEL,2,0),b.ITM_REVISION_LEVEL)),a.DDO_OPTION) DDO_OPTION,a.DDO_OPTION_PREFIX,a.DDO_MFG_GROUP,a.DDO_ENG_GROUP,a.DDO_COE_GROUP,a.DDO_TYPE ,null POS_OPTION_PRIORITY" + 
	  		" FROM T_D1D2_OPTIONS a, t_item b" + 
	  		" WHERE a.DDO_PRODUCT_ID= ?1" + 
	  		" AND a.DDO_TYPE IN ('P')" + 
	  		" AND TRIM(a.DDO_OPTION) = TRIM(b.ITM_NUMBER)" + 
	  		" AND a.DDO_PRINTED_FLAG = 'Y'" + 
	  		" AND b.ITM_REVISION_LEVEL = (SELECT MAX(D.ITM_REVISION_LEVEL) FROM T_ITEM D  " + 
	  		" WHERE D.ITM_NUMBER = b.ITM_NUMBER AND D.ITM_STATUS = 'Y' AND ITM_EFFECT_CODE!=40) ) ORDER BY  DDO_ECM_CODE,POS_OPTION_PRIORITY)";
	
	String NOTES_DETAIL_QUERY_NEW = "SELECT DISTINCT NOT_DESCRIPTION AS Description," + 
			"     SUBSTR(NOT_ITEM_NUMBER,1,7)               AS DDOption," + 
			"     NOT_LINE_NUMBER" + 
			"   FROM" + 
			"     (SELECT DISTINCT NOT_DESCRIPTION ," + 
			"       NOT_ITEM_NUMBER," + 
			"       NOT_LINE_NUMBER" + 
			"     FROM T_NOTE a" + 
			"     WHERE NOT_PRODUCT_ID =?1" + 
			"     AND SUBSTR(NOT_ITEM_NUMBER,1,7) IN" + 
			"       (SELECT DISTINCT DDO_OPTION" + 
			"       FROM T_D1D2_OPTIONS a" + 
			"       WHERE DDO_PRODUCT_ID       =NOT_PRODUCT_ID" + 
			"       AND DDO_TYPE              IN ('O')" + 
			"	   AND DDO_PRODUCT_ID not in (SELECT SMP_PRODUCT_ID FROM T_SMART_PRODUCTS" + 
			"									UNION " + 
			"								  SELECT TTP_PRODUCT_ID FROM T_TURBO_TECH_PRODUCTS	" + 
			"									UNION" + 
			"								  SELECT CES_PRODUCT_ID FROM T_CES_PRODUCTS)" + 
			"       AND DDO_PRINTED_FLAG = 'Y'" + 
			"       )" + 
			"	  UNION " + 
			"	SELECT DISTINCT NOT_DESCRIPTION ," + 
			"       NOT_ITEM_NUMBER," + 
			"       NOT_LINE_NUMBER" + 
			"     FROM T_NOTE a" + 
			"     WHERE NOT_PRODUCT_ID =?1" + 
			"     AND TRIM(NOT_ITEM_NUMBER) IN" + 
			"       (SELECT DISTINCT DDO_OPTION" + 
			"       FROM T_D1D2_OPTIONS a" + 
			"       WHERE DDO_PRODUCT_ID       =NOT_PRODUCT_ID" + 
			"       AND DDO_TYPE              IN ('O')" + 
			"	   AND DDO_PRODUCT_ID  in (SELECT SMP_PRODUCT_ID FROM T_SMART_PRODUCTS" + 
			"									UNION " + 
			"								  SELECT TTP_PRODUCT_ID FROM T_TURBO_TECH_PRODUCTS where TTP_NOTES_FLAG  !='A'	" + 
			"									UNION" + 
			"								  SELECT CES_PRODUCT_ID FROM T_CES_PRODUCTS)" + 
			"       AND DDO_PRINTED_FLAG = 'Y'" + 
			"       )	  	   " + 
			"	  UNION	  " + 
			"     SELECT DISTINCT NOT_DESCRIPTION ," + 
			"       NOT_ITEM_NUMBER," + 
			"       NOT_LINE_NUMBER" + 
			"     FROM T_NOTE a" + 
			"     WHERE NOT_PRODUCT_ID =?1" + 
			"     AND TRIM(NOT_ITEM_NUMBER) IN" + 
			"       ( SELECT DISTINCT DDO_OPTION" + 
			"       FROM T_D1D2_OPTIONS a" + 
			"       WHERE DDO_PRODUCT_ID       =NOT_PRODUCT_ID" + 
			"	   AND DDO_PRODUCT_ID IN  (select TTP_PRODUCT_ID from t_turbo_tech_products where TTP_NOTES_FLAG  ='A')" + 
			"       AND DDO_TYPE              IN ('P')	   " + 
			"       AND DDO_PRINTED_FLAG = 'Y'" + 
			"       )	  	   " + 
			"     )" + 
			"   ORDER BY NOT_LINE_NUMBER";
	// new query for to fix SN-4072
	String NOTES_QUERY_NEW2="SELECT DISTINCT   "
			+ "			    CASE WHEN PRM_OPTION_FLAG = 'Y' THEN (select UPPER(NOMN_DESCRIPTION) from T_OPTION_NOTES_MASTER OPM ,T_NOTES_MASTER_NPID NMN  "
			+ "			                                          where OPM.NOM_PRODUCT_ID=NOT_PRODUCT_ID  "
			+ "			                                          and OPM.NOM_OPTION_ID=SUBSTR(TRIM(NOT_ITEM_NUMBER),1,2)  "
			+ "			                                          and OPM.NOM_LINE_NUMBER=NOT_LINE_NUMBER  "
			+ "			                                          and OPM.NOM_SERIAL_NUMBER=1  "
			+ "			                                          AND OPM.NOM_OPTION_ID=NMN.NOMN_OPTION_ID  "
			+ "			                                          AND OPM.NOM_LINE_NUMBER=NMN.NOMN_LINE_NUMBER  "
			+ "			                                          AND OPM.NOM_SERIAL_NUMBER=NMN.NOMN_SERIAL_NUMBER  "
			+ "			                                          AND OPM.NOM_NOT_ID=NMN.NOMN_NOT_ID  "
			+ "			                                        )   "
			+ "			                                        ELSE   "
			+ "			                                        (select UPPER(NOM_DESCRIPTION) from T_OPTION_NOTES_MASTER OPM   "
			+ "			                                          where OPM.NOM_PRODUCT_ID=NOT_PRODUCT_ID  "
			+ "			                                          and OPM.NOM_OPTION_ID='UN'  "
			+ "			                                          and OPM.NOM_LINE_NUMBER=NOT_LINE_NUMBER  "
			+ "			                                          and OPM.NOM_SERIAL_NUMBER=1  "
			+ "			                                         )  END Description,  "
			+ "			    CASE WHEN PRM_OPTION_FLAG = 'Y' AND NOT_LINE_NUMBER = 1 THEN "
			+ "                                                                      CASE WHEN SUBSTR(TRIM(NOT_ITEM_NUMBER),1,2) IN "
			+ "                                                                      (SELECT DISTINCT OL_OPTION_ID FROM T_OPTION_LAYOUT WHERE "
			+ "                                                                      OL_APPENDIX IS NOT NULL AND OL_LINE_NO = '1')"
			+ "                                                                      THEN NOT_NOTE_VALUE ELSE NULL END"
			+ "			          ELSE TRIM(SUBSTR(NOT_DESCRIPTION,INSTR(NOT_DESCRIPTION,':')+1)) END  NOT_NOTE_VALUE,  "
			+ "			    Trim(Case When Instr(1234567890,Substr(TRIM(NOT_ITEM_NUMBER),5,1),1)>0  "
			+ "			             Then Substr(NOT_ITEM_NUMBER,1,7)  "
			+ "			             Else NOT_ITEM_NUMBER END)  AS DDOption,  "
			+ "			    NOT_LINE_NUMBER  "
			+ "			   FROM T_NOTE NOTE,T_PRODUCT_MASTER PM  "
			+ "			    WHERE  NOTE.NOT_PRODUCT_ID       = ?1   "
			+ "			    AND  "
			+ "			    NOTE.NOT_PRODUCT_ID =PM.PRM_PRODUCT_ID  "
			+ "			    AND EXISTS ( SELECT * FROM T_D1D2_OPTIONS DDO  "
			+ "			                 WHERE DDO.DDO_PRODUCT_ID = NOTE.NOT_PRODUCT_ID  "
			+ "			                 AND DDO.DDO_TYPE             = CASE WHEN (SELECT COUNT(1) FROM t_turbo_tech_products WHERE TTP_PRODUCT_ID =NOTE.NOT_PRODUCT_ID AND  TTP_NOTES_FLAG ='A') > 0 THEN 'P' ELSE 'O' END   "
			+ "			                 AND DDO.DDO_OPTION           =  Trim(Case When Instr(1234567890,Substr(TRIM(NOT_ITEM_NUMBER),5,1),1)>0  "
			+ "			                                                   Then Substr(NOT_ITEM_NUMBER,1,7)  "
			+ "			                                                   Else NOT_ITEM_NUMBER END)  "
			+ "			                AND DDO.DDO_PRINTED_FLAG = 'Y'  "
			+ "			                )  "
			+ "			    ORDER BY NOT_LINE_NUMBER ";
	//1st query
	@Query(value = CALIB_MAIN_QUERY_NEW, nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500000"))
	List<D1D2OptionDto> getOptionDataNew(String productId);

	//2nd query
	@Query(value = NOTES_QUERY_NEW2, nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500000"))
	List<OptionNotesDto> getOptionNotesByProductIdItemListNew(String productId);

	//3rd query
	@Query(value = "SELECT DISTINCT DDO_OPTION||'.'||lpad(A.ITM_REVISION_LEVEL,2,0) Parts" + 
			" FROM T_D1D2_OPTIONS," + 
			"  T_ITEM A" + 
			" WHERE DDO_PRODUCT_ID          = ?1" + 
			" AND DDO_ENG_GROUP    		  = 'Y'" + 
			" AND DDO_PRINTED_FLAG          = 'Y'" + 
			" AND DDO_OPTION                = TRIM(A.ITM_NUMBER)" + 
			" AND DDO_LINK_SUBFILE_CODE    = A.ITM_SUBFILE_CODE" + 
			" AND DDO_LINK_SUBFILE_SUBCODE = A.ITM_SUBFILE_SUB_CODE" + 
			" AND A.ITM_PRODUCT_ID           !='OBS'" + 
			" AND A.ITM_REVISION_LEVEL =" + 
			"  (SELECT MAX(B.ITM_REVISION_LEVEL)" + 
			"  FROM T_ITEM B" + 
			"  WHERE B.ITM_NUMBER = A.ITM_NUMBER" + 
			"  AND B.ITM_STATUS   = 'Y')" + 
			" UNION" + 
			" SELECT DISTINCT TRIM(A.ITM_NUMBER)||'.'||lpad(A.ITM_REVISION_LEVEL,2,0)" + 
			" FROM T_ITEM A ," + 
			"  T_SUBFILE_MASTER B" + 
			" WHERE A.ITM_PRODUCT_ID   = ?1" + 
			" AND A.ITM_EFFECT_CODE  !=40" + 
			" AND A.ITM_STATUS         = 'Y'" + 
			" AND A.ITM_REVISION_LEVEL =" + 
			"  (SELECT MAX(B.ITM_REVISION_LEVEL)" + 
			"  FROM T_ITEM B" + 
			"  WHERE B.ITM_NUMBER = A.ITM_NUMBER" + 
			"  AND B.ITM_STATUS   = 'Y')" + 
			" AND A.ITM_SUBFILE_CODE                        = B.SUM_SUBFILE_CODE" + 
			" AND A.ITM_SUBFILE_SUB_CODE                    = B.SUM_SUBFILE_SUB_CODE" + 
			" AND TRIM(UPPER(B.SUM_REVISION_LEVEL_PREFIX)) != 'X'", nativeQuery = true)
	List<PartsDTO> getPartsByProductId(String productId);
}
