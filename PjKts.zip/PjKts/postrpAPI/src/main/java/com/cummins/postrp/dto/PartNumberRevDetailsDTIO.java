package com.cummins.postrp.dto;

public interface PartNumberRevDetailsDTIO {
  public String getpart_dnld_list();

  public String getpart_file_typ();

  public String getpart_dnld_pth();
  public String getfile_path();
}
