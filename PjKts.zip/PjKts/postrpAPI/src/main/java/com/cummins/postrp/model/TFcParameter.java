package com.cummins.postrp.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_FC_PARAMETER database table.
 * 
 */
@Entity
@Table(name="T_FC_PARAMETER")
@NamedQuery(name="TFcParameter.findAll", query="SELECT t FROM TFcParameter t")
public class TFcParameter implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FCP_FC_OPTION")
	private String fcpFcOption;

	@Column(name="FCP_FPEPS_CODE")
	private String fcpFpepsCode;

	@Temporal(TemporalType.DATE)
	@Column(name="FCP_LAST_UPDATE_DATE")
	private Date fcpLastUpdateDate;

	@Column(name="FCP_LAST_UPDATE_USER")
	private String fcpLastUpdateUser;

	@Column(name="FCP_MAX_BLOW_BY")
	private BigDecimal fcpMaxBlowBy;

	@Column(name="FCP_MAX_RAIL_PRESSURE")
	private BigDecimal fcpMaxRailPressure;

	@Column(name="FCP_MAX_RATED_FUEL_RATE")
	private BigDecimal fcpMaxRatedFuelRate;

	@Column(name="FCP_MAX_RATED_PRESSURE")
	private BigDecimal fcpMaxRatedPressure;

	@Column(name="FCP_MAX_TORQ_FUEL_RATE")
	private BigDecimal fcpMaxTorqFuelRate;

	@Column(name="FCP_MAX_TORQ_PRESSURE")
	private BigDecimal fcpMaxTorqPressure;

	@Column(name="FCP_MIN_RAIL_PRESSURE")
	private BigDecimal fcpMinRailPressure;

	@Column(name="FCP_MIN_RATED_FUEL_RATE")
	private BigDecimal fcpMinRatedFuelRate;

	@Column(name="FCP_MIN_RATED_PRESSURE")
	private BigDecimal fcpMinRatedPressure;

	@Column(name="FCP_MIN_TORQ_FUEL_RATE")
	private BigDecimal fcpMinTorqFuelRate;

	@Column(name="FCP_MIN_TORQ_PRESSURE")
	private BigDecimal fcpMinTorqPressure;

	public TFcParameter() {
	}

	public String getFcpFcOption() {
		return this.fcpFcOption;
	}

	public void setFcpFcOption(String fcpFcOption) {
		this.fcpFcOption = fcpFcOption;
	}

	public String getFcpFpepsCode() {
		return this.fcpFpepsCode;
	}

	public void setFcpFpepsCode(String fcpFpepsCode) {
		this.fcpFpepsCode = fcpFpepsCode;
	}

	public Date getFcpLastUpdateDate() {
		return this.fcpLastUpdateDate;
	}

	public void setFcpLastUpdateDate(Date fcpLastUpdateDate) {
		this.fcpLastUpdateDate = fcpLastUpdateDate;
	}

	public String getFcpLastUpdateUser() {
		return this.fcpLastUpdateUser;
	}

	public void setFcpLastUpdateUser(String fcpLastUpdateUser) {
		this.fcpLastUpdateUser = fcpLastUpdateUser;
	}

	public BigDecimal getFcpMaxBlowBy() {
		return this.fcpMaxBlowBy;
	}

	public void setFcpMaxBlowBy(BigDecimal fcpMaxBlowBy) {
		this.fcpMaxBlowBy = fcpMaxBlowBy;
	}

	public BigDecimal getFcpMaxRailPressure() {
		return this.fcpMaxRailPressure;
	}

	public void setFcpMaxRailPressure(BigDecimal fcpMaxRailPressure) {
		this.fcpMaxRailPressure = fcpMaxRailPressure;
	}

	public BigDecimal getFcpMaxRatedFuelRate() {
		return this.fcpMaxRatedFuelRate;
	}

	public void setFcpMaxRatedFuelRate(BigDecimal fcpMaxRatedFuelRate) {
		this.fcpMaxRatedFuelRate = fcpMaxRatedFuelRate;
	}

	public BigDecimal getFcpMaxRatedPressure() {
		return this.fcpMaxRatedPressure;
	}

	public void setFcpMaxRatedPressure(BigDecimal fcpMaxRatedPressure) {
		this.fcpMaxRatedPressure = fcpMaxRatedPressure;
	}

	public BigDecimal getFcpMaxTorqFuelRate() {
		return this.fcpMaxTorqFuelRate;
	}

	public void setFcpMaxTorqFuelRate(BigDecimal fcpMaxTorqFuelRate) {
		this.fcpMaxTorqFuelRate = fcpMaxTorqFuelRate;
	}

	public BigDecimal getFcpMaxTorqPressure() {
		return this.fcpMaxTorqPressure;
	}

	public void setFcpMaxTorqPressure(BigDecimal fcpMaxTorqPressure) {
		this.fcpMaxTorqPressure = fcpMaxTorqPressure;
	}

	public BigDecimal getFcpMinRailPressure() {
		return this.fcpMinRailPressure;
	}

	public void setFcpMinRailPressure(BigDecimal fcpMinRailPressure) {
		this.fcpMinRailPressure = fcpMinRailPressure;
	}

	public BigDecimal getFcpMinRatedFuelRate() {
		return this.fcpMinRatedFuelRate;
	}

	public void setFcpMinRatedFuelRate(BigDecimal fcpMinRatedFuelRate) {
		this.fcpMinRatedFuelRate = fcpMinRatedFuelRate;
	}

	public BigDecimal getFcpMinRatedPressure() {
		return this.fcpMinRatedPressure;
	}

	public void setFcpMinRatedPressure(BigDecimal fcpMinRatedPressure) {
		this.fcpMinRatedPressure = fcpMinRatedPressure;
	}

	public BigDecimal getFcpMinTorqFuelRate() {
		return this.fcpMinTorqFuelRate;
	}

	public void setFcpMinTorqFuelRate(BigDecimal fcpMinTorqFuelRate) {
		this.fcpMinTorqFuelRate = fcpMinTorqFuelRate;
	}

	public BigDecimal getFcpMinTorqPressure() {
		return this.fcpMinTorqPressure;
	}

	public void setFcpMinTorqPressure(BigDecimal fcpMinTorqPressure) {
		this.fcpMinTorqPressure = fcpMinTorqPressure;
	}

}