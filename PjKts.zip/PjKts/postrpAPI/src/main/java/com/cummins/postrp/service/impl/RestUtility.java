package com.cummins.postrp.service.impl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.file.FileSystemException;
import java.sql.SQLRecoverableException;
import java.util.Collections;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

//import com.cummins.fpeps.exception.AppException;
import com.cummins.postrp.exception.BadRequestException;
import com.cummins.postrp.fpeps.dto.FpepRequestDTO;
import com.cummins.postrp.fpeps.dto.FpepsResponseDTO;
import com.cummins.postrp.fpeps.dto.ResponseToken;

import io.github.resilience4j.retry.annotation.Retry;

@Service
public class RestUtility {

	@Autowired
	RestTemplate restTemplate;

	@Retry(name = "retryExceptions", fallbackMethod = "getFallBack")
	public FpepsResponseDTO getRestResponse(ResponseToken responseToken, FpepRequestDTO requestDTO, String fpepUrl) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Bearer " + responseToken.getAccess_token());
		headers.add("Content-Type", "application/json");
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		System.out.println("Req : " + requestDTO.toString());
		HttpEntity<String> entity = new HttpEntity<>(requestDTO.toString(), headers);
		FpepsResponseDTO responseDTO = restTemplate
				.exchange(fpepUrl, HttpMethod.POST, entity, FpepsResponseDTO.class).getBody();
		System.out.println("responseDTO : " + responseDTO);
		return responseDTO;

	}

	public FpepsResponseDTO getFallBack(Exception e) throws Exception {

		System.out.println("fallback");

		System.out.println(e.getMessage());

	 if (e instanceof SQLRecoverableException || e instanceof ConnectException
				|| e instanceof SocketTimeoutException || e instanceof SocketException
				|| e instanceof PersistenceException) {
			System.out.println("500 exception");
			throw new ConnectException(e.getMessage());
		} else if (e instanceof FileSystemException) {
			System.out.println("file not found file syste, exception");
			throw new FileSystemException(e.getMessage());
		} else if (e instanceof FileNotFoundException || e instanceof BadRequestException) {
			throw new BadRequestException(e.getMessage());
		} else if (e instanceof IOException) {
			throw new BadRequestException(e.getMessage());
		} else {
			System.out.println("other exception");
			System.out.println(e.getMessage());
			throw new BadRequestException(e.getMessage());
		}

	}
}
