package com.cummins.postrp.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.cummins.postrp.dto.CommonParamStore;
import com.cummins.postrp.dto.ParamStore;
import com.cummins.postrp.dto.ResponseDTO;
import com.cummins.postrp.exception.BadRequestException;

@Service
public class DataPlateServiceImpl  {

	@Autowired
	private ParamStore paramStore;
	
	@Autowired
	private CommonParamStore commonPS;

	@Value("${mode}")
	private String mode;

	//private Mode currentMode = new Mode();

	
	public ResponseDTO createCdfxFile(String ecmCode, String productID, String productFilePath)	throws BadRequestException, Exception {
		String mappedPath="";
		if ("regular".equalsIgnoreCase(mode)) {
			mappedPath = commonPS.getRegular().getDrivePath()+paramStore.getMappedPath();
		} else {
			mappedPath = commonPS.getExportControl().getDrivePath()+paramStore.getMappedPathExp();
		}
		ResponseDTO response = new ResponseDTO();
		validateInput(ecmCode, productID, productFilePath);
		String strEcm = Arrays.toString(toAscii(ecmCode));
		String[] ecmHexValueArr = strEcm.substring(1, strEcm.length() - 1).split(", ");
		String strPid = Arrays.toString(toAscii(productID));
		String[] pidHexValueArr = strPid.substring(1, strPid.length() - 1).split(", ");
		try {

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(mappedPath + "\\" + "Template.cdfx"));

			XPathFactory xpathFactory = XPathFactory.newInstance();
			XPath xpath = xpathFactory.newXPath();

			String xpathArraySizeEcm = "//SW-INSTANCE[SHORT-NAME='ConfigurationTracker.caECUCode']/SW-VALUE-CONT/SW-ARRAYSIZE/V";
			XPathExpression exprArrEcm = xpath.compile(xpathArraySizeEcm);
			NodeList nodeListArrEcm = (NodeList) exprArrEcm.evaluate(doc, XPathConstants.NODESET);
			Element vArrElementEcm = (Element) nodeListArrEcm.item(0);
			vArrElementEcm.setTextContent(String.valueOf(ecmHexValueArr.length));

			String xpathExpression = "//SW-INSTANCE[SHORT-NAME='ConfigurationTracker.caECUCode']/SW-VALUE-CONT/SW-VALUES-PHYS/V";

			XPathExpression expr = xpath.compile(xpathExpression);
			NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
			for (int i = 0; i < nodeList.getLength(); i++) {
				Element vElement = (Element) nodeList.item(i);
				String newValue = ecmHexValueArr[i];
				vElement.setTextContent(newValue);
			}

			String xpathArraySizePid = "//SW-INSTANCE[SHORT-NAME='ConfigurationTracker.caProductId']/SW-VALUE-CONT/SW-ARRAYSIZE/V";
			XPathExpression exprArrpid = xpath.compile(xpathArraySizePid);
			NodeList nodeListArrpid = (NodeList) exprArrpid.evaluate(doc, XPathConstants.NODESET);
			Element vArrElement = (Element) nodeListArrpid.item(0);
			vArrElement.setTextContent(String.valueOf(pidHexValueArr.length));

			String xpathExpressionPid = "//SW-INSTANCE[SHORT-NAME='ConfigurationTracker.caProductId']/SW-VALUE-CONT/SW-VALUES-PHYS/V";
			XPathExpression exprpid = xpath.compile(xpathExpressionPid);
			NodeList nodeListpid = (NodeList) exprpid.evaluate(doc, XPathConstants.NODESET);
			for (int i = 0; i < nodeListpid.getLength(); i++) {
				Element vElement = (Element) nodeListpid.item(i);
				String newValue = pidHexValueArr[i];
				vElement.setTextContent(newValue);
			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);

			String fileName = productID+".CDFX";
			System.out.println("DataPlate Path-->"+(productFilePath + "\\" + fileName));
			File writefile=new File(productFilePath + "\\" + fileName);
			try (FileOutputStream output = new FileOutputStream(writefile)) {
				StreamResult result = new StreamResult(output);
				transformer.transform(source, result);
				System.out.println("CDFX file has been modified successfully.");
			} catch (IOException e) {
				System.out.println("IOException 6");
				File f = new File(productFilePath);
				if (!f.exists()) {
					throw new BadRequestException(productFilePath + " path not found");
				}
			}
			
			response.setErrorMessage(null);
			response.setResponse("0");
		} catch (Exception e) {
			response.setErrorMessage(e.getMessage());
			response.setResponse("1");
			System.err.println("Error creating the XML file: " + e.getMessage());
		}
		return response;
	}

	private void validateInput(String ecmCode, String productID, String path) throws BadRequestException {
		//String ECM_CODE_REGEX = "[a-zA-Z0-9]{7}[.][0-9]{2}[.][0-9]{2}$|[a-zA-Z0-9]{6}[.][0-9]{2}[.][0-9]{2}$";
		String pattern = "[a-zA-Z0-9]{7}[.][0-9]{2}$";
		String ecmPattern = "[a-zA-Z0-9]{6}[.][0-9]{2}$";
		String signedEcmPattern = "[a-zA-Z0-9]{7}[.][0-9]{2}[.][0-9]{2}$|[a-zA-Z0-9]{6}[.][0-9]{2}[.][0-9]{2}$"; 
		String ERROR_MESSAGE_ECM_CODE_BLANK = "ECM code should not be null";
		 String ERROR_MESSAGE_PRODUCT_ID_BLANK = "ProductID should not be empty and more then 3 characters";
		 String INNCORRECT_ECM_CODE = "Incorrect ECM code";
		if (productID == null || productID.isEmpty() || productID.length() != 3) {
			throw new BadRequestException(ERROR_MESSAGE_PRODUCT_ID_BLANK);
		} else if (path == null || (path.equals(""))) {
			throw new BadRequestException("FilePath Cannot be blank");
		} else if (ecmCode == null || ecmCode.isEmpty()) {
			throw new BadRequestException(ERROR_MESSAGE_ECM_CODE_BLANK);
		} else if (!ecmCode.trim().matches(pattern) && !ecmCode.trim().matches(ecmPattern)
				&& !ecmCode.trim().matches(signedEcmPattern)) {
			throw new BadRequestException(INNCORRECT_ECM_CODE);
		}
	}

	public int[] toAscii(String arg) {
		byte[] bytes = arg.getBytes(StandardCharsets.US_ASCII);
		int[] asciiValues = new int[bytes.length];
		for (int i = 0; i < bytes.length; i++) {
			asciiValues[i] = (int) bytes[i];
		}
		return asciiValues;
	}
}
