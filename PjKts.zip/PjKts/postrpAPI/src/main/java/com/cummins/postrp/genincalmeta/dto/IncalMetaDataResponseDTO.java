package com.cummins.postrp.genincalmeta.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
@Data
public class IncalMetaDataResponseDTO {
	@JsonProperty("success")
	  private boolean success;
	  @JsonProperty("code")
	  private Integer code;
	  @JsonProperty("message")
	  private String message;
}
