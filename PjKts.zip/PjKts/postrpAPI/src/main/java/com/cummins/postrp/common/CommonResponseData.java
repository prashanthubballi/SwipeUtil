package com.cummins.postrp.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CommonResponseData implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("response")
	private String response;

	@JsonProperty("errorMessage")
	private String errorMessage;

	public CommonResponseData() {
		super();
	}

	public CommonResponseData(String response, String errorMessage) {
		super();
		this.response = response;
		this.errorMessage = errorMessage;
	}

}
