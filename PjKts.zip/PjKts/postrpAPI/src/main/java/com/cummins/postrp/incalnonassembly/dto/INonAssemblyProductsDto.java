package com.cummins.postrp.incalnonassembly.dto;

public interface INonAssemblyProductsDto {

	String getproductId();

	String getitemNumber();

	String getrpCode();

	String getefCode();

	String getpath();
}
