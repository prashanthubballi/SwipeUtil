package com.cummins.postrp.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class TSubfileCrcMapTableKey implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "SRC_PROD_ID")
	private String srcProductId;

	@Column(name = "SRC_FLAG")
	private String srcFlag;

	@Column(name = "SRC_ASSEMBLER")
	private String srcAssembler;

	@Column(name = "SRC_ETR_PREFIX")
	private String srcETRPrefix;

	@Column(name = "SRC_ASSEMBLY_DEC")
	private String srcAssembly;

	@Column(name = "SRC_A_FILE_PART")
	private String srcAFilePart;

}
