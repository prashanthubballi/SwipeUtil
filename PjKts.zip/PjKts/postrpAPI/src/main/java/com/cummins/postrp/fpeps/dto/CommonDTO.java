package com.cummins.postrp.fpeps.dto;

import lombok.Data;

@Data
public class CommonDTO {

  private String targetSystem;

  @Override
  public String toString() {
    return "{\"targetSystem\" : \"" + targetSystem + "\"}";
  }

}
