package com.cummins.postrp.dto;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "maxRetryAttempts",
    "waitDuration",
    "retryExceptions"
})
@Data
public class Retry {

    @JsonProperty("maxRetryAttempts")
    private Integer maxRetryAttempts;
    @JsonProperty("waitDuration")
    private String waitDuration;
    @JsonProperty("retryExceptions")
    private List<String> retryExceptions = new ArrayList<String>();
}
