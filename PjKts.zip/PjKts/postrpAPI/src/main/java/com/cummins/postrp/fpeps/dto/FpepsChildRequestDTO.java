package com.cummins.postrp.fpeps.dto;

import java.util.List;

import lombok.Data;

@Data
public class FpepsChildRequestDTO {
	
	public String guid;
	List<String> fcCodeList;
	

}
