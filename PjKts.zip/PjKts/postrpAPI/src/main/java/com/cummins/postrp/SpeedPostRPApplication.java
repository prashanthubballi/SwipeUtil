package com.cummins.postrp;

import java.net.URISyntaxException;
import java.time.Duration;
import java.util.List;

import javax.annotation.PostConstruct;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cummins.postrp.dto.CommonParamStore;
import com.cummins.postrp.dto.CommonParamStore.Mode;
import com.cummins.postrp.dto.ParamStore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.github.resilience4j.common.retry.configuration.RetryConfigCustomizer;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;

@SpringBootApplication
@EntityScan(basePackageClasses = {SpeedPostRPApplication.class, Jsr310JpaConverters.class})
@ComponentScan("com.cummins.postrp")
public class SpeedPostRPApplication extends SpringBootServletInitializer{

	@Value("${param.value}")	
	private String paramValue;

	@Value("${mode}")	
	private String mode;
	
	@Autowired
	private RetryRegistry registry;

	private ParamStore paramStore = new ParamStore();
	private CommonParamStore commonParamStore = new CommonParamStore();
	private static final Logger logger = LoggerFactory.getLogger(SpeedPostRPApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(SpeedPostRPApplication.class, args);
	}
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(SpeedPostRPApplication.class);
	}

	@Bean
	public RestTemplate getRest() {
		return new RestTemplate();
	}


	@Bean(name = "retryConfig")
	public RetryConfigCustomizer getCentralizedData(@Value("${spring.common}") String commonValue)
			throws URISyntaxException, RestClientException, JSONException, JsonProcessingException {
		Class<?>[] classes = null;
		try {
			ObjectMapper objectMapper=new ObjectMapper();
			logger.info("CommonParamStore:"+commonValue);
			this.paramStore = objectMapper.readValue(paramValue, ParamStore.class);
			logger.info("Parameter store "+paramStore);
			this.commonParamStore=objectMapper.readValue(commonValue, CommonParamStore.class);
			Mode psMode=null;
			if("regular".equalsIgnoreCase(mode)) {
				psMode=commonParamStore.getRegular();
			}else {
				psMode=commonParamStore.getExportControl();
			}
			
			paramStore.setOutBoundSycUrl(psMode.getHostName()+paramStore.getOutBoundSycUrl());
			List<String> exptnclses = paramStore.getResilience4j().getRetry().getRetryExceptions();
			classes = new Class<?>[exptnclses.size()];
			for (int i = 0; i < exptnclses.size(); i++) {
				classes[i] = Class.forName(exptnclses.get(i));
			}
		} catch (RestClientException | JsonProcessingException | ClassNotFoundException e) {
			logger.error("Exception:while mapping paramstore values," + e.getMessage());
		}
		final Class<?>[] exptnclasses = classes;
		return RetryConfigCustomizer.of("retryExceptions", builder -> builder
				.maxAttempts(paramStore.getResilience4j().getRetry().getMaxRetryAttempts())
				.waitDuration(Duration.ofSeconds(
						Integer.parseInt(paramStore.getResilience4j().getRetry().getWaitDuration().replace("s", ""))))
				.retryExceptions(exptnclasses));
	}
	@Bean
	@DependsOn("retryConfig")
	public ParamStore getParam() {
		return paramStore;
	}
	@Bean
	@DependsOn("retryConfig")
	public CommonParamStore getCommonParam() {
		return commonParamStore;
	}
	@Bean
	public Retry retryBean() {
		return registry.retry("throwingException");
	}

	@PostConstruct
	public void postConstruct() {
		retryBean().getEventPublisher().onRetry(ev -> logger.info("RetryRegistryEventListener: {}", ev));
	}
}
