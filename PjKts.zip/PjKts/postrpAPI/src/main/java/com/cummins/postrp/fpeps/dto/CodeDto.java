package com.cummins.postrp.fpeps.dto;

import lombok.Data;

@Data
public class CodeDto {

  private String fcCode;
  private String fpepsCode;
  @Override
  public String toString() {
    return "{\"fcCode\" : \"" + fcCode + "\",\"fpepsCode\" : \"" + fpepsCode + "\"}";
  }
  
}
