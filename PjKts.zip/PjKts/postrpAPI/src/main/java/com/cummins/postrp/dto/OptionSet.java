package com.cummins.postrp.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;
import java.util.List;
import java.util.Set;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class OptionSet implements Serializable {
  private static final long serialVersionUID = 1L;

  Set<String> configuration;
  List<Options> options;
  String assembly;
}
