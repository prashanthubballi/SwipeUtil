package com.cummins.postrp.fpeps.dto;

import java.util.List;
import lombok.Data;

@Data
public class FpepsResponseDTO {
  private Header header;
  private List<DetailsDTO> data;
}
