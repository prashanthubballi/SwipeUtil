package com.cummins.postrp.common;

public interface Constants {

	public static String GENERIC_SUCCESS_MESSAGE = "Success";
	public static String GENERIC_FAILURE_MESSAGE = "Error";
  
}
