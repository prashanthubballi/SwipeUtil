package com.cummins.postrp.dto;

import java.io.Serializable;
import java.util.List;
import lombok.Data;

@Data
public class DownloadOptionPartResponse implements Serializable {
  private static final long serialVersionUID = 1L;

  public String folder;
  public String productId;
  public String productType;
  public List<String> odx_f;
  public List<String> cbf;
  public List<String> hex;
  public List<String> cdfx;
  public List<String> dominion;
  public List<String> commonFiles;
  public List<String> copyFailedFiles;
  public String errorMessage;
}
