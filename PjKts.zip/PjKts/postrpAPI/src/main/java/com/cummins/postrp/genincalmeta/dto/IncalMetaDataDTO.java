package com.cummins.postrp.genincalmeta.dto;


public interface IncalMetaDataDTO {

	public String getProductID();
	public String getEcmCode();
	public String getVersion();
	public String getFileName();
}
