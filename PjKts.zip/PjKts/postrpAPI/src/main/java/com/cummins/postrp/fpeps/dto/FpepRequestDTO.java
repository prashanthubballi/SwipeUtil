package com.cummins.postrp.fpeps.dto;

import java.util.List;
import lombok.Data;

@Data
public class FpepRequestDTO {

  private ChangeDetailsDTO changeDetails;
  private List<CodeDto> data;
  @Override
  public String toString() {
    return "{\"changeDetails\" : " + changeDetails.toString()+ ",\"data\" : " + data.toString() + "}";
  }
   

}
