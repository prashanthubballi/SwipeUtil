package com.cummins.postrp.repository;
import java.util.List;
import java.util.stream.Stream;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import com.cummins.postrp.genincalmeta.dto.IncalMetaDataDTO;
import com.cummins.postrp.model.TIncalHistory;

@Repository
public interface TIncalRepository extends JpaRepository<TIncalHistory,String> {

	@Query(value="select INCAL_PRD_ID as productID,INCAL_ECM_CODE as ecmCode,INCAL_ECM_VERSION as version,INCAL_ECM_FILE_NAME as fileName "
			+ "from T_INCAL_HISTORY where INCAL_PRD_ID in (?1) order by PRODUCTID , ECMCODE asc ",nativeQuery=true)
	 @QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500000"))
	Stream<IncalMetaDataDTO> getIncalData1(List<String> PIDs);
	
	@Query(value="select distinct(prm_product_id) from t_product_master where  prm_compliance_grp not in 'Export Control' order by prm_product_id asc",nativeQuery=true)
	List<String> getRegularProducts();
}
