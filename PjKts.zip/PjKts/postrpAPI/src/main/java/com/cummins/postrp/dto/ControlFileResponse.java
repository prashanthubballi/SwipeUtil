package com.cummins.postrp.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.io.Serializable;
import java.util.Map;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
@JsonPropertyOrder({"Response"})
public class ControlFileResponse implements Serializable {
	private static final long serialVersionUID = 1L;
	@JsonProperty("childCorrelationGuid")
	private String childCorrelationGuid;
	
	@JsonProperty("productId")
	private String productId;
	
	@JsonProperty("Response")
	private Map<String,String> response;

}
