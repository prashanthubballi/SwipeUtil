package com.cummins.postrp.genincalmeta.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CalibrationList {
	public String productID;
	public String ecmCode;
	public String fileName;
	public String version;
}
