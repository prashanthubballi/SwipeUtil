package com.cummins.postrp.fpeps.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class serviceNowRequestGenerationDTO {
  private String description;
  private String short_description;
  private String impact;
  private String urgency;
  private String assignment_group;
  @Override
  public String toString() {
    return "{description : " + description + ",short_description : " + short_description + ",impact : " + impact + ",urgency : " + urgency + ",assignment_group : "
      + assignment_group + "}";
  }
  
  
}
