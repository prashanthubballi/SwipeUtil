package com.cummins.postrp.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystemException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.DosFileAttributes;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.TransactionException;
import org.hibernate.exception.JDBCConnectionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cummins.postrp.dto.CommonParamStore;
import com.cummins.postrp.dto.CopyDTO;
import com.cummins.postrp.dto.ParamStore;
import com.cummins.postrp.exception.BadRequestException;
import com.cummins.postrp.incalhistory.dto.ECMCodeDetailsDTO;
import com.cummins.postrp.incalhistory.dto.InCalHistoryRequestDTO;
import com.cummins.postrp.repository.TInCalHistoryRepository;

import io.github.resilience4j.retry.annotation.Retry;

@Service
public class SpeedInCalHistoryServiceImpl {
	private Logger logger = LogManager.getLogger(SpeedInCalHistoryServiceImpl.class);
	@Autowired
	private RestTemplate restTemplate;

	@PersistenceContext
	private EntityManager em;

	@Autowired
	private ParamStore paramStore;
	
	@Value("${mode}")
	String mode;
	
	@Autowired
	private CommonParamStore commonPS;
	
	@Autowired
	private TInCalHistoryRepository inCalHistoryRepository;
	
	private static String drivePath = "";

	@Retry(name = "throwingException", fallbackMethod = "getFallBack")
	public void copyToInCalHistory(InCalHistoryRequestDTO inCalHistory)
			throws BadRequestException, FileNotFoundException, SQLException, FileSystemException {
		
		if("regular".equalsIgnoreCase(mode)) {
			drivePath=commonPS.getRegular().getDrivePath();
		}else {
			drivePath=commonPS.getExportControl().getDrivePath();
		}

		System.out.println("Incl Started");
		try {
			isNetworkDriveAccessible(drivePath);
		} catch (FileSystemException e) {
			throw new FileSystemException(e.getMessage());
		}
		InCalHistoryUtility.blankValidation(inCalHistory);

		String calibrationFile = inCalHistory.getCalibrationFile();
		String pattern = paramStore.getPattern();
		String ecmPattern = paramStore.getEcmPattern();
		String signedEcmPattern = paramStore.getSignedEcmPattern();
		String ecmCode = null;
		String calVersion = null;
		String fileDesrcriptor = null;
		String buildId = null;
		String buildName = null;
		String keyIndex = null;

		if (calibrationFile.matches(pattern)) {
			ecmCode = calibrationFile;
			keyIndex = null;
		} else if (calibrationFile.matches(ecmPattern)) {
			ecmCode = " " + calibrationFile;
			keyIndex = null;
		} else if (calibrationFile.matches(signedEcmPattern)) {
			ecmCode = (calibrationFile.length() == 12) ? " " + calibrationFile.substring(0, 9)
					: calibrationFile.substring(0, 10);
			keyIndex = (calibrationFile.length() == 12) ? calibrationFile.substring(10) : calibrationFile.substring(11);
		} else if (FilenameUtils.getExtension(calibrationFile).equalsIgnoreCase("pdx")) {
			ecmCode = FilenameUtils.getBaseName(calibrationFile);
			if (ecmCode.matches(signedEcmPattern)) {
				ecmCode = (FilenameUtils.getBaseName(calibrationFile).length() == 12)
						? FilenameUtils.getBaseName(calibrationFile).substring(0, 9)
						: FilenameUtils.getBaseName(calibrationFile).substring(0, 10);
				keyIndex = (FilenameUtils.getBaseName(calibrationFile).length() == 12)
						? FilenameUtils.getBaseName(calibrationFile).substring(10)
						: FilenameUtils.getBaseName(calibrationFile).substring(11);
			}
		} else {
			throw new BadRequestException("Incorrect ECM code");
		}
		if (inCalHistory.getFlag().equalsIgnoreCase("FA")|| inCalHistory.getFlag().equalsIgnoreCase("IC")) {
			copyFilesToCalibrationFolder(inCalHistory, ecmCode.trim());
		}
		if (inCalHistory.getMode().equalsIgnoreCase("CORE")) {
			processCalibrationDetails(inCalHistory, calVersion, fileDesrcriptor, buildId, buildName, ecmCode, keyIndex);
		} else if (inCalHistory.getMode().equalsIgnoreCase("CSAR") || inCalHistory.getMode().equalsIgnoreCase("DOM")) {
			processCalibrationDetailsForCSRDOMType(inCalHistory, ecmCode, keyIndex, calVersion);
		} else {
			throw new BadRequestException("Incorrect MODE");
		}

	}

	private void processCalibrationDetails(InCalHistoryRequestDTO inCalHistory, String calVersion,
			String fileDesrcriptor, String buildId, String buildName, String ecmCode, String keyIndex)
			throws BadRequestException, FileNotFoundException, SQLException {
		String calibrationFolder =drivePath+ paramStore.getCalibrationFolder();

		String inCalHistoryFileName = null;

		String[] last = inCalHistory.getCalibrationFilePath().split("\\\\");
		String prodFolderName = last[last.length - 1];
		String[] productList = prodFolderName.split("_");
		String product = productList[0];
		String fileName = (inCalHistory.getKeyIndex() != null && inCalHistory.getKeyIndex().size() > 0
				&& inCalHistory.getKeyIndex().contains(29))
						? calibrationFolder + "\\" + product + "\\" + inCalHistory.getCalibrationFile().trim() + "."
								+ "29"
						: inCalHistory.getKeyIndex().size() == 0
								? calibrationFolder + "\\" + product + "\\" + inCalHistory.getCalibrationFile().trim()
								: null;
		if (fileName != null) {
			try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
				String line = reader.readLine();
				while (line != null) {
					if (line.contains("<calibration_version>")) {
						String[] data = line.split("<calibration_version>");
						calVersion = data[1].split("</calibration_version>")[0];
					}
					if (line.contains("<file_descriptor>")) {
						int start = line.indexOf("<file_descriptor>") + "<file_descriptor>".length();
						int end = line.indexOf("</file_descriptor>");
						fileDesrcriptor = line.substring(start, end);

						line = reader.readLine();
						break;
					}
					if (line.startsWith("CalibrationVersion=")) {
						calVersion = line.substring("CalibrationVersion=".length());
					}
					if (line.startsWith("FileDescriptor=")) {
						fileDesrcriptor = line.substring("FileDescriptor=".length());
						break;
					} else {
						line = reader.readLine();
					}
				}
			} catch (FileNotFoundException e) {
				throw new FileNotFoundException("File path not found");
			} catch (Exception e) {
				throw new BadRequestException(e.getMessage());
			}
		} else {
			throw new BadRequestException("29 KeyIndex Not there");
		}
		if (fileDesrcriptor != null) {
			if (fileDesrcriptor.contains("Build ID")) {
				buildId = fileDesrcriptor.substring(fileDesrcriptor.indexOf("Build ID -") + "Build ID - ".length());
				buildName = fileDesrcriptor.substring(
						fileDesrcriptor.indexOf("Confidential -") + "Confidential -".length(),
						fileDesrcriptor.indexOf("- Build ID -"));
			} else if (fileDesrcriptor.contains("Cummins Confidential -")) {
				buildName = fileDesrcriptor
						.substring(fileDesrcriptor.indexOf("Confidential -") + "Confidential -".length());
			} else {
				buildName = fileDesrcriptor.split(",")[0];
			}
		}
		storeCalibrationDetails(inCalHistory, calVersion, fileDesrcriptor, buildId, buildName, inCalHistoryFileName,
				ecmCode, keyIndex);
	}

	@Transactional
	private void storeCalibrationDetails(InCalHistoryRequestDTO inCalHistory, String calVersion, String fileDesrcriptor,
			String buildId, String buildName, String inCalHistoryFileName, String ecmCode, String keyIndex)
			throws BadRequestException, SQLException {
		try {//vw596 check bwloe line
			String calibrationFolder =null; //paramStore.getcalibrationFolder;

			List<ECMCodeDetailsDTO> calibrationECMDetailList = inCalHistoryRepository.getCalDetails(ecmCode);
			if (calibrationECMDetailList != null && calibrationECMDetailList.size() > 0
					&& !calibrationECMDetailList.isEmpty()) {

				ECMCodeDetailsDTO calibrationECMDetails = calibrationECMDetailList.get(0);
				String prodId = calibrationECMDetails.getEcmProductID();
				String releasePhaseCode = calibrationECMDetails.getEcmReleasePhaseCode();
				LocalDate date = LocalDate.now(ZoneId.systemDefault());
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				String startTime = date.format(formatter);
				System.out.println("startTime:" + startTime);
				String lastUpdateUser = inCalHistoryRepository.getUserFromDB();
				if (keyIndex == null) {
					if (null != calVersion) {
						inCalHistoryFileName = ecmCode + "_" + prodId + "_" + calVersion + ".cal";
					} else {
						inCalHistoryFileName = ecmCode + ".cal";
					}
				} else {

					if (null != calVersion) {
						inCalHistoryFileName = ecmCode + "." + keyIndex + "_" + prodId + "_" + calVersion + ".cal";
					} else {
						inCalHistoryFileName = ecmCode + ".cal";
					}
				}
				if (fileDesrcriptor != null) {
					processTCalBuilDetails(calVersion, fileDesrcriptor, buildId, buildName, inCalHistoryFileName,
							ecmCode, prodId, releasePhaseCode, startTime, lastUpdateUser);
				}
				if (inCalHistory.getFlag().equalsIgnoreCase("FA")) {
					processTCVNDetails(inCalHistory, ecmCode, prodId, startTime);
				}
				if (inCalHistory.getKeyIndex() != null && inCalHistory.getKeyIndex().size() > 0) {
					inCalHistoryRepository.deleteTCalibrationWithIndex(ecmCode, inCalHistory.getKeyIndex());
					for (Integer calKeyIndex : inCalHistory.getKeyIndex()) {
						String fileName = calKeyIndex == null ? "\\" + ecmCode : "\\" + ecmCode + "." + calKeyIndex;

						if (null != calVersion) {
							inCalHistoryFileName = ecmCode + "." + calKeyIndex + "_" + prodId + "_" + calVersion
									+ ".cal";
						} else {
							inCalHistoryFileName = ecmCode + ".cal";
						}

						processTCalibrationDelete(inCalHistoryFileName, ecmCode, calKeyIndex.toString(), prodId,
								startTime, lastUpdateUser, calVersion, calibrationFolder + prodId + fileName);
						callStoredProcedureINCAL(ecmCode, inCalHistory, inCalHistoryFileName, calKeyIndex.toString(),
								calibrationECMDetails.getEcmReleasePhaseCode(), calVersion);
					}
				} else {
					inCalHistoryRepository.deleteTCalibration(ecmCode);
					processTCalibrationDelete(inCalHistoryFileName, ecmCode, null, prodId, startTime, lastUpdateUser,
							calVersion, calibrationFolder + prodId + "\\" + inCalHistory.getCalibrationFile());
					callStoredProcedureINCAL(ecmCode, inCalHistory, inCalHistoryFileName, null,
							calibrationECMDetails.getEcmReleasePhaseCode(), calVersion);
				}

			} else {
				throw new BadRequestException("ECM Code details not found in table");
			}
		} catch (PersistenceException | SQLException e) {
			throw new SQLException(e.getMessage());
		} catch (DataIntegrityViolationException e) {
			throw new BadRequestException("ECM Code already exists in DataBase");
		} catch (Exception e) {
			if (e.getCause() instanceof JDBCConnectionException) {
				throw new SQLException(e.getMessage());
			} else if (e.getCause() instanceof TransactionException) {
				System.out.println("TransactionException");
				throw new SQLException(e.getMessage());
			} else {
				throw new BadRequestException(e.getMessage());
			}
		}
	}

	/**
	 * @param inCalHistoryFileName
	 * @param ecmCode
	 * @param keyIndex
	 * @param prodId
	 * @param startTime
	 * @param lastUpdateUser
	 * @param incalPath
	 * @param calVersion
	 * @throws NumberFormatException
	 */
	private void processTCalibrationDelete(String inCalHistoryFileName, String ecmCode, String keyIndex, String prodId,
			String startTime, String lastUpdateUser, String calVersion, String incalIntPath)
			throws NumberFormatException, SQLException {
		try {
			inCalHistoryRepository.saveTCalibration(ecmCode, prodId, "Y", ecmCode, lastUpdateUser, startTime, keyIndex,
					calVersion, null);
		} catch (PersistenceException e) {
			throw new SQLException("Unable to connect to DB");
		} catch (Exception e) {
			if (e.getCause() instanceof JDBCConnectionException) {
				throw new SQLException(e.getMessage());
			} else if (e.getCause() instanceof TransactionException) {
				System.out.println("TransactionException");
				throw new SQLException(e.getMessage());
			} else {
				throw new BadRequestException(e.getMessage());
			}
		}
	}

	/**
	 * @param inCalHistory
	 * @param ecmCode
	 * @param prodId
	 * @param startTime
	 * @throws NumberFormatException
	 */
	private void processTCVNDetails(InCalHistoryRequestDTO inCalHistory, String ecmCode, String prodId,
			String startTime) throws NumberFormatException, SQLException {
		try {
			String count = inCalHistoryRepository.findTCVNDetails(ecmCode);
			if (Integer.valueOf(count) > 0) {
				inCalHistoryRepository.updateTCVNDetails(ecmCode, inCalHistory.getCVN(), prodId, startTime);
			} else {
				inCalHistoryRepository.saveTCVNDetails(ecmCode, inCalHistory.getCVN(), prodId, startTime);
			}
		} catch (PersistenceException e) {
			throw new SQLException("Unable to connect to DB");
		} catch (Exception e) {
			if (e.getCause() instanceof JDBCConnectionException) {
				throw new SQLException(e.getMessage());
			} else if (e.getCause() instanceof TransactionException) {
				System.out.println("TransactionException");
				throw new SQLException(e.getMessage());
			} else {
				throw new BadRequestException(e.getMessage());
			}
		}
	}

	/**
	 * @param calVersion
	 * @param fileDesrcriptor
	 * @param buildId
	 * @param buildName
	 * @param inCalHistoryFileName
	 * @param ecmCode
	 * @param prodId
	 * @param releasePhaseCode
	 * @param startTime
	 * @param lastUpdateUser
	 * @throws NumberFormatException
	 */
	private void processTCalBuilDetails(String calVersion, String fileDesrcriptor, String buildId, String buildName,
			String inCalHistoryFileName, String ecmCode, String prodId, String releasePhaseCode, String startTime,
			String lastUpdateUser) throws NumberFormatException, SQLException {
		try {
			String count = inCalHistoryRepository.findTCalBuildDetails(ecmCode);
			if (Integer.valueOf(count) > 0) {
				inCalHistoryRepository.updateTCalBuildDetails(ecmCode, fileDesrcriptor, buildId, buildName, prodId,
						releasePhaseCode, startTime, startTime, lastUpdateUser);
			} else {
				inCalHistoryRepository.saveTCalBuildDetails(ecmCode, fileDesrcriptor, buildId, buildName, prodId,
						releasePhaseCode, startTime, startTime, lastUpdateUser);
			}
		} catch (PersistenceException e) {
			throw new SQLException("Unable to connect to DB");
		} catch (Exception e) {
			if (e.getCause() instanceof JDBCConnectionException) {
				throw new SQLException(e.getMessage());
			} else if (e.getCause() instanceof TransactionException) {
				System.out.println("TransactionException");
				throw new SQLException(e.getMessage());
			} else {
				throw new BadRequestException(e.getMessage());
			}
		}
	}

	@Transactional
	private void processCalibrationDetailsForCSRDOMType(InCalHistoryRequestDTO inCalHistory, String ecmCode,
			String keyIndex, String calVersion) throws SQLException {
		try {
			String calibrationFolder = drivePath+paramStore.getCalibrationFolder();

			String inCalHistoryFileName = inCalHistory.getCalibrationFile();
			List<ECMCodeDetailsDTO> calibrationECMDetailList = inCalHistoryRepository.getCalDetails(ecmCode);
			if (calibrationECMDetailList != null && calibrationECMDetailList.size() > 0
					&& !calibrationECMDetailList.isEmpty()) {
				for (ECMCodeDetailsDTO calibrationECMDetails : calibrationECMDetailList) {
					String prodId = calibrationECMDetails.getEcmProductID();
					String startTime = new SimpleDateFormat("dd-MM-YY").format(new java.util.Date());
					String lastUpdateUser = inCalHistoryRepository.getUserFromDB();

					String stringFromList = inCalHistory.getMode().equalsIgnoreCase("CSAR") ? String.join(",",
							inCalHistory.getKeyIndex().stream().map(x -> x.toString()).collect(Collectors.toList()))
							: null;

					inCalHistoryRepository.deleteTCalibration(ecmCode);
					processTCalibrationDelete(inCalHistoryFileName, ecmCode, stringFromList, prodId, startTime,
							lastUpdateUser, calVersion, calibrationFolder + prodId + "\\" + inCalHistoryFileName);

					keyIndex = inCalHistory.getMode().equalsIgnoreCase("CSAR") && keyIndex == null ? stringFromList
							: keyIndex;
					callStoredProcedureINCAL(ecmCode, inCalHistory, inCalHistoryFileName, keyIndex,
							calibrationECMDetails.getEcmReleasePhaseCode(), calVersion);

				}
			} else {
				throw new BadRequestException("ECM Code not active");
			}
		} catch (PersistenceException e) {
			throw new SQLException("Unable to connect to DB");
		} catch (SQLException e) {
			throw new SQLException(e.getMessage());
		} catch (DataIntegrityViolationException e) {
			throw new BadRequestException("ECM Code already exists in DataBase");
		} catch (Exception e) {
			if (e.getCause() instanceof JDBCConnectionException) {
				throw new SQLException(e.getMessage());
			} else if (e.getCause() instanceof TransactionException) {
				System.out.println("TransactionException");
				throw new SQLException(e.getMessage());
			} else {
				throw new BadRequestException(e.getMessage());
			}
		}
	}

	private void callStoredProcedureINCAL(String ecmCode, InCalHistoryRequestDTO inCalHistory,
			String inCalHistoryFileName, String calKeyIndex, String ecmReleasePhaseCode, String calVersion)
			throws SQLException {
		try {
			String storeProc = "PKG_CONTROL_FILE_GENERATION.SP_DIST_GRP_CHECK";
			StoredProcedureQuery storedProcedure = em.createStoredProcedureQuery(storeProc);

			storedProcedure.registerStoredProcedureParameter("g_ecm", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("g_dis_grp", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("p_parent_prg_id", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("p_request_id", Integer.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("g_dis_ser_flag", String.class, ParameterMode.OUT);
			storedProcedure.registerStoredProcedureParameter("g_dis_mfg_flag", String.class, ParameterMode.OUT);
			storedProcedure.registerStoredProcedureParameter("g_dis_eng_flag", String.class, ParameterMode.OUT);
			storedProcedure.registerStoredProcedureParameter("g_dis_coe_flag", String.class, ParameterMode.OUT);
			storedProcedure.registerStoredProcedureParameter("g_return_flag", String.class, ParameterMode.OUT);

			storedProcedure.setParameter("g_ecm", ecmCode);
			storedProcedure.setParameter("g_dis_grp", "ServiceDistributionRule");
			storedProcedure.setParameter("p_parent_prg_id", null);
			storedProcedure.setParameter("p_parent_prg_id", null);
			System.out.println("ecmCode : " + ecmCode);
			storedProcedure.execute();

			String temp = storedProcedure.getOutputParameterValue("g_dis_ser_flag").toString();
			System.out.println("StoredProcedure Result: " + temp);

			if (temp.equalsIgnoreCase("Y")) {
				if (!inCalHistory.getMode().equalsIgnoreCase("CSAR")) {
					copyFileToInCalFolder(inCalHistory, inCalHistoryFileName, calKeyIndex, ecmReleasePhaseCode, ecmCode,
							calVersion);
				} else {
					String[] last = inCalHistory.getCalibrationFilePath().split("\\\\");
					String product = last[last.length - 1].split("_")[0];
//					if (calKeyIndex == null || calKeyIndex.isEmpty()) {
//						inCalHistoryRepository.deleteTIncalHistoryIfNull(product, ecmCode, ecmReleasePhaseCode, calVersion, inCalHistoryFileName.trim());
//					} else {
//						if("CSAR".equalsIgnoreCase(inCalHistory.getMode())) {
//							inCalHistoryRepository.deleteTIncalHistoryForCSAR(product, ecmCode, ecmReleasePhaseCode,  calVersion, inCalHistoryFileName.trim());
//						}else {
//							inCalHistoryRepository.deleteTIncalHistory(product, ecmCode, ecmReleasePhaseCode, calKeyIndex, calVersion, inCalHistoryFileName.trim());
//						}
//						//inCalHistoryRepository.deleteTIncalHistory(product, ecmCode, ecmReleasePhaseCode, calKeyIndex, calVersion, inCalHistoryFileName.trim());
//					}
					inCalHistoryRepository.deleteFrom_INCAL_HISTORY(product, ecmCode, inCalHistoryFileName.trim());
					inCalHistoryRepository.insertIntoT_INCAL_HISTORY(product, ecmCode, ecmReleasePhaseCode, calKeyIndex,
							calVersion, inCalHistoryFileName.trim());
				}
			}
		} catch (Exception e) {
			// Extract SQLException from the caught exception
			SQLException sqlException = extractSqlException(e);
			if (sqlException != null) {
				// Handle SQLException
				logger.info("SQL State: " + sqlException.getSQLState());
				logger.info("Error Code: " + sqlException.getErrorCode());
				logger.info("Message: " + sqlException.getMessage());
				if (sqlException.getMessage().contains("Connection is not available") || sqlException.getMessage()
						.contains("The Network Adapter could not establish the connection")) {
					throw new SQLException(sqlException.getMessage());
				}
				throw new BadRequestException(sqlException.getMessage());
			} else {
				// Handle other types of exceptions
				logger.info("Caught exception: " + e.getMessage());
				throw new BadRequestException(e.getMessage());
			}
		}
	}

	private static SQLException extractSqlException(Throwable throwable) {
		if (throwable == null) {
			return null;
		} else if (throwable instanceof SQLException) {
			return (SQLException) throwable;
		} else {
			// Check nested exceptions
			return extractSqlException(throwable.getCause());
		}
	}

	private void copyFileToInCalFolder(InCalHistoryRequestDTO inCalHistory, String inCalHistoryFileName,
			String calKeyIndex, String ecmReleasePhaseCode, String ecmCode, String calVersion)
			throws BadRequestException, SQLException {
		try {
			String incalFolder = drivePath+ paramStore.getIncalFolder();
			String calibrationFolder =drivePath+  paramStore.getCalibrationFolder();

			String[] last = inCalHistory.getCalibrationFilePath().split("\\\\");
			String prodFolderName = last[last.length - 1];
			String[] productList = prodFolderName.split("_");
			String product = productList[0];
			String fileName = "";

			fileName = calKeyIndex == null
					? calibrationFolder + "\\" + product + "\\" + inCalHistory.getCalibrationFile().trim()
					: inCalHistory.getMode().equalsIgnoreCase("CSAR")
							? calibrationFolder + "\\" + product + "\\" + inCalHistoryFileName
							: calibrationFolder + "\\" + product + "\\" + inCalHistory.getCalibrationFile().trim() + "."
									+ calKeyIndex;

			File source = new File(fileName);
			if (!source.exists()) {
				throw new BadRequestException(source.getAbsolutePath() + ", file path not found.");
			}
			String destFile = incalFolder + "\\" + product + "\\" + inCalHistoryFileName.trim();
			File dest = new File(destFile);
			File destFolder = new File(incalFolder + "\\" + product);
			if (!destFolder.exists()) {
				destFolder.mkdir();
			}
			boolean is29FileExist = false;
			if (dest.exists() && dest.getName().contains(".29_")) {
				is29FileExist = true;
			}
			// if file is .29 index file and is already exist means it wont copy rest all
			// files are copied.
			if (!is29FileExist) {
				Files.copy(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
				Date currentDate = new Date();
				long timestamp = currentDate.getTime();
				dest.setLastModified(timestamp);
			}
			reverseSyncCopy(paramStore.getOutBoundSycUrl(),
					new CopyDTO(destFile.replace("G:\\", "").replace("\\\\", "\\"), false));

//					if (calKeyIndex == null || calKeyIndex.isEmpty()) {
//						inCalHistoryRepository.deleteTIncalHistoryIfNull(product, ecmCode, ecmReleasePhaseCode, calVersion, inCalHistoryFileName.trim());
//					} else {
//						if("CSAR".equalsIgnoreCase(inCalHistory.getMode())) {
//							inCalHistoryRepository.deleteTIncalHistoryForCSAR(product, ecmCode, ecmReleasePhaseCode,  calVersion, inCalHistoryFileName.trim());
//						}else {
//							inCalHistoryRepository.deleteTIncalHistory(product, ecmCode, ecmReleasePhaseCode, calKeyIndex, calVersion, inCalHistoryFileName.trim());
//						}
//					}
			inCalHistoryRepository.deleteFrom_INCAL_HISTORY(product, ecmCode, inCalHistoryFileName.trim());
			inCalHistoryRepository.insertIntoT_INCAL_HISTORY(product, ecmCode, ecmReleasePhaseCode, calKeyIndex,
					calVersion, inCalHistoryFileName.trim());
		} catch (PersistenceException e) {
			throw new SQLException("Unable to connect to DB");
		} catch (Exception e) {
			if (e.getCause() instanceof JDBCConnectionException) {
				throw new SQLException(e.getMessage());
			} else if (e.getCause() instanceof TransactionException) {
				System.out.println("TransactionException");
				throw new SQLException(e.getMessage());
			} else {
				throw new BadRequestException(e.getMessage());
			}
		}
	}

	private void copyFilesToCalibrationFolder(InCalHistoryRequestDTO inCalHistory, String ecmCode) {
		try {
			if (inCalHistory.getMode().equalsIgnoreCase("CORE")) {
				if (inCalHistory.getKeyIndex() != null && inCalHistory.getKeyIndex().size() > 0) {
					for (Integer calKeyIndex : inCalHistory.getKeyIndex()) {
						copyFileToCalibration(inCalHistory, ecmCode, calKeyIndex.toString());
					}
				} else {
					copyFileToCalibration(inCalHistory, ecmCode, null);
				}
			} else if (inCalHistory.getMode().equalsIgnoreCase("DOM")
					|| inCalHistory.getMode().equalsIgnoreCase("CSAR")) {
				copyFileToCalibration(inCalHistory, ecmCode, null);
			}
		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
	}

	private void copyFileToCalibration(InCalHistoryRequestDTO inCalHistory, String ecmCode, String calKeyIndex) {
		String calibrationFolder =drivePath+ paramStore.getCalibrationFolder();

		try {
			String fileName = "";
			if (inCalHistory.getMode().equalsIgnoreCase("CSAR")) {
				fileName = "\\" + ecmCode + ".pdx";
			} else {
				fileName = calKeyIndex == null ? "\\" + ecmCode
						: inCalHistory.getMode().equalsIgnoreCase("CORE") ? "\\" + ecmCode + "." + calKeyIndex
								: "\\" + ecmCode + "." + calKeyIndex + "." + "pdx";
			}
			File source = new File(inCalHistory.getCalibrationFilePath() + fileName);
			if (!source.exists()) {
				throw new BadRequestException(fileName + ", file path not found.");
			}
			String[] last = inCalHistory.getCalibrationFilePath().split("\\\\");
			String prodFolderName = last[last.length - 1];
			String[] productList = prodFolderName.split("_");
			String product = productList[0];
			String destFile = calibrationFolder + "\\" + product + "\\" + fileName;
			File dest = new File(destFile);
			File destFolder = new File(calibrationFolder + "\\" + product);
			if (!destFolder.exists()) {
				destFolder.mkdir();
			}
			boolean is29FileExist = false;
			if (dest.exists() && dest.getName().endsWith(".29")) {
				is29FileExist = true;
			}
			// if file is .29 index file and is already exist means it wont copy rest all
			// files are copied.
			if (!is29FileExist) {
				Files.copy(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
				Date currentDate = new Date();
				long timestamp = currentDate.getTime();
				dest.setLastModified(timestamp);
			}
			reverseSyncCopy(paramStore.getOutBoundSycUrl(),
					new CopyDTO(destFile.replace("G:\\", "").replace("\\\\", "\\"), false));

		} catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
	}

	public void getFallBack(Exception e) throws FileSystemException, SQLException {
		handleExeptions(e);
	}

	/**
	 * handleExeptions
	 * 
	 * @param Exception
	 * @throws FileSystemException
	 * @throws SQLException
	 */
	private void handleExeptions(Exception e) throws FileSystemException, SQLException {
		System.out.println("inside fall");
		if (e instanceof FileSystemException) {
			throw new FileSystemException(e.getMessage());
		} else if (e instanceof SQLException) {
			throw new SQLException(e.getMessage());
		} else if (e instanceof FileNotFoundException || e instanceof BadRequestException) {
			throw new BadRequestException(e.getMessage());
		} else {
			throw new BadRequestException(e.getMessage());
		}
	}

	public static boolean isNetworkDriveAccessible(String drivePath) throws FileSystemException {
		boolean isAccessible = false;
		Path drive = FileSystems.getDefault().getPath(drivePath);
		DosFileAttributes attrs;
		try {
			attrs = Files.readAttributes(drive, DosFileAttributes.class);
			if (attrs.isDirectory()) {
				isAccessible = true;
			}
		} catch (IOException e) {
			throw new FileSystemException("Network Drive not found");
		}
		return isAccessible;
	}

	private void reverseSyncCopy(String url, CopyDTO req) {
		try {
			System.out.println("Reverse Sync Started.");
			ResponseEntity<String> response = restTemplate.postForEntity(url, req, String.class);
			System.out.println(response.getBody());
		} catch (Exception e) {
			System.out.println("Exception in reverse sync:" + e.getMessage());
		}

	}
}
