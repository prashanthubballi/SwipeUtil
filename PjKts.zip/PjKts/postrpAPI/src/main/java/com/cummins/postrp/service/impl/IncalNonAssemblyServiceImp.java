package com.cummins.postrp.service.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cummins.postrp.incalnonassembly.dto.CommonResponse;
import com.cummins.postrp.common.CommonResponseHeader;
import com.cummins.postrp.dto.CommonParamStore;
import com.cummins.postrp.dto.CopyDTO;
import com.cummins.postrp.dto.ParamStore;
import com.cummins.postrp.incalnonassembly.dto.CommonResponseData;
import com.cummins.postrp.incalnonassembly.dto.CountAndData;
import com.cummins.postrp.incalnonassembly.dto.InCalHistoryNonAssemblyRequestDTO;
import com.cummins.postrp.incalnonassembly.dto.Rule;
import com.cummins.postrp.incalnonassembly.dto.RuleSet;
import com.cummins.postrp.repository.INonAssemblyRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class IncalNonAssemblyServiceImp  {

	@Value("${mode}")
	private String mode;

	@Autowired
	private ParamStore paramStore;
	
	@Autowired
	private CommonParamStore commonPS;

	
	@Autowired
	private INonAssemblyRepository repo;

	RestTemplate restTemplate = new RestTemplate();

	AtomicInteger success_count = new AtomicInteger(0);
	AtomicInteger failure_count = new AtomicInteger(0);
	
	private static String drivePath="";

	public IncalNonAssemblyServiceImp(INonAssemblyRepository repo) {
		super();
		this.repo = repo;
	}

	public CommonResponse<CommonResponseData> processIncalForNonAssemblyProducts(InCalHistoryNonAssemblyRequestDTO nonassemblyProducts) {

		if("regular".equalsIgnoreCase(mode)) {
			drivePath=commonPS.getRegular().getDrivePath();
		}else {
			drivePath=commonPS.getExportControl().getDrivePath();
		}
		
		success_count.set(0);
		failure_count.set(0);
		List<String> successlist = new ArrayList<>();
		List<String> failurelist = new ArrayList<>();
		Map<String, List<String>> response = getBreRuleValues(nonassemblyProducts);
		if (response != null) {
			if (response.get("success_count") != null) {
				successlist.addAll(response.get("success_count"));
			}
			if (response.get("fail_count") != null) {
				failurelist.addAll(response.get("fail_count"));
			}
			return new CommonResponse<CommonResponseData>(new CommonResponseHeader(true, 200, null),
					new CommonResponseData(new CountAndData(failure_count.get(), failurelist),
							new CountAndData(success_count.get(), successlist)));
		} else {
			return new CommonResponse<CommonResponseData>(new CommonResponseHeader(false, 400, "No data in DB"),
					new CommonResponseData());
		}
	}

	/**
	 * @param nonassemblyProducts
	 */
	private Map<String, List<String>> getBreRuleValues(InCalHistoryNonAssemblyRequestDTO nonassemblyProducts) {
		Map<String, List<String>> response = new HashMap<String, List<String>>();
		try {
			String ServiceDistributionRule = repo.getDistributionRuleSetByName("ServiceDistributionRule");
			ObjectMapper mapper = new ObjectMapper();
			RuleSet sdRuleSet = mapper.readValue(ServiceDistributionRule, RuleSet.class);
			List<String> rpCodeList = extractRule(sdRuleSet, "ReleasePhaseCode");
			List<String> effectCodeList = extractRule(sdRuleSet, "EffectCode");
			if (nonassemblyProducts != null) {
				if (rpCodeList.contains(nonassemblyProducts.getRpCode())
						&& effectCodeList.contains(nonassemblyProducts.getEfCode())) {
					try {
						response.putAll(processNonAssembly(nonassemblyProducts, response));
					} catch (Exception e) {
						response.putAll(setFaliureResponse(nonassemblyProducts, response));
					}
				}
			} else {
				return null;
			}
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return response;
	}

	/**
	 * @param sdRuleSet
	 * @return
	 */
	private List<String> extractRule(RuleSet sdRuleSet, String code) {
		return sdRuleSet.getRules().parallelStream().filter(x -> x.getField().equalsIgnoreCase(code))
				.map(Rule::getValue).collect(Collectors.toList());
	}

	private Map<String, List<String>> setFaliureResponse(InCalHistoryNonAssemblyRequestDTO x,
			Map<String, List<String>> response) {
		List<String> failurelist = new ArrayList<>();
		if (response.get("fail_count") != null) {
			if (!response.get("fail_count").contains(x.getProductId() + ":" + x.getItemNumber())) {
				failure_count.incrementAndGet();
				response.get("fail_count").add(x.getProductId() + ":" + x.getItemNumber());
			}
		} else {
			failure_count.incrementAndGet();
			failurelist.add(x.getProductId() + ":" + x.getItemNumber());
			response.put("fail_count", failurelist);
		}
		return response;
	}

	private Map<String, List<String>> setSuccessResponse(InCalHistoryNonAssemblyRequestDTO x,
			Map<String, List<String>> response) {
		List<String> passlist = new ArrayList<>();
		if (response.get("success_count") != null) {
			if (!response.get("success_count").contains(x.getProductId() + ":" + x.getItemNumber())) {
				success_count.incrementAndGet();
				response.get("success_count").add(x.getProductId() + ":" + x.getItemNumber());
			}
		} else {
			success_count.incrementAndGet();
			passlist.add(x.getProductId() + ":" + x.getItemNumber());
			response.put("success_count", passlist);
		}
		return response;
	}

	private Map<String, List<String>> processNonAssembly(InCalHistoryNonAssemblyRequestDTO x,
			Map<String, List<String>> responses) throws SQLException {
		Map<String, List<String>> response = responses;
		response.putAll(copyToIncal(x, response));
		return response;
	}

	private Map<String, List<String>> copyToIncal(InCalHistoryNonAssemblyRequestDTO x,
			Map<String, List<String>> response) throws SQLException {
		
		Map<String, List<String>> responses = new HashMap<String, List<String>>();
		String filePath = x.getPath();
		String fileTo =drivePath+ paramStore.getIncalFolder() + x.getProductId() + "\\\\" + x.getItemNumber();
		File source = new File(filePath);
		if (!source.exists()) {
			responses.putAll(setFaliureResponse(x, response));
		}
		File dest = new File(fileTo);
		File destFolder = new File(drivePath+ paramStore.getIncalFolder() + x.getProductId());
		if (!destFolder.exists()) {
			destFolder.mkdir();
		}
		try {
			Files.copy(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
			reverseSyncCopy(paramStore.getOutBoundSycUrl(),
					new CopyDTO(fileTo.replace("G:\\", "").replace("\\\\", "\\"), false));
			Date currentDate = new Date();
			long timestamp = currentDate.getTime();
			dest.setLastModified(timestamp);
			responses.putAll(setSuccessResponse(x, response));
			updateDetailsInDb(x);
		} catch (IOException e) {
			responses.putAll(setFaliureResponse(x, response));
		}
		return responses;

	}

	private void updateDetailsInDb(InCalHistoryNonAssemblyRequestDTO x) throws SQLException {
		try {
			if (repo.findIncalHistory(x.getProductId(), x.getItemNumber()) > 0) {
				repo.updateTInCalHistory(x.getProductId(), x.getItemNumber(), x.getRpCode(), x.getItemNumber(), null);
			} else {
				repo.saveTInCalHistory(x.getProductId(), x.getItemNumber(), x.getRpCode(), x.getItemNumber(), null);
			}
		} catch (Exception e) {

		}
	}

	private void reverseSyncCopy(String url, CopyDTO req) {
		try {
			System.out.println("Reverse Sync Started.");
			ResponseEntity<String> response = restTemplate.postForEntity(url, req, String.class);
			System.out.println(response.getBody());
			// restTemplate.getForEntity(url+"/"+path, String.class);
		} catch (Exception e) {
			System.out.println("Exception in reverse sync:" + e.getMessage());
		}

	}
}
