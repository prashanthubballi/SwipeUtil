package com.cummins.postrp.model;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "t_cal_build_details")
@NamedQuery(name = "TCalBuildDetails.findAll", query = "SELECT t FROM TCalBuildDetails t")
public class TCalBuildDetails implements Serializable {
  private static final long serialVersionUID = 1L;

  @EmbeddedId
  TCalBuildKey T_Cal_build;
}
