package com.cummins.postrp.dto;

public interface PartsDTO{
	 String getPID();
	 
//	 String getItemNumber();

	  String getParts();

	  String getItemSubfileType();
	  
	  String getItemEXTPath();
}
