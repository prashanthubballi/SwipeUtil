package com.cummins.postrp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cummins.postrp.model.TFcParameter;

public interface ITFcParameterRepository extends JpaRepository<TFcParameter, String> {

}
