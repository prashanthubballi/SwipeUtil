package com.cummins.postrp.genincalmeta.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class IncalDataDTO {

	private List<CalibrationList> calibrationList = new ArrayList<CalibrationList>();

}
