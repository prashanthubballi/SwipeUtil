package com.cummins.postrp.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cummins.postrp.dto.ParamStore;
import com.cummins.postrp.fpeps.dto.ApiResponse;
import com.cummins.postrp.fpeps.dto.ChangeDetailsDTO;
import com.cummins.postrp.fpeps.dto.CodeDto;
import com.cummins.postrp.fpeps.dto.CommonDTO;
import com.cummins.postrp.fpeps.dto.DetailsDTO;
import com.cummins.postrp.fpeps.dto.FpepRequestDTO;
import com.cummins.postrp.fpeps.dto.FpepsResponseDTO;
import com.cummins.postrp.fpeps.dto.ResponseToken;
import com.cummins.postrp.model.TFcParameter;
import com.cummins.postrp.repository.ITFcParameterRepository;
import com.cummins.postrp.service.ITFcParameterService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Service
public class TFcParameterServiceImpl implements ITFcParameterService {

	@Autowired
	private RestUtility restUtility;

	@Autowired
	private RestTemplate restTemplate;

	

	@Autowired
	private ParamStore paramStore;

	

	private static final Logger logger = LogManager.getLogger(TFcParameterServiceImpl.class);

	private final ITFcParameterRepository tFcParameterRepository;

	public TFcParameterServiceImpl(ITFcParameterRepository tfFcParameterRepository) {
		super();
		this.tFcParameterRepository = tfFcParameterRepository;
	}

	public ApiResponse fpepsIntegration(List<String> fcCodeList, String guid) throws Exception {

		FpepRequestDTO requestDTO = generateFpepRequestDTO(fcCodeList);
		ResponseToken responseToken = sendFpepAuthRequest(paramStore);
		FpepsResponseDTO fpepResponse = sendFpepsRequest(responseToken, requestDTO, paramStore.getFpepsURL());
		System.out.println("Response : " + fpepResponse.toString());
		return updatedFpepsData(fpepResponse, requestDTO, guid);
	}

	private ApiResponse updatedFpepsData(FpepsResponseDTO responseDTO, FpepRequestDTO requestDTO, String guid)
			throws JsonMappingException, JsonProcessingException {
		List<CodeDto> fcCodeNotAvailableList = new ArrayList<>();
		List<String> fcCodeAvailableList = new ArrayList<>();
		DetailsDTO detailsDTO = null;
		if (responseDTO.getHeader() != null && responseDTO.getData() != null) {
			if (responseDTO.getHeader().getSuccess().equalsIgnoreCase("true") && responseDTO.getData() != null
					&& responseDTO.getData().size() > 0) {
				List<TFcParameter> list = new ArrayList<>();
				List<TFcParameter> checkinDB = new ArrayList<>();
				TFcParameter obj = null;
				for (CodeDto fcCode : requestDTO.getData()) {
					Optional<DetailsDTO> optionalDetailsDTO = responseDTO.getData().stream()
							.filter(dto -> dto.getFcCode().trim().equalsIgnoreCase(fcCode.getFcCode().trim()))
							.findFirst();

					if (optionalDetailsDTO.isPresent()) {
						detailsDTO = optionalDetailsDTO.get();
						fcCodeAvailableList.add(detailsDTO.getFcCode());
						obj = new TFcParameter();
						obj.setFcpFcOption(detailsDTO.getFcCode());
						obj.setFcpFpepsCode(detailsDTO.getFpepsCode());
						obj.setFcpMaxBlowBy(detailsDTO.getMaxBlowByMax().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMaxBlowByMax()));
						obj.setFcpMaxRailPressure(detailsDTO.getMaxRailPressure().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMaxRailPressure()));
						obj.setFcpMaxRatedFuelRate(detailsDTO.getMaxRatedFuelRate().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMaxRatedFuelRate()));
						obj.setFcpMaxRatedPressure(detailsDTO.getMaxRatedPressure().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMaxRatedPressure()));
						obj.setFcpMaxTorqFuelRate(detailsDTO.getMaxTorqdFuelRate().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMaxTorqdFuelRate()));
						obj.setFcpMaxTorqPressure(detailsDTO.getMaxTorqPressure().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMaxTorqPressure()));
						obj.setFcpMinRailPressure(detailsDTO.getMinRailPressure().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMinRailPressure()));
						obj.setFcpMinRatedFuelRate(detailsDTO.getMinRatedFuelRate().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMinRatedFuelRate()));
						obj.setFcpMinRatedPressure(detailsDTO.getMinRatedPressure().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMinRatedPressure()));
						obj.setFcpMinTorqFuelRate(detailsDTO.getMinTorqFuelRate().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMinTorqFuelRate()));
						obj.setFcpMinTorqPressure(detailsDTO.getMinTorqPressure().isBlank() ? new BigDecimal(0)
								: new BigDecimal(detailsDTO.getMinTorqPressure()));
						obj.setFcpLastUpdateDate(new Date());
						obj.setFcpLastUpdateUser("SPEEDADMIN");
						list.add(obj);
					} else {
						fcCodeNotAvailableList.add(fcCode);
					}
				}

				checkinDB = tFcParameterRepository.findAllById(fcCodeAvailableList);
				//				System.out.println("checkinDB:" + checkinDB);
				tFcParameterRepository.deleteAll(checkinDB);
				tFcParameterRepository.saveAll(list);
				if (fcCodeNotAvailableList.size() > 0) {
					return new ApiResponse(true,
							"Partially successfull for : "
									+ fcCodeAvailableList.stream().collect(Collectors.joining(", "))
									+ " and UnSuccessfull for : " + fcCodeNotAvailableList.toString());
				}
				return new ApiResponse(true, "Fpeps Data added successfully for : " + fcCodeAvailableList.toString());
			} else {
				for (CodeDto fcCode : requestDTO.getData()) {
					fcCodeNotAvailableList.add(fcCode);
				}
				return new ApiResponse(false, "Received Null Data from Fpeps");
			}
		} else {
			logger.debug("Null response received for the provided request");
			return new ApiResponse(false, "Received Null Data from Fpeps");
		}
	}

	

	private FpepsResponseDTO sendFpepsRequest(ResponseToken responseToken, FpepRequestDTO requestDTO, String fpepUrl) {
		return restUtility.getRestResponse(responseToken, requestDTO, fpepUrl);
	}

	private ResponseToken sendFpepAuthRequest(ParamStore paramStoreData) throws IOException {

		JSONObject requestJson = new JSONObject();
		requestJson.put("client_id", paramStoreData.getClientId()); // paramStoreData.get("clientId").toString());
		requestJson.put("client_secret", paramStoreData.getClient_secret());
		requestJson.put("resource", paramStoreData.getResource());
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		logger.info("Req : " + requestJson.toString());
		HttpEntity<String> entity = new HttpEntity<>(requestJson.toString(), headers);
		ResponseToken responseDTO = restTemplate
				.exchange(paramStoreData.getAuthUrl().toString(), HttpMethod.POST, entity, ResponseToken.class)
				.getBody();
		logger.debug("ResponseDTO : " + responseDTO);

		return responseDTO;

	}

	private FpepRequestDTO generateFpepRequestDTO(List<String> fcCodeList) {
		FpepRequestDTO fpepRequestDTO = new FpepRequestDTO();
		ChangeDetailsDTO changeDetailsDTO = new ChangeDetailsDTO();
		CommonDTO commonDTO = new CommonDTO();
		commonDTO.setTargetSystem("SPEED_FPEPS");
		changeDetailsDTO.setCommon(commonDTO);
		fpepRequestDTO.setChangeDetails(changeDetailsDTO);
		List<CodeDto> codeDtoList = new ArrayList<>();
		CodeDto codeDto = null;
		if (fcCodeList != null && fcCodeList.size() > 0) {
			for (String fcCode : fcCodeList) {
				// fcCode = fcCode.trim();
				codeDto = new CodeDto();
				logger.debug("Actual FC Option :  " + fcCode);
				codeDto.setFcCode(fcCode);
				codeDto.setFpepsCode(generateFpepFuleCode(fcCode));
				codeDtoList.add(codeDto);
			}

		}
		fpepRequestDTO.setData(codeDtoList);
		return fpepRequestDTO;
	}

	private static String generateFpepFuleCode(String fcpFcOption) {
		logger.debug("Position 3 :" + fcpFcOption.charAt(2));
		logger.debug("Position 4 :" + fcpFcOption.charAt(3));
		fcpFcOption = fcpFcOption.trim();
		boolean isCharThreeNumber = Character.isDigit(fcpFcOption.charAt(2));
		boolean isCharFourNumber = Character.isDigit(fcpFcOption.charAt(3));
		String returnVal = "";
		if (isCharThreeNumber && isCharFourNumber) {
			logger.debug("Position 3 and Position4 are Numbers");
			returnVal = fcpFcOption.substring(3, 7);
		} else if (!isCharThreeNumber && isCharFourNumber) {
			logger.debug("Position 3 is Alphabet and Position4 is Number");
			returnVal = fcpFcOption.charAt(2) + fcpFcOption.substring(4, 7);
		} else if (!isCharThreeNumber && !isCharFourNumber) {
			logger.debug("Position 3  and Position4 are Alphabets");

			String finalStr = Character.toString(fcpFcOption.charAt(2)) + Character.toString(fcpFcOption.charAt(3))
			+ Character.toString(fcpFcOption.charAt(5)) + Character.toString(fcpFcOption.charAt(6));
			returnVal = finalStr;
		} else if (isCharThreeNumber && !isCharFourNumber) {
			logger.debug("Position 3 is Number and Position 4 is Alphabet");
			returnVal = fcpFcOption.substring(3, 7);
		}
		logger.debug("Final Result : " + returnVal);
		return returnVal;

	}

}
