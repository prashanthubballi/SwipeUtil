
package com.cummins.postrp.incalnonassembly.dto;

import java.io.Serializable;

import com.cummins.postrp.common.CommonResponseHeader;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"header", "pagination", "data"})
public class CommonResponse<T> implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  @JsonProperty("header")
  private CommonResponseHeader header;

  @JsonProperty("data")
  private CommonResponseData data;

  public CommonResponse() {
    super();
  }

  public CommonResponse(CommonResponseHeader header, CommonResponseData data) {
    super();
    this.header = header;
    this.data = data;
  }

  public CommonResponse(CommonResponseHeader header) {
    super();
    this.header = header;
  }

  public CommonResponseHeader getHeader() {
    return header;
  }

  public void setHeader(CommonResponseHeader header) {
    this.header = header;
  }

  public CommonResponseData getData() {
    return data;
  }

  public void setData(CommonResponseData data) {
    this.data = data;
  }

  @Override
  public String toString() {
    return "CommonResponse [header=" + header + ", data=" + data + "]";
  }
}
