package com.cummins.postrp.service;

import java.io.IOException;
import java.util.List;

import com.cummins.postrp.fpeps.dto.ApiResponse;

public interface ITFcParameterService {

  ApiResponse fpepsIntegration(List<String> fcCodeList , String guid) throws IOException, Exception;
}
