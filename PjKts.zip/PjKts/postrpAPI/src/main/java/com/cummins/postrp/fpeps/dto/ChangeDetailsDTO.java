package com.cummins.postrp.fpeps.dto;

import lombok.Data;

@Data
public class ChangeDetailsDTO {

  private CommonDTO common;

  @Override
  public String toString() {
    return "{\"common\" : " + common.toString() + "}";
  }
  
  
}
