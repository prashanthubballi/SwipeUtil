package com.cummins.postrp.service.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.services.s3.AmazonS3;
import com.cummins.postrp.config.AmazonS3Config;
import com.cummins.postrp.dto.CommonParamStore;
import com.cummins.postrp.dto.ParamStore;
import com.cummins.postrp.genincalmeta.dto.CalibrationList;
import com.cummins.postrp.genincalmeta.dto.IncalDataDTO;
import com.cummins.postrp.genincalmeta.dto.IncalMetaDataDTO;
import com.cummins.postrp.repository.TIncalRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class IncalMetaDataServiceImpl {
	
	@Autowired
	private ParamStore paramStore;
	
	@Autowired
	private CommonParamStore commonPS;

	@Autowired
	private TIncalRepository tIncalRepo;
	
	@Autowired
	private AmazonS3Config amazonS3Config;

	private final Logger logger = LoggerFactory.getLogger(IncalMetaDataServiceImpl.class);
	
	
	@Transactional(readOnly = true)
	public List<CalibrationList> getInCalMetaData(List<String> regularProducts){
		List<CalibrationList> calLists=null;
		logger.info("Fetching IncalData");
		try(Stream<IncalMetaDataDTO> incalData = tIncalRepo.getIncalData1(regularProducts);) {			
			
			calLists=incalData.map(data -> new CalibrationList(data.getProductID(), data.getEcmCode(), data.getFileName(), data.getVersion())).collect(Collectors.toList());
			logger.info("Data fetched from DB");
			return calLists;
		}
		
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
	
	public List<String> getRegularProducts(){
		try {
			logger.info("Fetching Products");
			return tIncalRepo.getRegularProducts();
		}
		catch(Exception e) {
			return null;
		}
		
	}
	
	public String uploadToS3(IncalDataDTO obj) throws IOException {
		String fileName = paramStore.getIncalMetaDataFileName();
		String fileObjKeyName = paramStore.getIncalMetaDataFilePath()+fileName;
		//vw596 check code here.
		String folderPath =(commonPS.getRegular().getDrivePath()+fileObjKeyName).replace("/", "\\");
		String localPath = (commonPS.getRegular().getDrivePath()+fileObjKeyName).replace("/", "\\");
		Path localFile = new File(localPath).toPath();
		try {
			if (!Files.exists(Paths.get(folderPath))) {
				Files.createDirectories(Paths.get(folderPath));
			}
			Files.write(localFile, new ObjectMapper().writeValueAsBytes(obj));// ..writeString(localFile, obj.toString());
			logger.info("File created in Drive");
			AmazonS3 s3 = amazonS3Config.configAmazonS3();
			//vw596 check bucket name here.
			s3.putObject(commonPS.getRegular().getS3Bucket(), fileObjKeyName, new File(localPath));
			logger.info("File uploaded to S3");
			return "Success";
		}
		catch(Exception e ) {
			e.printStackTrace();
			return e.getMessage();
		}
	}
}
