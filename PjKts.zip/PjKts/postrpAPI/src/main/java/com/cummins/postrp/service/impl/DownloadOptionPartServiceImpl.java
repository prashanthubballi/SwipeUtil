package com.cummins.postrp.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystemException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.DosFileAttributes;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.exception.JDBCConnectionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.cummins.downloadoptionpart.service.util.DownloadOptionPartConstants;
import com.cummins.postrp.dto.DownloadOptionPartRequest;
import com.cummins.postrp.dto.DownloadOptionPartResponse;
import com.cummins.postrp.dto.ParamStore;
import com.cummins.postrp.dto.PartNumberRevDetailsDTIO;
import com.cummins.postrp.exception.BadRequestException;
import com.cummins.postrp.repository.DownloadOptionPartRepository;

import io.github.resilience4j.retry.annotation.Retry;

//import io.github.resilience4j.retry.annotation.Retry;

@Service
public class DownloadOptionPartServiceImpl  {

	@Autowired
	private ParamStore paramStore;

	@Autowired
	private DownloadOptionPartRepository headerProcessingRepository;

	 @Retry(name = "retryExceptions", fallbackMethod = "getFallBack")
	public DownloadOptionPartResponse copyFiles(DownloadOptionPartRequest request) throws BadRequestException,
			FileSystemException, FileNotFoundException, SQLException, JDBCConnectionException {

		DownloadOptionPartResponse response = new DownloadOptionPartResponse();

		String guidFolder = request.getGuidFolder();
		String type = request.getAssemblyType();
		String pid = request.getProductID();
		String option1 = request.getPrimaryOption();
		String option2 = request.getSecondaryOption();
		String date = request.getEnggReleaseDate();
		String itemType = request.getItemType();

		

		

		if (guidFolder == null || type == null || pid == null || option1 == null || option2 == null || date == null
				|| itemType == null || guidFolder.isEmpty() || type.isEmpty() || pid.isEmpty() || option1.isEmpty()
				|| option2.isEmpty() || date.isEmpty() || itemType.isEmpty()) {
			throw new BadRequestException("One or more input parameter values are missing.");
		} else {

			try {
				int lastIndex = guidFolder.lastIndexOf("\\");
				String drivepath = guidFolder.substring(0, lastIndex);
				isNetworkDriveAccessible(drivepath);
			} catch (FileSystemException e) {
				System.out.println("3");
				throw new FileSystemException(e.getMessage());
			} catch (Exception e) {
				throw new BadRequestException(e.getMessage());
			}

			try {
				guidFolder += "\\";

				List<String> odxfFiles = new ArrayList<>();
				List<String> hexFiles = new ArrayList<>();
				List<String> cbfFiles = new ArrayList<>();
				List<String> cdfxFiles = new ArrayList<>();
				List<String> dominionFiles = new ArrayList<>();
				List<String> commonFiles = new ArrayList<>();
				List<String> copyFailedFiles = new ArrayList<>();

				System.out.println("guidFolder: " + guidFolder);
				System.out.println("assemblyType: " + type);
				System.out.println("producId: " + pid);
				System.out.println("option1: " + option1);
				System.out.println("option2: " + option2);
				System.out.println("enggReleaseDate: " + date);
				System.out.println("itemType: " + itemType);

				Integer headerCount = 0;

				List<PartNumberRevDetailsDTIO> partNumberDetails;

				if (type.equalsIgnoreCase("C") || type.equalsIgnoreCase("A")) {
					// COREII and COREI aka CCASSEMBLER
					try {
						partNumberDetails = headerProcessingRepository.findDetails1(type, date, option1, option2,
								itemType, pid); // call the query
					} catch (Exception e) {
						if (e.getCause() instanceof JDBCConnectionException) {
							throw new SQLException(e.getMessage());
						} else {
							throw new BadRequestException(e.getMessage());
						}
					}
					System.out.println("=====LIST===== : " + partNumberDetails);

					if (partNumberDetails == null || partNumberDetails.size() == 0) {
						throw new BadRequestException("Parts are not available in SPEED for the provided Options.");
					} else {
						for (PartNumberRevDetailsDTIO i : partNumberDetails) {
							String fileName;
							String outputFileName;
							fileName = i.getpart_dnld_list().trim();
							String filePath = i.getfile_path();
							if (i.getpart_file_typ().equalsIgnoreCase("H")) {
								headerCount = 1;
								outputFileName = i.getpart_dnld_list().trim().split("\\.")[0] + ".hdr";
							} else {
								outputFileName = fileName;
							}
							System.out.println(
									"====data==== : " + i.getpart_dnld_list() + "  ,  " + i.getpart_file_typ());
							Boolean copySuccess = copyIndividualFile(filePath, guidFolder, outputFileName);
							if (copySuccess) {
								commonFiles.add(fileName);
							} else {
								copyFailedFiles.add(fileName);
							}
						}
						if (headerCount == 0) {
							String outputFileName = "default.hdr";
							//vw596 check below
							String sourcePathForHeaderFile = paramStore.getHeaderFileSource() + "\\" + pid	+ "\\hdr.dat";
							Boolean copySuccess = copyIndividualFile(sourcePathForHeaderFile, guidFolder,
									outputFileName);
							if (copySuccess) {
								commonFiles.add(outputFileName);
							}
							// if there is no file is found, skip this process. no need to throw error. so
							// else part is removed.
						}
					}
				} else if (type.equalsIgnoreCase("O")) {
					// CSAR
					try {
						partNumberDetails = headerProcessingRepository.findDetails1(type, date, option1, option2,
								itemType, pid); // call the query
					} catch (Exception e) {
						if (e.getCause() instanceof JDBCConnectionException) {
							throw new SQLException(e.getMessage());
						} else {
							throw new BadRequestException(e.getMessage());
						}
					}
					System.out.println("=====LIST===== : " + partNumberDetails);

					if (partNumberDetails == null || partNumberDetails.size() == 0) {
						throw new BadRequestException("Parts are not available in SPEED for the provided Options.");
					} else {
						for (PartNumberRevDetailsDTIO i : partNumberDetails) {
							String filePath = i.getfile_path();
							String outputFileName = i.getpart_dnld_list().trim();
							String extension = i.getpart_dnld_list().trim()
									.substring(i.getpart_dnld_list().trim().lastIndexOf(".") + 1);
							System.out.println(
									"====data==== : " + i.getpart_dnld_list() + "  ,  " + i.getpart_file_typ());
							Boolean copySuccess = copyIndividualFile(filePath, guidFolder, outputFileName);
							if (copySuccess) {
								if (extension.equalsIgnoreCase("ODX-F")) {
									odxfFiles.add(outputFileName);
								} else if (extension.equalsIgnoreCase("HEX")) {
									hexFiles.add(outputFileName);
								} else if (extension.equalsIgnoreCase("CBF")) {
									cbfFiles.add(outputFileName);
								} else if (extension.equalsIgnoreCase("CDFX")) {
									cdfxFiles.add(outputFileName);
								} else {
									commonFiles.add(outputFileName);
								}
							} else {
								copyFailedFiles.add(outputFileName);
							}
						}
					}
				} else if (type.equalsIgnoreCase("D")) {
					// DOMINION
					try {
						partNumberDetails = headerProcessingRepository.findDetails2(type, date, option1, option2,
								itemType, pid); // call the query
					} catch (Exception e) {
						if (e.getCause() instanceof JDBCConnectionException) {
							throw new SQLException(e.getMessage());
						} else {
							throw new BadRequestException(e.getMessage());
						}
					}
					System.out.println("=====LIST===== : " + partNumberDetails);

					if (partNumberDetails == null || partNumberDetails.size() == 0) {
						throw new BadRequestException("Parts are not available in SPEED for the provided Options.");
					} else {
						for (PartNumberRevDetailsDTIO i : partNumberDetails) {
							String filePath = i.getfile_path();
							System.out.println("====data==== : " + i.getpart_dnld_list() + "  ,  "
									+ i.getpart_file_typ() + " , " + i.getpart_dnld_pth());
							String outputFileName = i.getpart_dnld_pth().trim();
							Boolean copySuccess = copyIndividualFile(filePath, guidFolder, outputFileName);
							if (copySuccess) {
								dominionFiles.add(outputFileName);
							} else {
								copyFailedFiles.add(outputFileName);
							}
						}
					}
				} else {
					throw new BadRequestException("Incorrect assembly type");
				}

				// set the response
				response.setCbf(cbfFiles);
				response.setCdfx(cdfxFiles);
				response.setDominion(dominionFiles);
				response.setHex(hexFiles);
				response.setOdx_f(odxfFiles);
				response.setCommonFiles(commonFiles);
				response.setCopyFailedFiles(copyFailedFiles);

				System.out.println("=========response========= " + response);
				System.out.println("cbfFiles: " + response.getCbf());
				System.out.println("cdfxFiles: " + response.getCdfx());
				System.out.println("dominionFiles: " + response.getDominion());
				System.out.println("hexFiles: " + response.getHex());
				System.out.println("odxfFiles: " + response.getOdx_f());
				System.out.println("commonFiles: " + response.getCommonFiles());
				System.out.println("copyFailedFiles: " + response.getCopyFailedFiles());

				if (copyFailedFiles.size() > 0) {
//					response.setErrorMessage("Failed to copy one or more files.");
					String errorMessage = "";
					if (copyFailedFiles.size() == 1) {
						errorMessage = "File " + copyFailedFiles.get(0) + "is not found";
					} else {
						errorMessage = "Files ";
						for (String file : copyFailedFiles) {
							errorMessage = errorMessage + file + " ";
						}
						errorMessage += "are not found";
					}
					throw new FileNotFoundException(errorMessage);
				}

			} catch (javax.persistence.PersistenceException e) {
				throw new SQLException("Unable to connect to DB");
			} catch (SQLException e) {
				System.out.println("2");
				throw new SQLException(e.getMessage());
			} catch (BadRequestException e) {
				// TODO: handle exception
				response.setErrorMessage(e.getMessage());
				throw new BadRequestException(e.getMessage());
			}

		}

		response.setFolder(guidFolder);
		response.setProductId(pid);
		response.setProductType(type);

		return response;
	}

	// copyfiles methode
	public boolean copyIndividualFile(String inputFilePath, String guidFolder, String outputFileName)
			throws FileNotFoundException {
		try {
			System.out.println("inputFileName : " + inputFilePath);
			System.out.println("guidFolder : " + guidFolder);
			System.out.println("outputFileName : " + outputFileName);
			
			if (inputFilePath == null || inputFilePath.isEmpty() || inputFilePath.isBlank()) {
				return false;
			}

			String sourceFilePath = inputFilePath;

			String destinationFilePath = guidFolder;

			File sourceFile = new File(sourceFilePath);
			if (!sourceFile.exists()) {
				throw new FileNotFoundException("Source file at " + sourceFilePath + " not found");
			}
			File destinationFolder = new File(destinationFilePath);

			if (!destinationFolder.exists()) {
				destinationFolder.mkdirs();
			}

			try(FileInputStream inputStream = new FileInputStream(sourceFile);
					FileOutputStream outputStream = new FileOutputStream(new File(destinationFolder, outputFileName))) {
				System.out.println("fileSize in byte : " + sourceFile.length());
				byte[] buffer = new byte[1024 * 1024];
				int length;
				while ((length = inputStream.read(buffer)) > 0) {
					outputStream.write(buffer, 0, length);
				}
				System.out.println("file copied.");
				return true;
			}
		} catch (FileNotFoundException e) {
//			System.out.println("3");
//			throw new FileNotFoundException("Part files are not available");
			return false;
		} catch (IOException e) {
			throw new BadRequestException(e.getMessage());
		}
	}

	
	public DownloadOptionPartResponse getFallBack(Exception e) throws SQLException, FileSystemException {
		return handleExeptions(e);
	}

	/**
	 * @param e
	 * @return
	 * @throws SQLException
	 * @throws FileSystemException
	 */
	private DownloadOptionPartResponse handleExeptions(Exception e) throws SQLException, FileSystemException {
		System.out.println("inside fall");
		DownloadOptionPartResponse response = new DownloadOptionPartResponse();
		if (e instanceof SQLException) {
			System.out.println("2");
			throw new SQLException(e.getMessage());
		}
		if (e instanceof FileSystemException) {
			System.out.println("3");
			throw new FileSystemException(e.getMessage());
		} else if (e instanceof FileNotFoundException || e instanceof BadRequestException) {
			throw new BadRequestException(e.getMessage());
		}
		return response;
	}

	public static boolean isNetworkDriveAccessible(String drivePath) throws FileSystemException {
		boolean isAccessible = false;
		Path drive = FileSystems.getDefault().getPath(drivePath);
		DosFileAttributes attrs;
		try {
			attrs = Files.readAttributes(drive, DosFileAttributes.class);
			if (attrs.isDirectory()) {
				isAccessible = true;
			}
		} catch (IOException e) {
			throw new FileSystemException("Network Drive not found");
		}
		return isAccessible;
	}
}
