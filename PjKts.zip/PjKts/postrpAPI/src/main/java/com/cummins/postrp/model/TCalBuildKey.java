package com.cummins.postrp.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class TCalBuildKey implements Serializable {

  private static final long serialVersionUID = 1L;

  @Column(name = "CBD_ECM_CODE")
  private Date ecmCode;

  @Column(name = "CBD_FILE_DESC")
  private String fileDesc;

  @Column(name = "CBD_BUILD_ID")
  private String nuildId;

  @Column(name = "CBD_BUILD_NAME")
  private String buidlName;

  @Column(name = "CBD_PRD_ID")
  private String prdId;

  @Column(name = "CBD_RPC")
  private String rpc;

  @Column(name = "CBD_CAL_REV_DATE")
  private Date calRevDate;

  @Column(name = "CBD_LAST_UPDATE_DATE")
  private Date lastUpdateDate;

  @Column(name = "CBD_LAST_UPDATE_USER")
  private String lastUpdateUser;

  @Column(name = "CBD_CAL_VERSION")
  private String calVersion;

  @Column(name = "CBD_CAL_INCAL_NAME")
  private String calIncalName;
}
