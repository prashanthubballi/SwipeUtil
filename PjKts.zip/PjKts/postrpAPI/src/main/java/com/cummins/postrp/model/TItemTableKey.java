package com.cummins.postrp.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class TItemTableKey implements Serializable {

  private static final long serialVersionUID = 1L;

  @Column(name = "ITM_NUMBER")
  private String itmNumber;

  @Column(name = "ITM_REVISION_LEVEL")
  private String itmRevisionLevel;

  @Column(name = "ITM_DESCRIPTION")
  private String itmDescription;

  @Column(name = "ITM_SUBFILE_CODE")
  private String itmSubfileCode;

  @Column(name = "ITM_SUBFILE_SUB_CODE")
  private String itmSubfileSubCode;

  @Column(name = "ITM_SUBFILE_TYPE")
  private String itmSubfileType;

  @Column(name = "ITM_CONFIG_NUMBER")
  private String itmConfigNumber;

  @Column(name = "ITM_EFFECT_CODE")
  private String itmeffectCode;

  @Column(name = "ITM_RELEASE_PHASE_CODE")
  private String itmReleasePhaseCode;

  @Column(name = "ITM_STATUS")
  private String itmStatus;

  @Column(name = "ITM_LAST_UPDATE_USER")
  private String itmLastUpdateUser;

  @Column(name = "ITM_LAST_UPDATE_DATE")
  private String itmLastUpdateDate;

  @Column(name = "ITM_BLOB")
  private String itmBlob;

  @Column(name = "ITM_S3_PATH")
  private String itmS3Path;

  @Column(name = "ITM_EJR")
  private String itmEJR;

  @Column(name = "ITM_ER")
  private String itmER;

  @Column(name = "ITM_ER_DATE")
  private String itmERDate;

  @Column(name = "ITM_DISTRIBUTION_GROUP")
  private String itmDistributionGroup;

  @Column(name = "ITM_PRODUCT_ID")
  private String itmProductId;

  @Column(name = "ITM_STATUS_DATE")
  private String itmStatusDate;

  @Column(name = "ITM_FILE_PATH")
  private String itmFilePath;

  @Column(name = "ITM_REVISION_TYPE")
  private String itmRevisionType;

  @Column(name = "ITM_ID_CODE")
  private String itmIdCode;

  @Column(name = "ITM_TYPE_CODE")
  private String itmTypeCode;

  @Column(name = "ITM_RELEASE_DATE")
  private String itmReleaseDate;

  @Column(name = "ITM_S3_URL")
  private String itmS3Url;

}
