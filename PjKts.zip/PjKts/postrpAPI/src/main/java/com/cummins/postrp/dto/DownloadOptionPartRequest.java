package com.cummins.postrp.dto;

import lombok.Data;

@Data
public class DownloadOptionPartRequest {

  // public String sourcePath;
  public String guidFolder;
  public String assemblyType;
  public String productID;
  public String primaryOption;
  public String secondaryOption;
  public String enggReleaseDate;
  public String itemType;

}
