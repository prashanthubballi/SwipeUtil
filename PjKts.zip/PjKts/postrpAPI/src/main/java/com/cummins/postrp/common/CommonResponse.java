/*
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Vishal.
 */

package com.cummins.postrp.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.io.Serializable;

@JsonPropertyOrder({"header", "pagination", "data"})
public class CommonResponse<T> implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 7076872220319204959L;

  @JsonProperty("header")
  private CommonResponseHeader header;

  @JsonProperty("data")
  private T data;

  public CommonResponse() {
    super();
  }

  public CommonResponse(CommonResponseHeader header, T data) {
    super();
    this.header = header;
    this.data = data;
  }

  public CommonResponse(CommonResponseHeader header) {
    super();
    this.header = header;
  }

  public CommonResponseHeader getHeader() {
    return header;
  }

  public void setHeader(CommonResponseHeader header) {
    this.header = header;
  }

  public T getData() {
    return data;
  }

  public void setData(T data) {
    this.data = data;
  }

  @Override
  public String toString() {
    return "CommonResponse [header=" + header + ", data=" + data + "]";
  }
}
