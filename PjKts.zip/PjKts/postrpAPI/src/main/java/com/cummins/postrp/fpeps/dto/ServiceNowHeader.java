package com.cummins.postrp.fpeps.dto;

import lombok.Data;

@Data
public class ServiceNowHeader {
  private Boolean success;
  private Integer code;
  private String message;
}
