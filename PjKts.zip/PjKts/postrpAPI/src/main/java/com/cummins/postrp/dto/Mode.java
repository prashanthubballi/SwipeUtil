package com.cummins.postrp.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Mode {

	@JsonProperty("mappedPath")
	private String mappedPath;
}
