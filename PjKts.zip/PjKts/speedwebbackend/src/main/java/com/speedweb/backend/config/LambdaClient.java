package com.speedweb.backend.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.auth.STSAssumeRoleSessionCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.amazonaws.services.lambda.model.ServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.speedweb.backend.common.CommonAWSConstants;
import com.speedweb.backend.request.RequestLambdaDTO;

//@Order(1)
//@PropertySource(value = "classpath:application.yml")
@Configuration
public class LambdaClient {

	public String invokeLambda(String args, String ProductId, String userid, String fullname,
			String commonLambdaFunction)
			throws NoSuchAlgorithmException, KeyManagementException, IOException, Exception {
		AmazonS3Config amazonS3Config = new AmazonS3Config();
		/*
		 * its not lambdaFunction, its an API. Generic lambda invoker. /lambdaController/invoke
		 */
		System.out.println(commonLambdaFunction);
		
		LocalDate myDateObj = LocalDate.now();

		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("MM-dd-yyyy");

		String formattedDate = myDateObj.format(myFormatObj);

		String fileName = ProductId + "-" + formattedDate;
		String fullName = fullname;

		JSONObject json = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		json.put("base64encodedString", args);
		json.put("productID", ProductId);
		JSONObject jsonForMail = new JSONObject();
		JSONObject jsonForMailData = new JSONObject();
		JSONObject jsonForMailDataTableInfo = new JSONObject();
		// for Multi Users
//		List<String> toList = new ArrayList<>();
//		toList.add(userid.toLowerCase() + "@cummins.com");
//		toList.add(CommonAWSConstants.senderMailToPSCM);
		//new product introduction mail
		productIntroductionMail(ProductId,commonLambdaFunction);
		
		String toList = userid.toLowerCase() + "@cummins.com"+","+CommonAWSConstants.senderMailToPSCM;
		jsonForMail.put("to", toList);
		jsonForMail.put("from", CommonAWSConstants.senderMail);
        System.out.println("jsonForMail:"+jsonForMail);
//		jsonForMail.put("subject", fileName);
		jsonForMailData.put("username", "Dear " + fullname);

		jsonArray.add("");
		jsonForMailData.put("tableInformation", jsonArray);
//		jsonForMail.put("data", jsonForMailData);

		RestTemplate restTemplate = new RestTemplate();

//		InvokeResult result = null;
		ResponseEntity<Object> result = null;
		URI uri = new URI(commonLambdaFunction);

		try {
			byte[] excelBytes = Base64.getDecoder().decode(args);
			AmazonS3 s3 = amazonS3Config.configAmazonS3();
			 
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentLength(excelBytes.length);
			metadata.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8");

			PutObjectResult putObjectResult = s3.putObject(CommonAWSConstants.excelS3UploadBucket, "exportedexcel/"+fileName+".xlsx",
					new ByteArrayInputStream(excelBytes), metadata);
			
//			RequestLambdaDTO lambdaRequest = new RequestLambdaDTO();
//			System.out.println(commonLambdaFunction);
//
//			lambdaRequest.setFunctionName(CommonAWSConstants.lambdaForS3Upload);
//			lambdaRequest.setPayload(json);
//			System.out.println("lambda request : " + json);
//			result = restTemplate.postForEntity(uri, lambdaRequest, Object.class);
////			result = getLambdaResponse(lambdaRequest.getFunctionName(), lambdaRequest.getPayload());
//			System.out.println("lambda Response : " + result);
			
			
			if (putObjectResult != null) {
				jsonForMail.put("subject", fileName + " Upload successfull");
//				jsonForMail.put("template", "upload_successful");
				jsonForMail.put("template", "Common_Email_TPL");
				jsonForMailData.put("content", "<p>The "+fileName+" file has been uploaded to centralized repository.</p>\r\n<p>You can refer the uploaded file "+fileName+".</p>\r\n");
				jsonForMail.put("data", jsonForMailData);
				RequestLambdaDTO lambdaRequestForMail = new RequestLambdaDTO();
				lambdaRequestForMail.setFunctionName(CommonAWSConstants.lambdaForMailInNPID);
				lambdaRequestForMail.setPayload(jsonForMail);
//				getLambdaResponse(lambdaRequest.getFunctionName(), lambdaRequest.getPayload());
				System.out.println(lambdaRequestForMail.toString());
				 restTemplate.postForEntity(uri, lambdaRequestForMail, Object.class);

				return "1";
			} else {
				jsonForMail.put("subject", fileName + " Upload Failure");
//				jsonForMail.put("template", "upload_failure");
				jsonForMail.put("template", "Common_Email_TPL");
				jsonForMailData.put("content","<p>The "+fileName+" Upload Failure could not be uploaded to centralized repository.</p>\r\n<p>You can refer the file downloaded locally at the machine else kindly retry submitting after some time.</p>\r\n");
				jsonForMail.put("data", jsonForMailData);
				RequestLambdaDTO lambdaRequestForFailureMail = new RequestLambdaDTO();
				lambdaRequestForFailureMail.setFunctionName(CommonAWSConstants.lambdaForMailInNPID);
				lambdaRequestForFailureMail.setPayload(jsonForMail);
//				getLambdaResponse(lambdaRequest.getFunctionName(), lambdaRequest.getPayload());
				System.out.println(lambdaRequestForFailureMail.toString());
				 restTemplate.postForEntity(uri, lambdaRequestForFailureMail, Object.class);

				return "0";
			}
		}

		catch (Exception e) {
			System.out.println("Exception while excuting lambda function");
			e.printStackTrace();
			jsonForMail.put("subject", fileName + " Upload Failure");
//			jsonForMail.put("template", "upload_failure");
			jsonForMail.put("template", "Common_Email_TPL");
			jsonForMailData.put("content","<p>The "+fileName+" Upload Failure could not be uploaded to centralized repository.</p>\r\n<p>You can refer the file downloaded locally at the machine else kindly retry submitting after some time.</p>\r\n");
			jsonForMail.put("data", jsonForMailData);
			RequestLambdaDTO lambdaRequestForFailureMail = new RequestLambdaDTO();
			lambdaRequestForFailureMail.setFunctionName(CommonAWSConstants.lambdaForMailInNPID);
			lambdaRequestForFailureMail.setPayload(jsonForMail);
			System.out.println(lambdaRequestForFailureMail.toString());
			restTemplate.postForEntity(uri, lambdaRequestForFailureMail, Object.class);

			return "0";

		}

	}

	private void productIntroductionMail(String productId,String commonLambdaFunction) throws URISyntaxException {
		URI uri = new URI(commonLambdaFunction);
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonForMail = new JSONObject();
		JSONObject jsonForMailData = new JSONObject();
		String toList = CommonAWSConstants.ebuPSCM+","+CommonAWSConstants.corpSpeedDba;
//		toList.add(CommonAWSConstants.ebuPSCM);
//		toList.add(CommonAWSConstants.corpSpeedDba);
		jsonForMail.put("to", toList);
		jsonForMail.put("from", CommonAWSConstants.senderMail);
//		jsonForMail.put("cc", CommonAWSConstants.corpSpeedDba);
        System.out.println("jsonForMail:"+jsonForMail);

		jsonForMailData.put("username", "Hi All");

		jsonArray.add("");
		jsonForMailData.put("tableInformation", jsonArray);
		
		jsonForMail.put("subject", " Product "+productId+" introduction notification");
		jsonForMail.put("template", "Common_Email_TPL");
		
		TimeZone estTimeZone = TimeZone.getTimeZone("America/New_York");
		Calendar estCalendar = Calendar.getInstance(estTimeZone);
		SimpleDateFormat dateFormat = new SimpleDateFormat("d MMM yyyy");
		dateFormat.setTimeZone(estTimeZone);
		String formattedDate = dateFormat.format(estCalendar.getTime());
		SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
		timeFormat.setTimeZone(estTimeZone);
		String formattedTime = timeFormat.format(estCalendar.getTime());
		System.out.println("EST DATE and TIME : "+formattedDate+" "+formattedTime);
		
		jsonForMailData.put("content","<p>Product "+productId+" was introduced successfully in SPEED on "+formattedDate+" at "+formattedTime+"(EST) </p>");
		jsonForMail.put("data", jsonForMailData);

		RestTemplate restTemplate = new RestTemplate();
		
		RequestLambdaDTO lambdaRequestForMail = new RequestLambdaDTO();
		lambdaRequestForMail.setFunctionName(CommonAWSConstants.lambdaForMailInNPID);
		lambdaRequestForMail.setPayload(jsonForMail);
//		getLambdaResponse(lambdaRequest.getFunctionName(), lambdaRequest.getPayload());
		System.out.println(lambdaRequestForMail.toString());
		 restTemplate.postForEntity(uri, lambdaRequestForMail, Object.class);
	}

	public InvokeResult getLambdaResponse(String functionName, JSONObject jsonObject)
			throws JSONException, UnsupportedOperationException, IOException {
		String returnList = null;
		System.out.println(jsonObject);
		System.out.println("Function Name is :" + functionName);
		String lmdpayload = jsonObject.toString();
		System.out.println(lmdpayload);
		System.out.println("Lambda Payload :" + lmdpayload);

		String arn = "arn:aws:iam::083597665337:role/spd_lambda_role_alpha";

//		 InstanceProfileCredentialsProvider provider = new InstanceProfileCredentialsProvider(true);
//		 RoleInfo roleInfo = new RoleInfo();
//		 roleInfo.setRoleArn(arn);
//		 roleInfo.setLongLivedCredentialsProvider(provider);

		STSAssumeRoleSessionCredentialsProvider.Builder builder = new STSAssumeRoleSessionCredentialsProvider.Builder(
				arn, UUID.randomUUID().toString());
		InvokeRequest invokeRequest = new InvokeRequest().withFunctionName(functionName).withPayload(lmdpayload);
		InvokeResult invokeResult = null;

		try {
			AWSLambda awsLambda = AWSLambdaClientBuilder.standard().withRegion(Regions.US_EAST_1).build();

			invokeResult = awsLambda.invoke(invokeRequest);
//			String ans = new String(invokeResult.getPayload().array(), StandardCharsets.UTF_8);
//			if (invokeResult.getStatusCode() == 200) {
//				returnList = ans;
//				return returnList;
//
//			} else {
//				System.out.println("Status from else clause :" + invokeResult);
//				throw new BadRequestException("Invalid Request ");
//			}
		} catch (ServiceException e) {
			System.out.println(e);
		}
		return invokeResult;
	}

}
