
package com.speedweb.backend.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.Constants;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.config.LambdaClient;
import com.speedweb.backend.dtoprojection.ITCompatibilityProfileByProductId;
import com.speedweb.backend.dtoprojection.ServiceProfileValuesResponse;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.NpidCompatibilitySaveProfileRequestDTO;
import com.speedweb.backend.request.NpidNotesSaveProfileRequestDTO;
import com.speedweb.backend.request.NpidOptionStructureDetailsRequestDTO;
import com.speedweb.backend.request.NpidStructureSaveProfileRequestDTO;
import com.speedweb.backend.request.RequestExportExcelDTO;
import com.speedweb.backend.request.RequestMantaInfo;
import com.speedweb.backend.request.RequestManufacturingInitialDTO;
import com.speedweb.backend.request.RequestNPIDinProductMapping;
import com.speedweb.backend.request.RequestProductIntroControl;
import com.speedweb.backend.request.RequestProductIntroOption;
import com.speedweb.backend.request.RequestProductTypeDTO;
import com.speedweb.backend.request.RequestSaveNewProductInfo;
import com.speedweb.backend.request.RequestSaveProfile;
import com.speedweb.backend.request.RequestSaveTempMasterDTO;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.responseObject.NPIDManufacturingInitialResponse;
import com.speedweb.backend.responseObject.NPIValidateProductResponse;
import com.speedweb.backend.responseObject.NewProductIntroControlResponse;
import com.speedweb.backend.responseObject.NewProductIntroHomeResponse;
import com.speedweb.backend.responseObject.NewProductIntroOptionResponse;
import com.speedweb.backend.responseObject.NpidNotesModifyResponse;
import com.speedweb.backend.responseObject.NpidStructureModifyResponse;
import com.speedweb.backend.responseObject.ServiceProfileResponseForNextGen;
import com.speedweb.backend.service.INewProductIntroductionService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("newProductIntroController")
@ApiOperation(value = "API List for Admin -> New Product Introduction (SNAP)")
public class NewProductIntroductionController {

	private static Logger log = LogManager.getLogger(NewProductIntroductionController.class);

	@Autowired
	HttpServletRequest request;

	@Autowired
	private INewProductIntroductionService service;
	
	byte [] in = null;

	@ApiOperation(value = "Get LDAP User Details")
	@PostMapping("getLDAPUserDetails")
	public ResponseEntity<CommonResponse<String>> getLDAPUserDetails(@RequestBody RequestStringDTO dto)
			throws BusinessException {
		log.info("Inside Method -> NewProductIntroductionController -> getLDAPUserDetails");
		return ResponseUtility.generateResponse(service.getLDAPUserDetails(dto.getStrParam()), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Product Details")
	@PostMapping("getProductDetails")
	public ResponseEntity<CommonResponse<NewProductIntroHomeResponse>> getProductDetails() throws BusinessException {
		log.info("Inside Method -> NewProductIntroductionController -> getProductDetails");
		return ResponseUtility.generateResponse(service.getProductDetails(), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Compatibility By Product Id")
	@PostMapping("getCompatibilityByProductId")
	public ResponseEntity<CommonResponse<ITCompatibilityProfileByProductId>> getCompatibilityByProductId(
			@RequestBody RequestStringDTO plantId) throws BusinessException {
		return ResponseUtility.generateResponse(service.getCompatibilityByProductId(plantId.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Get Compatibility List")
	@GetMapping("getCompatibilityList")
	public ResponseEntity<CommonResponse<List>> getCompatibilityList() throws BusinessException {
		return ResponseUtility.generateResponse(service.getCompatibilityList(), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Option For Compatibility")
	@PostMapping("getOptionForCompatibility")
	public ResponseEntity<CommonResponse<List>> getOptionForCompatibility(@RequestBody RequestStringDTO plantId)
			throws BusinessException {
		return ResponseUtility.generateResponse(service.getOptionForCompatibility(plantId.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Validate Product")
	@PostMapping("validateProduct")
	public ResponseEntity<CommonResponse<NPIValidateProductResponse>> validateProduct(
			@RequestBody RequestStringDTO plantId) throws BusinessException {
		return ResponseUtility.generateResponse(service.validateProduct(plantId.getStrParam()), HttpStatus.OK);
	}

	@ApiOperation(value = "Validate Product Type")
	@PostMapping("validateProductType")
	public ResponseEntity<CommonResponse<ApiResponse>> validateProductType(
			@RequestBody RequestProductTypeDTO productType) throws BusinessException {
		return ResponseUtility.generateResponse(service.validateProductType(productType), HttpStatus.OK);
	}

	@ApiOperation(value = "Save New Product Info")
	@PostMapping("saveNewProductInfo")
	public ResponseEntity<CommonResponse<ApiResponse>> saveNewProductInfo(
			@RequestBody RequestSaveNewProductInfo productInfo) throws BusinessException {
		if (productInfo.getTempUrl().isEmpty()) {
			String url = (String) request.getSession().getAttribute("url");
			productInfo.setTempUrl(url);
		}
		if (productInfo != null && productInfo.getDescription() != null && productInfo.getDescription().length() > 20) {
			productInfo.setDescription(productInfo.getDescription().substring(0, 20).trim());
		}
		return ResponseUtility.generateResponse(service.saveNewProductInfoNew(productInfo), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Option Details")
	@PostMapping("getOptionDetails")
	public ResponseEntity<CommonResponse<NewProductIntroOptionResponse>> getOptionDetails(
			@RequestBody RequestStringDTO request) {
		log.info("Inside Method -> NewProductIntroductionController -> getOptionDetails");
		return ResponseUtility.generateResponse(service.getOptionDetails(request.getStrParam()), HttpStatus.OK);
	}

	@ApiOperation(value = "Save product option profile")
	@PostMapping("saveNewProductOption")
	public ResponseEntity<CommonResponse<ApiResponse>> saveNewProductOption(
			@RequestBody RequestProductIntroOption request) {
		log.info("Inside Method -> NewProductIntroductionController -> saveNewProductOption");
		return ResponseUtility.generateResponse(service.saveNewProductOption(request), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Control File Profile Details")
	@PostMapping("getControlProfileDetails")
	public ResponseEntity<CommonResponse<NewProductIntroControlResponse>> getControlFileProfileDetails(
			@RequestBody RequestStringDTO request) {
		log.info("Inside Method -> NewProductIntroductionController -> getControlFileProfileDetails");
		return ResponseUtility.generateResponse(service.getControlFileProfileDetails(request.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Save product Control profile")
	@PostMapping("saveNewProductControl")
	public ResponseEntity<CommonResponse<ApiResponse>> saveNewProductControl(
			@RequestBody RequestProductIntroControl request) {
		log.info("Inside Method -> NewProductIntroductionController -> saveNewProductControl");
		return ResponseUtility.generateResponse(service.saveNewProductControl(request), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Service Drop Down List Values")
	@PostMapping("getServiceDropDownValues")
	public ResponseEntity<CommonResponse<List>> getServiceDropDownValues() {
		log.info("Inside Method -> NewProductIntroductionController -> getServiceDropDownValues");
		return ResponseUtility.generateResponse(service.getServiceDropDownValues(), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Service Values By ProductId")
	@PostMapping("getServiceValuesByProductId")
	public ResponseEntity<CommonResponse<List>> getServiceValuesByProductId(@RequestBody RequestStringDTO productId) {
		log.info("Inside Method -> NewProductIntroductionController -> getServiceValuesByProductId");
		return ResponseUtility.generateResponse(service.getServiceValuesByProductId(productId.getStrParam()),
				HttpStatus.OK);
	}
	
	@ApiOperation(value = "New Get Service Values By ProductId")
		@PostMapping("fetchServiceLayoutBasedOnProductId")
		public ResponseEntity<CommonResponse<ServiceProfileResponseForNextGen>> fetchServiceLayoutBasedOnProductId(@RequestBody RequestStringDTO productId, HttpServletRequest request) {
			log.info("Inside Method -> NewProductIntroductionController -> fetchServiceLayoutBasedOnProductId");
			return ResponseUtility.generateResponse(service.fetchServiceLayoutBasedOnProductId(productId.getStrParam()),
					HttpStatus.OK);
		}
	
	@ApiOperation(value = "Get Service Profile Values By ProductId")
	@PostMapping("getAdditionalServiceValuesByProductId")
	public ResponseEntity<CommonResponse<ServiceProfileValuesResponse>> getAdditionalServiceValuesByProductId(@RequestBody RequestStringDTO productId) {
		log.info("Inside Method -> NewProductIntroductionController -> getServiceValuesByProductId");
		return ResponseUtility.generateResponse(service.getAdditionalServiceValuesByProductId(productId.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Get Npid Structure Modify Details")
	@PostMapping("getNpidStructureModifyDetails")
	public ResponseEntity<CommonResponse<NpidStructureModifyResponse>> getNpidStructureModifyDetails(
			@RequestBody RequestStringDTO productId) throws BusinessException {
		return ResponseUtility.generateResponse(service.getNpidStructureModifyDetails(productId.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Get Npid Option Structure Details")
	@PostMapping("getNpidOptionStructureDetails")
	public ResponseEntity<CommonResponse<List>> getNpidOptionStructureDetails(
			@RequestBody NpidOptionStructureDetailsRequestDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(service.getNpidOptionStructureDetails(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Save Structure Profile Info")
	@PostMapping("saveStructureProfileInfo")
	public ResponseEntity<CommonResponse<ApiResponse>> saveStructureProfileInfo(
			@RequestBody NpidStructureSaveProfileRequestDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(service.saveStructureProfileInfo(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Layout Option By Table Name")
	@PostMapping("getLayoutOptionByTableName")
	public ResponseEntity<CommonResponse<List>> getLayoutOptionByTableName(@RequestBody RequestStringDTO tableName) {
		log.info("Inside Method -> NewProductIntroductionController -> getLayoutOptionByTableName");
		return ResponseUtility.generateResponse(service.getLayoutOptionByTableName(tableName.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Get Npid Structure Options And Selected Info")
	@PostMapping("getNpidStructureOptionsAndSelectedInfo")
	public ResponseEntity<CommonResponse<List>> getNpidStructureOptionsAndSelectedInfo(
			@RequestBody RequestStringDTO productId) {
		return ResponseUtility.generateResponse(
				service.getNpidOptionsAndSelectedInfo(Constants.npidStructureScreen, productId.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Get Npid Notes Modify Details")
	@PostMapping("getNpidNotesModifyDetails")
	public ResponseEntity<CommonResponse<NpidNotesModifyResponse>> getNpidNotesModifyDetails(
			@RequestBody RequestStringDTO productId) throws BusinessException {
		return ResponseUtility.generateResponse(service.getNpidNotesModifyDetails(productId.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Get Npid Notes Details for Option")
	@PostMapping("getNpidOptionNotesDetails")
	public ResponseEntity<CommonResponse<List>> getNpidOptionNotesDetails(
			@RequestBody NpidOptionStructureDetailsRequestDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(service.getNpidOptionNotesDetails(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Save Notes Profile Info")
	@PostMapping("saveNotesProfileInfo")
	public ResponseEntity<CommonResponse<ApiResponse>> saveNotesProfileInfo(
			@RequestBody NpidNotesSaveProfileRequestDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(service.saveNotesProfileInfo(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Npid Notes Options And Selected Info")
	@PostMapping("getNpidNotesOptionsAndSelectedInfo")
	public ResponseEntity<CommonResponse<List>> getNpidNotesOptionsAndSelectedInfo(
			@RequestBody RequestStringDTO productId) {
		return ResponseUtility.generateResponse(
				service.getNpidOptionsAndSelectedInfo(Constants.npidNotesScreen, productId.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Save Service Profile")
	@PostMapping("saveServiceProfile")
	public ResponseEntity<CommonResponse<ApiResponse>> saveServiceProfile(@RequestBody RequestSaveProfile saveProfile) {
		return ResponseUtility.generateResponse(service.saveServiceProfile(saveProfile), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Manufacturing Screen")
	@PostMapping("getManufacturing")
	public ResponseEntity<CommonResponse<NPIDManufacturingInitialResponse>> getManufacturing(
			@RequestBody RequestManufacturingInitialDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(service.getManufacturingInitial(dto.getProductID(), dto.getBsProduct()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Get Auxilary Product Info")
	@PostMapping("getAuxProductInfo")
	public ResponseEntity<CommonResponse<List<String>>> getAuxProductInfo() throws BusinessException {
		return ResponseUtility.generateResponse(service.getAuxProductInfo(), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Manufacturing Layout")
	@PostMapping("getmanufacturingLayout")
	public ResponseEntity<CommonResponse<List<String>>> getmanufacturingLayout() throws BusinessException {
		return ResponseUtility.generateResponse(service.getmanufacturingLayout(), HttpStatus.OK);
	}

	@ApiOperation(value = "Save Manufacturing Data")
	@PostMapping("saveMantaInfo")
	public ResponseEntity<CommonResponse<ApiResponse>> saveMantaInfo(@RequestBody RequestMantaInfo dto)
			throws BusinessException {
		return ResponseUtility.generateResponse(service.saveMantaInfo(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Validate ECM Prefix")
	@PostMapping("validateECMPrefix")
	public ResponseEntity<CommonResponse<Integer>> validateECMPrefix(@RequestBody RequestStringDTO prefix)
			throws BusinessException {
		log.info("Inside Method -> NewProductIntroductionController -> validateECMPrefix");
		return ResponseUtility.generateResponse(service.validateECMPrefix(prefix.getStrParam()), HttpStatus.OK);
	}

	@ApiOperation(value = "Save Temp Master")
	@PostMapping("saveTempMaster")
	public ResponseEntity<CommonResponse<ApiResponse>> saveTempMaster(@RequestBody RequestSaveTempMasterDTO request)
			throws BusinessException {
		return ResponseUtility.generateResponse(service.saveTempMasterNew(request), HttpStatus.OK);
	}

	@ApiOperation(value = "Save Compatibility Profile Info")
	@PostMapping("saveCompatibilityProfileInfo")
	public ResponseEntity<CommonResponse<ApiResponse>> saveCompatibilityProfileInfo(
			@RequestBody NpidCompatibilitySaveProfileRequestDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(service.saveCompatibilityProfileInfo(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Index Value")
	@PostMapping("getIndexValue")
	public ResponseEntity<CommonResponse<Integer>> getIndexValue(@RequestBody RequestStringDTO productID)
			throws BusinessException {
		log.info("Inside Method -> NewProductIntroductionController -> getIndexValue");
		return ResponseUtility.generateResponse(service.getIndexValue(productID.getStrParam()), HttpStatus.OK);
	}
	@ApiOperation(value = "Making Excel File")
	@PostMapping("generateExcelFile")
	private ResponseEntity<byte []> generateExcelFile(@RequestBody RequestExportExcelDTO dto)
			throws IOException {
		
		try {
			 in = service.exportProductIntroData(dto.getProductID(), dto.getBsFlag(), dto.getServiceFlag());
			String args = Base64.getEncoder().encodeToString(in);
			
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=exportExcelData.xlsx");
			respHeaders.add("Status", "success");
			
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK); 
			
				
		} catch (Exception e) {
			e.printStackTrace();
			return null;
					
		}
	}

	@ApiOperation(value = "Export New Product Intro All Details")
	@PostMapping("exportProductIntroData")
	private ResponseEntity<CommonResponse<Integer>> exportProductIntroData(@RequestBody RequestExportExcelDTO dto)
			throws IOException,Exception {
		LocalDate myDateObj = LocalDate.now();

		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("MM-dd-yyyy");

		String formattedDate = myDateObj.format(myFormatObj);
		try {
			
			String args = Base64.getEncoder().encodeToString(in);
			LambdaClient lambdaClient = new LambdaClient();
			String urlString = lambdaClient.invokeLambda(args, dto.getProductID(),dto.getUserId(),dto.getFullname(),service.getcommonLambdaFunction());
			in = null;
			if(urlString.equalsIgnoreCase("1")) {
				return ResponseUtility.generateResponse((1), HttpStatus.OK);	}
			else {
				return ResponseUtility.generateResponse((0), HttpStatus.CREATED); // The file is created but not uploaded to S3	
			}	
		} catch (Exception e) {
			System.out.println("Exception while excuting lambda function");
			e.printStackTrace();
			return ResponseUtility.generateResponse((0), HttpStatus.CREATED);
			
					
		}
	}

	
	@ApiOperation(value = "validate NPID in ProductMapping")
	@PostMapping("validateNPIDinProductMapping")
	public ResponseEntity<CommonResponse<Integer>> validateNPIDinProductMapping(@RequestBody RequestNPIDinProductMapping request)
			throws BusinessException {
		log.info(" NewProductIntroductionController -> validateNPIDinProductMapping");
		return ResponseUtility.generateResponse(service.validateNPIDinProductMapping(request), HttpStatus.OK);
	}
}
