package com.speedweb.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.dtoprojection.IInterfaceSupportDTO;
import com.speedweb.backend.service.IInterfaceSupportService;

@RestController
public class InterfaceSupportController {
	
	@Autowired
	IInterfaceSupportService iInterfaceSupportService;
	
	@GetMapping("getInterfaceSupport")
	public List<IInterfaceSupportDTO>  getInterfaceSupportController() {
		
		return iInterfaceSupportService.IInterfaceSupportRepository();
		
	}

}
