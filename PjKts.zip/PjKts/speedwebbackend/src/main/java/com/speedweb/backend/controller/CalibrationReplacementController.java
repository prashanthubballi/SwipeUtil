package com.speedweb.backend.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.model.TReplacementcal;
import com.speedweb.backend.request.RequestCalibrationReplacement;
import com.speedweb.backend.request.RequestCalibrationSearch;
import com.speedweb.backend.request.RequestECMCode;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.responseObject.CalibrationReplacementData;
import com.speedweb.backend.service.impl.CalibrationReplacementService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("calibrationcontroller")
@ApiOperation(value = "API List for Calibration Replacement")
public class CalibrationReplacementController {

	@Autowired
	CalibrationReplacementService calReplacementService;

	@ApiOperation("Search data for calibration replacement")
	@PostMapping("replacementrequest")
	private ResponseEntity<CommonResponse<TReplacementcal>> getSearchData(
			@RequestBody RequestCalibrationSearch search) throws BusinessException, SQLException {
		return ResponseUtility.generateResponse(calReplacementService.searchCalReplacement(search), HttpStatus.OK);
	}

	@ApiOperation("API to get replacement data in excel format for Active and Pending")
	@PostMapping("downloadreplacementdata")
	private ResponseEntity<byte[]> downloadreplacementdata(HttpServletResponse responses) throws IOException {
		try {
			byte[] in = calReplacementService.getCalReplacementData();

			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=productRelease.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@ApiOperation("API to get replacement data in excel format for NOREPLACEMENT")
	@PostMapping("downloadnoreplacementdata")
	private ResponseEntity<byte[]> downloadnoreplacementdata(HttpServletResponse responses) throws IOException {
		try {

			byte[] in = calReplacementService.getNoReplacementData();

			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=productRelease.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@ApiOperation("Get ECM Code by Product id")
	@PostMapping("getecmcode")
	private ResponseEntity<CommonResponse<List>> getEcmCode(@RequestBody RequestStringDTO productId)
			throws BusinessException {
		return ResponseUtility.generateResponse(calReplacementService.getEcmCode(productId.getStrParam()),
				HttpStatus.OK);
	}
	
	@ApiOperation("Validate Old ECM Code")
	@PostMapping("validateoldecm")
	private ResponseEntity<CommonResponse<CalibrationReplacementData>> validateoldecm(@RequestBody RequestECMCode oldECMCode) throws BusinessException{
		return ResponseUtility.generateResponse(calReplacementService.validateOldECM(oldECMCode), HttpStatus.OK);
	}
	@ApiOperation("Validate New ECM Code")
	@PostMapping("validatenewecm")
	private ResponseEntity<CommonResponse<CalibrationReplacementData>> validatenewecm(@RequestBody RequestECMCode newECMCode) throws BusinessException {
		return ResponseUtility.generateResponse(calReplacementService.validdatenewecm(newECMCode), HttpStatus.OK);
	}
	
	@ApiOperation("Save Calibration Request")
	@PostMapping("saverequest")
	private ResponseEntity<CommonResponse<ApiResponse>> savecalibrationreplacement(@RequestBody RequestCalibrationReplacement request) throws BusinessException {

		return ResponseUtility.generateResponse(calReplacementService.savecalibrationreplacement(request), HttpStatus.OK);
	}
	
	@ApiOperation("Get Cal Replacement details by product Id")
	@PostMapping("getCalReplacementByProductId")
	private ResponseEntity<CommonResponse<List>> getCalReplacementByProductId(@RequestBody RequestCalibrationSearch search) throws BusinessException {

		return ResponseUtility.generateResponse(calReplacementService.getCalReplacementByProductId(search), HttpStatus.OK);
	}


}
