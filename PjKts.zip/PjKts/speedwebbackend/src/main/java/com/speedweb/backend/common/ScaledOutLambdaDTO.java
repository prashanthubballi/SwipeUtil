package com.speedweb.backend.common;

import lombok.Data;

@Data
public class ScaledOutLambdaDTO {

	public String functionName;
	public ScaleoutLambdaPayload payload;
}
