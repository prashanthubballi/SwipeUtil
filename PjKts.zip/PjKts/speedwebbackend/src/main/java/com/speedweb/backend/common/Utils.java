package com.speedweb.backend.common;

import java.lang.reflect.Field;
import java.util.Date;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;

public class Utils {

	public static String[] extractStringArrFromField(Class<?> classsInstance) {
		Field[] allFields = classsInstance.getDeclaredFields();
		String str = "";
		for (Field field : allFields) {

			String strValue = field.getName().toString();
			if (!strValue.equalsIgnoreCase("serialVersionUID")) {
				str = str + strValue + ",";
				System.out.println(strValue);
			}
		}
		if (!str.isEmpty()) {
			str = str.substring(0, str.length() - 1);
		}
		return str.split(",");
	}

	public static int getCellByValue(CellStyle defCellStyle, String value, Row row, int columnID) {
		Cell cell1 = row.createCell(columnID);
		cell1.setCellValue(value);
		cell1.setCellStyle(defCellStyle);
		return columnID;
	}

	public static int getCellByValue(CellStyle defCellStyle, Date value, Row row, int columnID) {
		Cell cell1 = row.createCell(columnID);
		cell1.setCellValue(value);
		cell1.setCellStyle(defCellStyle);
		return columnID;
	}

	/**
	 * @param headerString
	 * @param COLUMNS
	 * @param workbook
	 * @param createHelper
	 * @param sheet
	 * @param headerFont
	 * @param defCellStyle
	 * @param dateCellStyle
	 */
	public static void getExcelHeader(String headerString, String[] COLUMNS, Workbook workbook, CreationHelper createHelper,
			Sheet sheet, Font headerFont, CellStyle defCellStyle, CellStyle dateCellStyle) {
		headerFont.setBold(true);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setBorderBottom(BorderStyle.THIN);
		headerCellStyle.setBorderRight(BorderStyle.THIN);
		headerCellStyle.setBorderLeft(BorderStyle.THIN);
		headerCellStyle.setBorderTop(BorderStyle.THIN);
		headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
		headerCellStyle.setVerticalAlignment(VerticalAlignment.TOP);
		headerCellStyle.setFont(headerFont);

		// Row for Header
		Row headerRow = sheet.createRow(0);

		for (int col = 0; col < COLUMNS.length; col++) {
			Cell cell = headerRow.createCell(col);
			cell.setCellValue(headerString);
			cell.setCellStyle(headerCellStyle);
		}
		sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
				0, // last row (0-based)
				0, // first column (0-based)
				COLUMNS.length - 1 // last column (0-based)
		));
		Font columnheaderFont = workbook.createFont();
		columnheaderFont.setFontHeight((short) (12 * 20));
		columnheaderFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle columnheaderCellStyle = workbook.createCellStyle();
		columnheaderCellStyle.setBorderBottom(BorderStyle.THIN);
		columnheaderCellStyle.setBorderRight(BorderStyle.THIN);
		columnheaderCellStyle.setBorderLeft(BorderStyle.THIN);
		columnheaderCellStyle.setBorderTop(BorderStyle.THIN);
		columnheaderCellStyle.setVerticalAlignment(VerticalAlignment.TOP);
		columnheaderCellStyle.setFont(columnheaderFont);

		// Row for Column Header
		Row columnheaderRow = sheet.createRow(1);

		for (int col = 0; col < COLUMNS.length; col++) {
			Cell cell = columnheaderRow.createCell(col);
			cell.setCellValue(COLUMNS[col]);
			cell.setCellStyle(columnheaderCellStyle);
			sheet.autoSizeColumn(col);
		}

		Font rowFont = workbook.createFont();
		rowFont.setFontHeight((short) (11 * 20));

		// CellStyle for default

		defCellStyle.setBorderBottom(BorderStyle.THIN);
		defCellStyle.setBorderRight(BorderStyle.THIN);
		defCellStyle.setBorderTop(BorderStyle.THIN);
		defCellStyle.setBorderLeft(BorderStyle.THIN);
		defCellStyle.setFont(rowFont);
		defCellStyle.setVerticalAlignment(VerticalAlignment.TOP);

		// CellStyle for default

		dateCellStyle.setBorderBottom(BorderStyle.THIN);
		dateCellStyle.setBorderRight(BorderStyle.THIN);
		dateCellStyle.setBorderTop(BorderStyle.THIN);
		dateCellStyle.setBorderLeft(BorderStyle.THIN);
		dateCellStyle.setFont(rowFont);
		dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-mmm-yyyy"));
		dateCellStyle.setVerticalAlignment(VerticalAlignment.TOP);
	}
	


}
