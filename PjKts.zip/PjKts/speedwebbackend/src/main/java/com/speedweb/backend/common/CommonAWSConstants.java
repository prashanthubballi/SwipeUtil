package com.speedweb.backend.common;

import java.util.ArrayList;
import java.util.List;

public class CommonAWSConstants {

	public static String lambdaFunctionUrl="";
	public static String calibrationNoteMessage="";
	public static String packageMfgMasterServiceUrl="";
	
	public static String indexChangeParentUrl="";
	public static String lambdaForMailInNPID="";
	public static String lambdaForMailInECMReserveCode="";
	public static String senderMail="";
	public static String excelS3UploadBucket="";
	public static String senderMailToPSCM="";
	public static String fileUploadRegularUrl="";
	public static String fileUploadRestrictedUrl="";
	public static String ebuPSCM="";
	public static String corpSpeedDba="";
	public static String serviceCalDownloadRegularUrl="";
	public static String serviceCalDownloadRestrictedUrl="";
	
	public static String caltermDownloadUrl="";
	public static String scaledOutLambda = "";
	public static String caltermDownloadUrlExport="";
	public static String[] ExportControlProducts = null;
	public static String serviceDownloadTempPath="";
	public static String serviceDownloadZipPath="";
	
	public static String[] adminWwidListForPlantAccess=null;
	
//	public static String Authorization = "Basic Vko5NDQ6c21pV0AxMjM=";
	public static String Authorization = "";
//	public static String verifyWwidFormat = "https://wwimsngn-prod-app-oim.cummins.com/iam/governance/scim/v1/Users/.search";
	public static String verifyWwidFormat = "";

	public static String auditLogUrl="";
	public static String cnSearchAppId="";
	public static String cnSearchAppName="";
	public static String cnSearchAPI="";

}
