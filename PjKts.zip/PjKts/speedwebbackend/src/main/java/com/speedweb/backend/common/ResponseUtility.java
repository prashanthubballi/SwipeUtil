package com.speedweb.backend.common;

import java.io.Serializable;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;


@SuppressWarnings("unchecked")
public class ResponseUtility implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2406725743147396237L;

	public static <T> ResponseEntity generateResponse(T data, HttpHeaders headers, HttpStatus status) {
		return new CustomResponseEntity(data, headers, status);

	}

	public static <T> ResponseEntity<CommonResponse<T>> generateResponse(T data, MultiValueMap<String, String> headers, HttpStatus status, String message) {
		CommonResponseHeader responseHeader;
		if (message != null) {
			responseHeader = new CommonResponseHeader(isSuccessStatus(status), status.value(), message);
		} else {
			message = isSuccessStatus(status) ? Constants.GENERIC_SUCCESS_MESSAGE
					: Constants.GENERIC_FAILURE_MESSAGE;
			responseHeader = new CommonResponseHeader(isSuccessStatus(status), status.value(), message);
		}
		return new CustomResponseEntity<>(new CommonResponse<>(responseHeader, data), headers, status);

	}

	public static <T> ResponseEntity<CommonResponse<T>> generateResponse(T data, HttpStatus status, String message) {
		final CommonResponseHeader responseHeader = new CommonResponseHeader(isSuccessStatus(status), status.value(),
				message);
		return new CustomResponseEntity<>(new CommonResponse<>(responseHeader, data), status);
	}

	public static <T> ResponseEntity<CommonResponse<T>> generateResponse(T data, HttpStatus status) {
		String message = isSuccessStatus(status) ? Constants.GENERIC_SUCCESS_MESSAGE
				: Constants.GENERIC_FAILURE_MESSAGE;
		return generateResponse(data, status, message);
	}

	private static boolean isSuccessStatus(HttpStatus status) {
		return status.is2xxSuccessful() || status.is3xxRedirection();
	}

}