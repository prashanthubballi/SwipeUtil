package com.speedweb.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestNewPlantIntro;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.responseObject.PlantDetailsResponse;
import com.speedweb.backend.service.INewPlantIntroService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("newPlantIntroductionController")
@ApiOperation(value = "Application controller API List for New Plant Introduction Page")
public class NewPlantIntroductionController {

	@Autowired
	INewPlantIntroService iNewPlantIntroService;
	
	@ApiOperation(value = "Get PlantName by PlantId")
	@PostMapping("findPlantNameByPlantId")
	public ResponseEntity<CommonResponse<PlantDetailsResponse>> findPlantNameByPlantId(@RequestBody RequestStringDTO plantid )
			throws BusinessException {
		return ResponseUtility.generateResponse(iNewPlantIntroService.findPlantNamebyPlantId(plantid.getStrParam()), HttpStatus.OK);
	}
	

	@ApiOperation(value = "Save New Plant in T_Plant_Master")
	@PostMapping("saveNewPlantByPlantId")
	public ResponseEntity<CommonResponse<ApiResponse>> saveNewPlant(@RequestBody RequestNewPlantIntro plantMaster)
			throws BusinessException {		
		return ResponseUtility.generateResponse(iNewPlantIntroService.saveNewPlantByPlantId(plantMaster), HttpStatus.OK);
	}
	
	
}
