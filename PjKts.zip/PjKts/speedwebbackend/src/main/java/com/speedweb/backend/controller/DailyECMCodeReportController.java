package com.speedweb.backend.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.dtoprojection.IDailyECMCodeReportData;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestDailyECMCodeReportDTO;
import com.speedweb.backend.responseObject.DailyECMCodeReportDataDTO;
import com.speedweb.backend.service.impl.DailyECMCodeReportServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("dailyECMCodeReportController")
@ApiOperation(value = "API List for Daily ECM Code Report")
public class DailyECMCodeReportController {
	
	
	@Autowired
	DailyECMCodeReportServiceImpl dailyECMCodeReportService;

	@ApiOperation("Get Daily ECM Code Report By Date")
	@PostMapping("getReport")
	private ResponseEntity<CommonResponse<DailyECMCodeReportDataDTO>> getSearchData(
			@RequestBody RequestDailyECMCodeReportDTO search) throws BusinessException, SQLException {
		return ResponseUtility.generateResponse(dailyECMCodeReportService.searchByDate(search), HttpStatus.OK);
	}
	@ApiOperation(value = "Export Daily ECM Code Report By Date")
	@PostMapping("exportDailyECMCodeReport")
	private ResponseEntity<byte[]> exportDailyECMCodeReport(HttpServletResponse response,
			@RequestBody RequestDailyECMCodeReportDTO search) throws IOException {
		try {
			
			List<IDailyECMCodeReportData> list = dailyECMCodeReportService.exportDailyECMCodeReport(search);
			
			byte[] in = dailyECMCodeReportService.dailyECMCodeReportToExcel(list);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=dailyecmcodereport.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
