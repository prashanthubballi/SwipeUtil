package com.speedweb.backend.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestDownloadCaltermFiles;
import com.speedweb.backend.request.RequestPartNumberUploadStatus;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.ByteArrayStringReponse;
import com.speedweb.backend.responseObject.PartNumberUploadSearchResponseDTO;
import com.speedweb.backend.service.impl.PartNumberUploadSearchServiceImpl;

import io.swagger.annotations.ApiOperation;
import lombok.extern.java.Log;

@RestController
@RequestMapping("partNumberUploadStatusController")
@ApiOperation(value = "API List for Part Number Upload Status Screen")
public class PartNumberUploadStatusController {

	PartNumberUploadSearchServiceImpl partNumberUploadSearchService;
	
	HttpServletRequest request;
	

	public PartNumberUploadStatusController(PartNumberUploadSearchServiceImpl partNumberUploadSearchService, HttpServletRequest request) {
		super();
		this.partNumberUploadSearchService = partNumberUploadSearchService;
		this.request = request;
	}

	@ApiOperation(value = "Get Part Number Upload Status")
	@PostMapping("getPartNumberUploadStatus")
	public ResponseEntity<CommonResponse<PartNumberUploadSearchResponseDTO>> getPartNumberUploadStatusByPartNumber(
			@RequestBody RequestPartNumberUploadStatus search) throws BusinessException {
		if (search.getPartNumber() != null && !search.getPartNumber().isEmpty()) {
			return ResponseUtility.generateResponse(
					partNumberUploadSearchService.getPartNumberUploadStatusByPartNumber(search), HttpStatus.OK);
		} else {
			return ResponseUtility.generateResponse(
					partNumberUploadSearchService.getPartNumberUploadStatusByProductId(search), HttpStatus.OK);

		}
	}
	
	@ApiOperation(value = "Export Part Number Upload Status")
	@PostMapping("exportToExcel")
	private ResponseEntity<byte[]> exportHistoryDetails(HttpServletResponse response,
			@RequestBody RequestPartNumberUploadStatus req) throws IOException {
		try {
			
			PartNumberUploadSearchResponseDTO responseObject  = partNumberUploadSearchService.getPartNumberUploadStatusForExport(req);
			
			byte[] in = partNumberUploadSearchService.exportPartNumberUploadStatus(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=historyDetails.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
	
	@PostMapping("downloadCalterm")
	private ResponseEntity<byte[]> downloadCaltermFiles(HttpServletRequest request,
			@RequestBody RequestDownloadCaltermFiles req) throws IOException {
		try {
			ByteArrayStringReponse response = partNumberUploadSearchService.caltemFileDownload(request, req);
			byte[] in = response.getFileData();
			String fileName = response.getFileName();
			
		    HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		    headers.setContentDispositionFormData("attachment", fileName);
		    headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		    headers.add("Custom-Header", fileName);
		    headers.add("Access-Control-Expose-Headers", "Custom-Header, Content-Disposition");

		    return new ResponseEntity<>(in, headers, HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		    HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.TEXT_PLAIN);
		    if(e.getMessage() == null) {
		    	return new ResponseEntity<>("Internal Server Error".getBytes(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		    }

		    String errorMessage = e.getMessage();
		    System.out.println(errorMessage);
		    return new ResponseEntity<>(errorMessage.getBytes(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("getProductListByWwid")
	public ResponseEntity<CommonResponse<List>> getProductListbyWWID(@RequestBody RequestStringDTO wwid)
	throws BusinessException
	{
		return ResponseUtility.generateResponse(partNumberUploadSearchService.getProductListbyWWID(wwid.getStrParam()), HttpStatus.OK);
	}
	

}
