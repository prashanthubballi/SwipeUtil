
package com.speedweb.backend.common;

import java.sql.SQLException;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.stereotype.Component;

@Component

// @PropertySource("classpath:application.yml")
public class JNDIClass {

	// @Value("${jndiName}")
	private String jndiName;

	private Logger logger = LogManager.getLogger(JNDIClass.class.getName());


	 //@Bean
	public DataSource jndiDataSource() throws IllegalArgumentException, NamingException, SQLException {
		JndiObjectFactoryBean bean = new JndiObjectFactoryBean(); // create JNDI data source
		bean.setJndiName(jndiName); // jndiDataSource is name of JNDI data source
		bean.setProxyInterface(DataSource.class);
		bean.setLookupOnStartup(false);
		bean.afterPropertiesSet();

		// logger.info(((DataSource) bean.getObject()).getConnection());

		return (DataSource) bean.getObject();
	}

}
// 