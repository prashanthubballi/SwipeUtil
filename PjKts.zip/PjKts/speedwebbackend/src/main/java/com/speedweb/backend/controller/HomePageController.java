package com.speedweb.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestPollVote;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.service.IHomePageService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("homeController")
@ApiOperation(value = "Application controller API List for Home Page")
public class HomePageController {
	
	@Autowired
	IHomePageService homePageService;
	
	@ApiOperation(value = "Get Quick Link details")
	@PostMapping("getQuickLinkDetails")
	public ResponseEntity<CommonResponse<List>> getQuickLinkDetails()
			throws BusinessException {
		return ResponseUtility.generateResponse(homePageService.getQuickLinkDetails(), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get Quick Polls")
	@PostMapping("getQuickPolls")
	public ResponseEntity<CommonResponse<List>> getQuickPolls()
			throws BusinessException {
		return ResponseUtility.generateResponse(homePageService.getQuickPoll(), HttpStatus.OK);
	}

	@ApiOperation(value = "Get Release Status")
	@GetMapping("getReleaseStatus")
	public ResponseEntity<CommonResponse<List>> getReleaseStatus()
			throws BusinessException {
		return ResponseUtility.generateResponse(homePageService.getReleaseStatus(), HttpStatus.OK);
	}

	
	@ApiOperation(value = "Get Team Details")
	@PostMapping("getTeamDetails")
	public ResponseEntity<CommonResponse<List>> getTeamDetails()
			throws BusinessException {
		return ResponseUtility.generateResponse(homePageService.getTeamDetails(), HttpStatus.OK);
	}

	@ApiOperation(value = "Add Poll Vote")
	@PostMapping("addPollVote")
	public ResponseEntity<CommonResponse<ApiResponse>> addPollVote(@RequestBody RequestPollVote requestPollVote)
			throws BusinessException {
		return ResponseUtility.generateResponse(homePageService.addPollVote(requestPollVote), HttpStatus.OK);

	}

}
