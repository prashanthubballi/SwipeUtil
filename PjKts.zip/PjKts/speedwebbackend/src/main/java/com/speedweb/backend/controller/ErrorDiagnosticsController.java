package com.speedweb.backend.controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestErdHomeDTO;
import com.speedweb.backend.request.RequestErrorDiagnosticsDTO;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.AssemblyErrorResponse;
import com.speedweb.backend.responseObject.CompatibilityIncompleteDTO;
import com.speedweb.backend.responseObject.CompatibilityIncompleteResponseDTO;
import com.speedweb.backend.responseObject.InvalidProductIDResponse;
import com.speedweb.backend.responseObject.ResponseCompatibilityIncompleteForEtrDTO;
import com.speedweb.backend.responseObject.ResponseDuplicateOptionDTO;
import com.speedweb.backend.responseObject.ResponseErdHomeDTO;
import com.speedweb.backend.responseObject.ResponseMultipleETR;
import com.speedweb.backend.responseObject.ResponseProductIDMismatch;
import com.speedweb.backend.responseObject.StructureIncompleteResponse;
import com.speedweb.backend.responseObject.UnsupportedConfigNumberResponse;
import com.speedweb.backend.service.IErrorDiagnosticsService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("erdController")
@ApiOperation("API List for Error Diagnostics")
public class ErrorDiagnosticsController {
	
	@Autowired
	IErrorDiagnosticsService erdService;

	@ApiOperation("Get Error Diagnostics errors list")
	@PostMapping("getErdHomeErrors")
	private ResponseEntity<CommonResponse<ResponseErdHomeDTO>> getErrors(@RequestBody RequestErdHomeDTO dto)
			throws BusinessException, ParseException{
		return ResponseUtility.generateResponse(erdService.getErdHomeErrors(dto), HttpStatus.OK);
	}
	
	
	@ApiOperation("Get Error Diagnostics excel list")
	@PostMapping("exportToExcel")
	private ResponseEntity<byte[]> exportToExcel(@RequestBody RequestErdHomeDTO dto)
			throws BusinessException, ParseException{
		//return ResponseUtility.generateResponse(erdService.getErdHomeErrors(dto), HttpStatus.OK);
		try {
			
			ResponseErdHomeDTO responseObject = erdService.getErdHomeErrors(dto);
			byte[] in = erdService.exportToExcel(responseObject, dto);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ActivePartNoReport.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@ApiOperation("Get Error Diagnostics errors")
	@PostMapping("getProductIDMismatchErrorDetails")
	private ResponseEntity<CommonResponse<ResponseProductIDMismatch>> getProductIDMismatchErrorDetails(@RequestBody RequestErrorDiagnosticsDTO dto) 
			throws BusinessException, ParseException{
		return ResponseUtility.generateResponse(erdService.getProductIDMismatchDetails(dto), HttpStatus.OK);
	}
	

	@ApiOperation("Get Assembly Error Details")
	@PostMapping("getAssemblyErrorDetails")
	private ResponseEntity<CommonResponse<AssemblyErrorResponse>> getAssemblyErrorDetails(@RequestBody RequestErrorDiagnosticsDTO dto) 
			throws BusinessException, ParseException{
		return ResponseUtility.generateResponse(erdService.getAssemblyErrorDetails(dto), HttpStatus.OK);
	}
	
	@ApiOperation("Get Multiple ETR ECM Code")
	@PostMapping("getMultipleEtrEcmCode")
	private ResponseEntity<CommonResponse<ResponseMultipleETR>> getMultipleEtrEcmCode(@RequestBody RequestErrorDiagnosticsDTO dto) 
			throws BusinessException {
		return ResponseUtility.generateResponse(erdService.getMultEtrEcmCodeSCandPJ(dto), HttpStatus.OK);
	}
	
	@ApiOperation("Get Unsupported Configuration Number Error")
	@PostMapping("getUnsupportedConfigDetails")
	private ResponseEntity<CommonResponse<UnsupportedConfigNumberResponse>> getUnsupportedConfigNumberDetails(@RequestBody RequestErrorDiagnosticsDTO dto) 
			throws BusinessException, ParseException{
		return ResponseUtility.generateResponse(erdService.getUnsupportedConfigNumberDetails(dto), HttpStatus.OK);
	}
		

	@ApiOperation("Get Structure Incomplete")
	@PostMapping("getStructureIncomplete")
	private ResponseEntity<CommonResponse<StructureIncompleteResponse>> getStructureIncomplete(@RequestBody RequestErrorDiagnosticsDTO dto) 
			throws BusinessException {
		return ResponseUtility.generateResponse(erdService.getStructureIncomplete(dto), HttpStatus.OK);
	}
	
	@ApiOperation("Get Configuration Number")
	@PostMapping("getConfigurationNumber")
	private ResponseEntity<CommonResponse<CompatibilityIncompleteResponseDTO>> getConfigurationNumber(@RequestBody RequestErrorDiagnosticsDTO dto) 
			throws BusinessException {
		return ResponseUtility.generateResponse(erdService.getConfigurationNumber(dto), HttpStatus.OK);
	}
	
	@ApiOperation("Get DropDowns List for the selected config number ")
	@PostMapping("getDropDownListsCI")
	private ResponseEntity<CommonResponse<CompatibilityIncompleteResponseDTO>> getDropDownListsCI(@RequestBody RequestErrorDiagnosticsDTO dto) 
			throws BusinessException {
		return ResponseUtility.generateResponse(erdService.getDropDownListsCI(dto), HttpStatus.OK);
	}
	
	@ApiOperation("Get Compatibility Incomplete error Details ")
	@PostMapping("getCompatibilityIncompleteData")
	private ResponseEntity<CommonResponse<CompatibilityIncompleteResponseDTO>> getCompatibilityIncompleteData(@RequestBody CompatibilityIncompleteDTO dto) 
			throws BusinessException {
		return ResponseUtility.generateResponse(erdService.getCompatibilityIncompleteData(dto), HttpStatus.OK);
	}
	
	
	@ApiOperation("Get Duplicate Option Details")
	@PostMapping("getDuplicateOptionDetails")
	private ResponseEntity<CommonResponse<ResponseDuplicateOptionDTO>> getDuplicateOptionDetails(@RequestBody RequestErrorDiagnosticsDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(erdService.getDuplicateOptionErrorDetails(dto), HttpStatus.OK);
	}
	
	@ApiOperation("Get Compatibility Incomplete for ETR error Details")
	@PostMapping("getCompatibilityIncompleteForEtrDetails")
	private ResponseEntity<CommonResponse<ResponseCompatibilityIncompleteForEtrDTO>> getCompatibilityIncompleteForEtrDetails(@RequestBody RequestErrorDiagnosticsDTO dto)
			throws BusinessException {
		return ResponseUtility.generateResponse(erdService.getCompatibilityIncompleteForEtrDetails(dto), HttpStatus.OK);
	}
	
	@ApiOperation("Get Invalid Product ID Details")
	@PostMapping("getInvalidProductIDDetails")
	private ResponseEntity<CommonResponse<InvalidProductIDResponse>> getInvalidProductID(@RequestBody RequestStringDTO errorDesc)
			throws BusinessException {
		return ResponseUtility.generateResponse(erdService.getInvalidProductID(errorDesc.getStrParam()), HttpStatus.OK);
	}

}

