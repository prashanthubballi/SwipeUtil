package com.speedweb.backend.controller;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestERDetailsDTO;
import com.speedweb.backend.responseObject.IERDetailsResponse;
import com.speedweb.backend.responseObject.TERConfigurationPageResponse;
import com.speedweb.backend.service.IERReleaseReportService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("erReleaseReportController")
@ApiOperation(value = "API List for ER Release Report")
public class ERReleaseReportController {
	
	@Autowired
	IERReleaseReportService erReleaseReportService;
	
	@ApiOperation(value = "Get ER Release Report Part Number")
	@PostMapping("getERDetails")
	public ResponseEntity<CommonResponse<IERDetailsResponse>> getOptionStructureDetails(@RequestBody RequestERDetailsDTO dto)
			throws BusinessException {
		return ResponseUtility.generateResponse(erReleaseReportService.getERDetails(dto.getFromDate(), dto.getToDate(), dto.getErNumber(),dto.getCurrentPage(),dto.getPageSize()), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get ER Release Report by Configuration")
	@PostMapping("getErDetailsForConfiguation")
	public ResponseEntity<CommonResponse< TERConfigurationPageResponse>> getErDetailsForConfiguation(@RequestBody RequestERDetailsDTO dto)
			throws BusinessException, ParseException {
		return ResponseUtility.generateResponse(erReleaseReportService.getErDetailsForConfiguation(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get ER Release Report by Option")
	@PostMapping("getErDetailsForOption")
	public ResponseEntity<CommonResponse< IERDetailsResponse>> getErDetailsForOption(@RequestBody RequestERDetailsDTO dto)
			throws BusinessException ,ParseException{
		return ResponseUtility.generateResponse(erReleaseReportService.getERDetailsForOption(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get ER Release Report for All")
	@PostMapping("getErDetailsForAll")
	public ResponseEntity<CommonResponse< IERDetailsResponse>> getErDetailsForAll(@RequestBody RequestERDetailsDTO dto)
			throws BusinessException ,ParseException{
		return ResponseUtility.generateResponse(erReleaseReportService.getERDetailsForAll(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Export ER Details by Part Number")
	@PostMapping("exportToExcelERDetailsbyPartNumber")
	private ResponseEntity<byte[]> exportToExcelERDetailsbyPartNumber(HttpServletResponse response,
			@RequestBody RequestERDetailsDTO dto) throws IOException {
		try {
			IERDetailsResponse responseObject = erReleaseReportService.getERDetails(dto.getFromDate(), dto.getToDate(), dto.getErNumber(),0,Integer.MAX_VALUE);
			byte[] in = erReleaseReportService.getERDetailsForPartNumberToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ERDetailsbyPartNumber.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@ApiOperation(value = "Export ER Details by Option")
	@PostMapping("exportToExcelERDetailsbyOption")
	private ResponseEntity<byte[]> exportToExcelERDetailsbyOption(HttpServletResponse response,
			@RequestBody RequestERDetailsDTO dto) throws IOException {
		try {
			dto.currentPage = 0;
			dto.pageSize = Integer.MAX_VALUE;
			IERDetailsResponse responseObject = erReleaseReportService.getERDetailsForOption(dto);
			byte[] in = erReleaseReportService.getERDetailsForOptionToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ERDetailsbyOption.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@ApiOperation(value = "Export ER Details by Configuration")
	@PostMapping("exportToExcelERDetailsbyConfiguration")
	private ResponseEntity<byte[]> exportToExcelERDetailsbyConfiguration(HttpServletResponse response,
			@RequestBody RequestERDetailsDTO dto) throws IOException {
		try {
			dto.currentPage = 0;
			dto.pageSize = Integer.MAX_VALUE;
			TERConfigurationPageResponse responseObject = erReleaseReportService.getErDetailsForConfiguation(dto);
			byte[] in = erReleaseReportService.getERDetailsForConfigurationToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ERDetailsbyConfiguration.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@ApiOperation(value = "Export ER Details for All")
	@PostMapping("exportToExcelERDetailsbyAll")
	private ResponseEntity<byte[]> exportToExcelERDetailsbyAll(HttpServletResponse response,
			@RequestBody RequestERDetailsDTO dto) throws IOException {
		try {
			dto.currentPage = 0;
			dto.pageSize = Integer.MAX_VALUE;
			IERDetailsResponse responseObject = erReleaseReportService.getERDetailsForAll(dto);
			byte[] in = erReleaseReportService.getERDetailsForAllToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ERDetailsbyAll.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
