package com.speedweb.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.OptionEcmMapResponse;
import com.speedweb.backend.service.IOptionEcmMapService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("optionEcmMapController")
@ApiOperation(value = "API search for Option ECM map screen")
public class OptionEcmMapController {
	
	@Autowired
	IOptionEcmMapService optionEcmMapService;
	
	@ApiOperation(value = "Get Option Auto suggest list")
	@PostMapping("getOptionList")
	public ResponseEntity<CommonResponse<List>> getOptionAutoSuggestList(@RequestBody RequestStringDTO ecmMapRequest)
			throws BusinessException {
		return ResponseUtility.generateResponse(optionEcmMapService.getOptionList(ecmMapRequest.getStrParam().trim()),HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get Option Search Data")
	@PostMapping("getOptionEcmSearchData")
	public ResponseEntity<CommonResponse<OptionEcmMapResponse>> getOptionEcmSearchData(@RequestBody RequestStringDTO ecmMapRequest)
			throws BusinessException {
		return ResponseUtility.generateResponse(optionEcmMapService.getOptionEcmSearchData(ecmMapRequest.getStrParam().trim()),HttpStatus.OK);
	}

}
