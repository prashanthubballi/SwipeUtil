package com.speedweb.backend.config;

import org.springframework.context.annotation.Configuration;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
@Configuration
public class AmazonS3Config {
	public AmazonS3 configAmazonS3() {
		Regions clientRegion = Regions.US_EAST_1;
 
		AmazonS3 s3Client = null;
		try {
			 //This code expects that you have AWS credentials set up per:
//			 https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/setup-credentials.html
//			 s3Client = AmazonS3ClientBuilder.standard().withRegion(clientRegion).build();
//			 InstanceProfileCredentialsProvider provider = new
//			 InstanceProfileCredentialsProvider(true);
// 
			s3Client = AmazonS3ClientBuilder.standard().withRegion(clientRegion).build();
			System.out.println("AWS S3 Instance  : " + s3Client.toString());
			return s3Client;
		} catch (AmazonServiceException execption) {
			// The call was transmitted successfully, but Amazon S3 couldn't process
			// it, so it returned an error response.
			execption.printStackTrace();
		} catch (SdkClientException ex) {
			// Amazon S3 couldn't be contacted for a response, or the client
			// couldn't parse the response from Amazon S3.
			ex.printStackTrace();
		}
		return s3Client;
	}
}
