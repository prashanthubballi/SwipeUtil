package com.speedweb.backend.common;

public class TableName {

	public static final String T_ITEM = "T_ITEM";
	public static final String T_NOTE = "T_NOTE";
	public static final String T_ER_NOTES = "T_ER_NOTES";
	public static final String T_GREENHOUSE_DATA = "T_GREENHOUSE_DATA";
	public static final String T_GREENHOUSE_VIEW = "T_GREENHOUSE_VIEW";
	public static final String T_CHASSIS_DETAILS = "T_CHASSIS_DETAILS";
	public static final String T_CMI_USERS = "T_CMI_USERS";
	public static final String T_OEM_MASTER = "T_OEM_MASTER";
	public static final String T_OEM_LIST = "T_OEM_LIST";
	public static final String T_USERS_OEM = "T_USERS_OEM";
	public static final String T_OEM_CONFIG_MASTER = "T_OEM_CONFIG_MASTER";
	public static final String T_GH_MAIL_PREFERENCE = "T_GH_MAIL_PREFERENCE";
	public static final String T_CMI_USER_CONFIG = "T_CMI_USER_CONFIG";
	public static final String T_ER_CONFIGURATION = "T_ER_CONFIGURATION";
	public static final String ONE_SOURCE_USERS = "ONE_SOURCE_USERS";
}
