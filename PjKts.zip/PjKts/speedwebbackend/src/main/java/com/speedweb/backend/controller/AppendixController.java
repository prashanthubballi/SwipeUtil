package com.speedweb.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.AppendixEditRequest;
import com.speedweb.backend.request.AppendixRequest;
import com.speedweb.backend.request.RequestStringWithPagingDTO;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.responseObject.AppendixResponseDTO;
import com.speedweb.backend.service.impl.AppendixServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("appendixcontroller")
@ApiOperation(value = "API List for Appendix")
public class AppendixController {

	@Autowired
	AppendixServiceImpl appendixService;

	@ApiOperation(value = "Get Appendix List By Name")
	@PostMapping("getAppendixList")
	public ResponseEntity<CommonResponse<AppendixResponseDTO>> getAppendixList(
			@RequestBody RequestStringWithPagingDTO req) throws BusinessException {
		return ResponseUtility.generateResponse(appendixService.getAppendixListByName(req), HttpStatus.OK);
	}
	
	
	@ApiOperation(value="Save Appendix")
	@PostMapping("saveappendix")
	public ResponseEntity<CommonResponse<ApiResponse>> saveAppendix(@RequestBody AppendixRequest request) throws BusinessException {
		return ResponseUtility.generateResponse(appendixService.saveAppendix(request), HttpStatus.OK);
		
	}
	
	@ApiOperation(value="Edit Appendix")
	@PostMapping("editAppendix")
	public ResponseEntity<CommonResponse<ApiResponse>> editAppendix(@RequestBody AppendixEditRequest request) throws BusinessException {
		return ResponseUtility.generateResponse(appendixService.editAppendix(request), HttpStatus.OK);
		
	}
	
	@ApiOperation(value="delete Appendix")
	@PostMapping("deleteAppendix")
	public ResponseEntity<CommonResponse<ApiResponse>> deleteAppendix(@RequestBody AppendixRequest request) throws BusinessException {
		return ResponseUtility.generateResponse(appendixService.deleteAppendix(request), HttpStatus.OK);
		
	}

}
