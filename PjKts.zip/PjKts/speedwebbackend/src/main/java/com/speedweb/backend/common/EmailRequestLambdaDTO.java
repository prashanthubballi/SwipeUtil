package com.speedweb.backend.common;

import org.json.simple.JSONObject;

import lombok.Data;

@Data
public class EmailRequestLambdaDTO {
	public String functionName;
	public JSONObject payload;
}
