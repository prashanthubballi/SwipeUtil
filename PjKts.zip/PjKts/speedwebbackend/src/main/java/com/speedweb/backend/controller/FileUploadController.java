package com.speedweb.backend.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.dtoprojection.IFileProductDetailsDTO;
import com.speedweb.backend.dtoprojection.IFileUploadDTO;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.FileUploadToDbDTO;
import com.speedweb.backend.request.SetRevisionNumberForFileUploadRequestDTO;
import com.speedweb.backend.request.UpdateS3UrlinDbDTO;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.service.IFileUploadService;

//import com.speedweb.backend.service.JWTTokenAuthLambdaInvoker;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("fileUploadController")
@ApiOperation("API List for File upload")
public class FileUploadController {
	
	
	@Autowired
	IFileUploadService fileUploadService;
	
//	@Autowired
//	JWTTokenAuthLambdaInvoker jwttokenauthlambdaInvoker;
	
	
//	@ApiOperation("File Upload Main API")
//	@PostMapping("fileUploadMainAPI")
////	private String fileUploadMainAPI(FileUploadRequestDTO dto,MultipartFile file) throws BusinessException, ParseException, JSONException, UnsupportedOperationException, IOException, org.json.simple.parser.ParseException{
//	private String fileUploadMainAPI(String productId,@RequestBody String partNumber,@RequestBody String fileType,@RequestBody String crNumber,@RequestBody String fileName,@RequestBody boolean userType,@RequestBody String accessToken,@RequestBody MultipartFile file) throws BusinessException, ParseException, JSONException, UnsupportedOperationException, IOException, org.json.simple.parser.ParseException{
//		System.out.println("User submitted values::Product ID-"+productId+"PartNumber-"+partNumber+"File Type-"+fileType+"CR number-"+crNumber+"fileName"+fileName+"User Type"+userType+"Access token"+accessToken+"File uploaded"+file);
//		String responseMessage="";
//		FileUploadRequestDTO dto=new FileUploadRequestDTO();
//		dto.setProductId(productId);
//		dto.setPartNumber(partNumber);
//		dto.setFileType(fileType);
//		dto.setCrNumber(crNumber);
//		dto.setFileName(fileName);
//		dto.setUserType(userType);
//		dto.setAccessToken(accessToken);
//		System.out.println("---File upload main API--->");
//		System.out.println("File upload main API request DTO -->");
//		System.out.println("ProductID::"+dto.getProductId()+" PartNumber::"+dto.getPartNumber()+" FileType::"+dto.getFileType()+" CRNumber::"+dto.getCrNumber()+" fileName::"+dto.getFileName()+" isInternalUser::"+dto.isUserType());
//		System.out.println("Access Token::"+dto.getAccessToken());
//		System.out.println("File::"+file);
//		
//		if(dto.isUserType()==true) {
//			
//			Boolean validateUserRoleFlag=validateUserRole(dto,file);
//			
//			if(validateUserRoleFlag) {
//				responseMessage="S3 Bucket upload success and the path is::"+validateInputFile(dto,file);
//				
//			}
//			
//			else {
//				System.out.println("Please check your Product ID again");
//			}
//		
//		}
//		
//		else {
//			System.out.println("External user-->");
//		}
//		
//		return responseMessage;
//	}
//	
//	
//	
//	
//	public Boolean validateUserRole(FileUploadRequestDTO dto,MultipartFile file) throws ParseException, BusinessException, JSONException, UnsupportedOperationException, IOException, org.json.simple.parser.ParseException {
//		
//		System.out.println("---Validate User role--->");
//		
//		System.out.println("User selected product ID::"+dto.getProductId());
//		
//		Boolean validateUserRoleFlag=false;
//		
//		List<IFileProductDetailsDTO> productGrpList=new ArrayList<IFileProductDetailsDTO>();
//		
//		productGrpList=fileUploadService.getProductDetails(dto.getProductId());
//		
//		ResponseEntity<String> s3usergrp= jwttokenauthlambdaInvoker.getLambdaResponse(dto.getAccessToken());
//		
//		String strClaims=s3usergrp.getBody();
//		System.out.println();
//		JSONObject json=new JSONObject(strClaims);
//		String body=json.getString("body");
//		JSONObject jsonbody=new JSONObject(body);
//		String strbody=jsonbody.toString();
//		JSONObject jsonroles=new JSONObject(strbody);
//		JSONArray jsonArray=jsonroles.getJSONArray("roles");
//		for(int i=0;i<jsonArray.length();i++) {
//			System.out.println("User roles are::"+" "+jsonArray.getString(i));
//		}
//		
//		
//		String s3UserGroup="Regular";
//		
//		System.out.println("Product group::"+ productGrpList.get(0).getProductGrp());
//		
//		if(productGrpList.get(0).getProductGrp().equals(s3UserGroup)) {
//			
//			validateUserRoleFlag=true;
//			System.out.println("Validate User Role flag::"+validateUserRoleFlag);
//			
//		}
//		else {
//			validateUserRoleFlag=false;
//		}
//		
//		
//		return validateUserRoleFlag;
//		
//	} 
//	
//	public String validateInputFile(FileUploadRequestDTO dto,MultipartFile file) throws ParseException, BusinessException, JSONException, UnsupportedOperationException, IOException, org.json.simple.parser.ParseException {
//		
//		String responseMessage="";
//		
//		System.out.println("---Validate Input file--->");
//		
//		System.out.println("Validate Input file method inputs");
//		
//		System.out.println("ProductID::"+dto.getProductId()+" PartNumber::"+dto.getPartNumber()+" FileType::"+dto.getFileType()+" CRNumber::"+dto.getCrNumber()+" fileName::"+dto.getFileName()+" isInternalUser::"+dto.isUserType());
//		System.out.println("Access Token::"+dto.getAccessToken());
//		System.out.println("File::"+file);
//		
//		List<IFileUploadDTO> fileUploadDetalisList=new ArrayList<IFileUploadDTO>();
//		System.out.println("File upload details list size::"+fileUploadDetalisList.size());
//		
//		fileUploadDetalisList=fileUploadService.getFileUploadDetails(dto.getPartNumber());
//		
//		if(fileUploadDetalisList.size()==0) {
//			
//			String revision=Integer.toString(0);
//			System.out.println("S3 bucket parameters ------------"+file+" "+dto.getFileName()+""+revision+""+dto.getProductId());
//			String s3Url=uploadFile(dto.getAccessToken(),file,dto.getFileName(),dto.getProductId(),revision);
//			
//			FileUploadToDbDTO fileUploaddto=new FileUploadToDbDTO();
//			
//			fileUploaddto.revisionLevel=0;
//			fileUploaddto.releaseStatus="N";
//			fileUploaddto.partNumber=dto.getPartNumber();
//			fileUploaddto.queryFlag="Insert";
//			fileUploaddto.productId=dto.getProductId();
//			fileUploaddto.fileType=dto.getFileType();
//			fileUploaddto.s3Url=s3Url;
//			
//			System.out.println("File upload to DB dto input parameters--RevisionLevel::"+fileUploaddto.revisionLevel+" Release Status::"+fileUploaddto.releaseStatus+" Part Number::"+fileUploaddto.partNumber+" Query Flag::"+fileUploaddto.queryFlag+" ProductID::"+fileUploaddto.productId+" File Type"+fileUploaddto.fileType);
//			System.out.println("S3 Url::"+s3Url);
//			responseMessage=s3Url;
//			
////			updateFileReleaseDetails(fileUploaddto);
//		}
//		
//		else if(fileUploadDetalisList.size()>0) {
//			String revision=Integer.toString(0)+1;
//			System.out.println("S3 bucket parameters ------------"+file+" "+dto.getFileName()+""+revision+""+dto.getProductId());
//			String s3Url=uploadFile(dto.getAccessToken(),file,dto.getFileName(),dto.getProductId(),revision);
//			
//			FileUploadToDbDTO fileUploaddto=new FileUploadToDbDTO();
//			
//			fileUploaddto.revisionLevel=0;
//			fileUploaddto.releaseStatus="N";
//			fileUploaddto.partNumber=dto.getPartNumber();
//			fileUploaddto.queryFlag="Insert";
//			fileUploaddto.productId=dto.getProductId();
//			fileUploaddto.fileType=dto.getFileType();
//			fileUploaddto.s3Url=s3Url;
//			
//			System.out.println("File upload to DB dto input parameters--RevisionLevel::"+fileUploaddto.revisionLevel+" Release Status::"+fileUploaddto.releaseStatus+" Part Number::"+fileUploaddto.partNumber+" Query Flag::"+fileUploaddto.queryFlag+" ProductID::"+fileUploaddto.productId+" File Type"+fileUploaddto.fileType);
//			System.out.println("S3 Url::"+s3Url);
//			responseMessage=s3Url;
////			updateFileReleaseDetails(fileUploaddto);
//		}
//		return responseMessage;
//	}
	
	@ApiOperation("To set Revision number for File upload")
	@PostMapping("setRevisionNumberForFileUpload")
	public ResponseEntity<CommonResponse<ApiResponse>> fieValidation(@RequestBody SetRevisionNumberForFileUploadRequestDTO dto) throws ParseException, BusinessException {
		String fileName="";
		
		List<IFileUploadDTO> fileUploadDetalisList=new ArrayList<IFileUploadDTO>();
		fileUploadDetalisList=fileUploadService.getFileUploadDetails(dto.getPartNumber());
		System.out.println("File upload details list size::"+fileUploadDetalisList.size());
//		System.out.println("File upload status::"+fileUploadDetalisList.get(fileUploadDetalisList.size()-1).getuploadStatus());
		if(fileUploadDetalisList.size()==0) {
			System.out.println("1st usecase for fileupload");
			String revision="0"+Integer.toString(0);
			String status="N";
			fileName=dto.getPartNumber()+"."+revision+"."+dto.getFileName()+"."+status+"."+"I";
			System.out.println("Revision and Status::"+revision+"::"+status);
		}
		else if(fileUploadDetalisList.size()>0 && fileUploadDetalisList.get(fileUploadDetalisList.size()-1).getuploadStatus().equals("Y")) {
			System.out.println("2nd usecase for fileupload");
			int rev=fileUploadDetalisList.get(fileUploadDetalisList.size()-1).getrevision()+1;
			String revision="";
			if(rev>=0 && rev<=9) {
				revision="0"+Integer.toString(rev);
			}
			else {
				revision=Integer.toString(rev);
			}
			
			String status="N";
			fileName=dto.getPartNumber()+"."+revision+"."+dto.getFileName()+"."+status+"."+"I";
			System.out.println("Revision and Status::"+revision+"::"+status);
		}
		
		else if(fileUploadDetalisList.size()>0 && fileUploadDetalisList.get(fileUploadDetalisList.size()-1).getuploadStatus().equals("N")){
			System.out.println("3rd usecase for fileupload");
			int rev=fileUploadDetalisList.get(fileUploadDetalisList.size()-1).getrevision();
			String revision="";
			if(rev>=0 && rev<=9) {
				revision="0"+Integer.toString(rev);
			}
			else {
				revision=Integer.toString(rev);
			}
			String status="N";
			fileName=dto.getPartNumber()+"."+revision+"."+dto.getFileName()+"."+status+"."+"U";
			System.out.println("Revision and Status::"+revision+"::"+status);
		}
		
		
		
		return ResponseUtility.generateResponse(new ApiResponse(true,fileName), HttpStatus.OK);
	}
	
	
	@ApiOperation("updateS3urlindb")
	@PostMapping("updateS3Urlindb")
	private ResponseEntity<CommonResponse<ApiResponse>> updateS3Urlindb(@RequestBody UpdateS3UrlinDbDTO dto) throws ParseException, BusinessException{
//		dto.setLastUpdateddate(java.time.LocalDate.now().toString());
		String res=fileUploadService.updateS3Url(dto).toString();
		return ResponseUtility.generateResponse(new ApiResponse(true,res), HttpStatus.OK);
	}
	
	@ApiOperation("upsertS3urlindb")
	@PostMapping("upsertS3urlindb")
	private ResponseEntity<CommonResponse<ApiResponse>> upsertS3Urlindb(@RequestBody UpdateS3UrlinDbDTO dto) throws ParseException, BusinessException{
//		dto.setLastUpdateddate(java.time.LocalDate.now().toString());
		String res=fileUploadService.upsertS3Url(dto).toString();
		return ResponseUtility.generateResponse(new ApiResponse(true,res), HttpStatus.OK);
	}
	
	
	
//	@PostMapping("/getClaims")
//	public String getUserClaims(String authtoken) throws JSONException, UnsupportedOperationException, IOException {
//		
//		ResponseEntity<String> s3usergrp= jwttokenauthlambdaInvoker.getLambdaResponse(authtoken);
//		String strClaims=s3usergrp.getBody();
//		System.out.println();
//		JSONObject json=new JSONObject(strClaims);
//		String body=json.getString("body");
//		JSONObject jsonbody=new JSONObject(body);
//		String strbody=jsonbody.toString();
//		JSONObject jsonroles=new JSONObject(strbody);
//		JSONArray jsonArray=jsonroles.getJSONArray("roles");
//		for(int i=0;i<jsonArray.length();i++) {
//			System.out.println(jsonArray.getString(i));
//		}
//		return "Success";
//	}
	
	
	
//	@PostMapping("/uploadFile")
//	public String uploadFile(@RequestParam("authToken") String token, @RequestParam("file") MultipartFile file,
//			@RequestParam("fileName") String fileName, @RequestParam("productId") String productId,
//			@RequestParam("partNumber") String version)
//			throws IOException, JSONException, org.json.simple.parser.ParseException, UnsupportedOperationException, org.json.JSONException {
//
//		Boolean rolePresent = false;
//		String authToken;
//		authToken = token;
//		System.out.println(file);
//		System.out.println("Auth token is : " + authToken);
//		System.out.println(productId+" "+fileName+" "+version);
//		
////		JWTTokenAuthLambdaInvoker jwttokenauthlambdaInvoker = new JWTTokenAuthLambdaInvoker();
//		ResponseEntity<String> jwtlambdaresponse = jwttokenauthlambdaInvoker.getLambdaResponse(authToken);
//
//		if (jwtlambdaresponse.getStatusCode() == HttpStatus.OK) {
//			// extract role claims from response and check whether regular/ces
//			// groups are available
//			String strClaims = jwtlambdaresponse.getBody();
//			System.out.println("String Claims is:" + strClaims);
//			JSONObject json = new JSONObject(strClaims);
//			String testjson = json.toString();
//			System.out.println("Test Json value :" + testjson);
//			String body = json.getString("body");
//			System.out.println("Body is :" + body);
//			JSONObject jsonbody = new JSONObject(body);
//			String strbody = jsonbody.toString();
//
//			System.out.println("strbody Json value :" + strbody);
//
//			JSONObject jsonroles = new JSONObject(strbody);
//
//			// get locations array from the JSON Object and store it into
//			// JSONArray
//			JSONArray jsonArray = jsonroles.getJSONArray("roles");
//
//			// Iterate jsonArray using for loop
//			for (int i = 0; i < jsonArray.length(); i++) {
//
//				System.out.println("Roles are  :" + jsonArray.getString(i));
//
//				if (jsonArray.getString(i).equalsIgnoreCase("g_spd-adg-regular"))
//					{
//					System.out.println("Roles Available, role present= True");
//					rolePresent = true;
//					}
//				else
//				{
//					System.out.println("Roles not Available, role present= False");
//				}
//			}
//
//		}
//
//		String fileS3Url = null;
//		Map<String, String> requestMap = new HashMap<>();
//		requestMap.put("fileName", fileName);
//		requestMap.put("productId", productId);
//		// requestMap.put("revision", revision);
//
//		try {
//			// file.getBytes();
//			if (rolePresent)
//			{
//				System.out.println("Proceeding with S3 upload");
//				System.out.println(file+" "+requestMap);
//				fileS3Url = S3UploadTest(file, requestMap);
//			}
//			
//			else
//			{
//				System.out.println("Not proceeding with S3 upload as roles not found");
//			}
//			return fileS3Url;
//
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		return fileS3Url;
//	}



//	public String S3UploadTest(MultipartFile file, Map<String, String> requestMap)
//			throws AmazonServiceException, SdkClientException, IOException {
//		
//		String clientRegion = "us-east-1";
//		String bucketName = "spd-content-ext-rp-alpha";
//		// String filename= file.getOriginalFilename();
//		String filename = requestMap.get("fileName");
//		// String filetype= file.getContentType();
//		String filePrefix = DateTime.now().toString("ddMMyyyy-HHmmss");
//		String fileObjKeyName = "UPLOAD/" + requestMap.get("productId") + "/" + filename;
//		System.out.println("S3 upload test ----"+" "+filename+" "+filePrefix+" "+fileObjKeyName);
//		ObjectMetadata data = new ObjectMetadata();
//		// data.setContentType(file.getContentType());
//		data.setContentLength(file.getSize());
//		// data.addUserMetadata(requestMap.get("version"));
//
//		for (Map.Entry<String, String> entry : requestMap.entrySet()) {
//			data.addUserMetadata(entry.getKey(), entry.getValue());
//		}
//		AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(clientRegion).build();
//
//		PutObjectResult objectResult = s3Client.putObject(bucketName, fileObjKeyName, file.getInputStream(), data);
//		// System.out.println(objectResult.); //you can verify MD5
//		String s3DirectUrl = "s3://" + bucketName + "/" + fileObjKeyName;
//		return s3DirectUrl;
//
//	}
//	
	
	
	
	@ApiOperation("Get file upload details")
	@PostMapping("getFileUploadDetails")
	private ResponseEntity<CommonResponse<List>> getFileUploadDetails(String partNumber) throws BusinessException, ParseException{
//		return fileUploadService.getFileUploadDetails(partNumber);
		return ResponseUtility.generateResponse(fileUploadService.getFileUploadDetails(partNumber), HttpStatus.OK);
	}
	
	@ApiOperation("Product group details")
	@GetMapping("getProductGroupDetails")
	private ResponseEntity<CommonResponse<List>> getProductGroupDetails(String productId) throws ParseException, BusinessException{
		List<IFileProductDetailsDTO> productGrpList=new ArrayList<IFileProductDetailsDTO>();
		productGrpList=fileUploadService.getProductDetails(productId);

		return ResponseUtility.generateResponse(fileUploadService.getProductDetails(productId), HttpStatus.OK);
	}
	
		
	public ResponseEntity<CommonResponse<ApiResponse>> updateFileReleaseDetails(@RequestBody FileUploadToDbDTO fileuploadDto)
			throws BusinessException, ParseException {
		
		System.out.println("Db call");
		return ResponseUtility.generateResponse(fileUploadService.updateFileReleaseDetails(fileuploadDto), HttpStatus.OK);
	}
	
	

}
