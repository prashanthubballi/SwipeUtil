package com.speedweb.backend.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestPartNumberSearchDTO;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.PartNumberSearchResponse;
import com.speedweb.backend.responseObject.PartNumberSearchbyECMCodeRespone;
import com.speedweb.backend.service.IPartNumberSearchService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("partNumberController")
@ApiOperation(value = "API List for Part Number Search Request Screen")
public class PartNumberSeachController {
	
	@Autowired
	IPartNumberSearchService partNumberService;
	
	@Autowired
	HttpServletRequest request;
	
	
	@ApiOperation(value = "Get Part Number Details by Part Number")
	@PostMapping("getPartNumber")
	public ResponseEntity<CommonResponse<PartNumberSearchResponse>> getPartNumberSearchDetails(@RequestBody RequestPartNumberSearchDTO search )
			throws BusinessException {
		HttpSession session = request.getSession(true);
		search.setSessionId(session.getId().toLowerCase());
		return ResponseUtility.generateResponse(partNumberService.getPartNumberSearchDetails(search), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get Part Number Search by ECM Code")
	@PostMapping("getPartNumberbyECMCode")
	public ResponseEntity<CommonResponse<PartNumberSearchbyECMCodeRespone>> getPartNumberSearchDetailsbyECMCode(@RequestBody RequestPartNumberSearchDTO search )
			throws BusinessException {
		HttpSession session = request.getSession(true);
		search.setSessionId(session.getId().toLowerCase());
		return ResponseUtility.generateResponse(partNumberService.getECMCodes(search), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get ProductDescription by Product ID")
	@PostMapping("getProductDescbyProductId")
	public ResponseEntity<CommonResponse<String>> getProductDescbyProductID(@RequestBody RequestStringDTO productID )
			throws BusinessException {
		
		return ResponseUtility.generateResponse(partNumberService.getProductDescriptionfromTProductMaster(productID.getStrParam()), HttpStatus.OK);
	}


}
