package com.speedweb.backend.controller;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.dtoprojection.IFileUploadDTO;
import com.speedweb.backend.dtoprojection.MultiFileUploadRequestDTO;
import com.speedweb.backend.dtoprojection.MultiUploadResponseExcelDTO;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestErdHomeDTO;
import com.speedweb.backend.dtoprojection.FileUploadResponse;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.responseObject.ResponseErdHomeDTO;
import com.speedweb.backend.service.IFileUploadService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("enggFileUploadController")
@ApiOperation("API List for File upload")
public class EnggFileUploadController {
	@Autowired
	IFileUploadService fileUploadService;
	
	@PostMapping("/uploadFile")
	public FileUploadResponse uploadFile(@RequestParam("authToken") String authHeader,
			@RequestParam("file") MultipartFile file,
		    @RequestParam("partNumber") String partNumber,
		    @RequestParam("productId") String productId,
		    @RequestParam("caNumber") String caNumber,
		    @RequestParam("fileType") String fileType,
		    @RequestParam("mode") String mode
		)
			throws IOException, JSONException, org.json.simple.parser.ParseException, UnsupportedOperationException, org.json.JSONException, URISyntaxException {

		System.out.println(file.getName());
		System.out.println(file.getSize());
		System.out.println(file.getResource());
		System.out.println("----------------");
		System.out.println("partNumber: "+ partNumber);
		System.out.println("----------------");
		System.out.println(authHeader);
		return fileUploadService.uploadItemFile(authHeader, partNumber, productId, caNumber, fileType, file,mode);
	}
	
	@PostMapping("/multiUploadFile1")
	public FileUploadResponse multiUploadFile1(@RequestBody MultiFileUploadRequestDTO data)
			throws IOException, JSONException, org.json.simple.parser.ParseException, UnsupportedOperationException, org.json.JSONException, URISyntaxException {
		return null;
//		return fileUploadService.uploadItemFile(authHeader, partNumber, productId, caNumber, fileType, file,mode);
	}
	
	@PostMapping("/multiUploadFile")
	public FileUploadResponse[] multiUploadFile(
			@RequestParam("authToken") String authHeader,
			@RequestParam("file") MultipartFile[] file,
		    @RequestParam("partNumber") String[] partNumber,
		    @RequestParam("productId") String productId,
		    @RequestParam("caNumber") String caNumber,
		    @RequestParam("fileType") String[] fileType,
		    @RequestParam("mode") String mode
		  
		)
			throws IOException, JSONException, org.json.simple.parser.ParseException, UnsupportedOperationException, org.json.JSONException, URISyntaxException {
		System.out.println("Inside multiUploadFile");
		System.out.println(authHeader);
		System.out.println(productId+" "+mode);
		for(int i=0;i<partNumber.length;i++) {
//			System.out.println(file[i].getOriginalFilename());
			System.out.println(partNumber[i]);
			System.out.println(fileType[i]);
			System.out.println(file[i].getName());
			System.out.println(file[i].getSize());
			System.out.println(file[i].getResource());
			System.out.println(file[i].getOriginalFilename());
		}
		return fileUploadService.uploadMultiFile(authHeader, partNumber, productId, caNumber, fileType, file, mode);
		
	}
	
	@ApiOperation("Get multiple file upload excel list")
	@PostMapping("exportToExcel")
	private ResponseEntity<byte[]> exportToExcel(@RequestBody MultiUploadResponseExcelDTO[] dto)
			throws BusinessException, ParseException{
		//return ResponseUtility.generateResponse(erdService.getErdHomeErrors(dto), HttpStatus.OK);
		try {
			
			byte[] in = fileUploadService.exportToExcel(dto);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=FileUploadReport.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	} 
}
