package com.speedweb.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.dtoprojection.IOneSourceUserData;
import com.speedweb.backend.dtoprojection.IProductListDTO;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestNewConfiguration;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.service.INewConfigurationService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("newConfigurationController")
@ApiOperation(value = "API List for New Configuration ID Support Screen")
public class NewConfigurationController {
	@Autowired
	INewConfigurationService newConfigurationService;
	
	@ApiOperation(value = "Get Product Listing")
	@PostMapping("getProductListingBywwid")
	public ResponseEntity<CommonResponse<List>> getProductListingBywwid(@RequestBody RequestStringDTO wwid)
			throws BusinessException {
		return ResponseUtility.generateResponse(newConfigurationService.getProductListingBywwid(wwid.getStrParam()), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get Product Listing")
	@PostMapping("getProductListing")
	public ResponseEntity<CommonResponse<List>> getProductListing()
			throws BusinessException {
		return ResponseUtility.generateResponse(newConfigurationService.getProductListing(), HttpStatus.OK);
	}
	
	//getProductSummaryList()
		@ApiOperation(value = "Get Product Summary")
		@PostMapping("getProductSummaryList")
		public ResponseEntity<CommonResponse<List<IProductListDTO>>> getProductSummaryList()
				throws BusinessException {
			return ResponseUtility.generateResponse(newConfigurationService.getProductSummaryList(), HttpStatus.OK);
		}
	//getProductByWWID()
		@ApiOperation(value = "Get Product by Wwid")
		@PostMapping("getProductByWWID")
		public ResponseEntity<CommonResponse<List<IProductListDTO>>> getProductByWWID(@RequestBody RequestStringDTO wwid)
				throws BusinessException{
			return ResponseUtility.generateResponse(newConfigurationService.getProductByWWID(wwid.getStrParam()), HttpStatus.OK);
		}
		
		
		@ApiOperation(value = "Get Producta by Wwid for File upload")
		@PostMapping("getProductsForFileUpload")
		public ResponseEntity<CommonResponse<List<IProductListDTO>>> getProductsForFileUpload(@RequestBody RequestStringDTO wwid)
				throws BusinessException{
			return ResponseUtility.generateResponse(newConfigurationService.getProductsForFileUpload(wwid.getStrParam()), HttpStatus.OK);
		}
		
		@ApiOperation(value = "Get Producta by Wwid for Service download")
		@PostMapping("getProductsForServiceDownload")
		public ResponseEntity<CommonResponse<List<IProductListDTO>>> getProductsForServiceDownload(@RequestBody RequestStringDTO wwid)
				throws BusinessException{
			return ResponseUtility.generateResponse(newConfigurationService.getProductsForServiceDownload(wwid.getStrParam()), HttpStatus.OK);
		}
		
		@PostMapping("getProductCompliance")
		public ResponseEntity<CommonResponse<String>> getProductCompliance(@RequestBody RequestStringDTO productID) throws BusinessException{
			System.out.println(productID.getStrParam());
			String productCompliance=newConfigurationService.getProductCompliance(productID.getStrParam());
			System.out.println("Product compliance is "+productCompliance);
			return ResponseUtility.generateResponse(productCompliance,HttpStatus.OK);
		}
		
		//getFileTypeList()
		@ApiOperation(value="Get File Type")
		@GetMapping("getFileTypeList")
		public ResponseEntity<CommonResponse<List<String>>> getFileTypeList()
				throws BusinessException{
			return ResponseUtility.generateResponse(newConfigurationService.getFileTypeList(), HttpStatus.OK);
		}
		

	@ApiOperation(value = "Get ECM Code Prefix and Configuration")
	@PostMapping("getEcmCodeAndConfiguration")
	public ResponseEntity<CommonResponse<List>> getEcmCodeAndConfiguration(@RequestBody RequestStringDTO productId)
			throws BusinessException {
		return ResponseUtility.generateResponse(newConfigurationService.getECMAndConfigByProductId(productId.getStrParam()), HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "Get Product Contact by Product Id")
	@PostMapping("getRoleinfoByproductid")
	public ResponseEntity<CommonResponse<List>> getRoleinfoByproductid(@RequestBody RequestStringDTO productId)
			throws BusinessException {
		return ResponseUtility.generateResponse(newConfigurationService.getRoleinfoByproductid(productId.getStrParam()), HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "Get User Details By WWID")
	@PostMapping("getUserDetailsByWWID")
	public ResponseEntity<CommonResponse<IOneSourceUserData>> getUserDetailsByWWID(@RequestBody RequestStringDTO wwid)
			throws BusinessException {
		return ResponseUtility.generateResponse(newConfigurationService.getUserDetailsByWWID(wwid.getStrParam()), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Insert New Configuration")
	@PostMapping("saveNewConfiguration")
	public ResponseEntity<CommonResponse<ApiResponse>> saveNewConfiguration(@RequestBody RequestNewConfiguration newConfiguration)
			throws BusinessException {
		return ResponseUtility.generateResponse(newConfigurationService.saveNewConfiguration(newConfiguration), HttpStatus.OK);
	}


}
