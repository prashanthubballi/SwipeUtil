package com.speedweb.backend.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestActivePartNumberReport;
import com.speedweb.backend.responseObject.ActivePartNumberReportResponse;
import com.speedweb.backend.service.IActivePartNumberReportService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("activePartNoReportContoller")
@ApiOperation(value = "API List for Active ECM Part Number Report")
public class ActivePartNumberReportController {
	 
	@Autowired
	IActivePartNumberReportService activeReportService;
	
	@ApiOperation(value = "Get Active ECM Hardware Report")
	@PostMapping("getActivePartNumberReport")
	public ResponseEntity<CommonResponse<ActivePartNumberReportResponse>> getActivePartNumberReport(@RequestBody RequestActivePartNumberReport dto)
			throws BusinessException {
		return ResponseUtility.generateResponse(activeReportService.getActivePartNumberReport(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Export Active ECM Hardware Report")
	@PostMapping("exportToExcel")
	private ResponseEntity<byte[]> exportToExcel(HttpServletResponse response,
			@RequestBody RequestActivePartNumberReport dto) throws IOException {
		try {
			dto.currentPage = 0;
			dto.pageSize = Integer.MAX_VALUE;
			ActivePartNumberReportResponse responseObject = activeReportService.getActivePartNumberReport(dto);
			byte[] in = activeReportService.getActivePartNumberReportToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ActivePartNoReport.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
