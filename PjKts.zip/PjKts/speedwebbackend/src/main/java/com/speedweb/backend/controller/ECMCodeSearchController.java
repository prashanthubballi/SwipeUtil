package com.speedweb.backend.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.dtoprojection.TEcmCodeSearchResponseDTO;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestProductReleaseDTO;
import com.speedweb.backend.service.IEcmCodeSearchService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("ecmCodeSearchController")
@ApiOperation(value = "API List for ECM Code Search Screen")
public class ECMCodeSearchController {

	@Autowired
	IEcmCodeSearchService ecmCodeSearchService;

	@Autowired
	HttpServletRequest request;

	@ApiOperation(value = "ECM Code Search")
	@PostMapping("ecmCodeSearch")
	public ResponseEntity<CommonResponse<TEcmCodeSearchResponseDTO>> getEcmCodeSearchData(
			@RequestBody RequestProductReleaseDTO ecmCodeSearchDto) throws BusinessException {
		HttpSession session = request.getSession(true);
		ecmCodeSearchDto.setSessionId(session.getId().toLowerCase());
		return ResponseUtility.generateResponse(ecmCodeSearchService.getEcmCodeSearch(ecmCodeSearchDto), HttpStatus.OK);
	}

	@ApiOperation(value = "Pagination for Part History")
	@PostMapping("partHistoryPagination")
	public ResponseEntity<CommonResponse<TEcmCodeSearchResponseDTO>> partHistoryPagination(
			@RequestBody RequestProductReleaseDTO partHistPagination) throws BusinessException {
		return ResponseUtility.generateResponse(ecmCodeSearchService.partHistoryPagination(partHistPagination),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Pagination for Option History")
	@PostMapping("optionHistoryPagination")
	public ResponseEntity<CommonResponse<TEcmCodeSearchResponseDTO>> optionHistoryPagination(
			@RequestBody RequestProductReleaseDTO optionHistPagination) throws BusinessException {
		return ResponseUtility.generateResponse(ecmCodeSearchService.optionHistoryPagination(optionHistPagination),
				HttpStatus.OK);
	} 
	
	@ApiOperation(value = "Export ECM Code Search Details")
	@PostMapping("exportToExcelEcmCodeSearch")
	private ResponseEntity<byte[]> exportToExcelEcmCodeSearchDetails(@RequestBody RequestProductReleaseDTO dto) throws IOException {
		try {
			dto.setPagenumber(0);
			dto.setPagesize(Integer.MAX_VALUE);
			dto.setOptionspagenumber(0);
			dto.setOptionspagesize(Integer.MAX_VALUE);
			dto.setPartspagenumber(0);
			dto.setPartspagesize(Integer.MAX_VALUE);
			HttpSession session = request.getSession(true);
			dto.setSessionId(session.getId().toLowerCase());
			byte[] in = ecmCodeSearchService.exportToExcelEcmCodeSearch(dto);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ecmCodeSearch.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
