package com.speedweb.backend.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.dtoprojection.IOptionStructureSearchDTO;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.service.IOptionStructureSearchService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("optionStructureSearchController")
@ApiOperation(value = "API List for Option Structure Search Screen")
public class OptionStructureSearchController {
	

	@Autowired
	IOptionStructureSearchService optionStructureService;
	
	@Autowired
	HttpServletRequest request;
	
	@ApiOperation(value = "Get Option Structure Details by Option Number")
	@PostMapping("getOptionStructureDetails")
	public ResponseEntity<CommonResponse<List<IOptionStructureSearchDTO>>> getOptionStructureDetails(@RequestBody RequestStringDTO optionNumber)
			throws BusinessException {
		return ResponseUtility.generateResponse(optionStructureService.getOptionStructureDetails(optionNumber.getStrParam()), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get Option Numbers List from T_OPTION_STRUCTURE")
	@PostMapping("getOptionNumbersList")
	public ResponseEntity<CommonResponse<List<String>>> getOptionNumbersList(@RequestBody RequestStringDTO optionNumber)
			throws BusinessException {
		return ResponseUtility.generateResponse(optionStructureService.getOptionNumbersList(optionNumber.getStrParam()), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Export Option Structure Search Details")
	@PostMapping("exportOptionStructureDetails")
	private ResponseEntity<byte[]> exportOptionStructureDetails(HttpServletResponse response,
			@RequestBody RequestStringDTO optionNumber) throws IOException {
		try {
			List<IOptionStructureSearchDTO> responseObject  = optionStructureService.getOptionStructureDetails(optionNumber.getStrParam());
			// System.out.println("Reached here - 1");
			byte[] in = optionStructureService.productReleaseToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=optionStructure.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
