package com.speedweb.backend.common;

import lombok.Data;

@Data
public class ParameterStoreRequestLambdaDTO {
	public String functionName;
	public ParameterStoreRequestpayLoad payload;

}
