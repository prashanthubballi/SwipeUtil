package com.speedweb.backend.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestCalibrationImpacted;
import com.speedweb.backend.responseObject.CalibrationImpactedResponse;
import com.speedweb.backend.service.CalibrationImpactedService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("calibrationimpacted")
@ApiOperation(value = "API List for Calibration Impacted Due to Engineeering Release")
public class CalibrationImpactedController {

	@Autowired
	CalibrationImpactedService calibrationImpactedService;

	@Autowired
	HttpServletRequest request;

	@ApiOperation("Get Option Obsoleted")
	@PostMapping("getOptionObsoleted")
	private ResponseEntity<CommonResponse<CalibrationImpactedResponse>> getSearchData(
			@RequestBody RequestCalibrationImpacted req) throws BusinessException {
		HttpSession session = request.getSession(true);
		req.setSessionId(session.getId().toLowerCase());
		if (req.getType().equalsIgnoreCase("obsoleted")) {
			return ResponseUtility.generateResponse(calibrationImpactedService.getOptionObsoleted(req), HttpStatus.OK);
		} else if (req.getType().equalsIgnoreCase("partNumber")) {
			return ResponseUtility.generateResponse(calibrationImpactedService.getPartNumberObsoleted(req),
					HttpStatus.OK);
		} else {
			return ResponseUtility.generateResponse(calibrationImpactedService.brokenCompatibilityDetails(req),
					HttpStatus.OK);
		}
	}

	@ApiOperation("Export to Excel")
	@PostMapping("exportToExcel")
	private ResponseEntity<byte[]> exportToExcel(@RequestBody RequestCalibrationImpacted req) throws BusinessException {

		try {
			
			byte[] in = calibrationImpactedService.calibrationImpactedForExport(req);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=productRelease.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

}
