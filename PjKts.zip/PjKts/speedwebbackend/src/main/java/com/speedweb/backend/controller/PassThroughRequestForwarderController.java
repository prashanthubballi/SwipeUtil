package com.speedweb.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.service.impl.PassThroughRequestForwarderServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("passThroughRequestForwarder")
@ApiOperation(value = "API List for PassThrough Request Forwarder")
public class PassThroughRequestForwarderController {
	
	@Autowired
	PassThroughRequestForwarderServiceImpl passThroughRequestForwarder;

	@ApiOperation(value="PassThrough Request Forwarder call")
	@PostMapping("requestForwarder")
	public ResponseEntity<CommonResponse<ApiResponse>> forwardCall(@RequestParam String queryParam, @RequestBody Object request) throws BusinessException, JsonProcessingException {
		return ResponseUtility.generateResponse(passThroughRequestForwarder.callApi(queryParam, request), HttpStatus.OK);
	}
}
