package com.speedweb.backend.controller;

import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.dtoprojection.ICMIUserDetails;
import com.speedweb.backend.exception.BadRequestException;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.responseObject.LoginUser;
import com.speedweb.backend.service.impl.CmiUserService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("appController")
@ApiOperation(value = "Application controller API List")
@CrossOrigin
public class AppController {

	private Logger logger = LogManager.getLogger(AppController.class);
	public static String SPEED_DS_JNDI_NAME = "SPEED_DS_JNDI_NAME";
	public static Properties testops_props = null;
	@Autowired
	HttpServletRequest request;
	@Autowired
	LoginUser loginUser;

	@Autowired
	CmiUserService cmiUserService;

	@GetMapping("/loginuser")
	private ResponseEntity<CommonResponse<LoginUser>> ldaplogin() {
		System.out.println("Login check");
		HttpSession session = request.getSession(true);

		String strval = "";
		System.out.println(session);
		if (session == null) {
			System.out.println("Session is null");
			logger.info("Session is null");
		}else if (session != null) {
			strval = "S";
			System.out.println("Sesion UID: " + session.getAttribute("userid"));
			System.out.println("ReplacementRoleValue: " + session.getAttribute("ReplacementRoleValue"));
			System.out.println("adminFlag: " + session.getAttribute("adminFlag"));
			
			logger.info("Sesion UID: " + session.getAttribute("userid"));

			if (session.getAttribute("UID") != null) {
				loginUser.setUserid(session.getAttribute("userid").toString().toUpperCase());
				loginUser.setFirstname(session.getAttribute("firstname").toString());
				loginUser.setLastname(session.getAttribute("lastname").toString());
				loginUser.setFullname(request.getAttribute("firstname") + " " + request.getAttribute("lastname"));
			} else {
				strval = "H";
				System.out.println("Header UID: " + request.getHeader("userid"));
				logger.info("Header UID: " + request.getHeader("userid"));
				if (request.getHeader("userid") != null) {
					loginUser.setUserid(request.getHeader("userid").toUpperCase());
					loginUser.setLastname(request.getHeader("lastname"));
					loginUser.setFirstname(request.getHeader("firstname"));
					loginUser.setFullname(request.getHeader("firstname") + " " + request.getHeader("lastname"));
				}
			}
			try {
				try {
					checkAcessRolesForMenu();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			} catch (BusinessException e) {

				e.printStackTrace();
			}
		}
		return ResponseUtility.generateResponse(loginUser, HttpStatus.OK); // (true, strval, loginUser);
	}

	private void checkAcessRolesForMenu() throws SQLException, BusinessException {

		logger.info("inside checkAcessRolesForMenu");
		String userID = loginUser.getUserid();
//		if(userID == null) {
//		  userID = "RW105";
//		}
		
		if(userID == null) {
			
//			loginUser.setAdmin(1);
//			loginUser.setNewPlantCustomPartListAccess(1);
//			loginUser.setReplacementRoleValue(1);
			System.out.println("userID is null \n adminAccess false, replacementRoleAccess false, "
					+ "newPlantCustomPartListAccess false");
			logger.info("userID is null \n adminAccess false, replacementRoleAccess false, "
					+ "newPlantCustomPartListAccess false");
			return;
		}			
		
		userID = userID.toUpperCase();
		int adminAccessCount = cmiUserService.getAdminAccess(userID);
		loginUser.setAdmin(adminAccessCount);
		int replacementCalAcessCount = cmiUserService.getReplacementCalAccess(userID);
		loginUser.setReplacementRoleValue(replacementCalAcessCount);
		int newPlantAccessCount = cmiUserService.getNewPlantAccess(userID);
		loginUser.setNewPlantCustomPartListAccess(newPlantAccessCount);
		logger.info("adminAccess " + (adminAccessCount>0));
		logger.info("replacementRoleAccess " + (replacementCalAcessCount>0));
		logger.info("newPlantCustomPartListAccess " + (newPlantAccessCount>0));
		System.out.println("adminAccess " + (adminAccessCount>0));
		System.out.println("replacementRoleAccess " + (replacementCalAcessCount>0));
		System.out.println("newPlantCustomPartListAccess " + (newPlantAccessCount>0));
	}
	

	@ApiOperation(value = "Get logged in cmi user details")
	@PostMapping("getcmiuserdetails")
	public ResponseEntity<CommonResponse<ICMIUserDetails>> getCmiUsersDetails(@RequestBody RequestStringDTO wwid)
			throws BusinessException {
		return ResponseUtility.generateResponse(cmiUserService.getCmiUserDetails(wwid.getStrParam()), HttpStatus.OK);
	}
	
	@ApiOperation(value = "verifyWwidFormat")
	@PostMapping("/verifyWwidFormat")
	public ResponseEntity<CommonResponse<ApiResponse>> verifyWwidFormat(@RequestBody RequestStringDTO wwid
			) throws BadRequestException {
		ApiResponse response = cmiUserService.verifyWwidFormat(wwid);
		return ResponseUtility.generateResponse(response, HttpStatus.OK);
						
	}
}
