package com.speedweb.backend.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.dtoprojection.IDailyERUpdateDTO;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.DailyReportsSRReponse;
import com.speedweb.backend.service.IDailyReportsService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("dailyReportsController")
@ApiOperation(value = "API List for Daily Reports Screen")
public class DailyReportsController {
	
	@Autowired
	IDailyReportsService service;
	
	@Autowired
	HttpServletRequest request;
	
	@ApiOperation(value = "Get ER Details by date")
	@PostMapping("getDailyERUpdate")
	public ResponseEntity<CommonResponse<List<IDailyERUpdateDTO>>> getDailyERUpdate(@RequestBody RequestStringDTO toDate)
			throws BusinessException {
		return ResponseUtility.generateResponse(service.getDailyERUpdate(toDate.getStrParam()), HttpStatus.OK);
	}
	@ApiOperation(value = "Get SR Details by date")
	@PostMapping("getDailySRUpdate")
	public ResponseEntity<CommonResponse<DailyReportsSRReponse>> getDailySRUpdate(@RequestBody RequestStringDTO toDate)
			throws BusinessException, ParseException {
		return ResponseUtility.generateResponse(service.getDailySRUpdate(toDate.getStrParam()), HttpStatus.OK);
	}
	@ApiOperation(value = "Export ER Search Details")
	@PostMapping("exportToExcelbyER")
	private ResponseEntity<byte[]> exportToExcelbyER(HttpServletResponse response,
			@RequestBody RequestStringDTO toDate) throws IOException {
		try {
			List<IDailyERUpdateDTO> responseObject  = service.getDailyERUpdate(toDate.getStrParam());
			// System.out.println("Reached here - 1");
			byte[] in = service.dailyERToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=dailyERReport.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
	@ApiOperation(value = "Export SR Search Details")
	@PostMapping("exportToExcelbySR")
	private ResponseEntity<byte[]> exportToExcelbySR(HttpServletResponse response,
			@RequestBody RequestStringDTO toDate) throws IOException {
		try {
			DailyReportsSRReponse responseObject  = service.getDailySRUpdate(toDate.getStrParam());
			// System.out.println("Reached here - 1");
			byte[] in = service.dailySRToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=dailyERReport.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
