package com.speedweb.backend.controller;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestCVNReportDTO;
import com.speedweb.backend.responseObject.ResponseCVNReportDTO;
import com.speedweb.backend.service.ICVNReportService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("cvnReportController")
@ApiOperation("API List for CVN Report")
public class CVNReportController {

	@Autowired
	ICVNReportService cvnService;
	
	@ApiOperation("Get CVN Reports")
	@PostMapping("getCVNReport")
	private ResponseEntity<CommonResponse<ResponseCVNReportDTO>> getSearchData(
			@RequestBody RequestCVNReportDTO dto) throws BusinessException, ParseException{
		return ResponseUtility.generateResponse(cvnService.getCVNReports(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Export CVN Report")
	@PostMapping("exportCVNReport")
	private ResponseEntity<byte[]> exportCVNReport(HttpServletResponse response,
			@RequestBody RequestCVNReportDTO dto) throws IOException {
		try {
			dto.setCurrentPage(0);
			dto.setPageSize(Integer.MAX_VALUE);
			ResponseCVNReportDTO responseObject = cvnService.getCVNReports(dto);
			byte[] in = cvnService.cvnReportToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=cvnReport.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
}
