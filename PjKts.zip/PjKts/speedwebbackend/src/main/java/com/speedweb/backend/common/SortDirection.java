package com.speedweb.backend.common;

public enum SortDirection {
	ASC,
	DESC
}
