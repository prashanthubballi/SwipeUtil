package com.speedweb.backend.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestInactiveCalReportDTO;
import com.speedweb.backend.responseObject.ResponseInactiveCalReportDTO;
import com.speedweb.backend.service.IInactiveCalReportService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("inactiveCalReportController")
@ApiOperation("API List for Inactive Cal Report")
public class InactiveCalReportController {
	
	@Autowired
	IInactiveCalReportService service;
	
	@ApiOperation("Get Inactive Cal Reports between Dates")
	@PostMapping("getInactiveCalReport")
	private ResponseEntity<CommonResponse<ResponseInactiveCalReportDTO>> getSearchData(
			@RequestBody RequestInactiveCalReportDTO obj) throws BusinessException{
		return ResponseUtility.generateResponse(service.getInactiveCalReports(obj), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Export Inactive Cal Report")
	@PostMapping("exportInactiveCalReport")
	private ResponseEntity<byte[]> exportInactiveCalReport(HttpServletResponse response,
			@RequestBody RequestInactiveCalReportDTO dto) throws IOException {
		try {
			dto.setCurrentPage(0);
			dto.setPageSize(Integer.MAX_VALUE);
			ResponseInactiveCalReportDTO responseObject = service.getInactiveCalReports(dto);
			byte[] in = service.inactiveCalReportToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=inactiveCalReport.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
}