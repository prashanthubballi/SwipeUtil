package com.speedweb.backend.controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestCNNumberSearchDTO;
import com.speedweb.backend.request.RequestServiceDownloadDTO;
import com.speedweb.backend.responseObject.CNNumberSearchDetailsResponseDTO;
import com.speedweb.backend.service.ICNNumberSearchService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("cnNumberSearchController")
@ApiOperation(value = "API List for CN Number Search Screen")
public class CNNumberSearchController {

	@Autowired
	ICNNumberSearchService cnNumberSearchService;
	
	@ApiOperation("Get CN Number Search Details")
	@PostMapping("cnNumberSearch")
	public ResponseEntity<CommonResponse<CNNumberSearchDetailsResponseDTO>> getCNSearchData(@RequestBody RequestCNNumberSearchDTO req){
		return ResponseUtility.generateResponse(cnNumberSearchService.getCNSearchDetails(req), HttpStatus.OK);
	}
	
	@ApiOperation("Get Service download excel")
	@PostMapping("exportToExcel")
	private ResponseEntity<byte[]> exportToExcel(@RequestBody RequestCNNumberSearchDTO dto)
			throws BusinessException, ParseException{
		try {
			byte[] in = cnNumberSearchService.exportToExcel(dto);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=FileUploadReport.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
