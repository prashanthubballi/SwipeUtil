package com.speedweb.backend.common;

import lombok.Data;

@Data
public class ScaleoutLambdaPayload {

	private String guid;
}
