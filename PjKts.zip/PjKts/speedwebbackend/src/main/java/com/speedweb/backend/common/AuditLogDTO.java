package com.speedweb.backend.common;

import lombok.Data;

@Data
public class AuditLogDTO {
	public String correlationId;
	public String appId;
	public String appName;
	public String name;
	public String upn;
	public String country;
	public String ipAddress;
	public String apiName;
	public String dataName;
	public String data;
}
