package com.speedweb.backend.controller;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestPartNumberRevisionHistoryDTO;
import com.speedweb.backend.responseObject.PartNumberRevisionHistoryResponse;
import com.speedweb.backend.service.IPartNumberRevisionHistoryService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("partNumberRevisonHistoryController")
@ApiOperation(value = "API List for Part Number Revison History Request Screen")
public class PartNumberRevisionHistoryController {
	
	@Autowired
	IPartNumberRevisionHistoryService partNumberHistoryService;
	
	@ApiOperation(value = "Get Part Number Revision History by Part Number")
	@PostMapping("getPartNumber")
	public ResponseEntity<CommonResponse<PartNumberRevisionHistoryResponse>> getPartNumberRevisonHistoryDetails(@RequestBody RequestPartNumberRevisionHistoryDTO dto )
			throws BusinessException, ParseException {
		return ResponseUtility.generateResponse(partNumberHistoryService.getPartNumberHistoryDetils(dto), HttpStatus.OK);
	}

	
	@ApiOperation(value = "Export Option Structure Search Details")
	@PostMapping("exportPartNumberRevisionHistoryDetails")
	private ResponseEntity<byte[]> exportPartNumberRevisionHistoryDetails(HttpServletResponse response,
			@RequestBody RequestPartNumberRevisionHistoryDTO dto) throws IOException {
		try {
			PartNumberRevisionHistoryResponse responseObject = partNumberHistoryService.getPartNumberHistoryDetils(dto);
			byte[] in = partNumberHistoryService.partNumberRevisionHistoryToExcel(responseObject);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=productRelease.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
