package com.speedweb.backend.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.CalibrationRequestDTO;
import com.speedweb.backend.request.RequestCalibrationRequest;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.ApiResponse;
import com.speedweb.backend.responseObject.CalibrationRequestResponseDTO;
import com.speedweb.backend.responseObject.CalibrationResponseDTO;
import com.speedweb.backend.service.ICalibrationRequestService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("calibrationRequestController")
@ApiOperation(value = "API List for Calibration Request screen")
public class CalibrationRequestController {
	
	@Autowired
	ICalibrationRequestService calibrationService;
	
	@ApiOperation(value = "Get Plant List by wwid")
	@PostMapping("getPlantListbyWWID")
	public ResponseEntity<CommonResponse<List>> getPlantListbyWWID(@RequestBody RequestStringDTO wwid)
	throws BusinessException
	{
		return ResponseUtility.generateResponse(calibrationService.getPlantListbyWWID(wwid.getStrParam()), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get Grid data for Calibration Request")
	@PostMapping("getcalibGridData")
	public ResponseEntity<CommonResponse<CalibrationResponseDTO>> getcalibGridData(@RequestBody CalibrationRequestDTO dto)
	throws BusinessException
	{
		return ResponseUtility.generateResponse(calibrationService.getcalibGridData(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Check In Progress Status for calibration Request")
	@PostMapping("checkInProgressCalibration")
	public ResponseEntity<CommonResponse<ApiResponse>>checkInProgressCalibration(@RequestBody RequestStringDTO plantId)
	throws BusinessException
	{
		return ResponseUtility.generateResponse(calibrationService.inprogressCalibration(plantId.getStrParam()), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get Product ID based on plant id")
	@PostMapping("getproductIdList")
	public ResponseEntity<CommonResponse<List>> getProductId(@RequestBody RequestStringDTO plantId)
	throws BusinessException
	{
		return ResponseUtility.generateResponse(calibrationService.getProductId(plantId.getStrParam()), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get ECM code for selected product")
	@PostMapping("getecmCodeList")
	public ResponseEntity<CommonResponse<List>> getecmCode(@RequestBody RequestCalibrationRequest dto)
	throws BusinessException
	{
		return ResponseUtility.generateResponse(calibrationService.getecmCode(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Delete selected product id request")
	@PostMapping("delete")
	public ResponseEntity<CommonResponse<CalibrationRequestResponseDTO>> deleteRequest(@RequestBody RequestCalibrationRequest dto)
	throws BusinessException
	{
		return ResponseUtility.generateResponse(calibrationService.deleteRequest(dto), HttpStatus.OK);
	}
	
	
	
	@ApiOperation(value = "add new product id")
	@PostMapping("addNew")
	public ResponseEntity<CommonResponse<CalibrationRequestResponseDTO>> addNewCalibData(@RequestBody RequestCalibrationRequest dto)
	throws BusinessException
	{
		return ResponseUtility.generateResponse(calibrationService.addNewCalibData(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Update request")
	@PostMapping("updateRequest")
	public ResponseEntity<CommonResponse<CalibrationRequestResponseDTO>> updateRequest(@RequestBody RequestCalibrationRequest dto)
	throws BusinessException , SQLException
	{
		return ResponseUtility.generateResponse(calibrationService.updateCalibData(dto), HttpStatus.OK);
	}
	
	

	

}
