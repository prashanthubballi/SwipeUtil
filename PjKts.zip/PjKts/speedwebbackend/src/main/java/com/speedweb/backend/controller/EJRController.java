package com.speedweb.backend.controller;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.speedweb.backend.common.CommonResponse;
import com.speedweb.backend.common.ResponseUtility;
import com.speedweb.backend.dtoprojection.INotesDetails;
import com.speedweb.backend.dtoprojection.IProductIdAndStatusDTO;
//import com.speedweb.backend.dtoprojection.NotesDetails;
import com.speedweb.backend.exception.BusinessException;
import com.speedweb.backend.request.RequestCompatibiliyEJRO2DTO;
import com.speedweb.backend.request.RequestEjrGhgStatusDetails;
import com.speedweb.backend.request.RequestEjrNotesDetails;
import com.speedweb.backend.request.RequestEjrStructureDetails;
import com.speedweb.backend.request.RequestEjrtemDTO;
import com.speedweb.backend.request.RequestItemEJRDTO;
import com.speedweb.backend.request.RequestStringDTO;
import com.speedweb.backend.responseObject.CompatabilityEJRDTO;
import com.speedweb.backend.responseObject.CompatibilityEJRLevel1ResponseDTO;
import com.speedweb.backend.responseObject.CompatibilityEJRLevel2ResponseDTO;
import com.speedweb.backend.responseObject.CompatibilityEJRResponseDTO;
import com.speedweb.backend.responseObject.EJRCalibrationImpactETRResponse;
import com.speedweb.backend.responseObject.EJRCalibrationImpactReplacementResponse;
import com.speedweb.backend.responseObject.EJRCalibrationImpactResponse;
import com.speedweb.backend.responseObject.EJRCompatibilityViolationResponse;
import com.speedweb.backend.responseObject.EJRGhgListResponse;
import com.speedweb.backend.responseObject.EJRGhgStatusListResponse;
import com.speedweb.backend.responseObject.EJRItemResponse;
import com.speedweb.backend.responseObject.EJRNotesListResponse;
import com.speedweb.backend.responseObject.EJRStructureDetailsResponse;
import com.speedweb.backend.responseObject.EJRStructureListResponse;
import com.speedweb.backend.responseObject.EjrNotesDetailsWithProdIdResponse;
import com.speedweb.backend.responseObject.TEJRResponse;
import com.speedweb.backend.service.IEJRSearchService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("ejrController")
@ApiOperation(value = "API List for ECM Code Search Screen")
public class EJRController {
	private static Logger log = LogManager.getLogger(EJRController.class);

	@Autowired
	IEJRSearchService ejrSearchService;

	@ApiOperation(value = "EJR Single ER Number Search")
	@PostMapping("singleEJRSearch")
	public ResponseEntity<CommonResponse<TEJRResponse>> singleEJRSearch(@RequestBody RequestStringDTO erNumber)
			throws BusinessException {
		log.info("Inside singleejrsearch contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.singleEJRSearch(erNumber.getStrParam()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Notes Listing")
	@PostMapping("getNotesListing")
	public ResponseEntity<CommonResponse<EJRNotesListResponse>> getNotesListing(@RequestBody RequestEjrtemDTO dto)
			throws BusinessException {
		log.info("Inside getNotesListing contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getNotesListing(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Notes Listing")
	@PostMapping("getNotesDetailsListing")
	public ResponseEntity<CommonResponse<List>> getNotesDetailsListing(@RequestBody RequestEjrNotesDetails notesDetails)
			throws BusinessException {
		log.info("Inside getNotesDetailsListing contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getNotesDetailsListing(notesDetails), HttpStatus.OK);
	}

	@ApiOperation(value = "Compatibility Level1 data")
	@PostMapping("getCompatibilityLevel1Data")
	private ResponseEntity<CommonResponse<CompatibilityEJRLevel1ResponseDTO>> getCompatibilityLevel1Data(
			@RequestBody CompatabilityEJRDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(ejrSearchService.getCompatibilityLevel1Data(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Direct Compatibility level2 data")
	@PostMapping("getDirectComptLevel2Data")
	private ResponseEntity<CommonResponse<CompatibilityEJRResponseDTO>> getDirectComptLevel2Data(
			@RequestBody CompatabilityEJRDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(ejrSearchService.getDirectComptLevel2DataNew(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Compatibility drop down")
	@PostMapping("getCompatDropdown")
	private ResponseEntity<CommonResponse<CompatibilityEJRResponseDTO>> getCompatDropdown(
			@RequestBody CompatabilityEJRDTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(ejrSearchService.getCompatDropdownNew(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Compatibility level2 data")
	@PostMapping("getCompatibilityLevel2data")
	private ResponseEntity<CommonResponse<CompatibilityEJRLevel2ResponseDTO>> getCompatibilityLevel2data(
			@RequestBody RequestCompatibiliyEJRO2DTO dto) throws BusinessException {
		return ResponseUtility.generateResponse(ejrSearchService.getCompatibilityLevel2data(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Structure Listing")
	@PostMapping("getStructureListing")
	public ResponseEntity<CommonResponse<EJRStructureListResponse>> getStructureListing(
			@RequestBody RequestEjrtemDTO dto) throws BusinessException {
		log.info("Inside EJR Structure Listing controller function");
		return ResponseUtility.generateResponse(ejrSearchService.getStructureListing(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Structure Details")
	@PostMapping("getStructureDetails")
	public ResponseEntity<CommonResponse<EJRStructureDetailsResponse>> getStructureDetails(
			@RequestBody RequestEjrStructureDetails structureDetails) throws BusinessException {
		log.info("Inside EJR Structure Details controller function");
		return ResponseUtility.generateResponse(ejrSearchService.getStructureDetails(structureDetails), HttpStatus.OK);
	}

	@ApiOperation(value = "Item Details")
	@PostMapping("getItemDetails")
	public ResponseEntity<CommonResponse<EJRItemResponse>> getItemsDetails(@RequestBody RequestEjrtemDTO dto)
			throws BusinessException {
		log.info("Inside getItemsDetails contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getItemsList(dto), HttpStatus.OK);
	}
	

	@ApiOperation(value = "Compatibility Violation Details")
	@PostMapping("getCombatibilityViolationDetails")
	public ResponseEntity<CommonResponse<EJRCompatibilityViolationResponse>> getCompatibilityViolationList(
			@RequestBody RequestEjrtemDTO dto) throws BusinessException {
		log.info("Inside getCompatibilityViolationList contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getCompatibilityViolationList(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Calibration Impact Impact Details")
	@PostMapping("getCIImpactList")
	public ResponseEntity<CommonResponse<EJRCalibrationImpactResponse>> getCIImpactList(
			@RequestBody RequestEjrtemDTO dto) throws BusinessException {
		log.info("Inside getCompatibilityViolationList contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getCIImpactList(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Calibration Impact ETR Impact Details")
	@PostMapping("getCIETRImpactList")
	public ResponseEntity<CommonResponse<EJRCalibrationImpactETRResponse>> getCIETRImpactList(
			@RequestBody RequestEjrtemDTO dto) throws BusinessException {
		log.info("Inside getCIETRImpactList contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getCIETRImpactList(dto), HttpStatus.OK);
	}

	@ApiOperation(value = "Calibration Impact Replacement Details")
	@PostMapping("getCIReplacementImpactList")
	public ResponseEntity<CommonResponse<EJRCalibrationImpactReplacementResponse>> getCIReplacementImpactList(
			@RequestBody RequestEjrtemDTO dto) throws BusinessException {
		log.info("Inside getCIReplacementImpactList contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getCIReplacementImpactList(dto), HttpStatus.OK);
	}
	
	//GHG Validation check
	@ApiOperation(value = "GHG Validation")
	@PostMapping("getGhgValidationDetails")
	public ResponseEntity<CommonResponse<EJRGhgListResponse>> getGhgValidationDetails(@RequestBody RequestEjrtemDTO dto)
			throws BusinessException {
		log.info("Inside getGhgValidationDetails contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getGhgValidationDetails(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "GHG Validation Check for Status")
	@PostMapping("getGhgStatusDetails")
	public ResponseEntity<CommonResponse<List>> getGhgStatusDetails(@RequestBody RequestEjrGhgStatusDetails dto)
			throws BusinessException {
		log.info("Inside getGhgStatusDetails contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getGhgStatusDetails(dto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "GHG Validation Check for Summary error link")
	@PostMapping("getGhgStatusDetailsForSummary")
	public ResponseEntity<CommonResponse<List>> getGhgStatusDetailsForSummary(@RequestBody RequestEjrGhgStatusDetails dto)
			throws BusinessException {
		log.info("Inside getGhgStatusDetailsForSummary contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getGhgStatusDetailsForSummary(dto), HttpStatus.OK);
	}
	
	//---------------------
	
	
	
//SINCE EMAIL FUNCTIONALITY IS NOT THERE WE COMMENTED THIS CODE

//	@ApiOperation(value = "Send Mail for Multiple EJR Details")
//	@PostMapping("MultipleEJR")
//	public ResponseEntity<CommonResponse<ApiResponse>> saveMultipleEJR(@RequestBody RequestMultipleEJRList dto )
//			throws BusinessException {		
//		return ResponseUtility.generateResponse(ejrSearchService.saveMultipleEJR(dto), HttpStatus.OK);
//	}
	
	@ApiOperation(value = "EJR Single or Multiple ER Number Search")
	@PostMapping("getMultipleEJRSearch")
	public ResponseEntity<CommonResponse<TEJRResponse>> getMultipleEJRSearch(@RequestBody RequestEjrtemDTO dto)
			throws BusinessException {
		dto.setCurrentPage(0);
		dto.setPageSize(Integer.MAX_VALUE);
		log.info("Inside singleejrsearch contoller function");
		return ResponseUtility.generateResponse(ejrSearchService.getMultipleEJRSearch(dto),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Export EJR Review All Details")
	@PostMapping("exportEjrReviewAll")
	private ResponseEntity<byte[]> exportEjrReviewAll(@RequestBody RequestEjrtemDTO dto) throws IOException {
		try {
			dto.setCurrentPage(0);
			dto.setPageSize(Integer.MAX_VALUE);
			byte[] in = ejrSearchService.exportEjrReviewAll(dto);
			HttpHeaders respHeaders = new HttpHeaders();
			respHeaders.setContentLength(in.length);
			respHeaders.setContentType(new MediaType("text", "json"));
			respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			respHeaders.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ejrReview.xlsx");
			return new ResponseEntity<byte[]>(in, respHeaders, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@ApiOperation(value = "Notes Details with ProductID")
	@PostMapping("getNotesDetailsListingWithProdID")
	public ResponseEntity<CommonResponse<EjrNotesDetailsWithProdIdResponse>> getNotesDetailsListingWithProdID(@RequestBody RequestEjrNotesDetails notesDetails)
			throws BusinessException {
		log.info("Inside getNotesDetailsListingWithProdID contoller function");
		EjrNotesDetailsWithProdIdResponse responseObj = new EjrNotesDetailsWithProdIdResponse();
		List<INotesDetails> notesDetailsList = ejrSearchService.getNotesDetailsListing(notesDetails);
		List<IProductIdAndStatusDTO> pIdAndStatusList = ejrSearchService.getProductIdsForNotesDetails(notesDetails);
		responseObj.setNotesDetailsList(notesDetailsList);
		if (pIdAndStatusList != null && pIdAndStatusList.size()>0) {
			responseObj.setProductId(pIdAndStatusList.get(0).getproductId());
			responseObj.setUpdatedStatus(pIdAndStatusList.get(0).getupdatedStatus());
		} else {
			responseObj.setProductId("NPD");
			responseObj.setUpdatedStatus(null);
		}
		return ResponseUtility.generateResponse(responseObj, HttpStatus.OK);
	}

}
