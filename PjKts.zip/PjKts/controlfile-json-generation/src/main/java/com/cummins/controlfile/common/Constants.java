package com.cummins.controlfile.common;

public interface Constants {
  String EXPORTTOEXCEL = "./exporttoexcel/";
  Long TEN_MINUTE_IN_NANO_SECOND = 60 * 10 * 1000L;
  String GENERIC_SUCCESS_MESSAGE = "success";
  String GENERIC_FAILURE_MESSAGE = "error";
  int PAGE_SIZE = 20;
  int HIGHLIGHT_SIZE = 100;
  String NOT_RELEASED = "Not Released";
  String RELEASED = "Released";
}
