package com.cummins.controlfile.request.dto;

public interface D1D2OptionDto {
  String getId();

  String getProductId();

  String getEcmCode();

  String getDDoption();

  String getOptionPrefix();

  String getMFGGroup();

  String getENGGroup();

  String getCOEGroup();

  String getOptionType();

}
