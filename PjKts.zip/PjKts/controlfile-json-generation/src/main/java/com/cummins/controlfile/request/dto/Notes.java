package com.cummins.controlfile.request.dto;

import lombok.Data;

@Data
public class Notes {
  private String desc;
  private String value;

}
