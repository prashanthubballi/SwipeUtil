package com.cummins.controlfile.service.util;

import com.cummins.controlfile.exception.BadRequestException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ParentChildUtil {
  // @Autowired
  // static TD1D2OptionRepository TD1D2OptionRepository;

  public File createFile(String FilePath) throws BadRequestException {
    File file = new File(FilePath);
    try {
      if (!file.exists()) {
        file.getParentFile().mkdir();
        file.createNewFile();
      }
    } catch (IOException e) {
      throw new BadRequestException("The system cannot find the path specified " + FilePath);
    }
    return file;
  }

  public void writeJsonFile(File file, String finalJson) throws BadRequestException {
    try( BufferedWriter writer = new BufferedWriter(new FileWriter(file));) {
      writer.write(finalJson);
    } catch (IOException e) {
      throw new BadRequestException(e.getMessage());
    }
  }

}
