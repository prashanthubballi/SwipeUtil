package com.cummins.controlfile.request.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class ParentClass implements Serializable {
  private static final long serialVersionUID = 1L;

  String productId;

  List<CalibrationDetails> calibrationDetails = new ArrayList<>();

  List<OptionNotes> optionNotes = new ArrayList<>();
  
  @JsonInclude(Include.NON_NULL)
  List<String> parts = null;
  
}
