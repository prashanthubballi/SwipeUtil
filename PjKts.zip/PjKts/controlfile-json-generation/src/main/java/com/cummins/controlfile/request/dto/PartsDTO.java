package com.cummins.controlfile.request.dto;

public interface PartsDTO{
	 String getPID();
	 
//	 String getItemNumber();

	  String getParts();

	  String getItemSubfileType();
	  
	  String getItemEXTPath();
}
