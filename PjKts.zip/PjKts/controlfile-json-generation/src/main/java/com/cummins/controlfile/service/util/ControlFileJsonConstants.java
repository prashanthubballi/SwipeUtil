package com.cummins.controlfile.service.util;

public class ControlFileJsonConstants {
  public static final String DOUBLE_SLASH = "\\";
 
  public static final String JSON_EXTENSION = ".json";
 
  
  public static final String JSON_FILE_NAME = "Cntl_";
  public static final String MFG_NAME = "MFG";
  public static final String ENG_NAME = "ENG";
  public static final String COE_NAME = "COE";

  public static final String ERROR_MESSAGE_DATA_NOT_FOUND = "No data found for given product ID ";
}
