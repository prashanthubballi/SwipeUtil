package com.cummins.controlfile.model;

import com.cummins.controlfile.model.key.TD1D2OptionKey;
import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity(name = "TD1D2OptionVO")
@Table(name = "T_D1D2_OPTIONS")
// @NamedQuery(name = "TD1D2OptionVO.findAll", query = "SELECT m FROM TD1D2OptionVO m")
public class TD1D2OptionVO implements Serializable {
  private static final long serialVersionUID = 1L;

  @EmbeddedId
  TD1D2OptionKey productId;

  // @Id
  // @Column(name = "DDO_PRODUCT_ID")
  // String productId;
  //
  // @Column(name = "DDO_ECM_CODE")
  // String ecmCode;
  //
  // @Column(name = "DDO_OPTION")
  // Date doOption;
  //
  // @Column(name = "DDO_OPTION_PREFIX")
  // String doOptionPrefix;
  //
  // @Column(name = "DDO_MFG_GROUP")
  // String doMfgGroup;
  //
  // @Column(name = "DDO_ENG_GROUP")
  // String doEngGroup;
  //
  // @Column(name = "DDO_COE_GROUP")
  // String doCoeGroup;
  //
  // @Temporal(TemporalType.TIMESTAMP)
  // private Date createdAt;

}
