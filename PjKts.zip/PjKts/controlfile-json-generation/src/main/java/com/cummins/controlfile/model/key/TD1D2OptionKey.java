package com.cummins.controlfile.model.key;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Data;

@Data
@Embeddable
public class TD1D2OptionKey implements Serializable {
  private static final long serialVersionUID = 1L;

  @Column(name = "DDO_PRODUCT_ID")
  String productId;

  @Column(name = "DDO_ECM_CODE")
  String ecmCode;

  @Column(name = "DDO_OPTION")
  Date doOption;

  @Column(name = "DDO_OPTION_PREFIX")
  String doOptionPrefix;

  @Column(name = "DDO_MFG_GROUP")
  String doMfgGroup;

  @Column(name = "DDO_ENG_GROUP")
  String doEngGroup;

  @Column(name = "DDO_COE_GROUP")
  String doCoeGroup;

  @Temporal(TemporalType.TIMESTAMP)
  Date createdAt;

}
