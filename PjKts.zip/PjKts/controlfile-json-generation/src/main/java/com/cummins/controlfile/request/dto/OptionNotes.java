package com.cummins.controlfile.request.dto;

import java.io.Serializable;
import java.util.List;
import lombok.Data;

@Data
public class OptionNotes implements Serializable {
  private static final long serialVersionUID = 1L;
  String item;
  // List<Map<String,String>> notes=new ArrayList<>();
  List<Notes> notes;
}
