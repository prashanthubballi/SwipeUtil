package com.cummins.controlfile.request.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ControlFileRequest {

	
	@JsonProperty("childCorrelationGuid")
	private String childCorrelationGuid;
	
	@JsonProperty("productId")
	String productId;
	
	@JsonProperty("MFGFilePath")
	String MFGFilePath;
	
	@JsonProperty("ENGFilePath")
	String ENGFilePath;
	
	@JsonProperty("COEFilePath")
	String COEFilePath;

}
