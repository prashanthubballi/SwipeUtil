package com.cummins.controlfile.service;

import com.cummins.controlfile.exception.BadRequestException;
import com.cummins.controlfile.exception.GenericException;
import com.cummins.controlfile.request.dto.ControlFileRequest;
import com.cummins.controlfile.request.dto.ControlFileResponse;

public interface ControlFileService {

  ControlFileResponse fetchParentChild(ControlFileRequest controlFileRequest) throws GenericException,BadRequestException;
}
