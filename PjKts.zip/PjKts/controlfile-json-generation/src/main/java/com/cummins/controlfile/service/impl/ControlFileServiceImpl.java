package com.cummins.controlfile.service.impl;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.controlfile.exception.BadRequestException;
import com.cummins.controlfile.exception.GenericException;
import com.cummins.controlfile.repository.TD1D2OptionRepository;
import com.cummins.controlfile.request.dto.CalibrationDetails;
import com.cummins.controlfile.request.dto.ControlFileRequest;
import com.cummins.controlfile.request.dto.ControlFileResponse;
import com.cummins.controlfile.request.dto.D1D2OptionDto;
import com.cummins.controlfile.request.dto.Notes;
import com.cummins.controlfile.request.dto.OptionNotes;
import com.cummins.controlfile.request.dto.OptionNotesDto;
import com.cummins.controlfile.request.dto.OptionSet;
import com.cummins.controlfile.request.dto.Options;
import com.cummins.controlfile.request.dto.ParentClass;
import com.cummins.controlfile.request.dto.Partnumber;
import com.cummins.controlfile.request.dto.PartsDTO;
import com.cummins.controlfile.service.ControlFileService;
import com.cummins.controlfile.service.util.ControlFileJsonConstants;
import com.cummins.controlfile.service.util.ParentChildUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ControlFileServiceImpl implements ControlFileService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ControlFileServiceImpl.class);

	@Autowired
	TD1D2OptionRepository TD1D2OptionRepository;

	// static Integer calibrationDetailsCount;
	// static Integer OptionNotesCount;
	final Integer loopValue = 500;
	// final NumberFormat formatter = new DecimalFormat("#0.0");
	private ObjectMapper mapper=new ObjectMapper();
	private void inputValidation(ControlFileRequest req) throws BadRequestException {

		if (req.getProductId() == null || (req.getProductId().equals(""))) {
			throw new BadRequestException("ProductId should not be blank or null");
		} else if (req.getChildCorrelationGuid() == null || (req.getChildCorrelationGuid().equals(""))) {
			throw new BadRequestException("ChildCorrelationGuid should not be blank or null");
		} else if (req.getCOEFilePath() == null || (req.getCOEFilePath().equals(""))) {
			throw new BadRequestException("COEFilePath should not be blank or null");
		} else if (req.getENGFilePath() == null || (req.getENGFilePath().equals(""))) {
			throw new BadRequestException("ENGFilePath should not be blank or null");
		} else if (req.getMFGFilePath() == null || (req.getMFGFilePath().equals(""))) {
			throw new BadRequestException("MFGFilePath should not be blank or null");
		}
	}

	@Transactional
	@Override
	public ControlFileResponse fetchParentChild(ControlFileRequest controlFileRequest) throws  GenericException,BadRequestException {
		LOGGER.info("Started control file: "+controlFileRequest.getProductId());
		ControlFileResponse controlResponse = new ControlFileResponse();

		List<D1D2OptionDto> calibrationDetailsList = new LinkedList<>();

		//List<OptionNotesDto> optionNotesDetailList = new LinkedList<>();
		//List<PartsDTO> parts = new LinkedList<>();
		try {
			// Fetch from DB based page size
			inputValidation( controlFileRequest);

			calibrationDetailsList = TD1D2OptionRepository.getOptionDataNew(controlFileRequest.getProductId());

			List<OptionNotesDto> optionNotesDetailList = TD1D2OptionRepository.getOptionNotesByProductIdItemListNew(controlFileRequest.getProductId());
			List<PartsDTO> parts  = TD1D2OptionRepository.getPartsByProductId(controlFileRequest.getProductId());


			LOGGER.info("ProductID : " + controlFileRequest.getProductId()
			+ " | Total CalibrationDetails Record Count: " + calibrationDetailsList.size());

			LOGGER.info("ProductID : " + controlFileRequest.getProductId()
			+ " | Total OptionNotes Record Count: " + optionNotesDetailList.size());
			//exiting process as no result found in db query
			if(calibrationDetailsList.isEmpty() && parts.isEmpty()) {
				throw new BadRequestException("CalibrationDetails not found in DB for given productID");
			}
			List<D1D2OptionDto> mfgEcmcodeList = calibrationDetailsList.stream()
					.filter(x -> x.getProductId() != null && !x.getProductId().equals(""))
					.filter(x -> x.getMFGGroup() != null && "Y".equals(x.getMFGGroup())).collect(Collectors.toCollection(LinkedList::new));
			List<D1D2OptionDto> engEcmcodeList = calibrationDetailsList.stream()
					.filter(x -> x.getProductId() != null && !x.getProductId().equals(""))
					.filter(x -> x.getENGGroup() != null && "Y".equals(x.getENGGroup())).collect(Collectors.toCollection(LinkedList::new));
			List<D1D2OptionDto> coeEcmcodeList = calibrationDetailsList.stream()
					.filter(x -> x.getProductId() != null && !x.getProductId().equals(""))
					.filter(x -> x.getCOEGroup() != null && "Y".equals(x.getCOEGroup())).collect(Collectors.toCollection(LinkedList::new));

			if((mfgEcmcodeList.isEmpty() && parts.isEmpty()) && engEcmcodeList.isEmpty() && coeEcmcodeList.isEmpty()) {
				throw new BadRequestException("MFG_GROUP,ENG_GROUP,COE_GROUP details not found in DB for given productID");
			}
			ExecutorService pool = Executors.newFixedThreadPool(3);
			List<Callable<Map<String, String>>> servicePkgCalAddList=new LinkedList<>();
			Map<String, String> response=new TreeMap<String, String>();
			if (!mfgEcmcodeList.isEmpty()) {
				servicePkgCalAddList.add((Callable<Map<String, String>>) () ->
				createControlFileJson(ControlFileJsonConstants.MFG_NAME, controlFileRequest.getMFGFilePath(), controlFileRequest, mfgEcmcodeList, optionNotesDetailList, controlResponse));
			}else {
				LOGGER.info("MFG_GROUP :: No record with DB Status as Y found " + controlFileRequest.getProductId());
				response.put(ControlFileJsonConstants.MFG_NAME + " Controle File ", "MFG_GROUP:N");  
			}

			if (!engEcmcodeList.isEmpty() || !parts.isEmpty()) {
				servicePkgCalAddList.add((Callable<Map<String, String>>) () ->
				createControlFileJson(ControlFileJsonConstants.ENG_NAME, controlFileRequest.getENGFilePath(), controlFileRequest, engEcmcodeList, optionNotesDetailList, controlResponse,parts));
			}else {
				LOGGER.info("ENG_GROUP :: No record with DB Status as Y found " + controlFileRequest.getProductId());
				response.put(ControlFileJsonConstants.ENG_NAME + " Controle File ", "ENG_GROUP:N");   
			}
			if (!coeEcmcodeList.isEmpty()) {
				servicePkgCalAddList.add((Callable<Map<String, String>>) () ->
				createControlFileJson(ControlFileJsonConstants.COE_NAME, controlFileRequest.getCOEFilePath(), controlFileRequest, coeEcmcodeList, optionNotesDetailList, controlResponse));
			}else {
				LOGGER.info("COE_GROUP :: No record with DB Status as Y found "+ controlFileRequest.getProductId());
				response.put(ControlFileJsonConstants.COE_NAME + " Controle File ", "COE_GROUP:N");  
			}

			try {
				List<Future<Map<String, String>>>  results=pool.invokeAll(servicePkgCalAddList);
				for (Future<Map<String, String>> result : results) {
					response.putAll(result.get());
				}
			}catch (Exception e) {
				LOGGER.error("Exception in pool:"+e.getMessage());
			}
			controlResponse.setResponse(response);
			printGCStatsAndClean();
		} catch (BadRequestException e) {
			e.printStackTrace();
			throw new BadRequestException(e.getMessage());
		}

		return controlResponse;
	}

	Map<String, String>  createControlFileJson(String TYPE, String mainPath, ControlFileRequest controlFileRequest,
			List<D1D2OptionDto> calibrationDetailsList, List<OptionNotesDto> optionNotesDetailList,
			ControlFileResponse controlResponse) throws GenericException {
		Map<String, String> response=new TreeMap<String, String>();
		LOGGER.info(controlFileRequest.getProductId()+"-" + TYPE + " Control File Start");

		String filePath = mainPath + ControlFileJsonConstants.DOUBLE_SLASH + ControlFileJsonConstants.JSON_FILE_NAME
				+ controlFileRequest.getProductId() + ControlFileJsonConstants.JSON_EXTENSION;

		ParentClass parent = createParent(calibrationDetailsList, optionNotesDetailList,
				controlFileRequest.getProductId());

		try {
			ParentChildUtil pcUtil=	new ParentChildUtil();
			pcUtil.writeJsonFile(pcUtil.createFile(filePath), mapper.writeValueAsString(parent));
		}catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new GenericException(e.getMessage());
		}
		response.put(TYPE + " Controle File ", filePath);

		LOGGER.info(controlFileRequest.getProductId()+"-"+ TYPE + " Control File End");
		return response;
	}

	Map<String, String> createControlFileJson(String TYPE, String mainPath, ControlFileRequest controlFileRequest,
			List<D1D2OptionDto> calibrationDetailsList, List<OptionNotesDto> optionNotesDetailList,
			ControlFileResponse controlResponse,List<PartsDTO> parts) throws GenericException {

		Map<String, String> response=new TreeMap<String, String>();
		LOGGER.info(controlFileRequest.getProductId()+"-" + TYPE + " Control File Start");


		String filePath =mainPath + ControlFileJsonConstants.DOUBLE_SLASH + ControlFileJsonConstants.JSON_FILE_NAME
				+ controlFileRequest.getProductId() + ControlFileJsonConstants.JSON_EXTENSION;

		ParentClass parent = null;
		if((null!=calibrationDetailsList && !calibrationDetailsList.isEmpty()) || (null!=optionNotesDetailList && !optionNotesDetailList.isEmpty())) {
			parent = createParent(calibrationDetailsList, optionNotesDetailList,
					controlFileRequest.getProductId());
		} 
		if(null==parent && !parts.isEmpty()){
			parent = new ParentClass();
			parent.setProductId(controlFileRequest.getProductId());
		}
		if(!parts.isEmpty()) {
			parent.setParts(parts.stream().map(prts-> prts.getParts()).collect(Collectors.toList()));
		}
		try {
			ParentChildUtil pcUtil=	new ParentChildUtil();
			pcUtil.writeJsonFile(pcUtil.createFile(filePath), mapper.writeValueAsString(parent));
		}catch (Exception e) {
			e.printStackTrace();
			throw new GenericException(e.getMessage());
		}
		response.put(TYPE + " Controle File ", filePath);
		LOGGER.info(controlFileRequest.getProductId()+"-" + TYPE + " Control File End");
		return response;

	}

	ParentClass createParent(List<D1D2OptionDto> calibrationDetailsList, List<OptionNotesDto> optionNotesDetailList, String productId) {
		int optionCount = 0;
		ParentClass parent = new ParentClass();
		parent.setProductId(productId);
		List<CalibrationDetails> calibrationList = createCalibrationList(calibrationDetailsList, optionCount);
		LOGGER.info("Final calibrationList List size: " + calibrationList.size());
		if (calibrationList.size() > 0) {
			parent.setCalibrationDetails(calibrationList);
		}
		List<OptionNotes> optionNotes = createFinalOptionNotesDetails(calibrationDetailsList, optionNotesDetailList);
		LOGGER.info("Final OptionNotes List size: " + optionNotes.size());
		if (optionNotes.size() > 0) {
			parent.setOptionNotes(optionNotes);
		}
		return parent;
	}

	private List<OptionNotes> createFinalOptionNotesDetails(List<D1D2OptionDto> calibrationDetailsList,
			List<OptionNotesDto> optionNotesDetailList) {
		List<OptionNotes> optionNotesList = new ArrayList<>();
		Map<String, List<OptionNotesDto>> finalOptionNotesDetailMap = new TreeMap<>();

		finalOptionNotesDetailMap = createTempOptionNoteDetailsList(calibrationDetailsList, optionNotesDetailList);
		LOGGER.info("createFinalOptionNotesDetails finalOptionNotesDetailMap List size: " + finalOptionNotesDetailMap.size());
		if (finalOptionNotesDetailMap.size() > 0) {
			finalOptionNotesDetailMap.entrySet().stream().forEach(noteMap -> {
				List<Notes> notesList = new ArrayList<>();

				OptionNotes optionNotes = new OptionNotes();
				optionNotes.setItem(noteMap.getKey());
				notesList = createNotesList(noteMap.getValue());

				optionNotes.setNotes(notesList);
				optionNotesList.add(optionNotes);
			});
		}
		return optionNotesList;
	}
//new notes logic need to change here
	private List<Notes> createNotesList(List<OptionNotesDto> list) {
		List<Notes> notesList = new ArrayList<>();
		// Set<Notes> notesList = new HashSet<>();
		if (list.size() > 0) {
			list.stream().forEach(notes -> {
				Notes note = new Notes();
				note.setDesc(notes.getDescription().trim().replaceAll("\t", "").replaceAll("\r", ""));
				if(null!=notes.getNOT_NOTE_VALUE() && !"".equals(notes.getNOT_NOTE_VALUE().trim())) {
					note.setValue(notes.getNOT_NOTE_VALUE());
				}else {
					note.setValue("");
				}
				
			/*	if (notes.contains(": ")) {
					String splitStr[] = notes.split(": ");
					note.setDesc(splitStr[0]);
					if (splitStr.length > 1) {
						note.setValue(splitStr[1]);
					} else {
						note.setValue("");
					}

				} else if (notes.contains(":")) {
					String splitStr[] = notes.split(":");
					note.setDesc(splitStr[0]);
					if (splitStr.length > 1) {
						note.setValue(splitStr[1]);
					} else {
						note.setValue("");
					}
				} else {
					note.setDesc(notes);
					note.setValue("");
				} */
				notesList.add(note);
			});
		}
		return notesList;
	}

	private Map<String, List<OptionNotesDto>> createTempOptionNoteDetailsList(List<D1D2OptionDto> calibrationDetailsList,
			List<OptionNotesDto> optionNotesDetailList) {
		Map<String, List<OptionNotesDto>> finalOptionNotesDetailMap = new TreeMap<>();
		//Map<String, List<OptionNotesDto>> optionAndDescription = new HashMap<>();

		//commenting below line to remove filter logic in notes section- whatever notes query shared will be printed in json.
		//Set<String> ddOptionList = getDDOoptionList(calibrationDetailsList);
		
		// Here, Making optionNotesDetailsMap DDoption as Key and Description as Value
		// from T_Notes table
		Map<String, List<OptionNotesDto>> optionNotesDetailsMap = createOptionNotesDetailsMap(optionNotesDetailList);

//		// Label:ddOptionList
//		ddOptionList.stream().forEach(option -> {
//			// Here, Making final optionNoteDetail
//			if (optionNotesDetailsMap.get(option) != null) {
//				optionAndDescription.put(option, optionNotesDetailsMap.get(option));
//			}
//		});

		// Here, Sorting final optionNoteDetail
		if (optionNotesDetailsMap.size() > 0) {
			finalOptionNotesDetailMap = optionNotesDetailsMap.entrySet().stream()
					.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, TreeMap::new));
			LOGGER.info("createTempOptionNoteDetailsList finalOptionNotesDetailMap  size: " + finalOptionNotesDetailMap.size());
		}

		return finalOptionNotesDetailMap;
	}

	private Map<String, List<OptionNotesDto>> createOptionNotesDetailsMap(List<OptionNotesDto> optionNotesDetailList) {
		Map<String, List<OptionNotesDto>> optionNotesDetailsMap = new HashMap<>();
		if (optionNotesDetailList.size() > 0) {
			optionNotesDetailsMap = optionNotesDetailList.stream().filter(x -> x.getDescription() != null)
					.collect(Collectors.groupingBy(OptionNotesDto::getDDOption));
							//Collectors.mapping(OptionNotesDto::getDescription, Collectors.toList())));
		}
		return optionNotesDetailsMap;
	}

//	private Set<String> getDDOoptionList(List<D1D2OptionDto> calibrationDetailsList) {
//		TreeSet<String> ddOptionList = new TreeSet<>();
//		if (calibrationDetailsList.size() > 0) {
//			ddOptionList = calibrationDetailsList.stream()
//					// .filter(x -> ParentChildUtil.getOptionPrefixDesc().get(x.getOptionPrefix()) != null)
//					.filter(x -> x.getOptionType() != null && x.getOptionType().equals("O"))
//					.map(D1D2OptionDto::getDDoption).collect(Collectors.toCollection(TreeSet::new));
//		}
//		return ddOptionList;
//	}

	List<CalibrationDetails> createCalibrationList(List<D1D2OptionDto> calibrationDetailsList, int optionCount) {
		LOGGER.info("createCalibrationList List size: " + calibrationDetailsList.size());
		List<CalibrationDetails> calibrationList = new LinkedList<>();

		Map<String, List<D1D2OptionDto>> mfgEcmcodeMap = creatEcmcodeMap(calibrationDetailsList);
		LOGGER.info("mfgEcmcodeMap  size: " + mfgEcmcodeMap.size());
		Map<String, Set<String>> ecmPartnumberMap = createEcmCodePartnumberMap(mfgEcmcodeMap);
		LOGGER.info("ecmPartnumberMap  size: " + ecmPartnumberMap.size());
		Map<String, Set<String>> configurationMap = createEcmCodeConfigurationMap(mfgEcmcodeMap);
		LOGGER.info("configurationMap  size: " + configurationMap.size());
		Map<String, Map<String, Set<String>>> ecmCodePartNumberMapList = createEcmCodePartNumberMapList(
				mfgEcmcodeMap);
		LOGGER.info("ecmCodePartNumberMapList  size: " + ecmCodePartNumberMapList.size());

		Map<String, Map<String, Set<String>>> ecmCodeOptionSetMapList = createEcmCodeOptionSetMapList(
				mfgEcmcodeMap);
		LOGGER.info("ecmCodeOptionSetMapList  size: " + ecmCodeOptionSetMapList.size());

		if (mfgEcmcodeMap.size() > 0) {
			mfgEcmcodeMap.entrySet().stream().forEach(ecmCodeMap -> {
				if (ecmCodeMap.getKey() != null) {
					CalibrationDetails calibration = new CalibrationDetails();
					String ecmCode = ecmCodeMap.getKey();
					calibration.setEcmCode(ecmCode);

					if (ecmPartnumberMap.get(ecmCodeMap.getKey()) != null) {
						Set<String> ecmpartnumber = ecmPartnumberMap.get(ecmCodeMap.getKey());
						if (ecmpartnumber.size() > 0) {
							calibration.setEcmPartNumber(ecmpartnumber);
						}else {
							calibration.setEcmPartNumber(new HashSet<>());
						}
					}
					OptionSet optionSet = createOptionSet(ecmCodeMap.getKey(), configurationMap, ecmCodeOptionSetMapList);
					calibration.setOptionSet(optionSet);

					//
					List<Partnumber> partnumbersList = createPartNumberSet(ecmCodeMap.getKey(), ecmCodePartNumberMapList);
					if (partnumbersList.size() > 0) {
						calibration.setPartNumbers(partnumbersList);
					}
					calibrationList.add(calibration);
				}
			});
		}

		LOGGER.info("calibrationList  size: " + calibrationList.size());
		return calibrationList;
	}

	private OptionSet createOptionSet(String ecmCode, Map<String, Set<String>> configurationMap, Map<String, Map<String, Set<String>>> optionSetMap) {
		Set<String> configuration = configurationMap.get(ecmCode);
		//  LOGGER.info("createOptionSet optionSetandPartNumberMap size: " + optionSetandPartNumberMap.size());
		OptionSet optionSet = null;
		List<Options> options = createOptions(ecmCode, optionSetMap);
		optionSet = new OptionSet();
		if (configuration != null) {
			optionSet.setConfiguration(configuration);
		}
		if (options != null && options.size() > 1) {
			optionSet.setOptions(options);
		}else {
			optionSet.setOptions(new ArrayList<Options>());
		}
		if (options.size() == 1) {
			optionSet.setAssembly(String.join(",", options.get(0).getValue()));
		}
		return optionSet;

	}

	private List<Partnumber> createPartNumberSet(String ecmCode, Map<String, Map<String, Set<String>>> optionSetandPartNumberMap) {
		List<Partnumber> partnumbersList = new ArrayList<>();
		//  LOGGER.info("createOptionSet optionSetandPartNumberMap size: " + optionSetandPartNumberMap.size());
		if (optionSetandPartNumberMap.size() > 0) {
			if (optionSetandPartNumberMap.get(ecmCode) != null) {
				createPartNumberMap(optionSetandPartNumberMap.get(ecmCode)).entrySet().stream()
				.forEach(optionSetMap -> {

					Partnumber partnumber = new Partnumber();
					partnumber.setType(optionSetMap.getKey());
					partnumber.setValue(optionSetMap.getValue());
					partnumbersList.add(partnumber);
				});
			}
		}
		//  LOGGER.info("createOptionSet partnumbersList size: " + optionSetandPartNumberMap.size());
		return partnumbersList;

	}

	Map<String, String> createPartNumberMap(Map<String, Set<String>> optionSetandPartNumberMap) {
		Map<String, String> partNumbeMap = new HashMap<>();
		if (optionSetandPartNumberMap.size() > 0) {
			optionSetandPartNumberMap.entrySet().stream()
			// .filter(m -> m.getKey() != null && m.getValue() != null && !"HWP".equals(m.getKey()))
			.forEach(optionMap -> {
				// Here, Getting optionSet Map
				// if (ParentChildUtil.getPartNumberPrefixDesc().get(optionMap.getKey()) != null) {
				partNumbeMap.put(optionMap.getKey(),
						String.join(",", optionMap.getValue()));

				// }
			});
		}   
		return partNumbeMap.entrySet().stream()
				.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, TreeMap::new));
	}

	//order change required here
	private List<Options> createOptions(String ecmCode, Map<String, Map<String, Set<String>>> optionSetandPartNumberMap) {
		List<Options> optionsList = new LinkedList<>();
		if (optionSetandPartNumberMap.size() > 0) {
			if (optionSetandPartNumberMap.get(ecmCode) != null) {
				createOptionSet(optionSetandPartNumberMap.get(ecmCode)).entrySet().stream()
				.forEach(optionSetMap -> {
					Options option = new Options();
					Set<String> value = optionSetMap.getValue();
					String prefix = optionSetMap.getKey();
					option.setValue(value);
					option.setPrefix(prefix);
					optionsList.add(option);
				});
			}
		}
		return optionsList;
	}

	// order change required here.
	Map<String, Set<String>> createOptionSet(Map<String, Set<String>> optionSetandPartNumberMap) {

		Map<String, Set<String>> optionSet = new LinkedHashMap<>();
		if (optionSetandPartNumberMap.size() > 0) {
			optionSetandPartNumberMap.entrySet().stream()
			// .filter(m -> m.getKey() != null && m.getValue() != null && !"HWP".equals(m.getKey()) && !"CONFIG".equals(m.getKey()))
			.forEach(optionMap -> {
				// Here, Getting optionSet Map
				// if (ParentChildUtil.getOptionPrefixDesc().get(optionMap.getKey()) != null) {
				optionSet.put(optionMap.getKey(),
						optionMap.getValue());

				// }
			});
		}
		return optionSet;
		//  return optionSet.entrySet().stream()
		//    .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, TreeMap::new));
	}

	//order change required here
	Map<String, List<D1D2OptionDto>> creatEcmcodeMap(List<D1D2OptionDto> calibrationDetailsList) {
		Map<String, List<D1D2OptionDto>> EcmcodeMap = new LinkedHashMap<>();
		if (calibrationDetailsList.size() > 0) {
			EcmcodeMap = calibrationDetailsList.stream()
					.collect(Collectors.groupingBy(D1D2OptionDto::getEcmCode,LinkedHashMap::new, Collectors.toCollection(LinkedList::new)));
		}
		return EcmcodeMap;
		// return EcmcodeMap.entrySet().stream()
		//   .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, TreeMap::new));
	}

	Map<String, Set<String>> createEcmCodePartnumberMap(Map<String, List<D1D2OptionDto>> ecmCodeOptionListMap) {
		Map<String, Set<String>> ecmpartNumberMap = new HashMap<>();
		if (ecmCodeOptionListMap.size() > 0) {
			ecmCodeOptionListMap.entrySet().stream().forEach(typeMap -> {
				if (typeMap.getValue().size() > 0) {
					ecmpartNumberMap.put(typeMap.getKey(),
							typeMap.getValue().stream().filter(x -> x.getOptionType() != null && "H".equals(x.getOptionType()))
							.map(D1D2OptionDto::getDDoption).collect(Collectors.toSet()));
				}

			});
		}
		//  return ecmpartNumberMap;
		return ecmpartNumberMap.entrySet().stream()
				.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, TreeMap::new));
	}

	Map<String, Set<String>> createEcmCodeConfigurationMap(Map<String, List<D1D2OptionDto>> ecmCodeOptionListMap) {
		Map<String, Set<String>> configurationMap = new HashMap<>();
		if (ecmCodeOptionListMap.size() > 0) {
			ecmCodeOptionListMap.entrySet().stream().forEach(typeMap -> {
				if (typeMap.getValue().size() > 0) {
					configurationMap.put(typeMap.getKey(),
							typeMap.getValue().stream().filter(x -> x.getOptionType() != null && "C".equals(x.getOptionType()))
							.map(D1D2OptionDto::getDDoption).collect(Collectors.toSet()));
				}

			});
		}

		//return configurationMap;
		return configurationMap.entrySet().stream()
				.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, TreeMap::new));
	}
	//order change required here
	Map<String, Map<String, Set<String>>> createEcmCodeOptionSetMapList(
			Map<String, List<D1D2OptionDto>> ecmCodeOptionListMap) {
		Map<String, Map<String, Set<String>>> OptionSetandPartNumberMap = new LinkedHashMap<>();
		if (ecmCodeOptionListMap.size() > 0) {
			ecmCodeOptionListMap.entrySet().stream().forEach(typeMap -> {
				if (typeMap.getValue().size() > 0) {
					OptionSetandPartNumberMap.put(typeMap.getKey(),
							typeMap.getValue().stream().filter(p -> p.getOptionType() != null && p.getOptionType().equals("O"))
							.collect(Collectors.groupingBy(D1D2OptionDto::getOptionPrefix,LinkedHashMap::new,
									Collectors.mapping(D1D2OptionDto::getDDoption, Collectors.toCollection(LinkedHashSet::new)))));
				}

			});
		}
		return OptionSetandPartNumberMap;
		//   return OptionSetandPartNumberMap.entrySet().stream()
		//     .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, TreeMap::new));
	}

	Map<String, Map<String, Set<String>>> createEcmCodePartNumberMapList(
			Map<String, List<D1D2OptionDto>> ecmCodeOptionListMap) {
		Map<String, Map<String, Set<String>>> OptionSetandPartNumberMap = new HashMap<>();
		if (ecmCodeOptionListMap.size() > 0) {
			ecmCodeOptionListMap.entrySet().stream().forEach(typeMap -> {
				if (typeMap.getValue().size() > 0) {
					OptionSetandPartNumberMap.put(typeMap.getKey(),
							typeMap.getValue().stream()
							// .filter(p -> (p.getOptionType() != null && p.getOptionType().equals("H")) )
							.filter(p -> (p.getOptionType() != null && p.getOptionType().equals("P")) )
							.collect(Collectors.groupingBy(D1D2OptionDto::getOptionPrefix,
									Collectors.mapping(D1D2OptionDto::getDDoption, Collectors.toSet()))));
				}

			});
		}
		//return OptionSetandPartNumberMap;
		return OptionSetandPartNumberMap.entrySet().stream()
				.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, TreeMap::new));
	}

	Map<String, List<D1D2OptionDto>> createEcmCodeOptionDataMap(List<D1D2OptionDto> calibrationDetailsList) {
		Map<String, List<D1D2OptionDto>> ecmCodeOptionListMap = new HashMap<>();
		if (ecmCodeOptionListMap.size() > 0) {
			ecmCodeOptionListMap = calibrationDetailsList.stream()
					.collect(Collectors.groupingBy(D1D2OptionDto::getEcmCode, Collectors.toList()));
		}
		// return ecmCodeOptionListMap;
		return ecmCodeOptionListMap.entrySet().stream()
				.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, TreeMap::new));
	}
	public  void printGCStatsAndClean() {
		long totalGarbageCollections = 0;
		long garbageCollectionTime = 0;
		System.gc();
		for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans()) {
			long count = gc.getCollectionCount();

			if (count >= 0) {
				totalGarbageCollections += count;
			}

			long time = gc.getCollectionTime();

			if (time >= 0) {
				garbageCollectionTime += time;
			}
		}
		LOGGER.info("Garbage Collections: " + totalGarbageCollections + "\n" + "Garbage Collection Time (ms): "
				+ garbageCollectionTime);
		LOGGER.info("Garbage Collector Called ");
		if (totalGarbageCollections > 0 || garbageCollectionTime > 0) {
			System.gc();
		}

	}
}