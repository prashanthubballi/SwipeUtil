/*
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Vishal.
 */

package com.cummins.controlfile.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

@Data
public class CommonResponseHeader implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 2323340964009768888L;

  @JsonProperty("success")
  private boolean success;

  @JsonProperty("code")
  private Integer code;

  @JsonProperty("message")
  private String message;

  public CommonResponseHeader(boolean success, Integer code, String message) {
    super();
    this.success = success;
    this.code = code;
    this.message = message;
  }

  @Override
  public String toString() {
    return "CommonResponseHeader{" +
      "success=" + success +
      ", code=" + code +
      ", message='" + message + '\'' +
      '}';
  }
}
