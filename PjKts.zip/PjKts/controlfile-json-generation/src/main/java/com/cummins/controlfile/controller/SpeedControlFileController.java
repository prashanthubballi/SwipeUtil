package com.cummins.controlfile.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cummins.controlfile.common.ResponseUtility;
import com.cummins.controlfile.exception.BadRequestException;
import com.cummins.controlfile.exception.GenericException;
import com.cummins.controlfile.request.dto.ControlFileRequest;
import com.cummins.controlfile.request.dto.ControlFileResponse;
import com.cummins.controlfile.service.impl.ControlFileServiceImpl;

@RestController
@RequestMapping("SpeedControlFileController")
public class SpeedControlFileController {

	//private Logger logger = LogManager.getLogger(SpeedControlFileController.class);
	
	@Autowired
	private ControlFileServiceImpl controlFileServiceImpl;
	
	@PostMapping("/controlfilejson")
	private ResponseEntity<?> bulkInsert(@RequestBody ControlFileRequest controlFileRequest){
		try {
			ControlFileResponse  response=controlFileServiceImpl.fetchParentChild(controlFileRequest);
			response.setChildCorrelationGuid(controlFileRequest.getChildCorrelationGuid());
			response.setProductId(controlFileRequest.getProductId());
			return ResponseUtility.generateResponse(response,HttpStatus.OK);
		} catch (BadRequestException e) {
			Map<String,String> error=new HashMap<>();
			ControlFileResponse resp=new ControlFileResponse();
			resp.setChildCorrelationGuid(controlFileRequest.getChildCorrelationGuid());
			resp.setProductId(controlFileRequest.getProductId());
			error.put("ERROR", e.getMessage());
			resp.setResponse(error);
			return ResponseUtility.generateResponse(resp, HttpStatus.BAD_REQUEST);
		} catch(GenericException e){
			Map<String,String> error=new HashMap<>();
			ControlFileResponse resp=new ControlFileResponse();
			resp.setChildCorrelationGuid(controlFileRequest.getChildCorrelationGuid());
			resp.setProductId(controlFileRequest.getProductId());
			error.put("ERROR", e.getMessage());
			resp.setResponse(error);
			return ResponseUtility.generateResponse(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch(Exception e){
			Map<String,String> error=new HashMap<>();
			ControlFileResponse resp=new ControlFileResponse();
			resp.setChildCorrelationGuid(controlFileRequest.getChildCorrelationGuid());
			resp.setProductId(controlFileRequest.getProductId());
			error.put("ERROR", e.getMessage());
			resp.setResponse(error);
			return ResponseUtility.generateResponse(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
