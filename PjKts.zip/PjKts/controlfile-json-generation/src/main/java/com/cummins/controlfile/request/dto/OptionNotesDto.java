package com.cummins.controlfile.request.dto;

public interface OptionNotesDto {
  String getId();

  String getDescription();
  String getNOT_NOTE_VALUE();
  String getDDOption();

}
