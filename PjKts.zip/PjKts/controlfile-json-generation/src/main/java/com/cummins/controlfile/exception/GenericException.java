package com.cummins.controlfile.exception;

public class GenericException extends RuntimeException {

  /**
  * 
  */
  private static final long serialVersionUID = 8403434622963075770L;

  public GenericException(String message) {
    super(message);
  }

  public GenericException(String message, Throwable cause) {
    super(message, cause);
  }

}
