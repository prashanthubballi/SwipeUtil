package com.cummins.lambdatokenauth.util;
public interface Constants{
	//process
	String	ENGG="ENGG";
	String	MFG="MFG";
	String	SVC="SVC";
	String	GHG="GHG";
	String	SERVICE="SERVICE";
	//process type
	String	B2B="B2B";
	String	B2C="B2C";
	//modes
	String FileUpload_REGULAR="FileUpload_REGULAR";
	String FileUpload_RESTRICTED="FileUpload_RESTRICTED";
	String FileDownload_REGULAR="FileDownload_REGULAR";
	String FileDownload_RESTRICTED="FileDownload_RESTRICTED";
	String CalDownload_REGULAR="CalDownload_REGULAR";
	String Restricted="Forbidden";
	String InvalidToken="Expired or Invalid Token supplied";
	String UnauthorizedMessage="Unauthorized";
	String INVALID_GROUP_CLAIMS="Action not allowed-Invalid group claims";
	Integer	OK=200;
	Integer FORBIDDEN=403;
	Integer ERROR=500;
	Integer BADREQUEST=400;
	Integer UNAUTHORIZED=401;
}
