package com.cummins.lambdatokenauth.auth.dto;

import lombok.Data;
@Data
public class RequestLambdaDTO {
	public String functionName;
	public RequestPayload payload;
}
