package com.cummins.lambdatokenauth.auth.dto;
import lombok.Data;
@Data
public class RequestPayload {
	public String authHeader;
}
