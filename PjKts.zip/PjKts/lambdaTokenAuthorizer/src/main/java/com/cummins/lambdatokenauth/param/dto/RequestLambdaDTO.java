package com.cummins.lambdatokenauth.param.dto;

import lombok.Data;
@Data
public class RequestLambdaDTO {
	public String functionName;
//	public JSONObject payload;
	public RequestPayload payload;

}
