package com.cummins.lambdatokenauth.auth.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "aud",
    "iss",
    "iat",
    "nbf",
    "exp",
    "aio",
    "azp",
    "azpacr",
    "ctry",
    "email",
    "family_name",
    "given_name",
    "ipaddr",
    "name",
    "oid",
    "preferred_username",
    "rh",
    "roles",
    "scp",
    "sid",
    "sub",
    "tid",
    "upn",
    "uti",
    "ver",
    "verified_primary_email"
})
@Data
public class JWTResponse {

    @JsonProperty("aud")
    private String aud;
    @JsonProperty("iss")
    private String iss;
    @JsonProperty("iat")
    private Integer iat;
    @JsonProperty("nbf")
    private Integer nbf;
    @JsonProperty("exp")
    private Integer exp;
    @JsonProperty("aio")
    private String aio;
    @JsonProperty("azp")
    private String azp;
    @JsonProperty("azpacr")
    private String azpacr;
    @JsonProperty("ctry")
    private String ctry;
    @JsonProperty("email")
    private String email;
    @JsonProperty("family_name")
    private String familyName;
    @JsonProperty("given_name")
    private String givenName;
    @JsonProperty("ipaddr")
    private String ipaddr;
    @JsonProperty("name")
    private String name;
    @JsonProperty("oid")
    private String oid;
    @JsonProperty("preferred_username")
    private String preferredUsername;
    @JsonProperty("rh")
    private String rh;
    @JsonProperty("roles")
    private List<String> roles = new ArrayList<String>();
    @JsonProperty("scp")
    private String scp;
    @JsonProperty("sid")
    private String sid;
    @JsonProperty("sub")
    private String sub;
    @JsonProperty("tid")
    private String tid;
    @JsonProperty("upn")
    private String upn;
    @JsonProperty("uti")
    private String uti;
    @JsonProperty("ver")
    private String ver;
    @JsonProperty("verified_primary_email")
    private List<String> verifiedPrimaryEmail = new ArrayList<String>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

       @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(JWTResponse.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("aud");
        sb.append('=');
        sb.append(((this.aud == null)?"<null>":this.aud));
        sb.append(',');
        sb.append("iss");
        sb.append('=');
        sb.append(((this.iss == null)?"<null>":this.iss));
        sb.append(',');
        sb.append("iat");
        sb.append('=');
        sb.append(((this.iat == null)?"<null>":this.iat));
        sb.append(',');
        sb.append("nbf");
        sb.append('=');
        sb.append(((this.nbf == null)?"<null>":this.nbf));
        sb.append(',');
        sb.append("exp");
        sb.append('=');
        sb.append(((this.exp == null)?"<null>":this.exp));
        sb.append(',');
        sb.append("aio");
        sb.append('=');
        sb.append(((this.aio == null)?"<null>":this.aio));
        sb.append(',');
        sb.append("azp");
        sb.append('=');
        sb.append(((this.azp == null)?"<null>":this.azp));
        sb.append(',');
        sb.append("azpacr");
        sb.append('=');
        sb.append(((this.azpacr == null)?"<null>":this.azpacr));
        sb.append(',');
        sb.append("ctry");
        sb.append('=');
        sb.append(((this.ctry == null)?"<null>":this.ctry));
        sb.append(',');
        sb.append("email");
        sb.append('=');
        sb.append(((this.email == null)?"<null>":this.email));
        sb.append(',');
        sb.append("familyName");
        sb.append('=');
        sb.append(((this.familyName == null)?"<null>":this.familyName));
        sb.append(',');
        sb.append("givenName");
        sb.append('=');
        sb.append(((this.givenName == null)?"<null>":this.givenName));
        sb.append(',');
        sb.append("ipaddr");
        sb.append('=');
        sb.append(((this.ipaddr == null)?"<null>":this.ipaddr));
        sb.append(',');
        sb.append("name");
        sb.append('=');
        sb.append(((this.name == null)?"<null>":this.name));
        sb.append(',');
        sb.append("oid");
        sb.append('=');
        sb.append(((this.oid == null)?"<null>":this.oid));
        sb.append(',');
        sb.append("preferredUsername");
        sb.append('=');
        sb.append(((this.preferredUsername == null)?"<null>":this.preferredUsername));
        sb.append(',');
        sb.append("rh");
        sb.append('=');
        sb.append(((this.rh == null)?"<null>":this.rh));
        sb.append(',');
        sb.append("roles");
        sb.append('=');
        sb.append(((this.roles == null)?"<null>":this.roles));
        sb.append(',');
        sb.append("scp");
        sb.append('=');
        sb.append(((this.scp == null)?"<null>":this.scp));
        sb.append(',');
        sb.append("sid");
        sb.append('=');
        sb.append(((this.sid == null)?"<null>":this.sid));
        sb.append(',');
        sb.append("sub");
        sb.append('=');
        sb.append(((this.sub == null)?"<null>":this.sub));
        sb.append(',');
        sb.append("tid");
        sb.append('=');
        sb.append(((this.tid == null)?"<null>":this.tid));
        sb.append(',');
        sb.append("upn");
        sb.append('=');
        sb.append(((this.upn == null)?"<null>":this.upn));
        sb.append(',');
        sb.append("uti");
        sb.append('=');
        sb.append(((this.uti == null)?"<null>":this.uti));
        sb.append(',');
        sb.append("ver");
        sb.append('=');
        sb.append(((this.ver == null)?"<null>":this.ver));
        sb.append(',');
        sb.append("verifiedPrimaryEmail");
        sb.append('=');
        sb.append(((this.verifiedPrimaryEmail == null)?"<null>":this.verifiedPrimaryEmail));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.sub == null)? 0 :this.sub.hashCode()));
        result = ((result* 31)+((this.aio == null)? 0 :this.aio.hashCode()));
        result = ((result* 31)+((this.roles == null)? 0 :this.roles.hashCode()));
        result = ((result* 31)+((this.iss == null)? 0 :this.iss.hashCode()));
        result = ((result* 31)+((this.oid == null)? 0 :this.oid.hashCode()));
        result = ((result* 31)+((this.tid == null)? 0 :this.tid.hashCode()));
        result = ((result* 31)+((this.sid == null)? 0 :this.sid.hashCode()));
        result = ((result* 31)+((this.verifiedPrimaryEmail == null)? 0 :this.verifiedPrimaryEmail.hashCode()));
        result = ((result* 31)+((this.azp == null)? 0 :this.azp.hashCode()));
        result = ((result* 31)+((this.ctry == null)? 0 :this.ctry.hashCode()));
        result = ((result* 31)+((this.familyName == null)? 0 :this.familyName.hashCode()));
        result = ((result* 31)+((this.exp == null)? 0 :this.exp.hashCode()));
        result = ((result* 31)+((this.ipaddr == null)? 0 :this.ipaddr.hashCode()));
        result = ((result* 31)+((this.iat == null)? 0 :this.iat.hashCode()));
        result = ((result* 31)+((this.email == null)? 0 :this.email.hashCode()));
        result = ((result* 31)+((this.scp == null)? 0 :this.scp.hashCode()));
        result = ((result* 31)+((this.ver == null)? 0 :this.ver.hashCode()));
        result = ((result* 31)+((this.preferredUsername == null)? 0 :this.preferredUsername.hashCode()));
        result = ((result* 31)+((this.givenName == null)? 0 :this.givenName.hashCode()));
        result = ((result* 31)+((this.azpacr == null)? 0 :this.azpacr.hashCode()));
        result = ((result* 31)+((this.uti == null)? 0 :this.uti.hashCode()));
        result = ((result* 31)+((this.aud == null)? 0 :this.aud.hashCode()));
        result = ((result* 31)+((this.upn == null)? 0 :this.upn.hashCode()));
        result = ((result* 31)+((this.nbf == null)? 0 :this.nbf.hashCode()));
        result = ((result* 31)+((this.rh == null)? 0 :this.rh.hashCode()));
        result = ((result* 31)+((this.name == null)? 0 :this.name.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof JWTResponse) == false) {
            return false;
        }
        JWTResponse rhs = ((JWTResponse) other);
        return ((((((((((((((((((((((((((((this.sub == rhs.sub)||((this.sub!= null)&&this.sub.equals(rhs.sub)))&&((this.aio == rhs.aio)||((this.aio!= null)&&this.aio.equals(rhs.aio))))&&((this.roles == rhs.roles)||((this.roles!= null)&&this.roles.equals(rhs.roles))))&&((this.iss == rhs.iss)||((this.iss!= null)&&this.iss.equals(rhs.iss))))&&((this.oid == rhs.oid)||((this.oid!= null)&&this.oid.equals(rhs.oid))))&&((this.tid == rhs.tid)||((this.tid!= null)&&this.tid.equals(rhs.tid))))&&((this.sid == rhs.sid)||((this.sid!= null)&&this.sid.equals(rhs.sid))))&&((this.verifiedPrimaryEmail == rhs.verifiedPrimaryEmail)||((this.verifiedPrimaryEmail!= null)&&this.verifiedPrimaryEmail.equals(rhs.verifiedPrimaryEmail))))&&((this.azp == rhs.azp)||((this.azp!= null)&&this.azp.equals(rhs.azp))))&&((this.ctry == rhs.ctry)||((this.ctry!= null)&&this.ctry.equals(rhs.ctry))))&&((this.familyName == rhs.familyName)||((this.familyName!= null)&&this.familyName.equals(rhs.familyName))))&&((this.exp == rhs.exp)||((this.exp!= null)&&this.exp.equals(rhs.exp))))&&((this.ipaddr == rhs.ipaddr)||((this.ipaddr!= null)&&this.ipaddr.equals(rhs.ipaddr))))&&((this.iat == rhs.iat)||((this.iat!= null)&&this.iat.equals(rhs.iat))))&&((this.email == rhs.email)||((this.email!= null)&&this.email.equals(rhs.email))))&&((this.scp == rhs.scp)||((this.scp!= null)&&this.scp.equals(rhs.scp))))&&((this.ver == rhs.ver)||((this.ver!= null)&&this.ver.equals(rhs.ver))))&&((this.preferredUsername == rhs.preferredUsername)||((this.preferredUsername!= null)&&this.preferredUsername.equals(rhs.preferredUsername))))&&((this.givenName == rhs.givenName)||((this.givenName!= null)&&this.givenName.equals(rhs.givenName))))&&((this.azpacr == rhs.azpacr)||((this.azpacr!= null)&&this.azpacr.equals(rhs.azpacr))))&&((this.uti == rhs.uti)||((this.uti!= null)&&this.uti.equals(rhs.uti))))&&((this.aud == rhs.aud)||((this.aud!= null)&&this.aud.equals(rhs.aud))))&&((this.upn == rhs.upn)||((this.upn!= null)&&this.upn.equals(rhs.upn))))&&((this.nbf == rhs.nbf)||((this.nbf!= null)&&this.nbf.equals(rhs.nbf))))&&((this.rh == rhs.rh)||((this.rh!= null)&&this.rh.equals(rhs.rh))))&&((this.name == rhs.name)||((this.name!= null)&&this.name.equals(rhs.name))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
