package com.cummins.lambdatokenauth;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.cummins.lambdatokenauth.auth.dto.ApprovedClient;
import com.cummins.lambdatokenauth.auth.dto.JWTResponse;
import com.cummins.lambdatokenauth.auth.dto.LambdaTokenAuthResponse;
import com.cummins.lambdatokenauth.auth.dto.ParamStoreDTO;
import com.cummins.lambdatokenauth.auth.dto.RequestLambdaDTO;
import com.cummins.lambdatokenauth.auth.dto.RequestPayload;
import com.cummins.lambdatokenauth.util.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
public class LambdaTokenAuthorizer {

	private final Logger logger = LoggerFactory.getLogger(LambdaTokenAuthorizer.class);

	// @Autowired
	ParamStoreDTO paramStoreDTO;

	@Autowired
	RestTemplate restTemplate;

	ObjectMapper objectMapper = new ObjectMapper();

	public LambdaTokenAuthorizer() {

	}

	public LambdaTokenAuthorizer(ParamStoreDTO paramStoreDTO, @Value("${lambdaURL}") String lambdaURL,
			@Value("${paramStoreLambdaFunction}") String paramStoreLambdaFunction,
			@Value("${parameterStoreKey}") String parameterStoreKey)
			throws URISyntaxException, JsonMappingException, JsonProcessingException {
		this.paramStoreDTO = paramStoreDTO;
		logger.info(" Getting value from aws ParamStore:" + parameterStoreKey);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Object> result = null;
		URI uri;
		uri = new URI(lambdaURL);
		com.cummins.lambdatokenauth.param.dto.RequestPayload payload = new com.cummins.lambdatokenauth.param.dto.RequestPayload();
		payload.setName(parameterStoreKey);
		com.cummins.lambdatokenauth.param.dto.RequestLambdaDTO requestLambdaDTO = new com.cummins.lambdatokenauth.param.dto.RequestLambdaDTO();
		requestLambdaDTO.setFunctionName(paramStoreLambdaFunction);
		requestLambdaDTO.setPayload(payload);
		result = restTemplate.postForEntity(uri, requestLambdaDTO, Object.class);
		logger.info("## Param Store :" + result);
		JSONObject responseJson = new JSONObject(result);
		String bodyData = responseJson.getJSONObject("body").getString("data");
		this.paramStoreDTO = objectMapper.readValue(bodyData, ParamStoreDTO.class);
		// this.paramStoreDTO=result.getBody();
	}

	public LambdaTokenAuthResponse validateTokenAccess(String token, String process) {

		return validateTokenAccess(token, process, null);
	}

	public LambdaTokenAuthResponse validateTokenAccess(String token, String process, String mode) {
		logger.info("Method:ValidateTokenAccess Started");
		LambdaTokenAuthResponse lambdaTokenAuthResponse = new LambdaTokenAuthResponse();
		try {
			JWTResponse jwtResponse = getJWTResponse(token);
			validateJWTResponse(lambdaTokenAuthResponse, jwtResponse, process, mode);

		} catch (HttpClientErrorException | JsonProcessingException | URISyntaxException e) {
			if (e instanceof HttpClientErrorException) {
				try {
					return objectMapper.readValue(((HttpClientErrorException) e).getResponseBodyAsString(),
							LambdaTokenAuthResponse.class);
				} catch (JsonProcessingException e1) {
					logger.error("Could not map exact error to response");
				}
			}
			lambdaTokenAuthResponse.setCode(Constants.BADREQUEST);
			lambdaTokenAuthResponse.setSuccess(false);
			lambdaTokenAuthResponse.setMessage(Constants.InvalidToken);
			logger.error("ERROR: Exception in validate token:" + e.getMessage());
		}
		logger.info("Method:ValidateTokenAccess Completed");
		return lambdaTokenAuthResponse;
	}

	private JWTResponse getJWTResponse(String token)
			throws URISyntaxException, JsonMappingException, JsonProcessingException {
		logger.info("Calling lambda invoker");
		ResponseEntity<Object> result = null;
		URI uri;
		uri = new URI(paramStoreDTO.getGenericLambdaURL());
		RequestPayload payload = new RequestPayload();
		payload.setAuthHeader(token);
		RequestLambdaDTO requestLambdaDTO = new RequestLambdaDTO();
		requestLambdaDTO.setFunctionName(paramStoreDTO.getTokenAuthFunctionName());
		requestLambdaDTO.setPayload(payload);
		result = restTemplate.postForEntity(uri, requestLambdaDTO, Object.class);
		JSONObject responseJson = new JSONObject(result);
		String bodyData = responseJson.getJSONObject("body").getString("data");
		return objectMapper.readValue(bodyData, JWTResponse.class);
	}

	private LambdaTokenAuthResponse validateJWTResponse(LambdaTokenAuthResponse lambdaTokenAuthResponse,
			JWTResponse jwtResponse, String process, String mode) {
		switch (process) {
		case Constants.ENGG:
			return validateClaims(lambdaTokenAuthResponse, jwtResponse, process, mode);
		case Constants.MFG:
			return validateClaims(lambdaTokenAuthResponse, jwtResponse, process, mode);
		case Constants.SVC:
			return validateClaims(lambdaTokenAuthResponse, jwtResponse, process, mode);
		case Constants.GHG:
			return validateClaims(lambdaTokenAuthResponse, jwtResponse, process, mode);
		
		default:
			lambdaTokenAuthResponse.setCode(Constants.ERROR);
			lambdaTokenAuthResponse.setSuccess(false);
			lambdaTokenAuthResponse.setMessage(Constants.Restricted);
			return lambdaTokenAuthResponse;
		}
	}

	private LambdaTokenAuthResponse validateClaims(LambdaTokenAuthResponse lambdaTokenAuthResponse,
			JWTResponse jwtResponse, String process, String mode) {
		logger.info("Validating claims");
		ApprovedClient clientDetails = getApprovedClientDetails(jwtResponse.getAzp(),process);
		if (null != clientDetails) {
			lambdaTokenAuthResponse.setName(clientDetails.getName());
			lambdaTokenAuthResponse.setAppId(clientDetails.getAppID().get(0));
			lambdaTokenAuthResponse.setAudId(jwtResponse.getAud());
			lambdaTokenAuthResponse.setProcess(clientDetails.getProcess());
			lambdaTokenAuthResponse.setProcessType(clientDetails.getProcessType());
			lambdaTokenAuthResponse.setWwid(jwtResponse.getUpn());
			lambdaTokenAuthResponse.setUserName(jwtResponse.getName());
			lambdaTokenAuthResponse.setIpaddr(jwtResponse.getIpaddr());
			lambdaTokenAuthResponse.setCountry(jwtResponse.getCtry());
			lambdaTokenAuthResponse.setRoles(jwtResponse.getRoles());
			if (null == mode) { // allow all products access
				lambdaTokenAuthResponse.setCode(Constants.OK);
				lambdaTokenAuthResponse.setSuccess(true);
				lambdaTokenAuthResponse.setMessage("Success:Token validated");
				return lambdaTokenAuthResponse;
			} else if (Constants.B2B.equals(clientDetails.getProcessType())) {
				return validateB2B(lambdaTokenAuthResponse, mode);
			} else {
				return validateB2C(lambdaTokenAuthResponse, clientDetails, jwtResponse, mode);
			}
		} else {
			// app id in jwt token is not part of param store configs
			lambdaTokenAuthResponse.setCode(Constants.UNAUTHORIZED);
			lambdaTokenAuthResponse.setSuccess(false);
			lambdaTokenAuthResponse.setMessage(Constants.UnauthorizedMessage);
			return lambdaTokenAuthResponse;
		}
	}

	private ApprovedClient getApprovedClientDetails(String azp,String process) {
		List<ApprovedClient> clientDetails = paramStoreDTO.getApprovedClients();
		for (ApprovedClient clientDetailPS : clientDetails) {
			if (clientDetailPS.getAppID().contains(azp) && process.equalsIgnoreCase(clientDetailPS.getProcess())) {
				ApprovedClient clientDetail = new ApprovedClient();
				List<String> appId = new ArrayList<>();
				appId.add(azp);
				clientDetail.setAppID(appId);
				clientDetail.setGroupNames(clientDetailPS.getGroupNames());
				clientDetail.setName(clientDetailPS.getName());
				clientDetail.setProcess(clientDetailPS.getProcess());
				clientDetail.setProcessType(clientDetailPS.getProcessType());
				return clientDetail;
			}
		}
		return null;
	}

	private LambdaTokenAuthResponse validateB2B(LambdaTokenAuthResponse lambdaTokenAuthResponse, String mode) {
		lambdaTokenAuthResponse.setCode(Constants.OK);
		lambdaTokenAuthResponse.setSuccess(true);
		lambdaTokenAuthResponse.setMessage("Success:Token validated,B2B");
		return lambdaTokenAuthResponse;
	}

	private LambdaTokenAuthResponse validateB2C(LambdaTokenAuthResponse lambdaTokenAuthResponse,
			ApprovedClient clientDetails, JWTResponse jwtResponse, String mode) {
		List<String> jwtGroups = jwtResponse.getRoles();
		List<String> paramGroups = clientDetails.getGroupNames().stream()
				.filter(group -> mode.equalsIgnoreCase((group.getName()))).collect(Collectors.toList()).get(0)
				.getValues();
		if (paramGroups.stream().filter(two -> jwtGroups.stream().anyMatch(one -> two.equals(one))).count() > 0) {
			lambdaTokenAuthResponse.setCode(Constants.OK);
			lambdaTokenAuthResponse.setSuccess(true);
			lambdaTokenAuthResponse.setMessage("Success:Token validated,B2C");
			return lambdaTokenAuthResponse;
		} else {
			lambdaTokenAuthResponse.setCode(Constants.FORBIDDEN);
			lambdaTokenAuthResponse.setSuccess(false);
			lambdaTokenAuthResponse.setMessage(Constants.INVALID_GROUP_CLAIMS);
			return lambdaTokenAuthResponse;
		}
	}
	
}
