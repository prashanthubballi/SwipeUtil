package com.cummins.lambdatokenauth.auth.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import org.springframework.context.annotation.Configuration;
@Configuration
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "GenericLambdaURL",
    "TokenAuthFunctionName",
    "ApprovedClients"
})
@Data
public class ParamStoreDTO {

    @JsonProperty("GenericLambdaURL")
    private String genericLambdaURL;
    @JsonProperty("TokenAuthFunctionName")
    private String tokenAuthFunctionName;
    @JsonProperty("ApprovedClients")
    private List<ApprovedClient> approvedClients = new ArrayList<ApprovedClient>();
}
