package com.cummins.lambdatokenauth.auth.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Name",
    "Values"
})
@Data
public class GroupName {

    @JsonProperty("Name")
    private String name;
    @JsonProperty("Values")
    private List<String> values = new ArrayList<String>();
}
