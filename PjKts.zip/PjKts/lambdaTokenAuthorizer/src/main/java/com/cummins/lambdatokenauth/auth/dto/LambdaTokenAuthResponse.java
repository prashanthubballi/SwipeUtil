package com.cummins.lambdatokenauth.auth.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LambdaTokenAuthResponse {

	@JsonProperty("success")
	private boolean success;
	@JsonProperty("code")
	private Integer code;
	@JsonProperty("message")
	private String message;
	
	//param store details
	@JsonProperty("name")
	private String name;
	@JsonProperty("appId")
	private String appId;
	@JsonProperty("audId")
	private String audId;
	@JsonProperty("process")
	private String process;
	@JsonProperty("processType")
	private String processType;
	
	@JsonProperty("wwid")
	private String wwid;
	@JsonProperty("roles")
    private List<String> roles = new ArrayList<String>();
	@JsonProperty("userName")
	private String userName;
	@JsonProperty("ipaddr")
	private String ipaddr;
	@JsonProperty("country")
	private String country;
	
}
