package com.cummins.lambdatokenauth.param.dto;

import lombok.Data;

@Data
public class RequestPayload {
	public String Name;
}
