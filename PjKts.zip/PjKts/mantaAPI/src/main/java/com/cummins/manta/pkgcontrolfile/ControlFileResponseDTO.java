package com.cummins.manta.pkgcontrolfile;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ControlFileResponseDTO {

	@JsonProperty("correlationalGuid")
	private String correlationalGuid;
	@JsonProperty("message")
	private String message;
}
