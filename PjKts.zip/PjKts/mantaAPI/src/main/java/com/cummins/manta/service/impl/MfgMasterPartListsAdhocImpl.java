package com.cummins.manta.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.manta.common.ChildAPI;
import com.cummins.manta.common.Constants;
import com.cummins.manta.common.CountAndData;
import com.cummins.manta.common.PackageMfgMasterRequest;
import com.cummins.manta.common.PackageMfgMasterResponse;
import com.cummins.manta.common.ResponseSummary;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.dto.PartListsAdhocDto;
import com.cummins.manta.pkgcalibration.AdditionList;
import com.cummins.manta.pkgcalibration.CalibrationRequestDTO;
import com.cummins.manta.pkgcalibration.DeletionList;
import com.cummins.manta.pkgcalibration.PartList;
import com.cummins.manta.pkgcalibration.PartNumberListing;
import com.cummins.manta.pkgcontrolfile.ControlFileRequestDTO;
import com.cummins.manta.pkgshoporder.ShopOrderRequest;
import com.cummins.manta.pkgsupport.AdditionListRequest;
import com.cummins.manta.pkgsupport.DeletionListRequest;
import com.cummins.manta.pkgsupport.SupportFileListRequest;
import com.cummins.manta.pkgsupport.SupportRequestDTO;
import com.cummins.manta.repository.PackageMfgMasterRepo;
@Service
public class MfgMasterPartListsAdhocImpl {
	private final Logger logger = LoggerFactory.getLogger(MfgMasterPartListsAdhocImpl.class);

	@Autowired
	ParamStore paramStore;

	@Autowired
	PackageMfgMasterRepo repo;

	@Autowired
	CommonUtility commonUtility;

	@SuppressWarnings("unchecked")
	public PackageMfgMasterResponse processPartsListsAdhocRequests(PackageMfgMasterRequest req, List<String> ecProducts) {
		PackageMfgMasterResponse packageMfgMasterResponse=new PackageMfgMasterResponse();
		packageMfgMasterResponse.setCorrelationGuid(req.getCorrelationGuid());
		packageMfgMasterResponse.setPlantId(req.getPlantId());
		ResponseSummary responseSummary=new ResponseSummary();
		try {
			//Step2 : call DB
			responseSummary.setDbProceduresStatus(commonUtility.loadDBAndProcedures(req));
			logger.info("MfgMaster:partListAdhoc:req:"+req+":DB procedure completed");
			//Step3 : PkgCalAPI
			List<PartListsAdhocDto> plAddCalSupDetails=new ArrayList<>();
			List<PartListsAdhocDto> plDelCalDetails=new ArrayList<>();
			List<PartListsAdhocDto> plDelSupDetails=new ArrayList<>();
			if(Constants.ALL.equalsIgnoreCase(req.getMode())){
				if(Constants.PARTLISTS.equalsIgnoreCase(req.getOrigin())) {
					plAddCalSupDetails=repo.getALLPartListsCalSupDetails(req.getPlantId());
				}else {//adhoc
					plAddCalSupDetails=repo.getALLAdhocCalSupDetails(req.getPlantId());
				}
			}else {
				if(Constants.PARTLISTS.equalsIgnoreCase(req.getOrigin())) {
					plAddCalSupDetails=repo.getAddDAYPartListsCalSupDetails(req.getPlantId());
					plDelCalDetails=repo.getDelDAYPartListsCalDetails(req.getPlantId());
					plDelSupDetails=repo.getDelDAYPartListsSupDetails(req.getPlantId());
				}else {//adhoc
					plAddCalSupDetails=repo.getAddDAYAdhocCalSupDetails(req.getPlantId());
					plDelCalDetails=repo.getDelDAYAdhocCalDetails(req.getPlantId());
					plDelSupDetails=repo.getDelDAYAdhocSupDetails(req.getPlantId());
				}
			}
			logger.info("MfgMaster:partlistAdhoc:req:"+req+":calling cal select query");
			Map<String,CalibrationRequestDTO> allProductsDTO=getPartListsDetails(req,ecProducts,plAddCalSupDetails,plDelCalDetails);
			boolean isRegularPresent=false;
			boolean isExportPresent=false;
			if(null!=allProductsDTO) {
				CalibrationRequestDTO regularCalibrationRequestDTO=allProductsDTO.get(Constants.REQUESTREGULAR);
				CalibrationRequestDTO exportControlCalibrationRequestDTO=allProductsDTO.get(Constants.REQUESTEXPORTCONTROL);
				if(null!=regularCalibrationRequestDTO) {
					isRegularPresent=true;
					logger.info("Executing regular product Calibration");
					//for regular api is not called so passing url as null
					ChildAPI calReguar=commonUtility.callChildAPI(regularCalibrationRequestDTO,req.getCorrelationGuid(),null, Constants.CALIBRATION);
					responseSummary.setCalibration(calReguar);
					//productIdList.addAll(regularCalibrationRequestDTO.getAdditionList().stream().map(AdditionList::getProductId).collect(Collectors.toList()));
				}
				if(null!=exportControlCalibrationRequestDTO) {
					isExportPresent=true;
					logger.info("Executing export control product Calibration");
					ChildAPI calExport=commonUtility.callChildAPI(exportControlCalibrationRequestDTO,req.getCorrelationGuid(),paramStore.getPkgExpControlCalAPI(), Constants.CALIBRATION);
					if(null!=regularCalibrationRequestDTO) {
						ChildAPI calRegular=responseSummary.getCalibration();
						CountAndData regularSCountAData=calRegular.getSuccess();
						regularSCountAData.setCount(regularSCountAData.getCount()+calExport.getSuccess().getCount());
						regularSCountAData.getData().addAll(calExport.getSuccess().getData());
						CountAndData regularFCountAData=calRegular.getFailure();
						regularFCountAData.setCount(regularFCountAData.getCount()+calExport.getFailure().getCount());
						regularFCountAData.getData().addAll(calExport.getFailure().getData());

						responseSummary.setCalibration(new ChildAPI(regularSCountAData, regularFCountAData));
					}else {
						responseSummary.setCalibration(calExport);
					}
					//productIdList.addAll(exportControlCalibrationRequestDTO.getAdditionList().stream().map(AdditionList::getProductId).collect(Collectors.toList()));
				}
			}else {
				logger.info(req.getOrigin()+" Calibration details not found for given Plant Id:"+req.getPlantId());
				responseSummary.setPackagingStatus("Calibration details not found:"+req.getPlantId());
			}
			//Step4 : PkgSupportAPI
			logger.info("MfgMaster:partlistAdhoc:req:"+req+":calling Sup select query");
			Map<String,Object> allSupProductsDTO=getPartListsSupDetails(req,ecProducts,plAddCalSupDetails,plDelSupDetails);
			if(null!=allSupProductsDTO) {
				SupportRequestDTO regularSupportRequestDTO=(SupportRequestDTO) allSupProductsDTO.get(Constants.REQUESTREGULAR);
				SupportRequestDTO exportSupportRequestDTO=(SupportRequestDTO) allSupProductsDTO.get(Constants.REQUESTEXPORTCONTROL);
				if(null!=regularSupportRequestDTO) {
					isRegularPresent=true;
					logger.info("Executing regular product Support");
					ChildAPI supReguar=commonUtility.callChildAPI(regularSupportRequestDTO,req.getCorrelationGuid(),null, Constants.SUPPORT);
					responseSummary.setSupport(supReguar);
				}
				if(null!=exportSupportRequestDTO) {
					isExportPresent=true;
					logger.info("Executing export control product Support");
					ChildAPI calExport=commonUtility.callChildAPI(exportSupportRequestDTO,req.getCorrelationGuid(),paramStore.getPkgExpControlSupportAPI(), Constants.SUPPORT);
					if(null!=regularSupportRequestDTO) {
						ChildAPI supRegular=responseSummary.getSupport();
						CountAndData regularSCountAData=supRegular.getSuccess();
						regularSCountAData.setCount(regularSCountAData.getCount()+calExport.getSuccess().getCount());
						regularSCountAData.getData().addAll(calExport.getSuccess().getData());
						CountAndData regularFCountAData=supRegular.getFailure();
						regularFCountAData.setCount(regularFCountAData.getCount()+calExport.getFailure().getCount());
						regularFCountAData.getData().addAll(calExport.getFailure().getData());
						responseSummary.setSupport(new ChildAPI(regularSCountAData, regularFCountAData));
					}else {
						responseSummary.setSupport(calExport);
					}
				}
			}else {
				logger.info(req.getOrigin()+" Support details not found for given Plant Id:"+req.getPlantId());
				responseSummary.setPackagingStatus(responseSummary.getPackagingStatus()+",Support details not found:"+req.getPlantId());
			}
			if(null!=allProductsDTO  || null!=allSupProductsDTO) {
				//Step 8 : process errors if any  // earlier this step was present after Step7 files 
				responseSummary.setErrorHandleStatus(commonUtility.processPkgErrors(req,(Map<String, String>) allSupProductsDTO.get("DTO"),responseSummary,packageMfgMasterResponse));

				//Step5 : PkgShopOrderAPI
				if(Constants.PARTLISTS.equalsIgnoreCase(req.getOrigin())) {
					responseSummary.setShopOrder(commonUtility.callChildAPI(getShopOrderRequest(req),req.getCorrelationGuid(),null, Constants.SHOPORDER));
				}
				//Step6 : PkgControlFileAPI
				List<String> productIdList=new LinkedList<>();
				if(Constants.PARTLISTS.equalsIgnoreCase(req.getOrigin())) {
					productIdList=repo.getPartListsProductIds(req.getPlantId());
				}else if(Constants.ADHOC.equalsIgnoreCase(req.getOrigin())){
					productIdList=repo.getAdhocProductIds(req.getPlantId());
				}
				responseSummary.setControl(commonUtility.callChildAPI(getPartListsControlFileDeatils(req, productIdList),req.getCorrelationGuid(),null, Constants.CONTROL));

				//Step7 : PkgFiles
				if(Constants.ADHOC.equalsIgnoreCase(req.getOrigin())) {
					responseSummary.setPackagingStatus(commonUtility.packageFiles(req,isRegularPresent,isExportPresent));
				}
			}else {
				responseSummary.setPackagingStatus("Calibration and Support details not found for given plant id:"+req.getPlantId());
				//Step 8 : process errors if any
				responseSummary.setErrorHandleStatus(commonUtility.processPkgErrors(req,new HashMap<String, String>(),responseSummary,packageMfgMasterResponse));
				logger.error("Calibration and Support details not found for given plant id:"+req.getPlantId());
				//commonUtility.writeToLogFile(req, "Calibration and Support details not found for given plant id:"+req.getPlantId());
				return new PackageMfgMasterResponse(req.getCorrelationGuid(), req.getPlantId(),null,responseSummary);
			}
			packageMfgMasterResponse.setSummary(responseSummary);
			commonUtility.sendEmail(req.getPlantId(),"refresh");
		}catch (Exception e) {
			//Step 8 : process errors if any
			responseSummary.setErrorHandleStatus(commonUtility.processPkgErrors(req,new HashMap<String, String>(),responseSummary,packageMfgMasterResponse));
			logger.error(e.getMessage());
			e.printStackTrace();
			//commonUtility.writeToLogFile(req, e.getMessage());
			return new PackageMfgMasterResponse(req.getCorrelationGuid(), req.getPlantId(),e.getMessage(),responseSummary);
		}
		//commonUtility.writeToLogFile(req, packageMfgMasterResponse);
		return packageMfgMasterResponse;
	}

	private Map<String,CalibrationRequestDTO> getPartListsDetails(PackageMfgMasterRequest req,List<String> ecProducts,List<PartListsAdhocDto> plsAddCalDetails,List<PartListsAdhocDto> plDelCalDetails) {
		if((null==plsAddCalDetails || plsAddCalDetails.isEmpty()) && (null==plDelCalDetails || plDelCalDetails.isEmpty())) {
			logger.error(req.getOrigin()+" Calibration details not found for given Plant Id:"+req.getPlantId());
			return null;
		}
		Map<String,CalibrationRequestDTO> requestDtos=new HashMap<>();

		List<PartListsAdhocDto> plAddCalDetails=plsAddCalDetails.stream().filter(pls -> !"SUPPORT".equals(pls.getFILE_TYPE_NAME())).collect(Collectors.toList());
		//List<PartListsAdhocDto> plDelCalDetails=plDelCalSupDetails.stream().filter(pls -> !"SUPPORT".equals(pls.getFILE_TYPE_NAME())).collect(Collectors.toList());
		//true contains exportControl products, false contains regular products
		Map<Boolean, List<PartListsAdhocDto>> allAddProducts =plAddCalDetails.stream().collect(Collectors.partitioningBy(dto -> ecProducts.contains(dto.getPRODUCT_ID())));
		for (boolean isECProducts : allAddProducts.keySet()) {
			List<PartListsAdhocDto> splitAddProducts=allAddProducts.get(isECProducts);
			if(null!=splitAddProducts && !splitAddProducts.isEmpty()) {
				String key=isECProducts?Constants.REQUESTEXPORTCONTROL:Constants.REQUESTREGULAR;
				CalibrationRequestDTO requestDTO=new CalibrationRequestDTO();
				requestDTO.setMode(req.getMode());
				requestDTO.setOrigin(req.getOrigin());
				requestDTO.setPlantID(req.getPlantId());
				requestDTO.setCorrelationGuid(req.getCorrelationGuid());
				Map<String, List<PartListsAdhocDto>> plDetails=splitAddProducts.stream().collect(Collectors.groupingBy(PartListsAdhocDto::getPRODUCT_ID));
				for (String productId : plDetails.keySet()) {
					List<PartListsAdhocDto> productDetails=plDetails.get(productId);
					//adding filenames
					AdditionList additionList=new AdditionList();
					additionList.setProductId(productId);
					List<PartListsAdhocDto> ecmParts=productDetails.stream().filter(pls-> "ECM".equals(pls.getFILE_TYPE_NAME())).collect(Collectors.toList());
					//getting only ecm type files
					if(null!=ecmParts && !ecmParts.isEmpty()) {
						additionList.setProductType(ecmParts.get(0).getPRODUCT_TYPE());
						List<String> fileNames=ecmParts.stream().map(PartListsAdhocDto::getPART_NUMBER).map(str-> paramStore.getCalFilePath()+productId+"\\"+str).collect(Collectors.toList());
						additionList.setFileName(fileNames);
					}

					//adding partnumberlistings
					//getting all PART and MAF files
					List<PartListsAdhocDto> partMAFLists=productDetails.stream().filter(pls-> !"ECM".equals(pls.getFILE_TYPE_NAME())).collect(Collectors.toList());
					if(null!=partMAFLists&& !partMAFLists.isEmpty()) {
						additionList.setProductType("MultiA");
						Map<String, List<PartListsAdhocDto>> ecmDetails=partMAFLists.stream().collect(Collectors.groupingBy(PartListsAdhocDto::getECM_CODE));
						for (String ecmDetail : ecmDetails.keySet()) {
							PartNumberListing partNumberListing=new PartNumberListing();
							partNumberListing.setEcmCode(ecmDetail);
							List<PartListsAdhocDto> parts=ecmDetails.get(ecmDetail);
							for (PartListsAdhocDto part : parts) {
								PartList list=new PartList();
								//list.setSourceName(part.getPART_NUMBER());
								//list.setTargetName(part.getPART_NUMBER());
								//list.setSourceFilePath(part.getITM_INT_PATH());
								if("PART".equals(part.getFILE_TYPE_NAME())) {
									list.setSourceName(part.getPART_NUMBER());
									list.setTargetName(part.getPART_NUMBER());
									list.setSourceFilePath(part.getITM_INT_PATH());
								}else if("MAF".equals(part.getFILE_TYPE_NAME())) {
									list.setSourceName(part.getPART_NUMBER());
									list.setTargetName(part.getFILE_NAME());
									list.setSourceFilePath(part.getITM_INT_PATH());
								} 
								partNumberListing.getPartList().add(list);
							}
							additionList.getPartNumberListing().add(partNumberListing);
						}
					}
					requestDTO.getAdditionList().add(additionList);
				}
				requestDtos.put(key, requestDTO);
			}
		}
		//true contains exportControl products, false contains regular products
		Map<Boolean, List<PartListsAdhocDto>> allDelProducts =plDelCalDetails.stream().collect(Collectors.partitioningBy(dto -> ecProducts.contains(dto.getPRODUCT_ID())));
		//adding deletion 
		for (boolean isECProducts : allDelProducts.keySet()) {
			List<PartListsAdhocDto> splitDelProducts=allDelProducts.get(isECProducts);
			if(null!=splitDelProducts && !splitDelProducts.isEmpty()) {
				String key=isECProducts?Constants.REQUESTEXPORTCONTROL:Constants.REQUESTREGULAR;
				CalibrationRequestDTO requestDTO=null;
				if(null!=requestDtos.get(key)) {
					requestDTO=requestDtos.get(key);
				}else {
					requestDTO=new CalibrationRequestDTO();
					requestDTO.setMode(req.getMode());
					requestDTO.setOrigin(req.getOrigin());
					requestDTO.setPlantID(req.getPlantId());
					requestDTO.setCorrelationGuid(req.getCorrelationGuid());
				}
				Map<String, List<PartListsAdhocDto>> plDetails=splitDelProducts.stream().collect(Collectors.groupingBy(PartListsAdhocDto::getPRODUCT_ID));
				for (String productId : plDetails.keySet()) {
					//adding filenames
					DeletionList deletionList=new DeletionList();
					deletionList.setProductId(productId);
					List<PartListsAdhocDto> productDetails=plDetails.get(productId);
					//getting only ecm type files
					List<PartListsAdhocDto> ecmParts=productDetails.stream().filter(pls-> "ECM".equals(pls.getFILE_TYPE_NAME())).collect(Collectors.toList());
					if(null!=ecmParts && !ecmParts.isEmpty()) {
						deletionList.setProductType(ecmParts.get(0).getPRODUCT_TYPE());
						List<String> fileNames=ecmParts.stream().map( PartListsAdhocDto::getECM_CODE).collect(Collectors.toList());
						deletionList.setFileName(fileNames);
					}
					List<String> partMAFFiles=productDetails.stream().filter(pls-> !"ECM".equals(pls.getFILE_TYPE_NAME())).map( PartListsAdhocDto::getECM_CODE).collect(Collectors.toList());
					if(null!=partMAFFiles && !partMAFFiles.isEmpty()) {
						deletionList.setProductType("MultiA");
						deletionList.setFileName(partMAFFiles);
					}
					requestDTO.getDeletionList().add(deletionList);
				}
				requestDtos.put(key, requestDTO);
			}
		}

		return requestDtos;
	}
	private Map<String,Object> getPartListsSupDetails(PackageMfgMasterRequest req,List<String> ecProducts,List<PartListsAdhocDto> plAddCalSupDetails, List<PartListsAdhocDto> plDelSupDetails) {
		if((null==plAddCalSupDetails || plAddCalSupDetails.isEmpty()) && (null==plDelSupDetails || plDelSupDetails.isEmpty()))  {
			logger.error(req.getOrigin()+" Support details not found for given Plant Id:"+req.getPlantId());
			return null;
		}
		Map<String,Object> requestDtos=new HashMap<>();
		Map<String,String> ecmPartMap=new HashMap<>();
		List<PartListsAdhocDto> plAllAddSupDetails=plAddCalSupDetails.stream().filter(pls -> "SUPPORT".equals(pls.getFILE_TYPE_NAME())).collect(Collectors.toList());
		//List<PartListsAdhocDto> plAllDelSupDetails=plDelCalSupDetails.stream().filter(pls -> "SUPPORT".equals(pls.getFILE_TYPE_NAME())).collect(Collectors.toList());
		//true contains exportControl products, false contains regular products
		Map<Boolean, List<PartListsAdhocDto>> allAddProducts =plAllAddSupDetails.stream().collect(Collectors.partitioningBy(dto -> ecProducts.contains(dto.getPRODUCT_ID())));
		for (boolean isECProducts : allAddProducts.keySet()) {
			List<PartListsAdhocDto> splitAddProducts=allAddProducts.get(isECProducts);
			if(null!=splitAddProducts && !splitAddProducts.isEmpty()) {
				String key=isECProducts?Constants.REQUESTEXPORTCONTROL:Constants.REQUESTREGULAR;
				SupportRequestDTO requestDTO=new SupportRequestDTO();
				requestDTO.setMode(req.getMode());
				requestDTO.setOrigin(req.getOrigin());
				requestDTO.setPlantID(req.getPlantId());
				requestDTO.setCorrelationGuid(req.getCorrelationGuid());
				Map<String, List<PartListsAdhocDto>> plDetails=splitAddProducts.stream().collect(Collectors.groupingBy(PartListsAdhocDto::getPRODUCT_ID));
				for (String productId : plDetails.keySet()) {
					AdditionListRequest additionListRequest=new AdditionListRequest();
					additionListRequest.setProductId(productId);
					List<PartListsAdhocDto> supFiles=plDetails.get(productId);
					for (PartListsAdhocDto supFile : supFiles) {
						ecmPartMap.put(productId+"-"+supFile.getPART_NUMBER(),supFile.getECM_CODE());
						SupportFileListRequest sup=new SupportFileListRequest();
						sup.setSourceName(supFile.getPART_NUMBER());
						sup.setTargetName(supFile.getFILE_NAME());
						sup.setSourceFilePath(supFile.getITM_INT_PATH());
						additionListRequest.getSupportFileList().add(sup);
					}
					requestDTO.getAdditionListRequest().add(additionListRequest);
				}
				requestDtos.put(key, requestDTO);
			}
		}
		Map<Boolean, List<PartListsAdhocDto>> allDelProducts =plDelSupDetails.stream().collect(Collectors.partitioningBy(dto -> ecProducts.contains(dto.getPRODUCT_ID())));
		for (boolean isECProducts : allDelProducts.keySet()) {
			List<PartListsAdhocDto> splitDelProducts=allDelProducts.get(isECProducts);
			if(null!=splitDelProducts && !splitDelProducts.isEmpty()) {
				String key=isECProducts?Constants.REQUESTEXPORTCONTROL:Constants.REQUESTREGULAR;
				SupportRequestDTO requestDTO=null;
				if(null!=requestDtos.get(key)) {
					requestDTO=(SupportRequestDTO) requestDtos.get(key);
				}else {
					requestDTO=new SupportRequestDTO();
					requestDTO.setMode(req.getMode());
					requestDTO.setOrigin(req.getOrigin());
					requestDTO.setPlantID(req.getPlantId());
					requestDTO.setCorrelationGuid(req.getCorrelationGuid());
				}
				Map<String, List<PartListsAdhocDto>> plDetails=splitDelProducts.stream().collect(Collectors.groupingBy(PartListsAdhocDto::getPRODUCT_ID));
				for (String productId : plDetails.keySet()) {

					DeletionListRequest deletionListRequest=new DeletionListRequest();
					deletionListRequest.setProductId(productId);
					List<PartListsAdhocDto> supFiles=plDetails.get(productId);
					deletionListRequest.setSupportFileList(supFiles.stream().map(PartListsAdhocDto::getFILE_NAME).collect(Collectors.toList()));
					requestDTO.getDeletionListRequest().add(deletionListRequest);
				}
				requestDtos.put(key, requestDTO);
			}
		}
		requestDtos.put("DTO",ecmPartMap);
		return requestDtos;
	}
	private ShopOrderRequest getShopOrderRequest(PackageMfgMasterRequest req) {
		ShopOrderRequest shopOrderRequest=new ShopOrderRequest();
		shopOrderRequest.setOrigin(req.getOrigin());
		shopOrderRequest.setPlantID(req.getPlantId());
		shopOrderRequest.setTriggerType(req.getTriggerType());
		shopOrderRequest.setCorrelationGuid(req.getCorrelationGuid());
		return shopOrderRequest;
	}
	private ControlFileRequestDTO getPartListsControlFileDeatils(PackageMfgMasterRequest req,List<String> productIDList) {
		int plantCat=repo.getPlantCategory(req.getPlantId());
		String plantCategory=plantCat>0?"COE":"MFG";
		ControlFileRequestDTO fileRequestDTO=new ControlFileRequestDTO();
		fileRequestDTO.setOrigin(req.getOrigin());
		fileRequestDTO.setPlantID(req.getPlantId());
		fileRequestDTO.setProductIDList(productIDList);
		fileRequestDTO.setPlantType(plantCategory);
		fileRequestDTO.setTriggerType(req.getTriggerType());
		fileRequestDTO.setCorrelationGuid(req.getCorrelationGuid());
		return fileRequestDTO;
	}
}