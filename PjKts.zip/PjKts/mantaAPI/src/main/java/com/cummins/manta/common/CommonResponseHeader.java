/*
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Vishal.
 */

package com.cummins.manta.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommonResponseHeader implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2323340964009768888L;

	@JsonProperty("success")
	private boolean success;

	@JsonProperty("code")
	private Integer code;

	@JsonProperty("message")
	private String message;

	@Override
	public String toString() {
		return "CommonResponseHeader{" +
				"success=" + success +
				", code=" + code +
				", message='" + message + '\'' +
				'}';
	}
}