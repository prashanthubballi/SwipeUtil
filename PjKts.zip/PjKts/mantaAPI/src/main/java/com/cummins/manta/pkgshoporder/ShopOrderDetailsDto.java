package com.cummins.manta.pkgshoporder;

import java.util.List;
import lombok.Data;

@Data
public class ShopOrderDetailsDto {

  String partListNumber;
  List<CalibrationDetails> calibrationList;
}
