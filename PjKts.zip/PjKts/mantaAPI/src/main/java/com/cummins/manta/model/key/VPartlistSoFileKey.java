package com.cummins.manta.model.key;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;
@Data
@Embeddable
public class VPartlistSoFileKey implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1501847236463837973L;

  @Column(name = "DDO_ECM_CODE")
  private String ddoEcmCode;

  @Column(name = "DDO_OPTION")
  private String ddoOption;

  @Column(name = "DDO_OPTION_PREFIX")
  private String ddoOptionPrefix;

  @Column(name = "DDO_TYPE")
  private String ddoType;

  @Column(name = "MPLU_MODULE")
  private String mpluModule;

  @Column(name = "MPLU_PART_NUM")
  private String mpluPartNum;

  @Column(name = "MPLU_PLANT")
  private String mpluPlant;

  @Column(name = "MPLU_PROD_ID")
  private String mpluProdId;
}

