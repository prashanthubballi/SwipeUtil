package com.cummins.manta.service.rptrigger.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.persistence.PersistenceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.web.client.RestTemplate;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.CommonResponseHeader;
import com.cummins.manta.common.PackageMfgMasterRequest;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.pkgrptrigger.Constants;
import com.cummins.manta.pkgrptrigger.PackageMfgRPTriggerMasterResponse;
import com.cummins.manta.pkgrptrigger.PackageMfgRPTriggerRequest;
import com.cummins.manta.pkgrptrigger.PackageMfgdto;
import com.cummins.manta.repository.PackageMfgMasterRepo;
import com.cummins.manta.service.impl.MDCExecutorService;
import com.cummins.manta.service.impl.MfgMasterImpl;

@Service
public class PackageMfgRPTriggerServiceImpl {
	@Autowired
	private ParamStore paramStore;
	
	@Autowired
	private PackageMfgMasterRepo repo;
	@Autowired
	private MfgMasterImpl mfgMasterImpl;
	@Autowired
	private CallDBServices dbServices;
	private final Logger logger = LoggerFactory.getLogger(PackageMfgRPTriggerServiceImpl.class);

	public CommonResponse<PackageMfgRPTriggerMasterResponse> packageMfgFiles(PackageMfgRPTriggerRequest request) {
		logger.info("PackageMfg trigger RP trigger started.");
		PackageMfgRPTriggerMasterResponse masterResponse = new PackageMfgRPTriggerMasterResponse();
		CommonResponseHeader commonResponseHeader = null;
		
		try {
			dbServices.storeAudits(request.getGuid().toUpperCase(), Constants.PACKAGEMFGRPTRIGGER,Constants.PACKAGEMFGRPTRIGGER_STARTED, Constants.PACKAGEMFGRPTRIGGER_STARTED_CODE);
			repo.updateAdhocPlants();
			List<PackageMfgdto> plantList = repo.getlistofPlantIds();
			logger.info("The number of records fetched is " + plantList.size());
			//writeLogFile(request.getGuid(), plantList, Constants.REQUESTLOGFILENAME);
			
			if (!plantList.isEmpty()) {
				callMultiThreadPool(paramStore.getCommonThreadPool(),plantList, request.getGuid());
				commonResponseHeader = new CommonResponseHeader(true, 200, "PackageMfgMasterRPTrigger Completed");
			} else {
				
				commonResponseHeader = new CommonResponseHeader(true, 200,"PackageMfgMasterRPTrigger Data not present , PackageMfgMasterRPTrigger Completed");
			}
			dbServices.storeAudits(request.getGuid().toUpperCase(), Constants.PACKAGEMFGRPTRIGGER,Constants.PACKAGEMFGRPTRIGGER_COMPLETED, Constants.PACKAGEMFGRPTRIGGER_COMPLETED_CODE);
			logger.info("PackageMfg trigger RP trigger completed.");
			logger.info("Made completed entry in t_audit table");
		} catch (PersistenceException | CannotCreateTransactionException e) {
			logger.error("PackageMfg trigger RP trigger failed with internal server.{}",e.getMessage());
			e.printStackTrace();
			commonResponseHeader = new CommonResponseHeader(true, 500, "Internal Server Error");
			return new CommonResponse<>(commonResponseHeader, masterResponse);
		} catch (Exception e) {
			logger.error("PackageMfg trigger RP trigger failed with exception.{}",e.getMessage());
			commonResponseHeader = new CommonResponseHeader(true, 400, e.getMessage());
			dbServices.storeAudits(request.getGuid().toUpperCase(), Constants.PACKAGEMFGRPTRIGGER,Constants.PACKAGEMFGRPTRIGGER_COMPLETED, Constants.PACKAGEMFGRPTRIGGER_COMPLETED_CODE);
			logger.error("Made completed entry in t_audit table");
			return new CommonResponse<>(commonResponseHeader, masterResponse);
		}
		return new CommonResponse<>(commonResponseHeader, masterResponse);
	}

	public List<String> callMultiThreadPool(int numOfThreads, List<PackageMfgdto> plantList,String guid) throws Exception {
		ExecutorService delegate = Executors.newFixedThreadPool(numOfThreads);
		MDCExecutorService<ExecutorService> pool=new MDCExecutorService<ExecutorService>(delegate);
		List<Callable<String>> additiontasks = new ArrayList<>();
		logger.info("PkgRPTrigger:calling master api");
		for (int i = 0; i < plantList.size(); i++) {

			PackageMfgMasterRequest req = new PackageMfgMasterRequest();
			req.setCorrelationGuid(guid + "#" + i);
			req.setPlantId(plantList.get(i).getPLANT());
			req.setOrigin(plantList.get(i).getORIGIN());
			req.setMode(Constants.MODE);
			req.setTriggerType(Constants.TRIGGERTYPE);
			additiontasks.add((Callable<String>) () -> {

				return mfgMasterImpl.manufacturingPkgMaster(req).toString();
			});

		}
		List<String> allResults = new ArrayList<>();
		List<Future<String>> additionResults = pool.invokeAll(additiontasks);
		logger.info("PkgRPTrigger:invoked master api");
		for (Future<String> result : additionResults) {
			allResults.add(result.get());
		}
		logger.info("PkgRPTrigger:completed master api");
		pool.shutdown();
		return allResults;
	}

	

	
	
}
