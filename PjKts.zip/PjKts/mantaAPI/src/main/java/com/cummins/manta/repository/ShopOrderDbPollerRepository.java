package com.cummins.manta.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import com.cummins.manta.model.key.TShopTempVO;
import com.cummins.manta.pkgdbpoller.TShopTempDto;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface ShopOrderDbPollerRepository extends JpaRepository<TShopTempVO, Long> {
	
	List<TShopTempVO> findByPlantIdAndLastUpdateDate(String plantId,Date lastUpdateDate);
	List<TShopTempVO> findByLastUpdateDate(Date lastUpdateDate);
	List<TShopTempVO> findByPlantId(String plantId);


	@Query(value = "SELECT TST_SEQ_ID AS Id, TST_PLANT_ID AS PlantId, TST_PROCESSED_FLAG AS ProcessedFlag, TST_LOAD_FLAG AS LoadFlag, TO_CHAR(TST_LAST_UPDATE_DATE,'YYYY-MM-DD HH24:MI') AS LastUpdateDate FROM T_SHOP_TEMP where " + 
			" TST_LOAD_FLAG=?1 and TST_PROCESSED_FLAG is null", nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "30"))
	List<TShopTempDto> getTShopTempYLoadFlagData(String flag);
	
	@Query(value = "SELECT TST_SEQ_ID AS Id,"
			+ "  TST_PLANT_ID AS PlantId,"
			+ "  TST_PROCESSED_FLAG AS ProcessedFlag,"
			+ "  TST_LOAD_FLAG AS LoadFlag,"
			+ "  TO_CHAR(TST_LAST_UPDATE_DATE,'YYYY-MM-DD HH24:MI') AS LastUpdateDate"
			+ " FROM T_SHOP_TEMP where TST_PROCESSED_FLAG=?1 and TST_LOAD_FLAG='Y'", nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "30"))
	List<TShopTempDto> getTShopTempIPProcessedFlagData(String flag);

	@Modifying
	@Query(value = "update T_SHOP_TEMP set TST_LOAD_FLAG=?1 where TST_PLANT_ID=?2 and to_char(TST_LAST_UPDATE_DATE,'YYYY-MM-DD HH24:MI') in (?3)", nativeQuery = true)
	public void updateTShopLoadTable(String flag, String plantId,List<String> updateDate);

	@Modifying
	@Query(value = "update T_SHOP_LOAD set TST_LOAD_FLAG=?1 where TST_PLANT_ID=?2", nativeQuery = true)
	public void updateTempShopTable(String flag, String plantId);

	@Modifying
	@Query(value = "insert into T_SHOP_LOAD values(?1,null,?2,TO_DATE(?3, 'YYYY-MM-DD HH24:MI'))", nativeQuery = true)
	public void insertIntoTempShopTable(String plantId, String flag, String updateDate);

}
