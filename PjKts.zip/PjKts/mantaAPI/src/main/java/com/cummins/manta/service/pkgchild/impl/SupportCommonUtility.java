package com.cummins.manta.service.pkgchild.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.StandardCopyOption;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.ZipParameters;

@Service
public class SupportCommonUtility {
  private final static Logger logger = LoggerFactory.getLogger(SupportCommonUtility.class);

  
  /**
   * 
   * @param tempCopyPath
   * @param ecmCode
   * @param password
   * @param filesToAdd part/multiA
   * @param fileToAdd for core
   * @return
   * @throws IOException
   */
  public String copyItemFiles(File srcFile,String destFileName)throws IOException {
  //  String outputPath=tempCopyPath//+Constants.SLASH+ecmCode+Constants.SCAL;
	  File destFile=new File(destFileName);
      if(destFile.exists()) {
    	  destFile.delete();
      }
      FileUtils.copyFile(srcFile, destFile, StandardCopyOption.REPLACE_EXISTING);
      logger.info("Copy successful for:"+destFileName);
    return destFileName;
  }
  public String zipMainFolder(String srcPath, String outputPath) throws IOException {
    logger.info("Folder zip started:src"+srcPath+" dst:"+outputPath);
    if(new File(outputPath).exists()) {
      boolean status=new File(outputPath).delete();
      logger.info("Deleting existing zip in dst,status:"+status);
    }
    File dir = new File(srcPath);
    ZipParameters parameters = new ZipParameters();
    parameters.setIncludeRootFolder(false);
    try (ZipFile zipFile = new ZipFile(outputPath); ) {
      zipFile.addFolder(dir, parameters);
    }
    logger.info("Folder zip completed:"+outputPath);
    return outputPath;
  }
  
}
