package com.cummins.manta.pkgshoporder;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ShopOrderRequest {
	@JsonProperty("correlationGuid")
	String correlationGuid;
	@JsonProperty("origin")
	String origin;
//	@JsonProperty("productIDList")
//	List<String> productIDList;
	@JsonProperty("plantID")
	String plantID;
//	@JsonProperty("plantType")
//	String plantType;
	@JsonProperty("triggerType")
	String triggerType;
}
