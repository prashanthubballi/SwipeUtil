package com.cummins.manta.pkgsupport;

import java.util.List;
import lombok.Data;

@Data
public class DeletionListRequest {

	String productId;

	List<String> supportFileList;
}
