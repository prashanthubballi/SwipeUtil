package com.cummins.manta.pkgcalibration;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class DeletionList {
	private String productId;
	//private String ecmCode;
	private List<String> fileName=new ArrayList<>();
	private String productType;
	//private List<String> ecmCodes=new ArrayList<>();

}
