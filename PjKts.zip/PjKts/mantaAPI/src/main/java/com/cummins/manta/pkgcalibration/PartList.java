package com.cummins.manta.pkgcalibration;

import lombok.Data;

@Data
public class PartList {
	private String sourceName;
	private String targetName;
	private String sourceFilePath;
}
