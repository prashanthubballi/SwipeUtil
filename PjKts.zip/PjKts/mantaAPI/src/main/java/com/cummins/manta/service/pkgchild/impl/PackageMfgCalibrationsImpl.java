package com.cummins.manta.service.pkgchild.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.CommonResponseHeader;
import com.cummins.manta.common.Constants;
import com.cummins.manta.common.CountAndData;
import com.cummins.manta.common.ObjectData;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.exception.BadRequestException;
import com.cummins.manta.pkgcalibration.AdditionList;
import com.cummins.manta.pkgcalibration.CalibrationConstants;
import com.cummins.manta.pkgcalibration.CalibrationRequestDTO;
import com.cummins.manta.pkgcalibration.CommonResponseData;
import com.cummins.manta.pkgcalibration.DeletionList;
import com.cummins.manta.pkgcalibration.PartList;
import com.cummins.manta.pkgcalibration.PartNumberListing;
import com.cummins.manta.service.PackageMfgCalibrationService;
import com.cummins.manta.service.impl.MDCExecutorService;

import io.github.resilience4j.retry.Retry;

@Service
public class PackageMfgCalibrationsImpl implements PackageMfgCalibrationService {
	private final Logger logger = LoggerFactory.getLogger(PackageMfgCalibrationsImpl.class);

	@Autowired
	private ParamStore paramStore;
	
	@Autowired
	private CalibrationCommonUtility commonUtility;

	@Autowired
	Retry retry;

	@Override
	public CommonResponse<CommonResponseData> processMfgCalibrations(CalibrationRequestDTO req) {
		CommonResponse<CommonResponseData> response = new CommonResponse<>();
		CommonResponseHeader responseHeader = new CommonResponseHeader();
		CommonResponseData responseData = new CommonResponseData();
		try {
			logger.info("ProcessMfgCalibrations Started. Child req: {}",req);
			//validating input
			validateInput(req);
			//check mode and delete files if data present
			deleteFiles(req);
			//copy file to temp folder with encryption etc
			responseData=copyFilesToTempAndEncrypt(req);
			//create calibration.zip if all goes well.
			if(!CalibrationConstants.ADHOC.equalsIgnoreCase(req.getOrigin()) && null!=responseData.getSuccess() && responseData.getSuccess().getCount()>0) {
				logger.info("Creating zip");
				String outputPath=commonUtility.getDestinationPath(req);
				String srcPath=commonUtility.getTempPath(req);
				String zipresponse=	retry.executeCheckedSupplier(()->{ return commonUtility.zipMainFolder(srcPath, outputPath);});
				logger.info("Zip Response:"+zipresponse);
			}else {
				logger.info("Response does not have any files to zip or adhoc request.");
			}
			responseHeader.setCode(HttpStatus.OK.value());
			responseHeader.setMessage("Success");
			responseHeader.setSuccess(true);
		}catch (BadRequestException e) {
			responseHeader.setCode(HttpStatus.OK.value()); // updated to OK to avoid causing exception in parent
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}catch (Exception e) {
			responseHeader.setCode(HttpStatus.OK.value());// updated to OK to avoid causing exception in parent
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		} catch (Throwable e) {
			e.printStackTrace();
			responseHeader.setCode(HttpStatus.OK.value());// updated to OK to avoid causing exception in parent
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}

		responseData.setCorrelationGuid(req.getCorrelationGuid());
		response.setHeader(responseHeader);
		response.setData(responseData);
		logger.info("ProcessMfgCalibrations Completed.Child resp: {}",response);
		//commonUtility.writeToLogFile(CalibrationConstants.logFilePath, req, response);
		return response;
	}

	private void validateInput(CalibrationRequestDTO req) {
		logger.info("Validating input");
		if(null==req.getCorrelationGuid() || "".equalsIgnoreCase(req.getCorrelationGuid())) {
			throw new BadRequestException("Invalid Input: CorrelationGuid is required");
		}
		if(null==req.getOrigin() || "".equalsIgnoreCase(req.getOrigin())) {
			throw new BadRequestException("Invalid Input: Origin is required");
		}
		if(!CalibrationConstants.ADHOC.equalsIgnoreCase(req.getOrigin()) && !CalibrationConstants.SHOPORDER.equalsIgnoreCase(req.getOrigin()) && !CalibrationConstants.PARTLIST.equalsIgnoreCase(req.getOrigin())) {
			throw new BadRequestException("Invalid Origin, Allowed origin:Adhoc,ShopOrder,PartList");
		}
		if(!Constants.ALL.equalsIgnoreCase(req.getMode()) && !Constants.DAY.equalsIgnoreCase(req.getMode())) {
			throw new BadRequestException("Invalid Mode, Allowed mode:DAY,ALL");
		}
		logger.info("Validation Completed");
	}

	private void deleteFiles(CalibrationRequestDTO req) {

		if(Constants.ALL.equalsIgnoreCase(req.getMode())) {
			logger.info("Deleting Files, Mode:"+req.getMode());
			String tempPath=commonUtility.getTempPath(req);
			boolean status=FileSystemUtils.deleteRecursively(new File(tempPath));
			logger.info("Deleting folder :"+tempPath+", status:"+status);
		}else {
			List<String> deleteFailures=new ArrayList<>();
			logger.info("Deleting Files, Mode:"+req.getMode());
			List<DeletionList> deletionList = req.getDeletionList();
			String tempFolder = commonUtility.getTempPath(req);
			for (DeletionList deletion : deletionList) {
				//String productType = deletion.getProductType().toLowerCase();
				for (String fileName : deletion.getFileName()) {
					String deleteFilePath=tempFolder+deletion.getProductId()+Constants.SLASH+fileName;
					if(new File(deleteFilePath+CalibrationConstants.SCAL).exists()) {
						String filePathFull=deleteFilePath+CalibrationConstants.SCAL;
						boolean status=retryDelete(filePathFull);
						logger.info("Deleting file in :"+filePathFull+", status:"+status);
						if(!status) {
							deleteFailures.add(filePathFull);
						}
					}else if(new File(deleteFilePath+CalibrationConstants.PDX).exists()) {
						String filePathFull=deleteFilePath+CalibrationConstants.PDX;
						boolean status=retryDelete(filePathFull);
						logger.info("Deleting file in :"+filePathFull+", status:"+status);
						if(!status) {
							deleteFailures.add(filePathFull);
						}
					}else {
						logger.error("File not found for deletion:"+deleteFilePath);
					}
				}
			}
			if(!deleteFailures.isEmpty()) {
				logger.error("File deletion errors:"+deleteFailures);
			}
		}
	}

	/**
	 * in some case even though file exist giving true file is not getting deleted
	 * As retry trying 	to delete files again 3 times to make sure. else logging failure to file
	 * @param filePathFull
	 */
	//
	private boolean retryDelete(String filePathFull) {
		int count=0;
		boolean status;
		while(!(status=new File(filePathFull).delete()) && count<3) {
			logger.info("Deleting file in :"+filePathFull+",status:"+status+", count:"+count);
			count++;
		}
		if(new File(filePathFull).exists()) {
			return false;
		}
		return true;
	}

	private CommonResponseData copyFilesToTempAndEncrypt(CalibrationRequestDTO req) throws InterruptedException, ExecutionException {
		//logger.info("In CopyFile method");
		CommonResponseData responseData = new CommonResponseData();
		CountAndData success=new CountAndData();
		CountAndData failure=new CountAndData();
		success.setData(new LinkedList<ObjectData>());
		failure.setData(new LinkedList<ObjectData>());
		List<AdditionList> additionLists=req.getAdditionList();
		if(null!=additionLists && !additionLists.isEmpty()) {
			logger.info("AdditionList Present, Size:"+additionLists.size()+", list:"+additionLists);
			ExecutorService delegate = Executors.newFixedThreadPool(paramStore.getCalThreadPool());
			MDCExecutorService<ExecutorService> pool=new MDCExecutorService<ExecutorService>(delegate);
			
			List<Callable<Map<String, List<ObjectData>>>> tasks = new ArrayList<>();
			String pathToCopy=commonUtility.getTempPath(req);
			String password=commonUtility.getEncryptionKeyForPlant(req.getPlantID());
			for (AdditionList additionList : additionLists) {
				if(!"BHC".equals(additionList.getProductId())) {
					tasks.add((Callable<Map<String, List<ObjectData>>>) () -> invokeProductCopyAndEncrypt(pathToCopy, password, additionList));
				}
			}
			//logger.info("Invoking copy and encrypt");
			List<Future<Map<String, List<ObjectData>>>> invokeResults=pool.invokeAll(tasks);
			for (Future<Map<String, List<ObjectData>>> future : invokeResults) {
				//logger.info("Processing results");
				Map<String, List<ObjectData>> response=future.get();
				if(!response.get(CalibrationConstants.SUCCESS).isEmpty()) {
					success.getData().addAll(response.get(CalibrationConstants.SUCCESS));
				}
				if(!response.get(CalibrationConstants.FAILURE).isEmpty()) {
					failure.getData().addAll(response.get(CalibrationConstants.FAILURE));
				}
			}
			success.setCount(success.getData().size());
			failure.setCount(failure.getData().size());
			responseData.setSuccess(success);
			responseData.setFailure(failure);
			logger.info("Results fetched:"+req.getCorrelationGuid());
		}else {
			logger.info(req.getCorrelationGuid()+":No data for addition in request:"+req.getPlantID());
			responseData.setCorrelationGuid(req.getCorrelationGuid());
			responseData.setFailure(new CountAndData(0, new LinkedList<>()));
			responseData.setSuccess(new CountAndData(0, new LinkedList<>()));
		}
		return responseData;
	}

	private Map<String, List<ObjectData>> invokeProductCopyAndEncrypt(String tempPath,String password,AdditionList additionList) throws Exception{
		//logger.info("inside invokeProductCopyAndEncrypt method");
		Map<String, List<ObjectData>> map=new HashMap<>();
		map.put(CalibrationConstants.SUCCESS, new LinkedList<ObjectData>());
		map.put(CalibrationConstants.FAILURE, new LinkedList<ObjectData>());
		String productId=additionList.getProductId();
		String tempCopyPath=tempPath+productId;
		if("MultiA".equalsIgnoreCase(additionList.getProductType())) {
			//logger.info("inside MultiA");
			List<PartNumberListing> partNumberListings=additionList.getPartNumberListing();
			for (PartNumberListing partNumberListing : partNumberListings) {
				String ecmCode=partNumberListing.getEcmCode();
				List<File> filesToAdd=new LinkedList<>();
				Map<String, String> fileNamesMap = new HashMap<>();
				List<PartList> partLists=partNumberListing.getPartList();
				for (PartList partList : partLists) {
					if(null!=partList.getSourceFilePath()) {
						String srcFilePath=partList.getSourceFilePath();
						String targetName=partList.getTargetName();

						File srcFile=new File(srcFilePath);
						if(srcFile.exists()) {
							filesToAdd.add(srcFile);
							//multiA files rename case
							if(null!=targetName && null!=partList.getSourceName() && !partList.getSourceName().equalsIgnoreCase(partList.getTargetName())) {
								fileNamesMap.put(partList.getSourceName(), partList.getTargetName());
							}
						}else {
							map.get(CalibrationConstants.FAILURE).add(new ObjectData(productId, ecmCode, partList.getSourceName(), "File Not Found:"+srcFilePath));
						}
					}else {
						map.get(CalibrationConstants.FAILURE).add(new ObjectData(productId, ecmCode, partList.getSourceName(), "File Not Found SourcePath is null"));
					}
				}
				if(!filesToAdd.isEmpty()) {
					try {
						retry.executeCheckedSupplier(()->{ return commonUtility.copyAndEncryptFiles(tempCopyPath, ecmCode, password, filesToAdd,fileNamesMap,null);});
						map.get(CalibrationConstants.SUCCESS).add(new ObjectData(productId, ecmCode,null,CalibrationConstants.SUCCESS));
					}catch ( Throwable e) {
						map.get(CalibrationConstants.FAILURE).add(new ObjectData(productId, ecmCode,null,e.getMessage()));
					}
				}
			}
		}else if("CORE".equalsIgnoreCase(additionList.getProductType())){
			//logger.info("inside CORE");
			List<String> fileNames=additionList.getFileName();
			for (String fileName : fileNames) {
				File srcFile=new File(fileName);
				if(srcFile.exists()) {
					try {
						retry.executeCheckedSupplier(()->{ return commonUtility.copyAndEncryptFiles(tempCopyPath, srcFile.getName(), password, null,null,srcFile);});
						map.get(CalibrationConstants.SUCCESS).add(new ObjectData(productId, srcFile.getName(),null,CalibrationConstants.SUCCESS));
					}catch ( Throwable e) {
						map.get(CalibrationConstants.FAILURE).add(new ObjectData(productId, srcFile.getName(),null,e.getMessage()));
					}
				}else {
					map.get(CalibrationConstants.FAILURE).add(new ObjectData(productId, srcFile.getName(), null, "File Not Found:"+fileName));
				}
			}
		}else if("CSAR".equalsIgnoreCase(additionList.getProductType())) {
			//logger.info("inside CSAR");
			List<String> fileNames=additionList.getFileName();
			try {
				Files.createDirectories(Paths.get(tempCopyPath));
				for (String fileName : fileNames) {
					File srcFile=new File(fileName+CalibrationConstants.PDX);
					if(srcFile.exists()) {
						try {
							Path source=srcFile.toPath();
							Path newdir=new File(tempCopyPath).toPath();
							Path path=Files.copy(source, newdir.resolve(source.getFileName()), StandardCopyOption.REPLACE_EXISTING);
							logger.info("File copied to " + path.getFileName());
							map.get(CalibrationConstants.SUCCESS).add(new ObjectData(productId, srcFile.getName().replace(CalibrationConstants.PDX, ""),null,CalibrationConstants.SUCCESS));
						}catch (Exception e) {
							logger.error("Exception while copying file:"+e.getMessage());
							e.printStackTrace();
							map.get(CalibrationConstants.FAILURE).add(new ObjectData(productId, srcFile.getName().replace(CalibrationConstants.PDX, ""),null,"Unable to copy file :"+srcFile.getCanonicalPath()));
						}
					}else {
						map.get(CalibrationConstants.FAILURE).add(new ObjectData(productId, srcFile.getName().replace(CalibrationConstants.PDX, ""), null, "File Not Found:"+fileName));
					}
				}
			}catch (IOException e) {
				logger.error("Exception while creating directory for CSAR:"+e.getMessage());
				e.printStackTrace();
				map.get(CalibrationConstants.FAILURE).add(new ObjectData(productId,null, null, "Unable to create directory:"+tempCopyPath));
			}
		}
		return map;
	}
}

