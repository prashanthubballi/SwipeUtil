package com.cummins.manta.service.pkgchild.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.CommonResponseHeader;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.exception.BadRequestException;
import com.cummins.manta.pkgshoporder.PLObject;
import com.cummins.manta.pkgshoporder.ParentClassDto;
import com.cummins.manta.pkgshoporder.SOObject;
import com.cummins.manta.pkgshoporder.SOReconfig;
import com.cummins.manta.pkgshoporder.ShopOrder;
import com.cummins.manta.pkgshoporder.ShopOrderDetailsDto;
import com.cummins.manta.pkgshoporder.ShopOrderRequest;
import com.cummins.manta.pkgshoporder.ShopOrderResponse;
import com.cummins.manta.pkgshoporder.ShoporderDetail;
import com.cummins.manta.service.PackageShopOrderPartListService;

@Service
public class PackageShopOrderPartLImpl implements PackageShopOrderPartListService {

	private static final Logger logger = LoggerFactory.getLogger(PackageShopOrderPartLImpl.class);

	private static String splitKey="KEY";
	private static String ERROR_MESSAGE_INVALID_PARAMETER = "Invalid Parameter";
	@Autowired
	private ShopOrderPartListCommonUtility comUtil;

	@Autowired
	private ParamStore paramStore;

	@Override
	public CommonResponse<ShopOrderResponse> packageShopOrderAndPartListFiles(ShopOrderRequest req) {
		logger.info("PackageShopOrderAndPartListFiles Started. Child req: {}",req);
		ShopOrderResponse response=new ShopOrderResponse();
		String tempPath = null;
		String destPath = null;
		try {
		inputValidation(req);
		if(req.getOrigin().equalsIgnoreCase("ShopOrder")) {
			tempPath = paramStore.getTempPath() + req.getPlantID() + "//ShopOrder//";
			logger.info("tempPath----" + tempPath);
			destPath = paramStore.getDestPath() + req.getPlantID()+ "//ShopOrder.zip";
			logger.info("outputPath----" + destPath);
			//step 1 (Flush G:\\Manufacturing\\Temp\\[Payload.<PlantID>]\\ShopOrder folders)
			if(new File(tempPath).exists()) {
				FileUtils.cleanDirectory(new File(tempPath));
			}
			Files.createDirectories(Paths.get(tempPath));
			//"C:\\Users\\vw596\\OneDrive - Cummins\\Desktop\\Cummins\\Testing\\ShopOrder\\"
			response= getShopOrder(req,tempPath,destPath);
			
		}
		else if(req.getOrigin().equalsIgnoreCase("Partlist")) {
			tempPath = paramStore.getTempPath() + req.getPlantID() + "//ShopOrderP//";
			logger.info("tempPath----" + tempPath);
			destPath = paramStore.getDestPath() + req.getPlantID()+ "//ShopOrderP.zip";
			logger.info("outputPath----" + destPath);
			if(new File(tempPath).exists()) {
				FileUtils.cleanDirectory(new File(tempPath));
			}
			Files.createDirectories(Paths.get(tempPath));

			response= getPartList(req,tempPath,destPath);

		}else {
			response= new ShopOrderResponse(req.getCorrelationGuid(), 0, null,ERROR_MESSAGE_INVALID_PARAMETER);
		}
		}catch (Exception e) {
			response= new ShopOrderResponse(req.getCorrelationGuid(), 0, null,e.getMessage());
		}
		CommonResponse<ShopOrderResponse> commonResponse=new CommonResponse<ShopOrderResponse>(new CommonResponseHeader(true, 200, ""),response);
		logger.info("PackageShopOrderAndPartListFiles Completed. Child resp: {}",commonResponse);
		return commonResponse;
	}

	private ShopOrderResponse getShopOrder(ShopOrderRequest req,String tempPath,String outPutPath) {
		try {
			printGCStatsAndClean();
			ShopOrder shopOrder = new ShopOrder();
			List<ShoporderDetail> shopOrderDetailsList = new LinkedList<>();

			// Fetch from DB based page size
			List< SOObject> soList=comUtil.getShopOrders(req);
			List< SOReconfig> reconfigDetailsList=comUtil.getReConfigs(req);
			logger.info(soList.size()+", "+reconfigDetailsList.size());
			//Step 1:-- grouping fetched SO values into shop order number +key+ build date format
			Map<String, List<SOObject>> mainShopOrderBuildDateMap = soList.stream().collect(Collectors.groupingBy(soObj-> soObj.getShopOrderNumber()+splitKey+soObj.getBuildDate(),TreeMap::new,Collectors.toList()));
			logger.info("mainShopOrderBuildDateMap size: " + mainShopOrderBuildDateMap.size());

			//Step 2: -- grouping fetched Reconfig values into shop order number +key+ build date format
			Map<String, List<SOReconfig>> reConfigShopOrderBuildDateMap = reconfigDetailsList.stream().collect(Collectors.groupingBy(reconObj-> reconObj.getShopOrderNumber().trim()+splitKey+reconObj.getBuildDate().trim(),Collectors.toList()));

			logger.info("Creating json structure");
			//Step 3: -- build json for each

			mainShopOrderBuildDateMap.entrySet().stream().forEach(main -> {
				ShoporderDetail shopOrderDetail = new ShoporderDetail();
				String key=main.getKey();
				//setting SO number and Build Date
				shopOrderDetail.setShopOrderNumber(key.split(splitKey)[0]);
				shopOrderDetail.setEngineBuildDate(key.split(splitKey)[1]);

				List<SOObject> soObjLists=main.getValue();
				//Setting model name
				Set<String> modelName=soObjLists.stream().filter(obj-> null!=obj.getModelName()).map(SOObject::getModelName).collect(Collectors.toSet());
				if(!modelName.isEmpty()) {
				shopOrderDetail.setEngineModelName(String.join(",", modelName));
				}else {
					shopOrderDetail.setEngineModelName("");
				}
				//Setting Build Info
				shopOrderDetail.setBuildInformation(comUtil.getBuildInfo(soObjLists));
				//Setting ReConfig details
				if(null!=reConfigShopOrderBuildDateMap.get(key)) {
				shopOrderDetail.setReconfigIODetails(comUtil.getReconfigDetails(reConfigShopOrderBuildDateMap.get(key)));
				}

				//Setting calibration
				shopOrderDetail.setCalibrationList(comUtil.getCalibrationDetails(soObjLists));

				shopOrderDetailsList.add(shopOrderDetail);
			});

			logger.info("Completed structure creation");

			shopOrder.setPlantId(req.getPlantID());
			shopOrder.setShopOrderDetails(shopOrderDetailsList);
			comUtil.writeShopOrderToJson(shopOrder, req, tempPath);
			comUtil.zipMainFolder(tempPath, outPutPath);
			printGCStatsAndClean();

		} catch (Exception e) {
			e.printStackTrace();
			return new ShopOrderResponse(req.getCorrelationGuid(), 0, outPutPath, e.getMessage());
		} 
		//zipControlFiles(tempPath, outPutPath, req);
		return new ShopOrderResponse(req.getCorrelationGuid(), 0, outPutPath, null);
	}
	private ShopOrderResponse getPartList(ShopOrderRequest req,String tempPath,String outPutPath) {
		try {
			ParentClassDto parent = new ParentClassDto();
			List<ShopOrderDetailsDto> shopOrderDetails = new LinkedList<>();

			// Fetch from DB based page size
			List< PLObject> partlistData = comUtil.getPartList(req);
			//Step 1:-- grouping fetched PL values into partNumber
			TreeMap<String, List<PLObject>> plObjectMap=partlistData.stream().collect(Collectors.groupingBy(PLObject::getMpluPartNum,TreeMap::new,Collectors.toList()));
			logger.info("plObjectMap size: " + plObjectMap.size());

			logger.info("Creating json structure");
			//Step 2: build json for each
			plObjectMap.entrySet().stream().forEach(plObj -> {
				ShopOrderDetailsDto shopOrderDetail=new ShopOrderDetailsDto();
				//setting partlistNumber
				shopOrderDetail.setPartListNumber(plObj.getKey());

				//setting calibration
				shopOrderDetail.setCalibrationList(comUtil.getPartListCalibrationDetails(plObj.getValue()));

				shopOrderDetails.add(shopOrderDetail);
			});
			parent.setPlantId(req.getPlantID());
			parent.setShopOrderDetails(shopOrderDetails);
			logger.info("Completed structure creation");
			comUtil.writePartListToJson(parent, req, tempPath);
			comUtil.zipMainFolder(tempPath, outPutPath);
			printGCStatsAndClean();
		} catch (Exception e) {
			e.printStackTrace();
			throw new BadRequestException(e.getMessage());
		}
		return new ShopOrderResponse(req.getCorrelationGuid(), 0, outPutPath, null);
	}

	private void inputValidation(ShopOrderRequest req) throws BadRequestException {
		 
		   
		if (req.getCorrelationGuid() == null || (req.getCorrelationGuid().equals(""))) {
			throw new BadRequestException(ERROR_MESSAGE_INVALID_PARAMETER+":CorrelationGuid");
		}else if(req.getOrigin() == null || (req.getOrigin().equals(""))) {
			throw new BadRequestException(ERROR_MESSAGE_INVALID_PARAMETER+":Origin");
		}else if(req.getPlantID() == null || (req.getPlantID().equals(""))) {
			throw new BadRequestException(ERROR_MESSAGE_INVALID_PARAMETER+":PlantID");
		}
	}
	private void printGCStatsAndClean() {
		System.gc();
	}

	
}
