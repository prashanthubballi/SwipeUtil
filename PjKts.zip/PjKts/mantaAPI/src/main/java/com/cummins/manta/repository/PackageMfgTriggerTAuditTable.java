package com.cummins.manta.repository;

import org.springframework.data.repository.CrudRepository;

import com.cummins.manta.model.key.TAuditKey;
import com.cummins.manta.model.key.TAuditTable;

public interface PackageMfgTriggerTAuditTable extends CrudRepository<TAuditTable, TAuditKey> {

}
