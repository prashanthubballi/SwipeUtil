package com.cummins.manta.service.poller.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.naming.ServiceUnavailableException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.PackageMfgMasterRequest;
import com.cummins.manta.common.PackageMfgMasterResponse;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.exception.BadRequestException;
import com.cummins.manta.model.key.TShopTempVO;
import com.cummins.manta.pkgdbpoller.PickedLogResponse;
import com.cummins.manta.pkgdbpoller.TShopLoadRequest;
import com.cummins.manta.pkgdbpoller.TShopTempDto;
import com.cummins.manta.service.ShopOrderDbPollerService;
import com.cummins.manta.service.impl.MDCExecutorService;
import com.cummins.manta.service.impl.MfgMasterImpl;

@Service
public class ShopOrderDbPollerServiceImpl implements ShopOrderDbPollerService{
	private final Logger logger = LoggerFactory.getLogger(ShopOrderDbPollerServiceImpl.class);

	//@Autowired
	//private RestTemplate restTemplate;
	
	@Autowired
	private MfgMasterImpl masterimpl;

	@Autowired
	private ParamStore paramStore;

	@Autowired
	private ShopOrderDbPollerKickStartServiceImpl shopOrderDbPollerKickStartServiceImpl;


	public String triggerShopOrderDBPoller(String guid) throws BadRequestException, ServiceUnavailableException {
		logger.info("triggerShopOrderDBPoller started");

		try {
			List<TShopTempDto> tshopTempNFlagList =new ArrayList<>();
			List<TShopTempDto> tshopTempPFlagList = new ArrayList<>();
			List<TShopLoadRequest> mainShopLoadRequestList = new ArrayList<>();
			List<TShopLoadRequest> pickedRequestList = new ArrayList<>();
			List<TShopTempVO> tShopTempVOList = new ArrayList<>();

			//fetching db and updating data accordingly
			shopOrderDbPollerKickStartServiceImpl.kickStartProcess(tshopTempNFlagList,tshopTempPFlagList,mainShopLoadRequestList,tShopTempVOList,guid);
			if(!mainShopLoadRequestList.isEmpty()) {
				//grouping picked, skipped and ignored
				writeStartedLog(mainShopLoadRequestList,guid,pickedRequestList);

				//calling master service below
				if(!pickedRequestList.isEmpty()) {
					callMantaMaster(pickedRequestList,paramStore.getCommonThreadPool(), guid);
				}
			}else {
				logger.info("triggerShopOrderDBPoller completed:No data to process.");
				return "No data to process.";
			}
			logger.info("triggerShopOrderDBPoller completed");
			return "Shop order process triggered successfully";
		} catch (Exception ec) {
			ec.printStackTrace();
			return "Error:Exception in Shop order trigger:"+ec.getMessage();
		}
	}
	//grouping picked, skipped and ignored
	private void writeStartedLog(List<TShopLoadRequest> mainShopLoadRequestList, String guid, List<TShopLoadRequest> pickedRequestList) {
		List<TShopLoadRequest> pickedList = mainShopLoadRequestList.stream().filter(p ->p.getProcessedFlag()!=null && p.getProcessedFlag().equalsIgnoreCase(ShopOrderDbPollerKickStartServiceImpl.IP_FLAG))
				.collect(Collectors.toList());

		List<TShopLoadRequest> skippedList = mainShopLoadRequestList.stream().filter(p ->p.getProcessedFlag()!=null && p.getProcessedFlag().equalsIgnoreCase(ShopOrderDbPollerKickStartServiceImpl.S_FLAG))
				.collect(Collectors.toList());

		List<TShopLoadRequest> ignoreList = mainShopLoadRequestList.stream().filter(p -> (p.getProcessedFlag()==null))
				.collect(Collectors.toList());

		pickedRequestList.addAll(pickedList);

		PickedLogResponse pickedLogResponse = new PickedLogResponse();
		pickedLogResponse.setCorrelationGuid(guid);
		pickedLogResponse.setPicked(pickedList);
		pickedLogResponse.setSkipped(skippedList);
		pickedLogResponse.setIgnoreForFutureProcessing(ignoreList);
		logger.info("{}",pickedLogResponse);
		//vw596 log writing required
		//writeToLogFile(guid, pickedLogResponse, ShopOrderDbPollerConstants.STARTED_FLAG);
	}
	private void callMantaMaster(List<TShopLoadRequest> requestDTO, int numOfThreads, String guid) throws BadRequestException{
		logger.info("Started: ShopOrderDbPollerService.callMantaMasterApi");
		ExecutorService delegate = Executors.newFixedThreadPool(paramStore.getCommonThreadPool());
		MDCExecutorService<ExecutorService> pool=new MDCExecutorService<ExecutorService>(delegate);
		List<Callable<CommonResponse<PackageMfgMasterResponse> >> tasks = new ArrayList<>();
		try {
			for (int i = 0; i < requestDTO.size(); i++) {
				final int stepNum = i;
				tasks.add((Callable<CommonResponse<PackageMfgMasterResponse> >) () -> masterimpl.manufacturingPkgMaster(createMasterRequest(requestDTO.get(stepNum), guid+"#"+stepNum)));
				//CompletableFuture.runAsync(() ->  restTemplate.postForEntity(paramStore.getPkgMfgMaster(), createMasterRequest(requestDTO.get(stepNum), guid+"#"+stepNum), String.class));
			}
			List<Future<CommonResponse<PackageMfgMasterResponse> >> invokeResults=pool.invokeAll(tasks);
			for (Future<CommonResponse<PackageMfgMasterResponse> > future : invokeResults) {
				//logger.info("Processing results");
				future.get();
				logger.info("Recieved response from master api");
			}
		}catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}finally {
			pool.shutdown();
		}
		logger.info("Completed: Master API invoked");
	}

	private PackageMfgMasterRequest createMasterRequest(TShopLoadRequest tShopLoadRequest, String Guid) {
		PackageMfgMasterRequest req=new PackageMfgMasterRequest();
		try {
			req.setCorrelationGuid(Guid);
			req.setMode("ALL");
			req.setOrigin("ShopOrder");
			req.setPlantId(tShopLoadRequest.getPlantId());
			req.setTriggerType("RP");
			req.setSeqId(tShopLoadRequest.getId().toString());
		}catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}
		return req;
	}
}
