package com.cummins.manta.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true) 
public class PackageMfgMasterRequest {

	
	private String correlationGuid;
	
	private String origin;
	
	private String triggerType;
	
	private String plantId;
	
	private String mode;
	
	private String seqId;
}
