package com.cummins.manta.common;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

@JsonPropertyOrder({
	"dbProcedureStatus",
	"packagingStatus",
	"errorHandleStatus",
    "calibration",
    "support",
    "shopOrder",
    "control"
})
@Data
@Component
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class ResponseSummary {
	@JsonProperty("dbProcedureStatus")
	private String dbProceduresStatus;
	@JsonProperty("packagingStatus")
	private String packagingStatus;
	@JsonProperty("errorHandleStatus")
	private String errorHandleStatus;
    @JsonProperty("calibration")
    private ChildAPI calibration=new ChildAPI();
   
    @JsonProperty("support")
    private ChildAPI support=new ChildAPI();
   
    @JsonProperty("shopOrder")
    private ChildAPI shopOrder=new ChildAPI();
    @JsonProperty("control")
    private ChildAPI control=new ChildAPI();
  
}