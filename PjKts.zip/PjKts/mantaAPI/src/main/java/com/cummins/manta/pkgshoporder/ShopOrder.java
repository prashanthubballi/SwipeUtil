package com.cummins.manta.pkgshoporder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class ShopOrder {
  @JsonInclude(Include.NON_NULL)
  private String plantId;
  @JsonInclude(Include.NON_NULL)
  private List<ShoporderDetail> shopOrderDetails;
}
