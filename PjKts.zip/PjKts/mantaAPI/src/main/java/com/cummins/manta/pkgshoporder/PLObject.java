package com.cummins.manta.pkgshoporder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PLObject {
	private String ddoEcmCode;

	private String ddoOption;

	private String mpluPartNum;

	private String mpluPlant;

	private String mpluProdId;

	private String mpluModule;

	private String ddoOptionPrefix;

	private String ddoType;
}
