package com.cummins.manta.service.pkgchild.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.CommonResponseHeader;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.pkgcontrolfile.ControlFileRequestDTO;
import com.cummins.manta.pkgcontrolfile.ControlFileResponseDTO;
import com.cummins.manta.pkgcontrolfile.ParamStoreConstants;
import com.cummins.manta.service.PackageControlFileService;

import net.lingala.zip4j.ZipFile;

@Service
public class PackageControlFileServiceImpl implements PackageControlFileService{
	private final Logger logger = LoggerFactory.getLogger(PackageControlFileServiceImpl.class);

	@Autowired
	private ParamStore paramStore;
	
	@Override
	public CommonResponse<ControlFileResponseDTO> packageControlFiles(ControlFileRequestDTO req)  {
		ControlFileResponseDTO fileResponseDTO=new ControlFileResponseDTO();
		fileResponseDTO.setCorrelationalGuid(req.getCorrelationGuid());
		try {
			logger.info("Started control file package req:{}",req);
			boolean status=processControlFiles(req);
			if(status) {
				fileResponseDTO.setMessage("Package Control file created in:"+paramStore.getDestPath()+req.getPlantID());
			}else {
				fileResponseDTO.setMessage("Error:Failed to package control files");
			}
			//ve596 need to check log
			//writeToLogFile(req, fileResponseDTO);
		}catch (Exception e) {
			fileResponseDTO.setMessage("Error:"+e.getMessage());
		}
		logger.info("Completed control file package");
		CommonResponse<ControlFileResponseDTO> commonResponse=new CommonResponse<ControlFileResponseDTO>(new CommonResponseHeader(true, 200, "Package Control File Completed"),fileResponseDTO );
		return commonResponse;
	}

	private boolean processControlFiles(ControlFileRequestDTO req) throws Exception {

		if(ParamStoreConstants.SHOPORDER.equalsIgnoreCase(req.getOrigin()) || ParamStoreConstants.PARTLISTS.equalsIgnoreCase(req.getOrigin())) {
			logger.info("Shoporder/partlist request");
			String fileName=ParamStoreConstants.SHOPORDER.equalsIgnoreCase(req.getOrigin())?ParamStoreConstants.CONTROL+".zip":ParamStoreConstants.CONTROLP+".zip";
			String dstPath=paramStore.getDestPath()+req.getPlantID()+"\\"+fileName;
			Files.createDirectories(Paths.get(paramStore.getDestPath()+req.getPlantID()+"\\"));
			Map<String,String> errorMap=new HashMap<>();
			List<File> srcFiles=new ArrayList<File>();
			for (String productId : req.getProductIDList()) {
				String srcFile=ParamStoreConstants.ControlFilePath+req.getPlantType()+"\\Cntl_"+productId+".json";
				File file=new File(srcFile);
				if(file.exists()) {
					srcFiles.add(file);
				}else {
					errorMap.put(productId, "Source File Not Found:"+srcFile);
				}
			}
			if(!srcFiles.isEmpty()) {
				zipFiles(srcFiles, dstPath);
			}
			if(!errorMap.isEmpty()) {
				throw new Exception(errorMap.toString());
			}
		}else if(ParamStoreConstants.ADHOC.equalsIgnoreCase(req.getOrigin())) {
			String tmpDstPath=paramStore.getTempPath()+req.getPlantID()+"\\"+"Extra\\"+ParamStoreConstants.CONTROL;
			if(new File(tmpDstPath).exists()) {
				FileSystemUtils.deleteRecursively(new File(tmpDstPath));
			}
			return	copyFiles(req, tmpDstPath);
		}
		return true;
	}
	private boolean copyFiles(ControlFileRequestDTO req,String tmpDstPath) throws Exception {
		logger.info("Started copy files");
		Files.createDirectories(Paths.get(tmpDstPath));
		Map<String,String> errorMap=new HashMap<>();
		for (String productId : req.getProductIDList()) {
			String srcPath=ParamStoreConstants.ControlFilePath+req.getPlantType()+"\\Cntl_"+productId+".json";
			String destPath=tmpDstPath+"\\Cntl_"+productId+".json";
			try(InputStream is = new FileInputStream(srcPath);OutputStream os = new FileOutputStream(destPath);) {
				byte[] buffer = new byte[1024];
				int length;
				while ((length = is.read(buffer)) > 0) {
					os.write(buffer, 0, length);
				}
				//FileCopyUtils.copy(new File(srcPath),new File(destPath));
			} catch (IOException e) {
				logger.error("Error in copy file:"+e.getMessage());
				errorMap.put(productId, e.getMessage());
			}
		}
		if(!errorMap.isEmpty()) {
			logger.error("Error in copy file:"+errorMap.toString());
			throw new Exception("Error in copy file:"+errorMap.toString());	
		}
		logger.info("Completed copy files");
		return true;
	}

	private void  zipFiles(List<File> srcFiles,String dstPath) throws Exception {
		logger.info("Started Zip");
		if(new File(dstPath).exists()) {
			new File(dstPath).delete();
		}
		try(ZipFile zipFile=new ZipFile(dstPath)){
			zipFile.addFiles(srcFiles);
		}catch (Exception e) {
			logger.error("Error in zip:"+e.getMessage());
			throw new Exception("Error in zip:"+e.getMessage());
		}
		logger.info("Completed Zip successfully");

	}
	
}
