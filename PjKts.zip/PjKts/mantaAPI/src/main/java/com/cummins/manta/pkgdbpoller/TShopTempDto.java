package com.cummins.manta.pkgdbpoller;

public interface TShopTempDto {

  Long getId();
  
  String getplantId();

  String getprocessedFlag();

  String getloadFlag();

  String getlastUpdateDate();

}
