package com.cummins.manta.pkgsupport;

import lombok.Data;

@Data
public class SupportFileListRequest {

	String sourceName;
	String targetName;
	String sourceFilePath;
}
