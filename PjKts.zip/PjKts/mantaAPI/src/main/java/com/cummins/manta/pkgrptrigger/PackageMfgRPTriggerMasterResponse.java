package com.cummins.manta.pkgrptrigger;

import java.util.List;

import com.cummins.manta.common.PackageMfgMasterResponse;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class PackageMfgRPTriggerMasterResponse {

	private String correlationGuid;
	private List<PackageMfgMasterResponse> packageMfgMasterResponse;
}
