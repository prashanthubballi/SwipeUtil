package com.cummins.manta.dto;

import lombok.Data;

@Data
public class RequestPayload {
	public String Name;
	public String to;
	public String from;
	public String template;
	public String subject;
	public ContentForEmail data;
}
