package com.cummins.manta.service;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.PackageMfgMasterRequest;
import com.cummins.manta.common.PackageMfgMasterResponse;

public interface PackageMfgMasterService {
	CommonResponse<PackageMfgMasterResponse> manufacturingPkgMaster(PackageMfgMasterRequest req);	
}