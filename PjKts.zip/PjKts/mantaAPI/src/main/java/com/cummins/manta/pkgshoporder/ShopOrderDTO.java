package com.cummins.manta.pkgshoporder;

public interface ShopOrderDTO {
  String getId();

  String getPlantId();

  String getShopOrderNumber();

  String getBuildDate();

  String getModelName();

  String getGieaNumber();

  String getUnitNumber();

  String getSerialNumber();

  String getEcmCode();

  String getSopOption();

  String getModLocation();

  String getProductId();

  String getOptionPrefix();

  String getOptionType();

}
