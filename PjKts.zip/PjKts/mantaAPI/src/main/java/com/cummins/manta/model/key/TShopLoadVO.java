package com.cummins.manta.model.key;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity(name = "TShopLoadVO")
@Table(name = "T_SHOP_LOAD")
@IdClass(TShopLoadKey.class)
public class TShopLoadVO implements Serializable {
  private static final long serialVersionUID = 1L;
  @Id
  @Column(name = "TST_LAST_UPDATE_DATE")
  Date lastUpdateDate;
  
  @Id
  @Column(name = "TST_PLANT_ID")
  String plantId;

  @Column(name = "TST_PROCESSED_FLAG")
  String processedFlag;

  @Column(name = "TST_LOAD_FLAG")
  String loadFlag;

}
