package com.cummins.manta.pkgrptrigger;

public interface Constants {
	String GENERIC_SUCCESS_MESSAGE = "Success";
	String GENERIC_FAILURE_MESSAGE = "Failure";
	String CALIBRATION = "calibration";
	String CONTROL = "control";
	String SHOPORDER = "shopOrder";
	String SUPPORT = "support";
	String SUCCESS = "success";
	String FAILURE = "failure";
	String SUMMARY = "summary";
	String COUNT = "count";
	String ERRORMESSAGE = "errorMessage";
	String CORRELATIONGUID = "correlationGuid";
	String PLANTID = "plantId";
	String DATA = "data";
	String DBPROCEDURESTATUS = "dbProcedureStatus";
	String MODE = "DAY";
	String TRIGGERTYPE = "RP";
	String PACKAGEMFGRPTRIGGER = "PACKAGEMFGRPTRIGGER";
	String PACKAGEMFGRPTRIGGER_STARTED = "PACKAGEMFGRPTRIGGER STARTED";
	String PACKAGEMFGRPTRIGGER_COMPLETED = "PACKAGEMFGRPTRIGGER COMPLETED";
	int PACKAGEMFGRPTRIGGER_STARTED_CODE = 0;
	int PACKAGEMFGRPTRIGGER_COMPLETED_CODE = 1;
	String REQUESTLOGFILENAME = "PackageMfgRPTriggerRequest_";
	String RESPONSELOGFILENAME = "PackageMfgRPTriggerResponse_";
}
