package com.cummins.manta.repository;

import java.util.stream.Stream;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import com.cummins.manta.model.key.ShopOrderVO;
import com.cummins.manta.pkgshoporder.ReconfigDetailsDto;
import com.cummins.manta.pkgshoporder.ShopOrderDTO;

@Repository
public interface ShopOrderRepository extends JpaRepository<ShopOrderVO, Integer> {
	public static final String SHOPORDER_MAIN_QUERY = "SELECT SBL_PLANT_ID AS PlantId,"
		    + " SBL_SHOP_ORDER_NUMBER    AS ShopOrderNumber,"
		    + " to_char(SBL_SCHEDULED_BUILD_DATE,'YYYYMMDD') AS BuildDate,"
		    + "	SBL_MODEL_NAME           AS ModelName,"
		    + "	TRIM(SOE_GIEA_NUMBER)    AS GieaNumber,"
		    + "	SOE_UNIT_NUMBER          AS UnitNumber,"
		    + "	SOE_ENGINE_SERIAL_NUMBER AS SerialNumber,"
		    + "	SBL_ECM_CODE             AS EcmCode,"
		    + "	DDO_OPTION		         AS SopOption,"
		    + " CASE SBL_MOD_LOCATION"
		    + " WHEN 'M' THEN 'A'"
		    + " ELSE 'B'"
		    + " END AS ModLocation,"
		    + "	SBL_PRODUCT_ID           AS ProductId,"
		    + "	DDO_OPTION_PREFIX        AS OptionPrefix,"
		    + "	DDO_TYPE                 AS OptionType FROM V_SHOP_ORDER_FILE"
		    + "	WHERE sbl_plant_id = ?1 "
		    + " and DDO_TYPE in ('O','P','H')"
		    + " order by ShopOrderNumber,ModLocation,EcmCode,OptionPrefix,OptionType";

		  public static final String RECONFIG_MAIN_QUERY = "SELECT DISTINCT SUBSTR(SOP_SHOP_ORDER_NUMBER,1,7) AS ShopOrderNumber," + 
		  		" SUBSTR(SOP_OPTION,1,7)                       AS SOOption," + 
		  		" SOP_RECONFIG_IO_INDICATOR                    AS ReconfigIndicator," + 
		  		" TRIM(SOP_NOUN_NAME)                          AS SopNounName," + 
		  		" TRS_FEATURE_NAME                             AS TrsFeatureName," + 
		  		" TO_CHAR(SOP_SCHEDULED_BUILD_DATE,'YYYYMMDD') AS BuildDate" + 
		  		" FROM T_SHOP_OPTION ," + 
		  		" T_RIO_SPEC_VALUES" + 
		  		" WHERE TRS_OPTION_PREFIX        = SUBSTR(SOP_OPTION,1,2)" + 
		  		" AND SOP_RECONFIG_IO_INDICATOR  = TRS_VALUE" + 
		  		" AND TRIM(TRS_SHOP_NOUN_NAME)   = TRIM(SOP_NOUN_NAME)" + 
		  		" AND SOP_PLANT_ID               = ?1";
	
	
  @Query(value = SHOPORDER_MAIN_QUERY, nativeQuery = true)
  @QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "50000"))
  Stream<ShopOrderDTO> getOptionData(String plantId);

  @Query(value = RECONFIG_MAIN_QUERY, nativeQuery = true)
  @QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "3000"))
  Stream<ReconfigDetailsDto> getReconfigDetails(String plantId);

}
