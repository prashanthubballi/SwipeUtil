package com.cummins.manta.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;


@JsonPropertyOrder({
    "success",
    "failure"
})
@Data
@Component
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class ChildAPI {

    @JsonProperty("success")
    private CountAndData success=new CountAndData();
    @JsonProperty("failure")
    private CountAndData failure=new CountAndData();
    

}