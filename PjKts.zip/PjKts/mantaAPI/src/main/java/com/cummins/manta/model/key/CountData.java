package com.cummins.manta.model.key;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
@JsonInclude(Include.NON_NULL)
public class CountData {
	private long count;
	private List<String> plantID;
}
