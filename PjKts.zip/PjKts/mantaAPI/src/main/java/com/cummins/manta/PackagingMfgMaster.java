package com.cummins.manta;

import java.net.URISyntaxException;
import java.time.Duration;
import java.util.List;

import javax.annotation.PostConstruct;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cummins.manta.dto.CommonParamStore;
import com.cummins.manta.dto.CommonParamStore.Mode;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.pkgcalibration.CalibrationConstants;
import com.cummins.manta.pkgcalibration.EncryptionDetails;
import com.cummins.manta.pkgcontrolfile.ParamStoreConstants;
import com.cummins.manta.service.impl.CommonUtility;
import com.cummins.manta.service.impl.RestUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.github.resilience4j.common.retry.configuration.RetryConfigCustomizer;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;

@SpringBootApplication
@EntityScan(basePackageClasses = { PackagingMfgMaster.class, Jsr310JpaConverters.class })
@ComponentScan({"com.cummins.manta"})
public class  PackagingMfgMaster extends SpringBootServletInitializer{

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(PackagingMfgMaster.class);
	}
	
	//@Autowired
	private ParamStore paramStore=new ParamStore();

	@Value("${param.value}")
	private String paramValue;

	@Value("${aes256.value}")
	private String aes256Value;

	@Autowired
	private RetryRegistry registry;
	
	
	private ObjectMapper mapper=new ObjectMapper();
	private final Logger logger = LoggerFactory.getLogger(PackagingMfgMaster.class);


	public static void main(String[] args) {
		SpringApplication.run(PackagingMfgMaster.class, args);
	}
	@Bean
	public RestUtility util(){
		return new RestUtility();
	}
	@Bean
	public CommonUtility commonUtil() {
		return new CommonUtility();
	}

	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

	//below is for getting values from param store and setting it to Retry config

	@SuppressWarnings({ "unchecked" })
	@Bean(name="retryConfig")
	public RetryConfigCustomizer getCentralizedData(@Value("${spring.common}") String commonValue,@Value("${mode}") String mode) throws URISyntaxException, RestClientException, JSONException {
		Class<?>[] classes =null;
		try {
			CommonParamStore commonParamStore=mapper.readValue(commonValue, CommonParamStore.class);
			Mode psMode=null;
			if("Regular".equalsIgnoreCase(mode)){
				psMode=commonParamStore.getRegular();
			}else {
				psMode=commonParamStore.getExportControl();
			}

			//master
			this.paramStore=mapper.readValue(paramValue, ParamStore.class);

			this.paramStore.setPkgMfgMaster(commonParamStore.getRegular().getHostName()+paramStore.getPkgMfgMaster());
			this.paramStore.setPkgExpControlCalAPI(commonParamStore.getExportControl().getHostName()+paramStore.getPkgExpControlCalAPI());
			this.paramStore.setPkgExpControlSupportAPI(commonParamStore.getExportControl().getHostName()+paramStore.getPkgExpControlSupportAPI());
			this.paramStore.setPkgExpControlAdhocAPI(commonParamStore.getExportControl().getHostName()+paramStore.getPkgExpControlAdhocAPI());
			this.paramStore.setRegularReverseSyncURL(commonParamStore.getRegular().getHostName()+paramStore.getRegularReverseSyncURL());
			this.paramStore.setExportCReverseSyncURL(commonParamStore.getExportControl().getHostName()+paramStore.getExportCReverseSyncURL());
			this.paramStore.setServiceNowAPI(commonParamStore.getRegular().getHostName()+paramStore.getServiceNowAPI());
			this.paramStore.setCfgTransferURL(commonParamStore.getRegular().getHostName()+paramStore.getCfgTransferURL());
			this.paramStore.setCommonLambdaUrl(commonParamStore.getRegular().getHostName()+paramStore.getCommonLambdaUrl());

			this.paramStore.setDestPath(psMode.getDrivePath()+paramStore.getDestPath());
			this.paramStore.setTempPath(psMode.getDrivePath()+paramStore.getTempPath());
			this.paramStore.setCalFilePath(psMode.getDrivePath()+paramStore.getCalFilePath());
			this.paramStore.setCbfFilePath(psMode.getDrivePath()+paramStore.getCbfFilePath());

			//calibration related
			CalibrationConstants.encryptionDetails=mapper.readValue(aes256Value, EncryptionDetails.class);
			//support related
			ParamStoreConstants.ControlFilePath=psMode.getDrivePath()+"CONTROLFILE\\";
			// shop order related


			List<String> exptnclses=paramStore.getResilience4j().getRetry().getRetryExceptions();
			classes = new Class<?>[exptnclses.size()];
			for (int i=0;i<exptnclses.size();i++) {
				classes[i]=Class.forName(exptnclses.get(i));
			}
		}catch (RestClientException | JsonProcessingException | ClassNotFoundException e) {
			logger.error("Exception:while mapping paramstore values,"+e.getMessage());
		}
		final Class<?>[] exptnclasses =classes;
		return	RetryConfigCustomizer.of("throwingException", builder -> builder
				.maxAttempts(paramStore.getResilience4j().getRetry().getMaxRetryAttempts())
				.waitDuration(Duration.ofSeconds(Integer.parseInt(paramStore.getResilience4j().getRetry().getWaitDuration().replace("s", ""))))
				.retryExceptions(exptnclasses)
				);

	}
	@Bean
	public Retry retryBean() {
		return registry.retry("throwingException");
	}

	@PostConstruct
	public void postConstruct() {
		retryBean().getEventPublisher().onRetry(ev -> logger.info("RetryRegistryEventListener: {}", ev));
	}
	@Bean
	//@DependsOn("retryConfig") 
	public ParamStore getParam() { 
		return paramStore; }

}
