package com.cummins.manta.pkgadhoc;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@Data
@JsonPropertyOrder({ "correlationGuid", "status", "filePath", "errorMessage" })
@JsonInclude(Include.NON_NULL)
public class PkgMfgAdhocZipperChildResponse {
	@JsonProperty("correlationGuid")
	private String correlationGuid;
	
	@JsonProperty("status")
	private String status;
	
	@JsonProperty("filePath")
	private String filePath;
	
	@JsonProperty("errorMessage")
	private String errorMessage;
}
