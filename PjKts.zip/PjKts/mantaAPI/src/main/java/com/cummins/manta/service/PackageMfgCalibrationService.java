package com.cummins.manta.service;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.pkgcalibration.CalibrationRequestDTO;
import com.cummins.manta.pkgcalibration.CommonResponseData;

public interface PackageMfgCalibrationService {

	CommonResponse<CommonResponseData> processMfgCalibrations(CalibrationRequestDTO req);
}
