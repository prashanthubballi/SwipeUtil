package com.cummins.manta.pkgshoporder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class OptionSet implements Serializable {
  private static final long serialVersionUID = 1L;
  @JsonInclude(Include.NON_NULL)
  List<Options> options;
  
  String assembly;

  public OptionSet(List<Options> obj) {
    this.options = obj;
  }

  public OptionSet(String obj) {
    this.assembly = obj;
  }

  public OptionSet(List<Options> obj, String obj2) {
    this.options = obj;
    this.assembly = obj2;
  }

  public OptionSet() {
  }

}
