package com.cummins.manta.exception;

public class ResourceNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 8403434622963075770L;

	public ResourceNotFoundException(String message) {
		super(message);
	}

	public ResourceNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
	
}
