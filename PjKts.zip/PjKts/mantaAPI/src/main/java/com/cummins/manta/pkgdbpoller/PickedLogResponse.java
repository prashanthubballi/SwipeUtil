package com.cummins.manta.pkgdbpoller;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonPropertyOrder({ "correlationGuid", "dataCount", "data","errorMessage"})
@JsonInclude(Include.NON_NULL)
public class PickedLogResponse {
	
	@JsonProperty("correlationGuid")
	private String correlationGuid;
	
	@JsonProperty("dataCount")
	private Long dataCount;
	
	@JsonProperty("picked")
	private List<TShopLoadRequest> picked;
	
	@JsonProperty("skipped")
	private List<TShopLoadRequest> skipped;
	
	@JsonProperty("ignoreForFutureProcessing")
	private List<TShopLoadRequest> ignoreForFutureProcessing;
	
	@JsonProperty("errorMessage")
	private String errorMessage;
}
