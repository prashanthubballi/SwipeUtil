package com.cummins.manta.pkgcontrolfile;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

@Data
public class ControlFileRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("correlationGuid")
	String correlationGuid;
	@JsonProperty("origin")
	String origin;
	@JsonProperty("plantID")
	String plantID;
	@JsonProperty("plantType")
	String plantType;
	@JsonProperty("triggerType")
	String triggerType;
	@JsonProperty("productIDList")
	List<String> productIDList;
	
	
	
	
}
