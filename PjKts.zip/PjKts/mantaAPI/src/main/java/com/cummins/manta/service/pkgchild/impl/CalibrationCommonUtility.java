package com.cummins.manta.service.pkgchild.impl;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.Constants;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.pkgcalibration.Aes256EncryptionKey;
import com.cummins.manta.pkgcalibration.CalibrationConstants;
import com.cummins.manta.pkgcalibration.CalibrationRequestDTO;
import com.cummins.manta.pkgcalibration.CommonResponseData;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.CompressionLevel;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;

@Service
public class CalibrationCommonUtility {

	@Autowired
	private ParamStore paramStore;

	private final static Logger logger = LoggerFactory.getLogger(CalibrationCommonUtility.class);

	/**
	 * This method returns temp folder path for given request
	 * EX: G:\\MANUFACTURING\Temp\(PlantId)\(Calibration\CalibrationP\[Extra\Calibration])\
	 * @param req
	 * @return
	 */
	public String getTempPath(CalibrationRequestDTO req) {
		if(CalibrationConstants.ADHOC.equalsIgnoreCase(req.getOrigin())) {
			return paramStore.getTempPath()+req.getPlantID()+Constants.SLASH+CalibrationConstants.adhocPath+Constants.SLASH;
		}else if(CalibrationConstants.PARTLIST.equalsIgnoreCase(req.getOrigin())) {
			return paramStore.getTempPath()+req.getPlantID()+Constants.SLASH+CalibrationConstants.partListPath+Constants.SLASH;
		}else {
			return paramStore.getTempPath()+req.getPlantID()+Constants.SLASH+CalibrationConstants.shopOrderPath+Constants.SLASH;
		}

	}
	/**
	 * This method returns destination folder  file  for given request
	 * EX: G:\\MANUFACTURING\(PlantId)\(Calibration\CalibrationP\[Extra\Calibration])\
	 * @param req
	 * @return
	 * @throws Exception 
	 */
	public String getDestinationPath(CalibrationRequestDTO req) throws Exception {
		/*
		 * if(Constants.ADHOC.equalsIgnoreCase(req.getOrigin())) { return
		 * Constants.destinationPath+req.getPlantID()+Constants.SLASH+Constants.
		 * adhocPath+Constants.SLASH; }else
		 */
		try {
			Files.createDirectories(Paths.get(paramStore.getDestPath()+req.getPlantID()));
			if(CalibrationConstants.PARTLIST.equalsIgnoreCase(req.getOrigin())) {
				return paramStore.getDestPath()+req.getPlantID()+Constants.SLASH+CalibrationConstants.partListPath+CalibrationConstants.ZIP;
			}else {
				return paramStore.getDestPath()+req.getPlantID()+Constants.SLASH+CalibrationConstants.shopOrderPath+CalibrationConstants.ZIP;
			}
		}catch (Exception e) {
			logger.error("Exception in destination path:"+e.getMessage());
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

	}
	public  String getEncryptionKeyForPlant(String plantID) {
		List<Aes256EncryptionKey> enKeys = CalibrationConstants.encryptionDetails.getAes256EncryptionKeys();
		
		String encryptionKey =String.join(",", enKeys.stream().filter(obj -> "DEFAULT".equalsIgnoreCase(obj.getPlantId())).map(Aes256EncryptionKey::getValue).collect(Collectors.toSet()));
				//enKeys.stream().filter(obj -> "DEFAULT".equalsIgnoreCase(obj.getPlantId())).map(Aes256EncryptionKey::getValue).collect(Collectors.toSet()));
		for (Aes256EncryptionKey aes256EncryptionKey : enKeys) {
			if(plantID.equalsIgnoreCase(aes256EncryptionKey.getPlantId())) {
				encryptionKey = aes256EncryptionKey.getValue();
				break;
			}
		}
		
		logger.info("Encryption key for plant" + plantID + " is Found:" + encryptionKey);
		return encryptionKey;
	}
	/**
	 * 
	 * @param tempCopyPath
	 * @param ecmCode
	 * @param password
	 * @param filesToAdd part/multiA
	 * @param fileToAdd for core
	 * @return
	 * @throws IOException
	 */
	public String copyAndEncryptFiles(String tempCopyPath,String ecmCode,String password,List<File> filesToAdd,Map<String, String> fileNamesMap,File fileToAdd)throws IOException {
		String outputPath=tempCopyPath+Constants.SLASH+ecmCode+CalibrationConstants.SCAL;
		if(new File(outputPath).exists()) {
			new File(outputPath).delete();
		}
		logger.info("inside copyAndEncryptMultiAFiles method:"+ecmCode);
		Files.createDirectories(Paths.get(tempCopyPath));
		ZipParameters parameters = new ZipParameters();
		parameters.setEncryptFiles(true);
		parameters.setEncryptionMethod(EncryptionMethod.AES);
		parameters.setCompressionMethod(CompressionMethod.DEFLATE);
		parameters.setCompressionLevel(CompressionLevel.NORMAL); 
		parameters.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);
		if(null!=filesToAdd && !filesToAdd.isEmpty()) {
			try(ZipFile zipFile = new ZipFile(outputPath,password.toCharArray());){
				zipFile.addFiles(filesToAdd, parameters);
				//multiA file rename
				if(null!=fileNamesMap && !fileNamesMap.isEmpty()) {
					zipFile.renameFiles(fileNamesMap);
				}
			}
		}else {
			try(ZipFile zipFile = new ZipFile(outputPath,password.toCharArray());){
				zipFile.addFile(fileToAdd, parameters);
			}
		}
		return outputPath;
	}
	public String zipMainFolder(String srcPath, String outputPath) throws IOException {
		logger.info("Folder zip started:src"+srcPath+" dst:"+outputPath);
		if(new File(outputPath).exists()) {
			boolean status=new File(outputPath).delete();
			logger.info("Deleting existing zip in dst,status:"+status);
		}
		File dir = new File(srcPath);
		ZipParameters parameters = new ZipParameters();
		parameters.setIncludeRootFolder(false);
		try (ZipFile zipFile = new ZipFile(outputPath); ) {
			zipFile.addFolder(dir, parameters);
		}
		logger.info("Folder zip completed:"+outputPath);
		return outputPath;
	}
	public void writeToLogFile(String filePath,CalibrationRequestDTO req,CommonResponse<CommonResponseData> response){
		SimpleDateFormat format=new SimpleDateFormat("ddMMyyyyhhmmss");
		String fileName="PackageMfgCalibrations_"+ req.getOrigin() + "-" + req.getPlantID() + "_" + req.getCorrelationGuid()+"_" + format.format(new Date()) + ".json";
		//response.getSummary().getSuccess().getData().
		try{
			Files.createDirectories(Paths.get(filePath));
			ObjectWriter ow=new ObjectMapper().writer().withDefaultPrettyPrinter();
			String content=ow.writeValueAsString(req)+"\n"+ow.writeValueAsString(response);
			//drive need to create log file in g drive path
			//G:\PROCESSING\LOG\PackagerMfgCaibrations_CorrelationGuid#7_ddmmyyyyhhmmss.json
			Files.write(Paths.get(filePath+fileName), content.getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE);
		}catch (IOException e) {
			logger.error(e.getMessage());
		}
	}
}
