package com.cummins.manta.service.rptrigger.impl;


import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.manta.model.key.TAuditKey;
import com.cummins.manta.model.key.TAuditTable;
import com.cummins.manta.repository.PackageMfgMasterRepo;
import com.cummins.manta.repository.PackageMfgTriggerTAuditTable;

import io.github.resilience4j.retry.annotation.Retry;

@Service
public class CallDBServices {

	@Autowired
	PackageMfgTriggerTAuditTable packageMfgTriggerTAuditTable;
	
	@Autowired
	PackageMfgMasterRepo packageMfgRPTriggerRepo;

	@Retry(name = "throwingException")
	public void storeAudits(String guid, String audActivity, String audSubActivity, int audStatus) {

		TAuditTable auditEntity = new TAuditTable();
		TAuditKey key = new TAuditKey();
		key.setAudActivitId("MFG");
		key.setAudDate(LocalDateTime.now());
		key.setAudSubActivity(audSubActivity);
		key.setAudFunctionId("MFG");
		key.setAudSubCode("Parent");
		key.setAudSubFunctionId("MFG");
		key.setAudCode(" ");
		key.setAudDetails(" ");
		key.setAudActivity(audActivity);
		key.setAudLastUpdateUser(packageMfgRPTriggerRepo.getUserFromDB());
		key.setAudLastUpdateDate(LocalDateTime.now());
		key.setAudRequestId(guid);
		key.setAudStatus(audStatus);
		auditEntity.setKey(key);
		packageMfgTriggerTAuditTable.save(auditEntity);

	}

}
