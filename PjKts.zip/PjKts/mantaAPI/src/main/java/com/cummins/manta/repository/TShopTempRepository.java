package com.cummins.manta.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cummins.manta.model.key.TShopLoadKey;
import com.cummins.manta.model.key.TShopLoadVO;

@Repository
public interface TShopTempRepository extends JpaRepository<TShopLoadVO, TShopLoadKey> {

}
