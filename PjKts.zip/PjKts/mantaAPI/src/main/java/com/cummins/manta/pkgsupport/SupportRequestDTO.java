package com.cummins.manta.pkgsupport;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SupportRequestDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@JsonProperty("correlationGuid")
	String correlationGuid;
		@JsonProperty("origin")
	String origin;
	@JsonProperty("plantID")
	String plantID;
	@JsonProperty("mode")
	String mode;
	@JsonProperty("additionList")
	List<AdditionListRequest> additionListRequest=new ArrayList<>();
	@JsonProperty("deletionList")
	List<DeletionListRequest> deletionListRequest=new ArrayList<>();
	
	
	
	


}
