package com.cummins.manta.controller;

import java.io.IOException;
import java.nio.file.FileSystemException;
import java.util.List;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.PackageMfgMasterRequest;
import com.cummins.manta.common.PackageMfgMasterResponse;
import com.cummins.manta.common.ResponseUtility;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.exception.BadRequestException;
import com.cummins.manta.pkgadhoc.PkgMfgAdhocZipperChildRequest;
import com.cummins.manta.pkgadhoc.PkgMfgAdhocZipperChildResponse;
import com.cummins.manta.pkgcalibration.CalibrationRequestDTO;
import com.cummins.manta.pkgcalibration.CommonResponseData;
import com.cummins.manta.pkgcontrolfile.ControlFileRequestDTO;
import com.cummins.manta.pkgcontrolfile.ControlFileResponseDTO;
import com.cummins.manta.pkgdbpoller.ShopOrderDBPollerRequest;
import com.cummins.manta.pkgrptrigger.PackageMfgRPTriggerMasterResponse;
import com.cummins.manta.pkgrptrigger.PackageMfgRPTriggerRequest;
import com.cummins.manta.pkgshoporder.ShopOrderRequest;
import com.cummins.manta.pkgshoporder.ShopOrderResponse;
import com.cummins.manta.pkgsupport.PackageSupportFileResponse;
import com.cummins.manta.pkgsupport.SupportRequestDTO;
import com.cummins.manta.service.PackageMfgMasterService;
import com.cummins.manta.service.impl.RestUtility;
import com.cummins.manta.service.pkgchild.impl.PackageControlFileServiceImpl;
import com.cummins.manta.service.pkgchild.impl.PackageMfgCalibrationsImpl;
import com.cummins.manta.service.pkgchild.impl.PackageShopOrderPartLImpl;
import com.cummins.manta.service.pkgchild.impl.PackageSupportFileServiceImpl;
import com.cummins.manta.service.pkgchild.impl.PkgMfgAdhocZipperChildImpl;
import com.cummins.manta.service.poller.impl.ShopOrderDbPollerServiceImpl;
import com.cummins.manta.service.rptrigger.impl.PackageMfgRPTriggerServiceImpl;

@RestController
@RequestMapping("manta")
public class PackageMfgMasterController {

	@Autowired
	private PackageMfgCalibrationsImpl packageMfgCalibrationsImpl;

	@Autowired
	private PackageSupportFileServiceImpl packageSupportFileServiceImpl;

	@Autowired
	private PackageControlFileServiceImpl packageControlFileServiceImpl;

	@Autowired
	private PackageShopOrderPartLImpl shopOrderPerformanceImpl;

	@Autowired
	private PackageMfgRPTriggerServiceImpl packageMfgRPTriggerServiceImpl;

	@Autowired
	private ShopOrderDbPollerServiceImpl shopOrderDbPollerService;

	@Autowired
	private PkgMfgAdhocZipperChildImpl PkgMfgAdhocZipperChildService;

	@Autowired
	private PackageMfgMasterService packageMfgMasterService;

	

	@SuppressWarnings("rawtypes")
	@PostMapping("/packagemfgfiles")
	private ResponseEntity<CommonResponse> getManufacturingPkgMaster(@RequestBody PackageMfgMasterRequest req) throws Exception {
		MDC.put("uuid", req.getCorrelationGuid());
		CommonResponse<PackageMfgMasterResponse> resp=packageMfgMasterService.manufacturingPkgMaster(req);
		//call reverse sync
		//CompletableFuture.runAsync(() -> util.reverseSync(paramStore.getRegularReverseSyncURL(), "MANUFACTURING/"+req.getPlantId()));
		//CompletableFuture.runAsync(() ->util.reverseSync(paramStore.getExportCReverseSyncURL(), "MANUFACTURING/"+req.getPlantId()));
		//util.reverseSync(paramStore.getRegularReverseSyncURL(), "MANUFACTURING\\"+req.getPlantId());
		//util.reverseSync(paramStore.getExportCReverseSyncURL(), "MANUFACTURING\\"+req.getPlantId());
		//CompletableFuture.runAsync(() -> util.reverseSync(paramStore.getRegularReverseSyncURL(), "MANUFACTURING"));
		//CompletableFuture.runAsync(() ->util.reverseSync(paramStore.getExportCReverseSyncURL(), "MANUFACTURING"));
		MDC.remove("uuid");
		return ResponseUtility.generateCommonResponse(resp.getData(),HttpStatus.valueOf(resp.getHeader().getCode()));
	}


	@PostMapping("/calibration")
	private ResponseEntity<CommonResponse<CommonResponseData>> packageMantaCalFiles(@RequestBody CalibrationRequestDTO req) throws Exception {
		CommonResponse<CommonResponseData> response = packageMfgCalibrationsImpl.processMfgCalibrations(req);
		if (response.getHeader().isSuccess()) {
			return ResponseEntity.ok(response);
		} else {
			return new ResponseEntity<CommonResponse<CommonResponseData>>(response, HttpStatus.valueOf(response.getHeader().getCode()));
		}
	}


	@PostMapping("/support")
	private ResponseEntity<CommonResponse<PackageSupportFileResponse>> generateSupportFilePackage(@RequestBody SupportRequestDTO request) throws Exception {
		
		CommonResponse<PackageSupportFileResponse> response = packageSupportFileServiceImpl.packageSupportFile(request);

		if (response.getHeader().isSuccess()) {
			return ResponseEntity.ok(response);
		} else {
			return new ResponseEntity<CommonResponse<PackageSupportFileResponse>>(response, HttpStatus.valueOf(response.getHeader().getCode()));
		}
	}

	@PostMapping("/controlfile")
	private ResponseEntity<CommonResponse<ControlFileResponseDTO>> generateControlFilePackage(@RequestBody ControlFileRequestDTO dto) throws IOException {
		
		CommonResponse<ControlFileResponseDTO> response=packageControlFileServiceImpl.packageControlFiles(dto);
		return ResponseEntity.ok(response);

	}

	@PostMapping("/shoporder")
	private ResponseEntity<?> packageShoporderFile(@RequestBody ShopOrderRequest ShopOrderRequest)	throws BadRequestException, IOException,FileSystemException {
		
		CommonResponse<ShopOrderResponse> response= null;
		response = shopOrderPerformanceImpl.packageShopOrderAndPartListFiles(ShopOrderRequest);
		return ResponseEntity.ok(response);
	}
	@PostMapping("/packageMfgRPTrigger")
	private ResponseEntity<CommonResponse<PackageMfgRPTriggerMasterResponse>> packageMfgRPTrigger( @RequestBody PackageMfgRPTriggerRequest request, BindingResult bindingResult) throws Exception {
		MDC.put("uuid", request.getGuid());
		PackageMfgRPTriggerMasterResponse response = new PackageMfgRPTriggerMasterResponse();
		if (bindingResult.hasErrors()) {
			// Handle validation errors
			List<ObjectError> errors = bindingResult.getAllErrors();
			String errorMessage = errors.get(0).getDefaultMessage();
			return ResponseUtility.generateResponse(response, HttpStatus.BAD_REQUEST, errorMessage);
		}
		CommonResponse<PackageMfgRPTriggerMasterResponse> resp = packageMfgRPTriggerServiceImpl.packageMfgFiles(request);
		MDC.remove("uuid");
		return ResponseUtility.generateResponse(resp.getData(), HttpStatus.valueOf(resp.getHeader().getCode()),
				resp.getHeader().getMessage());
	}

	@PostMapping("/ShopOrderDBPoller")
	private ResponseEntity<String> triggerShopOrderDBPoller(@RequestBody ShopOrderDBPollerRequest request) throws Exception {
		String guid=request.getGuid().toUpperCase();
		MDC.put("uuid", request.getGuid());
		String response=null;
		try {
			response=shopOrderDbPollerService.triggerShopOrderDBPoller(guid);
		} catch (BadRequestException e) {
			//shopOrderDbPollerCommonUtil.writeErrorLog(e.getMessage(),guid);
			MDC.remove("uuid");
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		MDC.remove("uuid");
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}


	@SuppressWarnings("rawtypes")
	@PostMapping("/adhoczip")
	private ResponseEntity<CommonResponse> adhocZipExtra(@RequestBody PkgMfgAdhocZipperChildRequest req) throws Exception {
		PkgMfgAdhocZipperChildResponse response = new PkgMfgAdhocZipperChildResponse();
		try {
			String filePath = PkgMfgAdhocZipperChildService.adhocZipper(req);
			response.setCorrelationGuid(req.getCorrelationGuid().toUpperCase());
			response.setStatus("Success");
			response.setFilePath(filePath);
			response.setErrorMessage("");
		} catch (Exception e) {
			response.setCorrelationGuid(req.getCorrelationGuid().toUpperCase());
			response.setStatus("Failed");
			response.setFilePath("");
			response.setErrorMessage(e.getMessage());
			ResponseUtility.generateCommonResponse(response, HttpStatus.BAD_REQUEST);
		}

		return ResponseUtility.generateCommonResponse(response, HttpStatus.OK);
	}
}
