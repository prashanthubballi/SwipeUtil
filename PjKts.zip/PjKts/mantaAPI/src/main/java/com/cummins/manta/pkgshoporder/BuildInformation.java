package com.cummins.manta.pkgshoporder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BuildInformation  {
  @JsonInclude(Include.NON_NULL)
  private String engineSerialNumber;
  @JsonInclude(Include.NON_NULL)
  private String engineUnitnumber;
  @JsonInclude(Include.NON_NULL)
  private String chassisNumber;
}
