package com.cummins.manta.pkgsupport;

import com.cummins.manta.common.CountAndData;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PackageSupportFileResponse {

	@JsonProperty("correlationalGuid")
	private String correlationalGuid;
	@JsonProperty("success")
	private CountAndData success=new CountAndData();
	@JsonProperty("failure")
	private CountAndData failure=new CountAndData();

}
