package com.cummins.manta.service;

import javax.naming.ServiceUnavailableException;

import com.cummins.manta.exception.BadRequestException;

public interface ShopOrderDbPollerService {

	Object triggerShopOrderDBPoller(String guid)throws BadRequestException, ServiceUnavailableException;

}
