package com.cummins.manta.service.pkgchild.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cummins.manta.exception.BadRequestException;
import com.cummins.manta.pkgadhoc.PkgMfgAdhocZipperChildRequest;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.ZipParameters;

@Service
public class PkgMfgAdhocZipperChildImpl {
	private final Logger logger = LoggerFactory.getLogger(PkgMfgAdhocZipperChildImpl.class);

	
	public String adhocZipper(PkgMfgAdhocZipperChildRequest req) {
		logger.info(req.getPlantId()+":adhocZipper started:"+req.getCorrelationGuid());
		String destinationPath;
		try {
			
			//vw596 made it null
			String souceFolderPath = null;//PkgMfgAdhocZipperChildConstants.SOURCE_PATH + "\\" + req.getPlantId() + "\\Extra";
			destinationPath =null;// PkgMfgAdhocZipperChildConstants.DESTINATION_PATH + "\\" + req.getPlantId();
			Files.createDirectories(Paths.get(destinationPath));
			zipMainFolder(souceFolderPath,destinationPath);
			logger.info("adhocZipper finished");
		} catch (BadRequestException e) {
			throw new BadRequestException(e.getMessage());
		}  catch (Exception e) {
			throw new BadRequestException(e.getMessage());
		}

		return destinationPath + "\\Extra.zip";
	}


	private void zipMainFolder(String mainFolderPath, String zipFilePath) {
		logger.info("Extra Folder zip started:"+zipFilePath + "\\Extra.zip");
		if(new File(zipFilePath + "\\Extra.zip").exists()) {
			boolean status=new File(zipFilePath + "\\Extra.zip").delete();
			logger.info("Deleting existing zip in dst,status:"+status);
		}
		File dir = new File(mainFolderPath);
		ZipParameters parameters = new ZipParameters();
		parameters.setIncludeRootFolder(false);
		try (ZipFile zipFile = new ZipFile(zipFilePath + "\\Extra.zip"); ) {
			zipFile.addFolder(dir, parameters);
		} catch (Exception e) {
			logger.error("Extra Folder zip exception:"+e.getMessage());
			e.printStackTrace();
			throw new BadRequestException(e.getMessage());
		}
		logger.info("Extra Folder zip completed");
	}

	
}
