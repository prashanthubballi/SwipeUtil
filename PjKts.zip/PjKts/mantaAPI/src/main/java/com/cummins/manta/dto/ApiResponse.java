package com.cummins.manta.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.io.Serializable;
import lombok.Data;

@Data
@JsonPropertyOrder({"Response"})
public class ApiResponse implements Serializable {
  private static final long serialVersionUID = 1L;

  @JsonProperty("Response")
  Integer response;

  @JsonProperty("Message")
  String message;

  @JsonProperty("ErrorMessgae")
  String errorMsg;

}
