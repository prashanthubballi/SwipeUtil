package com.cummins.manta.pkgrptrigger;

public interface PackageMfgdto {

	public String getPLANT();

	public String getORIGIN();

}
