package com.cummins.manta.pkgcontrolfile;

public class ParamStoreConstants {

	public static String ControlFilePath="";
	public static final String PARTLISTS="PartList";
	public static final String ADHOC ="Adhoc";
	public static final String SHOPORDER="ShopOrder";
	public static final String CONTROL="Control";
	public static final String CONTROLP="ControlP";

}
