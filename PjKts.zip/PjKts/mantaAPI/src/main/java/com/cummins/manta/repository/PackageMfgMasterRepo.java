package com.cummins.manta.repository;

import com.cummins.manta.dto.EmailRecipients;
import com.cummins.manta.dto.PartListsAdhocDto;
import com.cummins.manta.dto.ShopOrderDto;
import com.cummins.manta.model.key.TItemTable;
import com.cummins.manta.model.key.TItemTableKey;
import com.cummins.manta.pkgrptrigger.PackageMfgdto;

import java.util.List;



import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface PackageMfgMasterRepo extends JpaRepository<TItemTable, TItemTableKey> {
	// validate Plantid
	String identifyPlant = "select distinct PLM_TYPE_FLAG from t_plant_master where plm_plant_id=?1";

	@Query(value = identifyPlant, nativeQuery = true)
	String getPlantType(String plantId) throws DataAccessException;

	// identify plant category COE/MFG
	String plantCategory = "SELECT count(1) as cnt FROM T_PRODUCT_PLANT_USER_LIST WHERE " + " PPU_PLANT_ID = ?1 "
			+ " AND PPU_PLANT_ID in (Select hpl_plant_id from t_hybrid_plant_list) ";

	// " AND PPU_PRODUCT_ID= ?2 ";
	@Query(value = plantCategory, nativeQuery = true)
	Integer getPlantCategory(String plantId) throws DataAccessException;

	// identify ExportControl products
	String exportControl_products = "select distinct prm_product_id as product_id from t_product_master where PRM_COMPLIANCE_GRP  = 'Export Control'";

	@Query(value = exportControl_products, nativeQuery = true)
	List<String> getECProducts() throws DataAccessException;

	// identify CES plants
	String cesPlants = "select CES_PLANT_ID from t_ces_plants";

	@Query(value = cesPlants, nativeQuery = true)
	List<String> getCESPlants() throws DataAccessException;

	// ShopOrder calibration details
	String shopOrderCalDetails = "select PLANT_ID, PRODUCT_ID, PRODUCT_TYPE, ECM_CODE, PHASE_CODE, EFFECT_CODE, ITEM_TYPE, AFILE, AFILE_INT_PATH as INT_PATH,"
			+ " ENC_REQUIRE, ECM_NAME from V_SO_CAL_FILE_DWLD "
			+ " where PLANT_ID  = ?1 order by PRODUCT_ID,ECM_CODE";

	@Query(value = shopOrderCalDetails, nativeQuery = true)
	List<ShopOrderDto> getShopOrderCalDetails(String plantId) throws DataAccessException;

	// ShopOrder support details
	String shopOrderSupDetails = "select distinct PLANT_ID, PRODUCT_ID, SUP_FILE_PART,INT_PATH, EXT_PATH, SUP_FILE_NAME from v_so_supp_file_dwld "
			+ " where PLANT_ID  = ?1 order by PRODUCT_ID";

	@Query(value = shopOrderSupDetails, nativeQuery = true)
	List<ShopOrderDto> getShopOrderSupDetails(String plantId) throws DataAccessException;

	// shop order CTT/CES calibration details
	String shopOrderCTTCESCalDetails = "SELECT distinct PLANT_ID, PRODUCT_ID,case when PRODUCT_ID in (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC  ='O') then 'CSAR' "
			+ " ELSE 'CORE' END PRODUCT_TYPE,ECM_CODE,  AFILE, INT_PATH, EXT_PATH, ENC_REQUIRE, ECM_NAME  "
			+ " FROM V_SO_CES_CAL_FILE_DWLD where PLANT_ID  = ?1 order by PRODUCT_ID";

	@Query(value = shopOrderCTTCESCalDetails, nativeQuery = true)
	List<ShopOrderDto> getShopOrderCTTCESCalDetails(String plantId) throws DataAccessException;

	// shop order CTT/CES support details
	String shopOrderCTTCESSupDetails = "select distinct PLANT_ID , PRODUCT_ID,case when PRODUCT_ID in (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC  ='O') then 'CSAR' "
			+ " ELSE 'CORE' END PRODUCT_TYPE, ECM_CODE, SUP_FILE_PART, INT_PATH, EXT_PATH, SUP_FILE_NAME"
			+ " from V_SO_CES_SUPP_FILE_DWLD where PLANT_ID  =?1 order by PRODUCT_ID,ECM_CODE";

	@Query(value = shopOrderCTTCESSupDetails, nativeQuery = true)
	List<ShopOrderDto> getShopOrderCTTCESSupDetails(String plantId) throws DataAccessException;

	// updating T_SHOP_TEMP table for shopOrder
	String modifyQueryForTshopTable = "UPDATE T_SHOP_TEMP SET TST_PROCESSED_FLAG = ?1, TST_LAST_UPDATE_DATE=sysdate WHERE TST_PLANT_ID = ?2 AND TST_SEQ_ID = ?3 ";

	@Modifying
	@Query(value = modifyQueryForTshopTable, nativeQuery = true)
	public int updateTShopTempTable(String flag, String plantId, String seqId);

	// PartLists ALL Mode CalSup details
	String partListALLCalSupDetails = "select distinct PLANT_ID, PRODUCT_ID,case when PRODUCT_ID in (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC  ='O') then 'CSAR' "
			+ " ELSE 'CORE' END PRODUCT_TYPE, BASE_ECM, ECM_CODE, PART_NUMBER, FILE_NAME, FILE_TYPE_NAME, ITM_INT_PATH, ITM_EXT_PATH"
			+ " from " + " (select PAC_PLANT_ID PLANT_ID, PAC_PRODUCT_ID PRODUCT_ID, "
			+ " PAC_ECM_BASE BASE_ECM , PAC_ECM_CODE ECM_CODE, PAC_PART_NUMBER PART_NUMBER,"
			+ " PAC_FILE_NAME FILE_NAME, PAC_FILE_TYPE_NAME FILE_TYPE_NAME , ITM_INT_PATH, ITM_EXT_PATH"
			+ " from T_PART_LIST_CURRENT " + " LEFT JOIN  T_ITEM "
			+ " ON PAC_PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0'))" + " where PLANT_ID =?1 "
			+ " order by PRODUCT_ID, ECM_CODE";

	@Query(value = partListALLCalSupDetails, nativeQuery = true)
	List<PartListsAdhocDto> getALLPartListsCalSupDetails(String PlantId);
	
	//partlist control file, products ids for given plant 
	String getPartListProductIds="select distinct  PRODUCT_ID" + 
			" from (select PAC_PLANT_ID PLANT_ID, PAC_PRODUCT_ID PRODUCT_ID, " + 
			" PAC_ECM_BASE BASE_ECM , PAC_ECM_CODE ECM_CODE, PAC_PART_NUMBER PART_NUMBER," + 
			" PAC_FILE_NAME FILE_NAME, PAC_FILE_TYPE_NAME FILE_TYPE_NAME , ITM_INT_PATH, ITM_EXT_PATH " + 
			" from T_PART_LIST_CURRENT " + 
			" LEFT JOIN  T_ITEM " + 
			" ON PAC_PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0'))" + 
			" where PLANT_ID = ?1 " + 
			" order by PRODUCT_ID";
	@Query(value = getPartListProductIds, nativeQuery = true)
	List<String> getPartListsProductIds(String PlantId);

	// PartLists DAY Mode ECM(cal) Deletion
	String deletionPartListDAYCalDetails = "SELECT DISTINCT PLANT_ID, PRODUCT_ID,case when PRODUCT_ID in (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC  ='O') then 'CSAR'" + 
			" ELSE 'CORE' END PRODUCT_TYPE, BASE_ECM,ECM_CODE,  PART_NUMBER, FILE_NAME, FILE_TYPE_NAME, ITM_INT_PATH, ITM_EXT_PATH" + 
			" FROM (SELECT PAH_PLANT_ID PLANT_ID, PAH_PRODUCT_ID PRODUCT_ID, PAH_ECM_BASE BASE_ECM, PAH_ECM_CODE ECM_CODE," + 
			" PAH_PART_NUMBER PART_NUMBER, " + 
			" PAH_FILE_NAME FILE_NAME, PAH_FILE_TYPE_NAME FILE_TYPE_NAME FROM T_PART_LIST_HISTORY " + 
			" where PAH_PLANT_ID=?1" + 
			" and PAH_FILE_TYPE_NAME !='SUPPORT'" + 
			" MINUS" + 
			" SELECT PAC_PLANT_ID, PAC_PRODUCT_ID, PAC_ECM_BASE,PAC_ECM_CODE,  PAC_PART_NUMBER, " + 
			" PAC_FILE_NAME, PAC_FILE_TYPE_NAME FROM T_PART_LIST_CURRENT " + 
			" where PAC_PLANT_ID=?1" + 
			" and PAC_FILE_TYPE_NAME !='SUPPORT')" + 
			" LEFT JOIN  T_ITEM ON PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0')" + 
			" AND PLANT_ID =?1" + 
			" ORDER BY PRODUCT_ID , PART_NUMBER";
	@Query(value = deletionPartListDAYCalDetails, nativeQuery = true)
	List<PartListsAdhocDto> getDelDAYPartListsCalDetails(String PlantId);
	
	// PartLists DAY Mode Support(sup) Deletion
	String deletionPartListDAYsupDetails = "SELECT DISTINCT PLANT_ID, PRODUCT_ID,case when PRODUCT_ID in (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC  ='O') then 'CSAR'" + 
			" ELSE 'CORE' END PRODUCT_TYPE,  PART_NUMBER, FILE_NAME, FILE_TYPE_NAME, ITM_INT_PATH, ITM_EXT_PATH" + 
			" FROM (SELECT PAH_PLANT_ID PLANT_ID, PAH_PRODUCT_ID PRODUCT_ID," + 
			" PAH_PART_NUMBER PART_NUMBER, PAH_FILE_NAME FILE_NAME, PAH_FILE_TYPE_NAME FILE_TYPE_NAME FROM T_PART_LIST_HISTORY " + 
			" where PAH_PLANT_ID=?1" + 
			" and PAH_FILE_TYPE_NAME ='SUPPORT'" + 
			" MINUS" + 
			" SELECT PAC_PLANT_ID, PAC_PRODUCT_ID,   PAC_PART_NUMBER, PAC_FILE_NAME, PAC_FILE_TYPE_NAME FROM T_PART_LIST_CURRENT " + 
			" where PAC_PLANT_ID=?1" + 
			" and PAC_FILE_TYPE_NAME ='SUPPORT')" + 
			" LEFT JOIN  T_ITEM ON PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0')" + 
			" AND PLANT_ID =?1" + 
			" ORDER BY PRODUCT_ID,PART_NUMBER";
	@Query(value = deletionPartListDAYsupDetails, nativeQuery = true)
	List<PartListsAdhocDto> getDelDAYPartListsSupDetails(String PlantId);
	

	// PartLists DAY Mode Addition CalSup details
	String additionPartListDAYCalSupDetails = "SELECT DISTINCT PLANT_ID, PRODUCT_ID," + 
			" case when PRODUCT_ID in (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC  ='O') " + 
			" then 'CSAR' ELSE 'CORE' END PRODUCT_TYPE, " + 
			" BASE_ECM, ECM_CODE, PART_NUMBER, FILE_NAME, FILE_TYPE_NAME, ITM_INT_PATH, ITM_EXT_PATH  from  " + 
			" (SELECT PAC_PLANT_ID PLANT_ID, PAC_PRODUCT_ID PRODUCT_ID ,  PAC_ECM_BASE BASE_ECM , PAC_ECM_CODE ECM_CODE, " + 
			" PAC_PART_NUMBER PART_NUMBER,  PAC_FILE_NAME FILE_NAME, PAC_FILE_TYPE_NAME FILE_TYPE_NAME " + 
			" FROM T_PART_LIST_CURRENT WHERE PAC_PLANT_ID=?1 " + 
			" AND  PAC_ECM_CODE IN (SELECT PAC_ECM_CODE FROM (SELECT PAC_PLANT_ID, PAC_PRODUCT_ID,PAC_ECM_BASE, PAC_ECM_CODE, PAC_PART_NUMBER,  PAC_FILE_NAME, PAC_FILE_TYPE_NAME " + 
			" FROM T_PART_LIST_CURRENT  WHERE PAC_FILE_TYPE_NAME ='MAF' AND PAC_PLANT_ID=?1" + 
			" MINUS SELECT PAH_PLANT_ID, PAH_PRODUCT_ID, PAH_ECM_BASE, PAH_ECM_CODE, PAH_PART_NUMBER,  PAH_FILE_NAME, PAH_FILE_TYPE_NAME " + 
			" FROM T_PART_LIST_HISTORY  WHERE PAH_FILE_TYPE_NAME ='MAF' AND PAH_PLANT_ID=?1 )) " + 
			" UNION  (SELECT PAC_PLANT_ID, PAC_PRODUCT_ID, PAC_ECM_BASE, PAC_ECM_CODE, PAC_PART_NUMBER,  PAC_FILE_NAME, PAC_FILE_TYPE_NAME " + 
			" FROM T_PART_LIST_CURRENT  WHERE PAC_FILE_TYPE_NAME !='MAF' AND PAC_PLANT_ID=?1 " + 
			" MINUS SELECT PAH_PLANT_ID, PAH_PRODUCT_ID, PAH_ECM_BASE, PAH_ECM_CODE, PAH_PART_NUMBER,  PAH_FILE_NAME, PAH_FILE_TYPE_NAME " + 
			" FROM T_PART_LIST_HISTORY  WHERE PAH_FILE_TYPE_NAME !='MAF' AND PAH_PLANT_ID=?1 )) " + 
			" LEFT JOIN  T_ITEM  ON PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0')  " + 
			" where plant_id=?1 order by PRODUCT_ID, ECM_CODE ";
	@Query(value = additionPartListDAYCalSupDetails, nativeQuery = true)
	List<PartListsAdhocDto> getAddDAYPartListsCalSupDetails(String PlantId);

	// Adhoc ALL mode Cal Sup details
	String allAdhocCalSupDetails = "select distinct TAC_PLANT_ID PLANT_ID, TAC_PRODUCT_ID PRODUCT_ID ,case when TAC_PRODUCT_ID in (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC  ='O') then 'CSAR' "
			+ " ELSE 'CORE' END PRODUCT_TYPE, "
			+ " TAC_ECM_BASE BASE_ECM , TAC_ECM_CODE ECM_CODE, TAC_PART_NUMBER PART_NUMBER, "
			+ " TAC_FILE_NAME FILE_NAME, TAC_FILE_TYPE_NAME FILE_TYPE_NAME,ITM_INT_PATH, ITM_EXT_PATH from T_ADHOC_CURRENT "
			+ " LEFT JOIN  T_ITEM " + " ON TAC_PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0')"
			+ " where TAC_PLANT_ID =?1 " + " order by TAC_PRODUCT_ID, TAC_ECM_CODE";

	@Query(value = allAdhocCalSupDetails, nativeQuery = true)
	List<PartListsAdhocDto> getALLAdhocCalSupDetails(String PlantId);

	//Adhoc Control file, product ids for given plant
	String getAdhocProductIds="select distinct TAC_PRODUCT_ID PRODUCT_ID  " + 
			" from T_ADHOC_CURRENT " + 
			" LEFT JOIN  T_ITEM " + 
			" ON TAC_PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0')" + 
			" where TAC_PLANT_ID = ?1 " + 
			" order by TAC_PRODUCT_ID";
	@Query(value = getAdhocProductIds, nativeQuery = true)
	List<String> getAdhocProductIds(String PlantId);
	
	// Adhoc Day ECM(cal) Deletion
	String deletionDAYAdhocCalDetails = "SELECT DISTINCT PLANT_ID, PRODUCT_ID,case when PRODUCT_ID in (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC  ='O') then 'CSAR'" + 
			" ELSE 'CORE' END PRODUCT_TYPE,BASE_ECM,ECM_CODE,PART_NUMBER,FILE_NAME,FILE_TYPE_NAME,ITM_INT_PATH, ITM_EXT_PATH" + 
			" FROM (SELECT TAH_PLANT_ID PLANT_ID, TAH_PRODUCT_ID PRODUCT_ID, TAH_ECM_BASE BASE_ECM, TAH_ECM_CODE ECM_CODE," + 
			" TAH_PART_NUMBER PART_NUMBER, " + 
			" TAH_FILE_NAME FILE_NAME, TAH_FILE_TYPE_NAME FILE_TYPE_NAME FROM T_ADHOC_HISTORY" + 
			" where TAH_PLANT_ID  =?1" + 
			" and  TAH_FILE_TYPE_NAME !='SUPPORT'" + 
			" MINUS" + 
			" SELECT TAC_PLANT_ID, TAC_PRODUCT_ID, TAC_ECM_BASE,TAC_ECM_CODE,  TAC_PART_NUMBER, " + 
			" TAC_FILE_NAME, TAC_FILE_TYPE_NAME FROM T_ADHOC_CURRENT" + 
			" where TAC_PLANT_ID=?1" + 
			" and  TAC_FILE_TYPE_NAME !='SUPPORT')" + 
			" LEFT JOIN  T_ITEM ON PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0')" + 
			" AND PLANT_ID =?1" + 
			" ORDER BY PRODUCT_ID,PART_NUMBER";
	@Query(value = deletionDAYAdhocCalDetails, nativeQuery = true)
	List<PartListsAdhocDto> getDelDAYAdhocCalDetails(String plantId);
	
	// Adhoc Day Support(sup) Deletion
	String deletionDAYAdhocSupDetails = "SELECT DISTINCT PLANT_ID, PRODUCT_ID,case when PRODUCT_ID in (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC  ='O') then 'CSAR'" + 
			" ELSE 'CORE' END PRODUCT_TYPE,PART_NUMBER,FILE_NAME, FILE_TYPE_NAME,ITM_INT_PATH,ITM_EXT_PATH" + 
			" FROM (SELECT TAH_PLANT_ID PLANT_ID, TAH_PRODUCT_ID PRODUCT_ID,TAH_PART_NUMBER PART_NUMBER,TAH_FILE_NAME FILE_NAME, TAH_FILE_TYPE_NAME FILE_TYPE_NAME FROM T_ADHOC_HISTORY" + 
			" where TAH_PLANT_ID=?1" + 
			" and TAH_FILE_TYPE_NAME ='SUPPORT'" + 
			" MINUS" + 
			" SELECT TAC_PLANT_ID, TAC_PRODUCT_ID,   TAC_PART_NUMBER,TAC_FILE_NAME, TAC_FILE_TYPE_NAME FROM T_ADHOC_CURRENT" + 
			" where TAC_PLANT_ID=?1" + 
			" and  TAC_FILE_TYPE_NAME ='SUPPORT')" + 
			" LEFT JOIN  T_ITEM ON PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0')" + 
			" AND PLANT_ID =?1" + 
			" ORDER BY PRODUCT_ID , PART_NUMBER";
	@Query(value = deletionDAYAdhocSupDetails, nativeQuery = true)
	List<PartListsAdhocDto> getDelDAYAdhocSupDetails(String plantId);
	
	
	// Adhoc Day addition CalSup
	String additionDAYAdhocCalSupDetails = "select distinct PLANT_ID, PRODUCT_ID,case when PRODUCT_ID in " + 
			" (select SRC_PROD_ID from t_subfile_crc_map where SRC_ASSEMBLY_DEC ='O') then 'CSAR' ELSE 'CORE' END PRODUCT_TYPE, " + 
			" BASE_ECM, ECM_CODE, PART_NUMBER, FILE_NAME, FILE_TYPE_NAME ,ITM_INT_PATH, ITM_EXT_PATH " + 
			" from (SELECT TAC_PLANT_ID PLANT_ID, TAC_PRODUCT_ID PRODUCT_ID , " + 
			" TAC_ECM_BASE BASE_ECM ,TAC_ECM_CODE ECM_CODE, TAC_PART_NUMBER PART_NUMBER, " + 
			" TAC_FILE_NAME FILE_NAME,TAC_FILE_TYPE_NAME FILE_TYPE_NAME " + 
			" FROM T_ADHOC_CURRENT WHERE TAC_PLANT_ID=?1 " + 
			" AND TAC_ECM_CODE IN (SELECT TAC_ECM_CODE FROM " + 
			" (SELECT TAC_PLANT_ID,TAC_PRODUCT_ID,TAC_ECM_BASE,TAC_ECM_CODE,TAC_PART_NUMBER,TAC_FILE_NAME,TAC_FILE_TYPE_NAME " + 
			" FROM T_ADHOC_CURRENT WHERE TAC_FILE_TYPE_NAME ='MAF' AND TAC_PLANT_ID=?1" + 
			" MINUS SELECT TAH_PLANT_ID, TAH_PRODUCT_ID, TAH_ECM_BASE,TAH_ECM_CODE,TAH_PART_NUMBER,TAH_FILE_NAME,TAH_FILE_TYPE_NAME " + 
			" FROM T_ADHOC_HISTORY WHERE TAH_FILE_TYPE_NAME ='MAF' AND TAH_PLANT_ID=?1)) " + 
			" UNION   (SELECT TAC_PLANT_ID, TAC_PRODUCT_ID, TAC_ECM_BASE,TAC_ECM_CODE,TAC_PART_NUMBER,TAC_FILE_NAME, TAC_FILE_TYPE_NAME " + 
			" FROM T_ADHOC_CURRENT WHERE TAC_FILE_TYPE_NAME !='MAF' AND TAC_PLANT_ID=?1" + 
			" MINUS  SELECT TAH_PLANT_ID, TAH_PRODUCT_ID, TAH_ECM_BASE, TAH_ECM_CODE, TAH_PART_NUMBER,TAH_FILE_NAME, TAH_FILE_TYPE_NAME " + 
			" FROM T_ADHOC_HISTORY WHERE TAH_FILE_TYPE_NAME !='MAF' AND TAH_PLANT_ID=?1)) " + 
			" LEFT JOIN T_ITEM  ON PART_NUMBER = trim(itm_number)||'.'||LPAD(ITM_REVISION_LEVEL,2,'0') " + 
			" where PLANT_ID =?1 order by PRODUCT_ID, ECM_CODE";
	@Query(value = additionDAYAdhocCalSupDetails, nativeQuery = true)
	List<PartListsAdhocDto> getAddDAYAdhocCalSupDetails(String plantId);

	// to get recipients for email for refresh notification
	String emailRecipients = "select distinct tiu_mail_id from t_info_users where "
			+ "tiu_tig_id='SO' AND TIU_STATUS='A' AND TIU_PLANT_ID=?1 ";

	@Query(value = emailRecipients, nativeQuery = true)
	List<EmailRecipients> getEmailRecipientsForRefereshNotification(String plantId) throws DataAccessException;
	
	// to get recipients for email for shop order error
		String emailRecipientsForShopOrderError = "select distinct tiu_mail_id from t_info_users where "
				+ "tiu_tig_id='SO' AND TIU_PLANT_ID=?1 ";

		@Query(value = emailRecipients, nativeQuery = true)
		List<EmailRecipients> getEmailRecipientsForShopOrderError(String plantId) throws DataAccessException;
	
		// to check whether to trigger email for shop order error
	String checkShopOrderError = "		SELECT count(1)  FROM T_ERROR_TEMP "
			//+ "		WHERE  UPPER(ERT_ERROR_STRING) LIKE 'ERROR%' AND ERT_PLANT_ID = ?1 "
			+ "		WHERE  ERT_PLANT_ID = ?1 "
			+ "		  AND ERT_SYSTEM_DATE >= (SELECT TST_LAST_UPDATE_DATE FROM T_SHOP_TEMP A "
			+ "		                     WHERE A.TST_SEQ_ID = (SELECT MAX(TST_SEQ_ID) FROM T_SHOP_TEMP B "
			+ "		                            WHERE A.TST_PROCESSED_FLAG ='IP' "
			+ "		                            AND A.TST_PLANT_ID = B.TST_PLANT_ID)"
			+ "		                          AND A.TST_PLANT_ID = ERT_PLANT_ID) ";

	@Query(value = checkShopOrderError, nativeQuery = true)
	int checkShopOrderError(String plantId) throws DataAccessException;

	//RP trigger related queries
	String listofPlantIds = "SELECT DISTINCT MPLU_PLANT as PLANT, 'PartList' as ORIGIN FROM T_ME_PART_LIST_UPLD " + 
			" WHERE MPLU_ECM_BASE IN  (SELECT DISTINCT SUBSTR(ECM_CODE,1,7)          FROM T_ECM " + 
			" WHERE (TO_CHAR(ECM_ER_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS') " + 
			" FROM T_ER_LIST where ERL_RELEASE_STATUS = 'Y') " + 
			" OR TO_CHAR(ECM_RELEASE_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS') " + 
			" FROM T_ER_LIST  where ERL_RELEASE_STATUS = 'Y') " + 
			" OR TO_CHAR(ECM_STATUS_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS') " + 
			" FROM T_ER_LIST  where ERL_RELEASE_STATUS = 'Y'))) " + 
			" AND MPLU_STATUS != 'U'  UNION             " + 
			" (SELECT DISTINCT ACSR_PLANT_ID , 'Adhoc' FROM T_CAL_ADHOC_REQ  WHERE ACSR_ECM_BASE IN " + 
			" (SELECT DISTINCT SUBSTR(ECM_CODE,1,7)  FROM T_ECM " + 
			" WHERE (TO_CHAR(ECM_ER_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS') " + 
			" FROM T_ER_LIST  where ERL_RELEASE_STATUS = 'Y') " + 
			" OR TO_CHAR(ECM_RELEASE_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS') " + 
			" FROM T_ER_LIST  where ERL_RELEASE_STATUS = 'Y') " + 
			" OR TO_CHAR(ECM_STATUS_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS') " + 
			" FROM T_ER_LIST  where ERL_RELEASE_STATUS = 'Y')))"
			+ " UNION "
			+ "SELECT DISTINCT ACSR_PLANT_ID ,'Adhoc' FROM T_CAL_ADHOC_REQ "
			+ "WHERE ACSR_REQ_VAL_DATE < SYSDATE AND ACSR_STATUS         = 'U' "
			+ "AND ACSR_LAST_UPD_DATE LIKE SYSDATE)";

	@Query(value = listofPlantIds, nativeQuery = true)
	List<PackageMfgdto> getlistofPlantIds() throws DataAccessException;
	
	@Query(value = "select user from dual", nativeQuery = true)
	public String getUserFromDB();
	
	@Modifying
	@Query(value = "UPDATE T_CAL_ADHOC_REQ SET ACSR_STATUS = 'U', ACSR_LAST_UPD_DATE = SYSDATE, ACSR_ERROR_MSG = null "
			+ "WHERE ACSR_REQ_VAL_DATE < SYSDATE "
			+ "AND ACSR_STATUS in ('N','A')", nativeQuery = true)
	public void updateAdhocPlants();
}
