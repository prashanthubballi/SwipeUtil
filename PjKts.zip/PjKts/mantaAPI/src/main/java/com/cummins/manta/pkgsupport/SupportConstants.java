package com.cummins.manta.pkgsupport;

public interface SupportConstants {
	String SUCCESS="Success";
	String INVALIDORIGIN = "Invalid Origin";
	String INVALIDMODE = "Invalid Mode";
	String COPYERROR = "Error while copying ";
	String DELETEERROR = "Error while deleting files from ";
	String ZIPERROR = "Error while zipping ";
	String separator = "\\";
	String support = "Support";
	String supportP = "SupportP";
	String extra = "Extra";
	String ecfg = "ecfg";
	String zipExtension = ".zip";
	String cbfExtension = ".cbf";
	String SHOPORDER = "ShopOrder";
	String PARTLIST = "Partlist";
	String ADHOC = "Adhoc";
	String ALLMODE = "All";
	String DAYMODE = "Day";
	String GENERIC_SUCCESS_MESSAGE = "Success";
	String GENERIC_FAILURE_MESSAGE = "Failure";
	String supportzip="/Support.zip";
	String supportpzip="/SupportP.zip";
	String extrazip="/Extra.zip";
	String MODE="Mode";
	String ORIGIN = "Origin";
	String SUPPORTFILESNOTFOUND = "SupportFilesNotFound";
	String PLANTID = "PlantID";
	String SUCCESS_LIST = "success_list";
	String FAILURE_LIST = "failure_list";
	String NETWORKDRIVEERRORMESSAGE= "Network Drive not found";
	}
