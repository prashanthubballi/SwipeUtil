package com.cummins.manta.pkgcalibration;

import com.cummins.manta.common.Constants;

public class CalibrationConstants {

	public static EncryptionDetails encryptionDetails=new EncryptionDetails();
	
	public static final String CALIBRATION="Calibration";
	public static final String adhocPath = "Extra"+Constants.SLASH+CALIBRATION;
	public static final String partListPath = "CalibrationP";
	public static final String shopOrderPath = CALIBRATION;
	

	public static final String CORE="CORE";
	public static final String CSAR="CSAR";
	public static final String MULTIA="MultiA";
	
	public static final String ADHOC="Adhoc";
	public static final String SHOPORDER="ShopOrder";
	public static final String PARTLIST="PartList";
	
	public static final String SCAL=".scal";
	public static final String PDX=".pdx";
	public static final String ZIP=".zip";
	
	public static final String SUCCESS="SUCCESS";
	public static final String FAILURE="FAILURE";
	
	public static final String ERROR="ERROR";
}
