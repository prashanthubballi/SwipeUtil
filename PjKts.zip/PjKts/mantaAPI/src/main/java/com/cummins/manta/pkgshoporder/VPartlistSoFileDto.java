package com.cummins.manta.pkgshoporder;

public interface VPartlistSoFileDto {

	  String getddoEcmCode();

	  String getddoOption();

	  String getmpluPartNum();

	  String getmpluPlant();

	  String getmpluProdId();

	  String getmpluModule();

	  String getddoOptionPrefix();

	  String getddoType();

	}