package com.cummins.manta.service.poller.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cummins.manta.model.key.TShopTempVO;
import com.cummins.manta.pkgdbpoller.TShopLoadRequest;
import com.cummins.manta.pkgdbpoller.TShopTempDto;
import com.cummins.manta.repository.ShopOrderDbPollerRepository;

@Service
public class ShopOrderDbPollerKickStartServiceImpl {
	@Autowired
	private ShopOrderDbPollerRepository shopOrderDbPollerRepository;

	public static final String IP_FLAG = "IP";
	public static final String Y_FLAG = "Y";
	public static final String S_FLAG = "S";
	
	private final Logger logger = LoggerFactory.getLogger(ShopOrderDbPollerKickStartServiceImpl.class);

	public void kickStartProcess(List<TShopTempDto> tshopTempNFlagList, List<TShopTempDto> tshopTempPFlagList, List<TShopLoadRequest> mainShopLoadRequestList, List<TShopTempVO> tShopTempVOList, String guid) throws Exception {
		try {
			//tshopTempNFlagList -- contains list that need to be processed,
			//tshopTempPFlagList -- contains list that are already IP.
			getPickupQueryDetails(tshopTempNFlagList, tshopTempPFlagList);
			if(!tshopTempNFlagList.isEmpty()) {
				Map<String, List<Long>> shopLoadYFlagMap = tshopTempNFlagList.stream().collect(Collectors.groupingBy(p -> p.getplantId(), Collectors.mapping(TShopTempDto::getId, Collectors.toList())));

				Map<String, List<Long>> shopLoadIPFlagMap = tshopTempPFlagList.stream().collect(Collectors.groupingBy(p -> p.getplantId(), Collectors.mapping(TShopTempDto::getId, Collectors.toList())));

				Map<String, List<TShopTempDto>> mainShopTempMap = tshopTempNFlagList.stream().collect(Collectors.groupingBy(p -> p.getplantId(), Collectors.toList()));

				logger.info("shopLoadYFlagMap size--> " + shopLoadYFlagMap.size());
				logger.info("shopLoadIPFlagMap size--> " + shopLoadIPFlagMap.size());

				setupMantaMasterAPIRequest(shopLoadYFlagMap, shopLoadIPFlagMap, mainShopTempMap, tShopTempVOList,mainShopLoadRequestList,guid);

				logger.info("Update PFlagtShopTempVOList size--> " + tShopTempVOList.size());
				logger.info("MantaMasterApi RequestList size--> {}", mainShopLoadRequestList);

				saveOrUpdateShopTemp(tShopTempVOList);
			}else {
				logger.info("There is no data to process in Shop order");
			}
		}
		catch (Exception e) {
			throw e;
		}

	}

	//shopLoadYFlagMap -- id list that need to be processed,
	//shopLoadIPFlagMap --id list that are already in IP
	//mainShopTempMap  -- dto list which need to be processed
	private void setupMantaMasterAPIRequest(Map<String, List<Long>> shopLoadYFlagMap, Map<String, List<Long>> shopLoadIPFlagMap, Map<String, List<TShopTempDto>> mainShopTempMap, List<TShopTempVO> tShopTempVOList, List<TShopLoadRequest> mainShopLoadRequestList, String guid){
		shopLoadYFlagMap.entrySet().stream().forEach(map -> {
			if (shopLoadIPFlagMap != null && !(shopLoadIPFlagMap.get(map.getKey()) != null)) {
				if (mainShopTempMap != null && mainShopTempMap.get(map.getKey()) != null) {
					List<TShopTempDto> listShopTemp = mainShopTempMap.get(map.getKey());
					logger.info("PlantId--> " + map.getKey() + " listShopTemp size--> " + listShopTemp.size());
					if (listShopTemp.size() > 1) {
						Long maxId = listShopTemp.stream().map(TShopTempDto::getId).max(Long::compare).get();
						logger.info("MaxId-->" + maxId);
						//More than one record with same PlantId with flag=Y start
						listShopTemp.stream().forEach(shopTemp -> {
							if (maxId.equals(shopTemp.getId())) {
								//Identifying data by Max id with flag=IP
								tShopTempVOList.add(updateTShopTempVOFlag(maxId, IP_FLAG,guid));
								TShopLoadRequest request = new TShopLoadRequest(shopTemp.getId(),map.getKey(), IP_FLAG, shopTemp.getloadFlag(),shopTemp.getlastUpdateDate());
								mainShopLoadRequestList.add(request);
							} else {
								//Identifying skipped data with flag=S
								tShopTempVOList.add(updateTShopTempVOFlag(shopTemp.getId(), S_FLAG,guid));
								TShopLoadRequest request = new TShopLoadRequest(shopTemp.getId(),map.getKey(), S_FLAG, shopTemp.getloadFlag(),shopTemp.getlastUpdateDate());
								mainShopLoadRequestList.add(request);
							}
						});
						//More than one record with same PlantId with flag=Y start
					} else if (listShopTemp.size() > 0) {
						//Identifying data with flag=IP
						listShopTemp.stream().forEach(shopTemp -> {
							tShopTempVOList.add(updateTShopTempVOFlag(shopTemp.getId(), IP_FLAG,guid));
							TShopLoadRequest request = new TShopLoadRequest(shopTemp.getId(),map.getKey(), IP_FLAG, shopTemp.getloadFlag(),shopTemp.getlastUpdateDate());
							mainShopLoadRequestList.add(request);
						});
					}
				}
			}

			if (shopLoadIPFlagMap != null && (shopLoadIPFlagMap.get(map.getKey()) != null)) {
				if (mainShopTempMap != null && mainShopTempMap.get(map.getKey()) != null) {
					List<TShopTempDto> listShopTemp = mainShopTempMap.get(map.getKey());
					logger.info("PlantId--> " + map.getKey() + " listShopTemp size--> " + listShopTemp.size());
					if (listShopTemp.size() > 0) {
						//Identifying data with flag=IP
						listShopTemp.stream().forEach(shopTemp -> {
							TShopLoadRequest request = new TShopLoadRequest(shopTemp.getId(),map.getKey(),null, shopTemp.getloadFlag(),	shopTemp.getlastUpdateDate());
							mainShopLoadRequestList.add(request);
						});
					}
				}
			}
		});
	}


	@Transactional(readOnly = true)
	private void getPickupQueryDetails(List<TShopTempDto> tshopTempNFlagList, List<TShopTempDto> tshopTempPFlagList) throws SQLException {
		try {
			List<TShopTempDto> tshopTempNFlagStream = shopOrderDbPollerRepository.getTShopTempYLoadFlagData(Y_FLAG);
			List<TShopTempDto> tshopTempPFlagStream = shopOrderDbPollerRepository.getTShopTempIPProcessedFlagData(IP_FLAG);
			tshopTempNFlagList.addAll(tshopTempNFlagStream.stream().collect(Collectors.toList()));

			tshopTempPFlagList.addAll(tshopTempPFlagStream.stream().collect(Collectors.toList()));
		} catch (Exception e) {
			throw e;
		}
	}

	@Transactional
	private void processCompleteEntryIntoDB(TShopLoadRequest request) {
		shopOrderDbPollerRepository.updateTempShopTable(request.getLoadFlag(), request.getPlantId());
	}

	@Transactional
	private void saveOrUpdateShopTemp(List<TShopTempVO> tShopTempVOList) throws SQLException {
		try {
			shopOrderDbPollerRepository.saveAll(tShopTempVOList);
		} catch (Exception e) {
			throw e;
		}
	}

	@Transactional
	private TShopTempVO updateTShopTempVOFlag(Long id, String flag, String guid) {
		TShopTempVO tshopTemp = shopOrderDbPollerRepository.findById(id).get();
		tshopTemp.setProcessdFlag(flag);
		tshopTemp.setCorrelationGuid(guid);
		return tshopTemp;
	}	
}
