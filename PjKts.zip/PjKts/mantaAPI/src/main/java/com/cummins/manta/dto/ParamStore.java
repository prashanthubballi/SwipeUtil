
package com.cummins.manta.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ParamStore {
	@JsonProperty("commonThreadPool")
    private int commonThreadPool;
	@JsonProperty("calThreadPool")
    private int calThreadPool;
	@JsonProperty("supThreadPool")
    private int supThreadPool;
	@JsonProperty("pkgMfgMaster")
	private String pkgMfgMaster;
    @JsonProperty("pkgExpControlCalAPI")
    private String pkgExpControlCalAPI;
    @JsonProperty("pkgExpControlSupportAPI")
    private String pkgExpControlSupportAPI;
    @JsonProperty("pkgExpControlAdhocAPI")
    private String pkgExpControlAdhocAPI;
    @JsonProperty("regularReverseSyncURL")
    private String regularReverseSyncURL;
    @JsonProperty("exportCReverseSyncURL")
    private String exportCReverseSyncURL;
    @JsonProperty("serviceNowAPI")
    private String serviceNowAPI;
    @JsonProperty("serviceNowAssignmentGrp")
    private String serviceNowAssignmentGrp;
    @JsonProperty("serviceNowImpact")
    private String serviceNowImpact;
    @JsonProperty("serviceNowUrgency")
    private String serviceNowUrgency;
    @JsonProperty("destPath")
    private String destPath;
    @JsonProperty("tempPath")
    private String tempPath;
    @JsonProperty("calFilePath")
    private String calFilePath;
    @JsonProperty("cbfFilePath")
    private String cbfFilePath;
    @JsonProperty("ctt_Products")
    private String cttProducts;
    @JsonProperty("ces_Products")
    private String cesProducts;
    @JsonProperty("sendersEmail")
    private String sendersEmail;
    @JsonProperty("emailTemplateName")
    private String emailTemplateName;
    @JsonProperty("plantDashBoardLink")
    private String plantDashBoardLink;
    @JsonProperty("emailIdForSupport")
    private String emailIdForSupport;
    @JsonProperty("uasLink")
    private String uasLink;
    @JsonProperty("cfgTransferURL")
    private String cfgTransferURL;
    @JsonProperty("cfgFrom")
    private String cfgFrom;
    @JsonProperty("cfgTo")
    private String cfgTo;
    @JsonProperty("commonLambdaUrl")
    private String commonLambdaUrl;
    @JsonProperty("lambdaFunctionforEmail")
    private String lambdaFunctionforEmail;
    @JsonProperty("resilience4j")
    private Resilience4j resilience4j;
 
}
