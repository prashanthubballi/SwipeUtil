package com.cummins.manta.common;

import java.io.File;

public interface Constants {

	public static final String API="API";
	public static final String SLASH=File.separator;
	//String DATA="data";

	public static final String SUCCESS="Success";
	public static final String FAILURE="Failure";

	
	public static final String CALIBRATION="Calibration";
	public static final String SUPPORT="Support";
	public static final String SHOPORDER="ShopOrder";
	public static final String CONTROL="Control";
	public static final String ADHOCZIP="AdhocZIP";
	public static final String SERVICENOW="ServiceNow";

	public static final String PATH="G:\\PROCESSING\\Manufacturing\\LOG\\";//"G:\\PROCESSING\\LOG\\";

	public static final String	PARTLISTS="PartList";
	public static final String ADHOC ="Adhoc";

	public static final String ALL="All";
	public static final String	DAY="Day";

	public static final String REQUESTEXPORTCONTROL="RequestExportControl";
	public static final String REQUESTREGULAR="RequestRegular";
		
	public static final String	RPTRIGGER="RP";
	public static final String	WEBTRIGGER="WEB";

	public static final String CFG_TRANSFER="CFG_TRANSFER";
	public static final String CFG_REQUEST="{\r\n"
			+ "    \"fromPath\": \"G:\\\\MANUFACTURING\\\\ISZ\",\r\n"
			+ "    \"toFolder\": \"To_Isuzu\"\r\n"
			+ "}";
	
	public static final String LOGTEXT="\nChild API logs present in path\r\n" + 
			"Sufix='<origin>_<plantId>_<guid>_<ddMMyyyyhhmmss>';\r\n" + 
			"Calibrations: G:\\PROCESSING\\Manufacturing\\LOG\\PackageMfgCalibrations_<suffix>.json\r\n" + 
			"Support: G:\\PROCESSING\\Manufacturing\\LOG\\PackageSupportFiles_<suffix>.json\r\n" + 
			"ShopOrder: G:\\PROCESSING\\Manufacturing\\LOG\\PackageShopOrderFile_<suffix>.json\r\n" + 
			"Controlfile: G:\\PROCESSING\\Manufacturing\\LOG\\PkgControlFile_<suffix>.json";
}
