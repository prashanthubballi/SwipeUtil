package com.cummins.manta.pkgshoporder;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShopOrderResponse implements Serializable {
	/**
	 
	 */
	private static final long serialVersionUID = -5350649609327500427L;

	@JsonProperty("CorrelationGuid")
	String correlationGuid;

	@JsonProperty("Response")
	Integer response;

	@JsonProperty("FilePath")
	String filepath;

	@JsonProperty("ErrorMessgae")
	String errorMsg;
}
