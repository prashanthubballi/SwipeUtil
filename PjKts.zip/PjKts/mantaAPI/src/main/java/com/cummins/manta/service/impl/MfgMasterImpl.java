package com.cummins.manta.service.impl;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.CommonResponseHeader;
import com.cummins.manta.common.Constants;
import com.cummins.manta.common.PackageMfgMasterRequest;
import com.cummins.manta.common.PackageMfgMasterResponse;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.exception.BadRequestException;
import com.cummins.manta.repository.PackageMfgMasterRepo;
import com.cummins.manta.service.PackageMfgMasterService;

@Service
public class MfgMasterImpl implements PackageMfgMasterService {

	@Autowired
	private PackageMfgMasterRepo repo;

	@Autowired
	private MfgMasterShopOrderImpl shopOrderImpl;

	@Autowired
	private MfgMasterPartListsAdhocImpl partListsAdhocImpl;
	
	@Autowired
	private CommonUtility commonUtility;
	
	@Autowired
	private RestUtility util;

	@Autowired
	private ParamStore paramStore;
	
	private final Logger logger = LoggerFactory.getLogger(MfgMasterImpl.class);
	
	@Override
	public CommonResponse<PackageMfgMasterResponse> manufacturingPkgMaster(PackageMfgMasterRequest req){
		PackageMfgMasterResponse mfgMasterResponse=null;
		CommonResponseHeader commonResponseHeader=null;
		logger.info("MfgMaster:Started:req:"+req);
		try {
			mfgMasterResponse=validateAndProcessPackaging(req);
			commonResponseHeader=new CommonResponseHeader(true, 200, "Package MFG Master Completed");
		}catch (BadRequestException e) {
			mfgMasterResponse=new PackageMfgMasterResponse(req.getCorrelationGuid(),req.getPlantId(),e.getMessage(),null);
			commonResponseHeader=new CommonResponseHeader(false, 400, e.getMessage());	
		}catch (Exception e) {
			e.printStackTrace();
			mfgMasterResponse=new PackageMfgMasterResponse(req.getCorrelationGuid(), req.getPlantId(),e.getMessage(),null);
			commonResponseHeader=new CommonResponseHeader(false, 500, "Package MFG Master Failed:"+e.getMessage());
		}
	
		if(req.getPlantId().equals("ISZ")){
			commonUtility.doCFGTransfer(req);
		}
		
		if(null!=mfgMasterResponse.getErrorMessage() && !"".equals(mfgMasterResponse.getErrorMessage())) {
			String shortError="Failure in MFG distributions:"+req.getCorrelationGuid()+":Origin:"+req.getOrigin()+"_"+req.getPlantId();
			String description=req.getCorrelationGuid()+"\nRequest:"+req.toString()+"\nErrorMessage:"+mfgMasterResponse.toString()+"\nResponse:"+mfgMasterResponse.toString()+Constants.LOGTEXT;
			
			logger.info("SNOW:"+commonUtility.createServiceNowTicket(shortError, description, req.getCorrelationGuid()));
		}
		logger.info("MfgMaster:Completed:req"+req+":resp:"+mfgMasterResponse);
		util.reverseSync(paramStore.getRegularReverseSyncURL(), "MANUFACTURING\\"+req.getPlantId());
		util.reverseSync(paramStore.getExportCReverseSyncURL(), "MANUFACTURING\\"+req.getPlantId());

		return new CommonResponse<PackageMfgMasterResponse>(commonResponseHeader, mfgMasterResponse);
	}
	
	private PackageMfgMasterResponse validateAndProcessPackaging(PackageMfgMasterRequest req) {
		String plantType=repo.getPlantType(req.getPlantId());
		if(null==plantType ||"".equals(plantType)) {
			throw new BadRequestException("Invalid Plant Id");
		}
		List<String> ecProducts=repo.getECProducts();
		if(Constants.SHOPORDER.equalsIgnoreCase(req.getOrigin()) ) {
			if(("N".equals(plantType) || "X".equals(plantType))) {
				if(Constants.RPTRIGGER.equalsIgnoreCase(req.getTriggerType()) && Constants.ALL.equalsIgnoreCase(req.getMode())) {
					if(null!=req.getSeqId() && !req.getSeqId().isEmpty()) {
						//everything related to shop order happens here
						PackageMfgMasterResponse packageMfgMasterResponse=shopOrderImpl.processShopOrderRequests(req,ecProducts);
						
						return packageMfgMasterResponse;
					}else {
						throw new BadRequestException("seqId required for Origin:"+req.getOrigin());
					}
				}else {
					throw new BadRequestException(req.getOrigin()+" process allowed for TriggerType:RP and Mode:ALL");
				}
			}else {
				throw new BadRequestException("Provided Origin and PlantId combination is not allowed,Origin:"+req.getOrigin()+",PlantId:"+req.getPlantId());
			}
		}else if(Constants.PARTLISTS.equalsIgnoreCase(req.getOrigin()) ||Constants.ADHOC.equalsIgnoreCase(req.getOrigin())) {
			if(Constants.RPTRIGGER.equalsIgnoreCase(req.getTriggerType()) || ( Constants.WEBTRIGGER.equalsIgnoreCase(req.getTriggerType()) && Constants.DAY.equalsIgnoreCase(req.getMode()))) {
				if(Constants.ALL.equalsIgnoreCase(req.getMode()) || Constants.DAY.equalsIgnoreCase(req.getMode())) {
					if(Constants.PARTLISTS.equalsIgnoreCase(req.getOrigin()) && ("P".equals(plantType) || "X".equals(plantType))) {
						//everything related to partlist request happens here
						return partListsAdhocImpl.processPartsListsAdhocRequests(req,ecProducts);
					}else if(Constants.ADHOC.equalsIgnoreCase(req.getOrigin()) && ("N".equals(plantType) || "X".equals(plantType))) {
						//everything related to AdHoc request happens here
						return partListsAdhocImpl.processPartsListsAdhocRequests(req,ecProducts);
					}else {
						throw new BadRequestException("Provided Origin and PlantId combination is not allowed,Origin:"+req.getOrigin()+",PlantId:"+req.getPlantId());
					}
				}else {
					throw new BadRequestException(req.getOrigin()+" Allowed only in mode=ALL/DAY");
				}
			}else {
				throw new BadRequestException(req.getOrigin()+" Allowed only in triggerType:RP/WEB and WEB can not have mode:ALL");
			}	
		}else {
			throw new BadRequestException("Invalid Origin,allowed valaues ShopOrder/PartList/Adhoc");	
		}
	}
}