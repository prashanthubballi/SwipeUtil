package com.cummins.manta.service.pkgchild.impl;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cummins.manta.exception.BadRequestException;
import com.cummins.manta.pkgshoporder.BuildInformation;
import com.cummins.manta.pkgshoporder.CalibrationDetails;
import com.cummins.manta.pkgshoporder.OptionSet;
import com.cummins.manta.pkgshoporder.Options;
import com.cummins.manta.pkgshoporder.PLObject;
import com.cummins.manta.pkgshoporder.ParentClassDto;
import com.cummins.manta.pkgshoporder.Partnumber;
import com.cummins.manta.pkgshoporder.ReconfigDetailsDto;
import com.cummins.manta.pkgshoporder.ReconfigIODetail;
import com.cummins.manta.pkgshoporder.SOObject;
import com.cummins.manta.pkgshoporder.SOReconfig;
import com.cummins.manta.pkgshoporder.ShopOrder;
import com.cummins.manta.pkgshoporder.ShopOrderDTO;
import com.cummins.manta.pkgshoporder.ShopOrderRequest;
import com.cummins.manta.pkgshoporder.VPartlistSoFileDto;
import com.cummins.manta.repository.ITPartlistRepository;
import com.cummins.manta.repository.ShopOrderRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.ZipParameters;

@Service
public class ShopOrderPartListCommonUtility {
	@Autowired
	private ShopOrderRepository shopOrderRepository;

	@Autowired
	private ITPartlistRepository iTPartlistRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(ShopOrderPartListCommonUtility.class);
	private static String splitKey="KEY";
	public static final String JSON_FILE_NAME = "Shop.";
	public static final String JSON_FILE_NAME_PARTS = "Partlist.";
	public static final String JSON_EXTENSION = ".json";


	@Transactional(readOnly = true)
	public List<SOObject> getShopOrders(ShopOrderRequest req) {
		try (Stream<ShopOrderDTO> optionData = shopOrderRepository.getOptionData(req.getPlantID());) {
			List<SOObject> shopOrderList = optionData.map(data -> new SOObject(data.getPlantId(), data.getShopOrderNumber(),data.getBuildDate(),data.getModelName(),data.getGieaNumber(),data.getUnitNumber(),data.getSerialNumber(),data.getEcmCode(),data.getSopOption(),
					data.getModLocation(),data.getProductId(),data.getOptionPrefix(),data.getOptionType())).collect(Collectors.toList());
			LOGGER.info("ShopOrder Query:" + shopOrderList.size());
			return shopOrderList;
		}
	}
	@Transactional(readOnly = true)
	public List<SOReconfig> getReConfigs(ShopOrderRequest req) {
		try (Stream<ReconfigDetailsDto> reConfigs = shopOrderRepository.getReconfigDetails(req.getPlantID());) {
			List<SOReconfig> reconfigDetailsList = reConfigs.map(data -> new SOReconfig(data.getSOOption(),data.getReconfigIndicator(),data.getSopNounName(),data.getTrsFeatureName(),data.getShopOrderNumber(),data.getBuildDate())).collect(Collectors.toList());
			LOGGER.info("ReConfig Query:" + reconfigDetailsList.size());
			return reconfigDetailsList;
		}
	}
	@Transactional(readOnly = true)
	public List<PLObject> getPartList(ShopOrderRequest shopOrderRequest) {
		try (Stream<VPartlistSoFileDto> partListDto = iTPartlistRepository.getFinalPartList(shopOrderRequest.getPlantID());) {
			List<PLObject> plObjectList = partListDto.map(data -> new PLObject(data.getddoEcmCode(),data.getddoOption(),data.getmpluPartNum(),data.getmpluPlant(),data.getmpluProdId(),data.getmpluModule(),data.getddoOptionPrefix(),data.getddoType())).collect(Collectors.toList());
			LOGGER.info("plObjectList:" + plObjectList.size());
			return plObjectList;
		}
	}

	//Shop order related functions
	public Set<BuildInformation> getBuildInfo(List<SOObject> soObjLists) {
		Set<BuildInformation> buildInfoSet=new HashSet<>();
		Set<String> buildInfoStringSet=soObjLists.stream().filter(bldInfo-> (null!=bldInfo.getGieaNumber() && !bldInfo.getGieaNumber().isEmpty())
				|| (null!=bldInfo.getUnitNumber() && !bldInfo.getUnitNumber().isEmpty())
				|| (null!=bldInfo.getSerialNumber() && !bldInfo.getSerialNumber().isEmpty())).map(obj -> obj.getSerialNumber()+splitKey+obj.getUnitNumber()+splitKey+obj.getGieaNumber()).collect(Collectors.toSet());

		buildInfoStringSet.stream().forEach(bldInfo -> {
			String[] splitInfo=bldInfo.split(splitKey);
			String serialNum="";
			String unitNumber="";
			String chasissNum="";
			if(splitInfo.length>=1 && null!=splitInfo[0] && !"null".equalsIgnoreCase(splitInfo[0])) {
				serialNum=splitInfo[0];
			}
			if(splitInfo.length>=2 && null!=splitInfo[1] && !"null".equalsIgnoreCase(splitInfo[1])) {
				unitNumber=splitInfo[1];
			}
			if(splitInfo.length>=3 && null!=splitInfo[2] && !"null".equalsIgnoreCase(splitInfo[2])) {
				chasissNum=splitInfo[2];
			}
			buildInfoSet.add(new BuildInformation(serialNum, unitNumber, chasissNum));
		});
		return buildInfoSet;
	}
	public Set<ReconfigIODetail> getReconfigDetails(List<SOReconfig> reConfigObjLists) {
		Set<ReconfigIODetail> reConfigs=new HashSet<>();
		Set<String> reConfigStringSet=reConfigObjLists.stream().map(obj-> obj.getSOOption()+splitKey+obj.getSopNounName()+splitKey+obj.getTrsFeatureName()+splitKey+obj.getReconfigIndicator()).collect(Collectors.toSet());
		reConfigStringSet.stream().forEach( reconfig-> {
			String[] splitConfig=reconfig.split(splitKey);
			reConfigs.add(new ReconfigIODetail(splitConfig[0], splitConfig[1], splitConfig[2], splitConfig[3]));
		});
		return reConfigs;
	}

	public List<CalibrationDetails> getCalibrationDetails(List<SOObject> soObjLists) {
		List<CalibrationDetails> calibrationLists=new LinkedList<>();
		Collections.sort(soObjLists,Comparator.comparing(SOObject::getModLocation).thenComparing(SOObject::getEcmCode));
		LinkedHashMap<String, List<SOObject>> sortedMapSOObjects=soObjLists.stream().collect(Collectors.groupingBy(SOObject::getEcmCode,LinkedHashMap::new,Collectors.toList()));
		sortedMapSOObjects.entrySet().forEach(ecmCode -> {
			if(null!=ecmCode && null!=ecmCode.getKey()) {
				CalibrationDetails calibration = new CalibrationDetails();
				List<SOObject> ecmCodeSOObjects= ecmCode.getValue();
				//module Type
				String parentChild = "";
				Set<String> modType= ecmCodeSOObjects.stream().map(SOObject::getModLocation).collect(Collectors.toSet());
				if(null!=modType && String.join(",", modType).equals("A")) {
					parentChild = "Parent";
				} else {
					parentChild = "Child";
				}
				calibration.setModuleType(parentChild);
				//productId
				calibration.setProductId(String.join(",",ecmCodeSOObjects.stream().map(SOObject::getProductId).collect(Collectors.toSet())));
				//ecmCode
				calibration.setEcmCode(ecmCode.getKey());
				//ecmPartNumber
				calibration.setEcmPartNumber(ecmCodeSOObjects.stream().filter(obj -> null!=obj.getOptionPrefix() 
						&& "ecmPartnumber".equals(obj.getOptionPrefix())).map(SOObject::getSopOption).collect(Collectors.toSet()));
				//option set
				Map<String, Set<String>> optionList =ecmCodeSOObjects.stream().filter(optn -> null!=optn.getOptionPrefix() && null!=optn.getOptionType() 
						&& "O".equals(optn.getOptionType()) && !"UN".equalsIgnoreCase(optn.getOptionPrefix())).collect(Collectors.groupingBy(SOObject::getOptionPrefix,Collectors.mapping(SOObject::getSopOption, Collectors.toSet())));
				Set<String> optionLessSet =ecmCodeSOObjects.stream().filter(optn -> null!=optn.getOptionPrefix() && null!=optn.getOptionType() 
						&& "O".equals(optn.getOptionType()) && "UN".equalsIgnoreCase(optn.getOptionPrefix())).map(SOObject::getSopOption).collect(Collectors.toSet());

				calibration.setOptionSet(createOptionSet(optionList, optionLessSet));
				//part Numbers
				Map<String, Set<String>> partNumbers =ecmCodeSOObjects.stream().filter(optn -> null!=optn.getOptionPrefix() && null!=optn.getOptionType() 
						&& "P".equals(optn.getOptionType()) && !"ecmPartnumber".equalsIgnoreCase(optn.getOptionPrefix())).collect(Collectors.groupingBy(SOObject::getOptionPrefix,Collectors.mapping(SOObject::getSopOption, Collectors.toSet())));

				calibration.setPartNumbers(createPartNumber(partNumbers));
				calibrationLists.add(calibration);
			}
		});
		return calibrationLists;
	}
	//partlist related functions
	public List<CalibrationDetails> getPartListCalibrationDetails(List<PLObject> plObjects) {
		List<CalibrationDetails> calibrationLists=new LinkedList<>();
		Collections.sort(plObjects,Comparator.comparing(PLObject::getMpluModule).thenComparing(PLObject::getDdoEcmCode));
		LinkedHashMap<String, List<PLObject>> sortedMapPLObjects=plObjects.stream().collect(Collectors.groupingBy(PLObject::getDdoEcmCode,LinkedHashMap::new,Collectors.toList()));
		sortedMapPLObjects.entrySet().forEach(ecmCode -> {
			if(null!=ecmCode && null!=ecmCode.getKey()) {
				CalibrationDetails calibration = new CalibrationDetails();
				List<PLObject> ecmCodeSOObjects= ecmCode.getValue();
				//module Type
				String parentChild = "";
				Set<String> modType= ecmCodeSOObjects.stream().map(PLObject::getMpluModule).collect(Collectors.toSet());
				if(null!=modType && String.join(",", modType).equals("0")) {
					parentChild = "Parent";
				} else {
					parentChild = "Child";
				}
				calibration.setModuleType(parentChild);
				//productId
				calibration.setProductId(String.join(",",ecmCodeSOObjects.stream().map(PLObject::getMpluProdId).collect(Collectors.toSet())));
				//ecmCode
				calibration.setEcmCode(ecmCode.getKey());
				//ecmPartNumber
				calibration.setEcmPartNumber(ecmCodeSOObjects.stream().filter(obj -> null!=obj.getDdoOptionPrefix() 
						&& "ecmPartnumber".equals(obj.getDdoOptionPrefix())).map(PLObject::getDdoOption).collect(Collectors.toSet()));
				//option set
				Map<String, Set<String>> optionList =ecmCodeSOObjects.stream().filter(optn -> null!=optn.getDdoOptionPrefix() && null!=optn.getDdoType() 
						&& "O".equals(optn.getDdoType()) && !"UN".equalsIgnoreCase(optn.getDdoOptionPrefix())).collect(Collectors.groupingBy(PLObject::getDdoOptionPrefix,Collectors.mapping(PLObject::getDdoOption, Collectors.toSet())));
				Set<String> optionLessSet =ecmCodeSOObjects.stream().filter(optn -> null!=optn.getDdoOptionPrefix() && null!=optn.getDdoType() 
						&& "O".equals(optn.getDdoType()) && "UN".equalsIgnoreCase(optn.getDdoOptionPrefix())).map(PLObject::getDdoOption).collect(Collectors.toSet());

				calibration.setOptionSet(createOptionSet(optionList, optionLessSet));
				//part Numbers
				Map<String, Set<String>> partNumbers =ecmCodeSOObjects.stream().filter(optn -> null!=optn.getDdoOptionPrefix() && null!=optn.getDdoType() 
						&& "P".equals(optn.getDdoType()) && !"ecmPartnumber".equalsIgnoreCase(optn.getDdoOptionPrefix())).collect(Collectors.groupingBy(PLObject::getDdoOptionPrefix,Collectors.mapping(PLObject::getDdoOption, Collectors.toSet())));

				calibration.setPartNumbers(createPartNumber(partNumbers));
				calibrationLists.add(calibration);
			}
		});
		return calibrationLists;
	}
	//common functions used in both
	private OptionSet createOptionSet(Map<String, Set<String>> optionList,Set<String> optionLessSet) {
		OptionSet optionSet = new OptionSet();
		if(null!=optionLessSet && !optionLessSet.isEmpty()) {
			optionSet.setAssembly(optionLessSet.iterator().next());
		}
		List<Options> optionsList = new ArrayList<>();
		optionList.entrySet().stream().forEach(optn -> {
			Options option = new Options();
			option.setPrefix(optn.getKey());
			option.setValue(optn.getValue());
			optionsList.add(option);
		});
		optionSet.setOptions(optionsList);
		return optionSet;
	}
	private List<Partnumber> createPartNumber(Map<String, Set<String>> partNumbers) {
		List<Partnumber> partnumbersList = new ArrayList<>();
		partNumbers.entrySet().stream().forEach(prt -> {
			Partnumber partNumber = new Partnumber();
			partNumber.setValue(String.join(",", prt.getValue()));
			partNumber.setType(prt.getKey());
			partnumbersList.add(partNumber);
		});
		Collections.sort(partnumbersList, Comparator.comparing(Partnumber::getType));
		return partnumbersList;
	}

	//

	public void writeShopOrderToJson(ShopOrder shopOrder, ShopOrderRequest req,String tempPath) {
		// String response = "";

		String filePath = tempPath + JSON_FILE_NAME + req.getPlantID() + JSON_EXTENSION;
		try {
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String content = ow.writeValueAsString(shopOrder);
			Files.write(Paths.get(filePath ), content.getBytes(StandardCharsets.UTF_8),
					StandardOpenOption.CREATE);
		}catch (IOException e) {
			throw new BadRequestException(e.getMessage());
		} 
	}
	public void writePartListToJson(ParentClassDto parent, ShopOrderRequest req,String tempPath) {
		// String response = "";

		String filePath=tempPath+ JSON_FILE_NAME_PARTS + req.getPlantID() + JSON_EXTENSION;
		try {
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String content = ow.writeValueAsString(parent);
			Files.write(Paths.get(filePath ), content.getBytes(StandardCharsets.UTF_8),
					StandardOpenOption.CREATE);
		}catch (IOException e) {
			throw new BadRequestException(e.getMessage());
		} 
	}
	public String zipMainFolder(String srcPath, String outputPath) throws IOException {
		LOGGER.info("Folder zip started:src"+srcPath+" dst:"+outputPath);
		if(new File(outputPath).exists()) {
			boolean status=new File(outputPath).delete();
			LOGGER.info("Deleting existing zip in dst,status:"+status);
		}
		File dir = new File(srcPath);
		ZipParameters parameters = new ZipParameters();
		parameters.setIncludeRootFolder(false);
		try (ZipFile zipFile = new ZipFile(outputPath); ) {
			zipFile.addFolder(dir, parameters);
		}
		LOGGER.info("Folder zip completed:"+outputPath);
		return outputPath;
	}
}