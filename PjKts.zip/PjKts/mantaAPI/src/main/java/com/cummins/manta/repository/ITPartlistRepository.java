package com.cummins.manta.repository;

import java.util.stream.Stream;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;

import com.cummins.manta.model.key.VPartlistSoFile;
import com.cummins.manta.model.key.VPartlistSoFileKey;
import com.cummins.manta.pkgshoporder.VPartlistSoFileDto;

public interface ITPartlistRepository extends JpaRepository<VPartlistSoFile, VPartlistSoFileKey> {

	  @QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "30000"))
	  @Query(value = "SELECT MPLU_PART_NUM as mpluPartNum , MPLU_PLANT as mpluPlant, MPLU_PROD_ID as mpluProdId," + 
	  		"	   case  MPLU_MODULE when 'P' then '0' else MPLU_MODULE end as mpluModule, DDO_ECM_CODE as ddoEcmCode, RTRIM(DDO_OPTION) as ddoOption, DDO_OPTION_PREFIX as ddoOptionPrefix, " + 
	  		"	    DDO_TYPE as ddoType FROM V_PARTLIST_SO_FILE WHERE MPLU_PLANT = ?1 ", nativeQuery = true)
	  Stream<VPartlistSoFileDto> getFinalPartList(String plantId);
	}
