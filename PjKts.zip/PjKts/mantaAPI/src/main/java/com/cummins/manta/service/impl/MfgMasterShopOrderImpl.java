package com.cummins.manta.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.manta.common.ChildAPI;
import com.cummins.manta.common.Constants;
import com.cummins.manta.common.CountAndData;
import com.cummins.manta.common.PackageMfgMasterRequest;
import com.cummins.manta.common.PackageMfgMasterResponse;
import com.cummins.manta.common.ResponseSummary;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.dto.ShopOrderDto;
import com.cummins.manta.pkgcalibration.AdditionList;
import com.cummins.manta.pkgcalibration.CalibrationRequestDTO;
import com.cummins.manta.pkgcalibration.PartList;
import com.cummins.manta.pkgcalibration.PartNumberListing;
import com.cummins.manta.pkgcontrolfile.ControlFileRequestDTO;
import com.cummins.manta.pkgshoporder.ShopOrderRequest;
import com.cummins.manta.pkgsupport.AdditionListRequest;
import com.cummins.manta.pkgsupport.SupportFileListRequest;
import com.cummins.manta.pkgsupport.SupportRequestDTO;
import com.cummins.manta.repository.PackageMfgMasterRepo;

@Service
public class MfgMasterShopOrderImpl {

	private final Logger logger = LoggerFactory.getLogger(MfgMasterShopOrderImpl.class);

	@Autowired
	ParamStore paramStore;

	@Autowired
	PackageMfgMasterRepo repo;

	@Autowired
	CommonUtility commonUtility;

	public PackageMfgMasterResponse processShopOrderRequests(PackageMfgMasterRequest req, List<String> ecProducts) {
		PackageMfgMasterResponse packageMfgMasterResponse=new PackageMfgMasterResponse();
		packageMfgMasterResponse.setCorrelationGuid(req.getCorrelationGuid());
		packageMfgMasterResponse.setPlantId(req.getPlantId());
		ResponseSummary responseSummary=new ResponseSummary();
		//Step2 : call DB
		//Step2 : call
		logger.info("MfgMaster:ShopOrder:req:"+req+":DB procedure started");
		String spOutput = commonUtility.loadDBAndProcedures(req);
		
		responseSummary.setDbProceduresStatus(spOutput);
		if (spOutput.equalsIgnoreCase("Success")) {
			logger.info("MfgMaster:ShopOrder:req:"+req+":DB procedure completed");
			try {
				String plantSubCategory;
				//				List<String> cesPlants=repo.getCESPlants();
				//				if(cesPlants.contains(req.getPlantId())) {
				//					plantSubCategory="CES";
				//				}else 
				if(new ArrayList<String>(Arrays.asList(paramStore.getCttProducts().split(","))).contains(req.getPlantId())){
					plantSubCategory="CTP";
				}else {
					plantSubCategory="NA";
				}
				//Step3 : PkgCalAPI
				logger.info("MfgMaster:ShopOrder:req:"+req+":calling cal select query");
				Set<String> productIdList=new HashSet<>();
				Map<String,CalibrationRequestDTO> allProductsDTO=getShopOrderCalDetails(req,plantSubCategory,ecProducts);
				if(null!=allProductsDTO) {
					CalibrationRequestDTO regularCalibrationRequestDTO=allProductsDTO.get(Constants.REQUESTREGULAR);
					CalibrationRequestDTO exportControlCalibrationRequestDTO=allProductsDTO.get(Constants.REQUESTEXPORTCONTROL);
					if(null!=regularCalibrationRequestDTO) {
						logger.info("Executing regular product Calibration");
						//for regular api is not called so passing url as null
						ChildAPI calReguar=commonUtility.callChildAPI(regularCalibrationRequestDTO,req.getCorrelationGuid(),null, Constants.CALIBRATION);
						responseSummary.setCalibration(calReguar);
						productIdList.addAll(regularCalibrationRequestDTO.getAdditionList().stream().map(AdditionList::getProductId).collect(Collectors.toSet()));
					}
					if(null!=exportControlCalibrationRequestDTO) {
						logger.info("Executing export control product Calibration");
						ChildAPI calExport=commonUtility.callChildAPI(exportControlCalibrationRequestDTO,req.getCorrelationGuid(),paramStore.getPkgExpControlCalAPI(), Constants.CALIBRATION);
						if(null!=regularCalibrationRequestDTO) {
							ChildAPI calRegular=responseSummary.getCalibration();
							CountAndData regularSCountAData=calRegular.getSuccess();
							regularSCountAData.setCount(regularSCountAData.getCount()+calExport.getSuccess().getCount());
							regularSCountAData.getData().addAll(calExport.getSuccess().getData());
							CountAndData regularFCountAData=calRegular.getFailure();
							regularFCountAData.setCount(regularFCountAData.getCount()+calExport.getFailure().getCount());
							regularFCountAData.getData().addAll(calExport.getFailure().getData());

							responseSummary.setCalibration(new ChildAPI(regularSCountAData, regularFCountAData));
						}else {
							responseSummary.setCalibration(calExport);
						}
						productIdList.addAll(exportControlCalibrationRequestDTO.getAdditionList().stream().map(AdditionList::getProductId).collect(Collectors.toSet()));
					}
				}else {
					logger.info(req.getOrigin()+" Calibration details not found for given Plant Id:"+req.getPlantId());
					responseSummary.setPackagingStatus("Calibration details not found:"+req.getPlantId());
				}
				//Step4 : PkgSupportAPI
				logger.info("MfgMaster:ShopOrder:req:"+req+":calling sup select query");
				Map<String,Object>  allSupProductsDTO=getShopOrderSupDetails(req,plantSubCategory,ecProducts);
				if(null!=allSupProductsDTO) {
					SupportRequestDTO regularSupportRequestDTO=(SupportRequestDTO) allSupProductsDTO.get(Constants.REQUESTREGULAR);
					SupportRequestDTO exportSupportRequestDTO=(SupportRequestDTO) allSupProductsDTO.get(Constants.REQUESTEXPORTCONTROL);
					if(null!=regularSupportRequestDTO) {
						logger.info("Executing regular product Support");
						//for regular api is not called so passing url as null
						ChildAPI supReguar=commonUtility.callChildAPI(regularSupportRequestDTO,req.getCorrelationGuid(),null, Constants.SUPPORT);
						responseSummary.setSupport(supReguar);
						if(null==allProductsDTO) {
							productIdList.addAll(regularSupportRequestDTO.getAdditionListRequest().stream().map(AdditionListRequest::getProductId).collect(Collectors.toSet()));
						}
					}
					if(null!=exportSupportRequestDTO) {
						logger.info("Executing export control product Support");
						ChildAPI calExport=commonUtility.callChildAPI(exportSupportRequestDTO,req.getCorrelationGuid(),paramStore.getPkgExpControlSupportAPI(), Constants.SUPPORT);
						if(null!=regularSupportRequestDTO) {
							ChildAPI supRegular=responseSummary.getSupport();
							CountAndData regularSCountAData=supRegular.getSuccess();
							regularSCountAData.setCount(regularSCountAData.getCount()+calExport.getSuccess().getCount());
							regularSCountAData.getData().addAll(calExport.getSuccess().getData());
							CountAndData regularFCountAData=supRegular.getFailure();
							regularFCountAData.setCount(regularFCountAData.getCount()+calExport.getFailure().getCount());
							regularFCountAData.getData().addAll(calExport.getFailure().getData());

							responseSummary.setSupport(new ChildAPI(regularSCountAData, regularFCountAData));
						}else {
							responseSummary.setSupport(calExport);
						}
						if(null==allProductsDTO) {
							productIdList.addAll(exportSupportRequestDTO.getAdditionListRequest().stream().map(AdditionListRequest::getProductId).collect(Collectors.toSet()));
						}
					}
				}else {
					logger.info(req.getOrigin()+" Support details not found for given Plant Id:"+req.getPlantId());
					responseSummary.setPackagingStatus(responseSummary.getPackagingStatus()+",Support details not found:"+req.getPlantId());
				}
				//Step5 : PkgShopOrderAPI
				if(null!=allProductsDTO  || null!=allSupProductsDTO) {
					if("NA".equals(plantSubCategory) || "CTP".equals(plantSubCategory) ) {
						//for regular api is not called so passing url as null
						
						responseSummary.setShopOrder(commonUtility.callChildAPI(getShopOrderRequest(req),req.getCorrelationGuid(),null, Constants.SHOPORDER));
					}
					//Step6 : PkgControlFileAPI
					//paramStore.setPkgControlFileAPI("http://internal-speed-alpha-1503200788.us-east-1.elb.amazonaws.com/PackageControlFileController/generateControlFilePackage");
					
					responseSummary.setControl(commonUtility.callChildAPI(getShopOrderControlFileDeatils(req, productIdList),req.getCorrelationGuid(),null, Constants.CONTROL));

					//Step 8 : process errors if any
					responseSummary.setErrorHandleStatus(commonUtility.processPkgErrors(req,null,responseSummary,packageMfgMasterResponse));
				}else {
					logger.error("Calibration and Support details not found for given plant id:"+req.getPlantId());
					responseSummary.setPackagingStatus("Calibration and Support details not found for given plant id:"+req.getPlantId());
					
					if (repo.checkShopOrderError(req.getPlantId()) > 0) {
						commonUtility.sendEmail(req.getPlantId(), "error");
					}
					repo.updateTShopTempTable("X", req.getPlantId(), req.getSeqId());
					//commonUtility.writeToLogFile(req, "Calibration and Support details not found for given plant id:"+req.getPlantId());
					packageMfgMasterResponse.setSummary(responseSummary);
					return new PackageMfgMasterResponse(req.getCorrelationGuid(), req.getPlantId(),null,responseSummary);
				}
				packageMfgMasterResponse.setSummary(responseSummary);
				commonUtility.sendEmail(req.getPlantId(),"refresh");
			}catch (Exception e) {	
				logger.error(e.getMessage());
				e.printStackTrace();
				if (repo.checkShopOrderError(req.getPlantId()) > 0) {
					commonUtility.sendEmail(req.getPlantId(), "error");
				}
				repo.updateTShopTempTable("X", req.getPlantId(), req.getSeqId());
				//commonUtility.writeToLogFile(req, e.getMessage());
				return new PackageMfgMasterResponse(req.getCorrelationGuid(), req.getPlantId(),e.getMessage(),responseSummary);
			}
		}else {
			// SP failed scenario
			if (repo.checkShopOrderError(req.getPlantId()) > 0) {
				commonUtility.sendEmail(req.getPlantId(), "error");
			}
			repo.updateTShopTempTable("X", req.getPlantId(), req.getSeqId());
			logger.error("DB procedure failed.");
			//commonUtility.writeToLogFile(req, packageMfgMasterResponse);
			return new PackageMfgMasterResponse(req.getCorrelationGuid(), req.getPlantId(),"DB procedure failed.",responseSummary);
		}
		//commonUtility.writeToLogFile(req, packageMfgMasterResponse);
		return packageMfgMasterResponse;
	}

	private Map<String,CalibrationRequestDTO> getShopOrderCalDetails(PackageMfgMasterRequest req, String plantSubCategory,List<String> ecProducts) {
		Map<String,CalibrationRequestDTO> requestDtos=new HashMap<>();
		List<ShopOrderDto> soCalDetails=null;
		if("NA".equals(plantSubCategory)) {
			soCalDetails=repo.getShopOrderCalDetails(req.getPlantId());
		}else {
			soCalDetails=repo.getShopOrderCTTCESCalDetails(req.getPlantId());
		}
		if(null!=soCalDetails && !soCalDetails.isEmpty()) {
			//true contains exportControl products, false contains regular products
			Map<Boolean, List<ShopOrderDto>> allProducts =soCalDetails.stream().collect(Collectors.partitioningBy(dto -> ecProducts.contains(dto.getPRODUCT_ID())));
			for (boolean isECProducts : allProducts.keySet()) {
				List<ShopOrderDto> splitProducts=allProducts.get(isECProducts);
				if(null!=splitProducts && !splitProducts.isEmpty()) {
					String key=isECProducts?Constants.REQUESTEXPORTCONTROL:Constants.REQUESTREGULAR;
					CalibrationRequestDTO requestDTO=new CalibrationRequestDTO();
					requestDTO.setMode(req.getMode());
					requestDTO.setOrigin(req.getOrigin());
					requestDTO.setPlantID(req.getPlantId());
					requestDTO.setCorrelationGuid(req.getCorrelationGuid());
					Map<String, List<ShopOrderDto>> soDetails=splitProducts.stream().collect(Collectors.groupingBy(ShopOrderDto::getPRODUCT_ID));
					for (String productId : soDetails.keySet()) {
						List<ShopOrderDto> productDetails=soDetails.get(productId);
						AdditionList additionList=new AdditionList();
						additionList.setProductId(productId);
						//getting only ecms
						List<ShopOrderDto> ecmParts=productDetails.stream().filter(sodtls-> null==sodtls.getAFILE() || "".equals(sodtls.getAFILE())).collect(Collectors.toList());
						if(null!=ecmParts && !ecmParts.isEmpty()) {
							additionList.setFileName(ecmParts.stream().map( ShopOrderDto::getECM_CODE).map(str-> paramStore.getCalFilePath()+productId+"\\"+str) .collect(Collectors.toList()));
							additionList.setProductType(ecmParts.get(0).getPRODUCT_TYPE());
						}
						//getting all PART and MAF files
						List<ShopOrderDto> aFilesParts=productDetails.stream().filter(sodtls-> null!=sodtls.getAFILE() && !"".equals(sodtls.getAFILE())).collect(Collectors.toList());
						if(null!=aFilesParts&& !aFilesParts.isEmpty()) {
							additionList.setProductType("MultiA");
							Map<String, List<ShopOrderDto>> soProductLevelDetails=aFilesParts.stream().collect(Collectors.groupingBy(ShopOrderDto::getECM_CODE));
							for (String ecmCode : soProductLevelDetails.keySet()) {
								PartNumberListing partNumberListing=new PartNumberListing();
								partNumberListing.setEcmCode(ecmCode);
								List<ShopOrderDto> parts=soProductLevelDetails.get(ecmCode);
								for (ShopOrderDto part : parts) {
									PartList list=new PartList();
									list.setSourceName(part.getAFILE());
									list.setTargetName(part.getAFILE());
									list.setSourceFilePath(part.getINT_PATH());
									partNumberListing.getPartList().add(list);
								}
								additionList.getPartNumberListing().add(partNumberListing);
							}
						}
						requestDTO.getAdditionList().add(additionList);
					}
					requestDtos.put(key, requestDTO);
				}
			}
		}else {
			logger.info(req.getOrigin()+" Calibration details not found for given Plant Id:"+req.getPlantId());
			return null;
		}
		return requestDtos;
	}
	private Map<String,Object> getShopOrderSupDetails(PackageMfgMasterRequest req, String plantSubCategory,List<String> ecProducts) {
		Map<String,Object> response=new HashMap<>();
		//Map<String,String> ecmPartMap=new HashMap<>();
		List<ShopOrderDto> soSupDetails=null;
		if("NA".equals(plantSubCategory)) {
			soSupDetails=repo.getShopOrderSupDetails(req.getPlantId());
		}else {
			//Support not applicable for CTP plant so returning empty
			return response;
			//soSupDetails=repo.getShopOrderCTTCESSupDetails(req.getPlantId());
		}
		if(null!=soSupDetails && !soSupDetails.isEmpty()) {
			//true contains exportControl products, false contains regular products
			Map<Boolean, List<ShopOrderDto>> allProducts =soSupDetails.stream().collect(Collectors.partitioningBy(dto -> ecProducts.contains(dto.getPRODUCT_ID())));
			for (boolean isECProducts : allProducts.keySet()) {
				List<ShopOrderDto> splitProducts=allProducts.get(isECProducts);
				if(null!=splitProducts && !splitProducts.isEmpty()) {
					String key=isECProducts?Constants.REQUESTEXPORTCONTROL:Constants.REQUESTREGULAR;

					SupportRequestDTO requestDTO=new SupportRequestDTO();
					requestDTO.setMode(req.getMode());
					requestDTO.setOrigin(req.getOrigin());
					requestDTO.setPlantID(req.getPlantId());
					requestDTO.setCorrelationGuid(req.getCorrelationGuid());
					Map<String, List<ShopOrderDto>> soDetails=splitProducts.stream().collect(Collectors.groupingBy(ShopOrderDto::getPRODUCT_ID));
					for (String productId : soDetails.keySet()) {
						AdditionListRequest additionListRequest=new AdditionListRequest();
						additionListRequest.setProductId(productId);
						List<ShopOrderDto> supFiles=soDetails.get(productId);
						for (ShopOrderDto supFile : supFiles) {
							//ecmPartMap.put(productId+"-"+supFile.getSUP_FILE_PART(),supFile.getECM_CODE());
							SupportFileListRequest sup=new SupportFileListRequest();
							sup.setSourceName(supFile.getSUP_FILE_PART());
							sup.setTargetName(supFile.getSUP_FILE_NAME());
							sup.setSourceFilePath(supFile.getINT_PATH());
							additionListRequest.getSupportFileList().add(sup);
						}
						requestDTO.getAdditionListRequest().add(additionListRequest);
					}
					response.put(key, requestDTO);
				}
			}
		}else {
			logger.info(req.getOrigin()+" Support details not found for given Plant Id:"+req.getPlantId());
			return null;
		}
		//response.put("DTO",ecmPartMap);
		return response;
	}
	private ShopOrderRequest getShopOrderRequest(PackageMfgMasterRequest req) {
		ShopOrderRequest shopOrderRequest=new ShopOrderRequest();
		shopOrderRequest.setOrigin(req.getOrigin());
		shopOrderRequest.setPlantID(req.getPlantId());
		shopOrderRequest.setTriggerType(req.getTriggerType());
		shopOrderRequest.setCorrelationGuid(req.getCorrelationGuid());
		return shopOrderRequest;
	}
	private ControlFileRequestDTO getShopOrderControlFileDeatils(PackageMfgMasterRequest req,Set<String> productIDList) {
		int plantCat=repo.getPlantCategory(req.getPlantId());
		String plantCategory=plantCat>0?"COE":"MFG";
		ControlFileRequestDTO fileRequestDTO=new ControlFileRequestDTO();
		fileRequestDTO.setOrigin(req.getOrigin());
		fileRequestDTO.setPlantID(req.getPlantId());
		fileRequestDTO.setProductIDList(new LinkedList<String>(productIDList));
		fileRequestDTO.setPlantType(plantCategory);
		fileRequestDTO.setTriggerType(req.getTriggerType());
		fileRequestDTO.setCorrelationGuid(req.getCorrelationGuid());

		return fileRequestDTO;
	}
}
