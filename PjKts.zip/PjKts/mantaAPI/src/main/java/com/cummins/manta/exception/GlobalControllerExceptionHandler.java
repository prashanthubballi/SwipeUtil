package com.cummins.manta.exception;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.cummins.manta.common.CommonResponseHeader;

@EnableWebMvc
@ControllerAdvice
public class GlobalControllerExceptionHandler {
//    @ExceptionHandler
//    @ResponseStatus(value=HttpStatus.NOT_FOUND)
//    @ResponseBody
//    public CommonResponseHeader requestHandlingNoHandlerFound(final NoHandlerFoundException ex) {
//        return new CommonResponseHeader(false,HttpStatus.NOT_FOUND.value(),ConstantsUtil.ERROR_MESSAGE_URL_NOT_VALID);
//    }
//    
    @ExceptionHandler
    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
    @ResponseBody
    public CommonResponseHeader badRequestFound(final Exception ex) {
        return new CommonResponseHeader(false,HttpStatus.BAD_REQUEST.value(),"Bad Request, please validate input passed and try again.");
    }
}
