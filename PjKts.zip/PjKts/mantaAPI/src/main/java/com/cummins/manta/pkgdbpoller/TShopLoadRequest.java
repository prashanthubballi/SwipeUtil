package com.cummins.manta.pkgdbpoller;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@JsonPropertyOrder({ "id", "plantId", "processedFlag", "loadFlag", "lastUpdateDate" })
public class TShopLoadRequest {

	@JsonProperty("id")
	Long Id;
	
	@JsonProperty("plantId")
	String plantId;

	@JsonProperty("processedFlag")
	String processedFlag;

	@JsonProperty("loadFlag")
	String loadFlag;

	@JsonProperty("lastUpdateDate")
	String lastUpdateDate;

}
