package com.cummins.manta.model.key;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
//@Embeddable
public class TShopLoadKey implements Serializable {
  private static final long serialVersionUID = 1L;
  
  Date lastUpdateDate;
  
  String plantId;

}
