package com.cummins.manta.dto;


public interface PartListsAdhocDto {
	public String getPLANT_ID();
	public String getPRODUCT_ID();
	public String getPRODUCT_TYPE();
	public String getBASE_ECM();
	public String getECM_CODE();
	public String getPART_NUMBER();
	public String getFILE_NAME();
	public String getFILE_TYPE_NAME();
	public String getITM_INT_PATH();
	public String getITM_EXT_PATH();

	}
