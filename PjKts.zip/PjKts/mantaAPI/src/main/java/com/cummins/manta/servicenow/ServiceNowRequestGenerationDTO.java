package com.cummins.manta.servicenow;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ServiceNowRequestGenerationDTO {
  private String description;
  private String short_description;
  private String impact;
  private String urgency;
  private String assignment_group;
}
