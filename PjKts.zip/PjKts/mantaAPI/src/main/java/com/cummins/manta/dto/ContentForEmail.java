package com.cummins.manta.dto;

import java.util.List;
import lombok.Data;
@Data
public class ContentForEmail {
	public String username;
	public String content;
	public List<Object> tableInformation;

}
