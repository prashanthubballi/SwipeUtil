package com.cummins.manta.pkgshoporder;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class CalibrationDetails implements Serializable {
  private static final long serialVersionUID = 1L;
  String moduleType;

  String productId;

  String ecmCode;

  Set<String> ecmPartNumber;

  OptionSet optionSet;

  List<Partnumber> partNumbers;
}
