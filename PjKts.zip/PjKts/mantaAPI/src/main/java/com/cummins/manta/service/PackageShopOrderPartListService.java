package com.cummins.manta.service;

import java.io.IOException;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.pkgshoporder.ShopOrderRequest;
import com.cummins.manta.pkgshoporder.ShopOrderResponse;

public interface PackageShopOrderPartListService {
  
  public CommonResponse<ShopOrderResponse> packageShopOrderAndPartListFiles(ShopOrderRequest shopOrderRequest) throws IOException;
}
