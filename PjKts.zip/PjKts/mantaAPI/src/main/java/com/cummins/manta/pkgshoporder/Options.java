package com.cummins.manta.pkgshoporder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;
import java.util.Set;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class Options implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  String prefix;
  Set<String> value;

}
