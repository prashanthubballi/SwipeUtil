package com.cummins.manta.pkgrptrigger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PackageMfgRPTriggerRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("guid")
	String guid;
}
