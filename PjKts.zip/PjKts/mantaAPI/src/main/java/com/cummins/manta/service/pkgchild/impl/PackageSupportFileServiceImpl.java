package com.cummins.manta.service.pkgchild.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.CommonResponseHeader;
import com.cummins.manta.common.CountAndData;
import com.cummins.manta.common.ObjectData;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.exception.BadRequestException;
import com.cummins.manta.pkgsupport.AdditionListRequest;
import com.cummins.manta.pkgsupport.DeletionListRequest;
import com.cummins.manta.pkgsupport.PackageSupportFileResponse;
import com.cummins.manta.pkgsupport.SupportConstants;
import com.cummins.manta.pkgsupport.SupportFileListRequest;
import com.cummins.manta.pkgsupport.SupportRequestDTO;
import com.cummins.manta.repository.PackageMfgMasterRepo;
import com.cummins.manta.service.impl.MDCExecutorService;

import io.github.resilience4j.retry.Retry;

@Service
public class PackageSupportFileServiceImpl {
	private final Logger logger = LoggerFactory.getLogger(PackageSupportFileServiceImpl.class);


	@Autowired
	private SupportCommonUtility commonUtility;
	
	@Autowired
	private PackageMfgMasterRepo packageMfgMasterRepo;
	
	@Value("${mode}")
	private String mode;

	@Autowired
	private ParamStore paramStore;

	@Autowired
	Retry retry;

	public CommonResponse<PackageSupportFileResponse> packageSupportFile(SupportRequestDTO req) {
		logger.info("PackageSupportFile Started. Child req: {}",req);
		CommonResponse<PackageSupportFileResponse> response = new CommonResponse<>();
		CommonResponseHeader responseHeader = new CommonResponseHeader();
		PackageSupportFileResponse res=new PackageSupportFileResponse();
		String tempPath = "";
		String destPath = "";

		if (!(req.getMode().equalsIgnoreCase(SupportConstants.ALLMODE)|| req.getMode().equalsIgnoreCase(SupportConstants.DAYMODE))) {
			responseHeader.setCode(HttpStatus.OK.value()); // updated to OK to avoid causing exception in parent
			responseHeader.setMessage(SupportConstants.INVALIDMODE);
			responseHeader.setSuccess(false);
			res = new PackageSupportFileResponse();
			List<ObjectData> obj = new ArrayList<>();
			obj.add(new ObjectData(null, null, null,SupportConstants.INVALIDMODE));
			res.setCorrelationalGuid(req.getCorrelationGuid());
			res.setFailure(new CountAndData(1, obj));
			res.setSuccess(new CountAndData(0, new ArrayList<>()));
		}
		try {
			if (req.getOrigin().equalsIgnoreCase(SupportConstants.SHOPORDER)) {
				tempPath = paramStore.getTempPath() + req.getPlantID()+ SupportConstants.separator + SupportConstants.support;
				destPath = paramStore.getDestPath() + req.getPlantID()+ SupportConstants.separator + SupportConstants.support + SupportConstants.zipExtension;

			} else if (req.getOrigin().equalsIgnoreCase(SupportConstants.PARTLIST)) {
				tempPath = paramStore.getTempPath() + req.getPlantID()+ SupportConstants.separator + SupportConstants.supportP;
				destPath = paramStore.getDestPath() + req.getPlantID()+ SupportConstants.separator + SupportConstants.supportP + SupportConstants.zipExtension;

			} else if (req.getOrigin().equalsIgnoreCase(SupportConstants.ADHOC)) {
				tempPath = paramStore.getTempPath() + req.getPlantID()+ SupportConstants.separator + SupportConstants.extra + SupportConstants.separator + SupportConstants.support;

			} else {
				responseHeader.setCode(HttpStatus.OK.value()); // updated to OK to avoid causing exception in parent
				responseHeader.setMessage(SupportConstants.INVALIDORIGIN);
				responseHeader.setSuccess(false);
			}

			int numOfThreads = (req.getAdditionListRequest().size() > req.getDeletionListRequest().size())? req.getAdditionListRequest().size(): req.getDeletionListRequest().size();
			if(numOfThreads>paramStore.getSupThreadPool()) {
				numOfThreads=paramStore.getSupThreadPool();
			}

			res = callMultiThreadPool(numOfThreads, req.getAdditionListRequest(), req.getOrigin(),req.getMode(), req.getDeletionListRequest(), tempPath, req.getCorrelationGuid());
			logger.info("Copied all files");
			if (!req.getOrigin().equalsIgnoreCase(SupportConstants.ADHOC) && null!=res && null!=res.getSuccess() && res.getSuccess().getCount()>0) {
				commonUtility.zipMainFolder(tempPath, destPath);//(destinationPath, zipPath);
			}else {
				logger.error("Request is for Adhoc or no files copied in support.");
			}
			responseHeader.setCode(HttpStatus.OK.value());
			responseHeader.setMessage("Success");
			responseHeader.setSuccess(true);
		}catch (BadRequestException e) {
			responseHeader.setCode(HttpStatus.OK.value()); // updated to OK to avoid causing exception in parent
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
			res = new PackageSupportFileResponse();
			List<ObjectData> obj = new ArrayList<>();
			obj.add(new ObjectData(null, null, null,e.getMessage()));
			res.setCorrelationalGuid(req.getCorrelationGuid());
			res.setFailure(new CountAndData(1, obj));
			res.setSuccess(new CountAndData(0, new ArrayList<>()));
		}catch (Exception e) {
			responseHeader.setCode(HttpStatus.OK.value());// updated to OK to avoid causing exception in parent
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
			res = new PackageSupportFileResponse();
			List<ObjectData> obj = new ArrayList<>();
			obj.add(new ObjectData(null, null, null,e.getMessage()));
			res.setCorrelationalGuid(req.getCorrelationGuid());
			res.setFailure(new CountAndData(1, obj));
			res.setSuccess(new CountAndData(0, new ArrayList<>()));
		}
		response.setHeader(responseHeader);
		response.setData(res);
		logger.info("PackageSupportFile Completed. Child resp: {}",response);
		return response;
	}
	private Map<String, List<ObjectData>> copyFileToTemp(String pid, List<SupportFileListRequest> supportFiles,String destinationPath) {
		Map<String, List<ObjectData>> resultMap = new ConcurrentHashMap<>();
		try {
			//File destinationFile = new File(destinationPath + SupportConstants.separator + pid );
			Files.createDirectories(Paths.get(destinationPath + SupportConstants.separator + pid ));//create dest dir
			resultMap.put(SupportConstants.FAILURE_LIST, new LinkedList<ObjectData>());
			resultMap.put(SupportConstants.SUCCESS_LIST, new LinkedList<ObjectData>());

			for (SupportFileListRequest supportFile : supportFiles) {
				if(null!=supportFile.getSourceFilePath() && new File(supportFile.getSourceFilePath()).exists()) {
					//all file copy
					try {
						//src file already exist so not checking agains
						String destPathName=new String(destinationPath + SupportConstants.separator + pid + SupportConstants.separator + supportFile.getTargetName());
						retry.executeCheckedSupplier(()->{ return commonUtility.copyItemFiles(new File(supportFile.getSourceFilePath()), destPathName);});
						resultMap.get(SupportConstants.SUCCESS_LIST).add(new ObjectData(pid, null,supportFile.getSourceName(),SupportConstants.SUCCESS));
					} catch (Throwable e) {
						resultMap.get(SupportConstants.FAILURE_LIST).add(new ObjectData(pid, null,supportFile.getSourceName(),e.getMessage()));
					}
					if (supportFile.getTargetName().contains(SupportConstants.ecfg)) {
						//cbf copy
						//String[] cbfFileName = supportFile.getTargetName().split("\\.");
						String cbf=supportFile.getSourceName() + SupportConstants.cbfExtension;
						File srcFile=new File(paramStore.getCbfFilePath() + cbf);
						if(srcFile.exists()) {
							try {
								String destPathName=new String(destinationPath + SupportConstants.separator + pid + SupportConstants.separator + supportFile.getSourceName().split("\\.")[0]+SupportConstants.cbfExtension);
								retry.executeCheckedSupplier(()->{ return commonUtility.copyItemFiles(srcFile, destPathName);});
								resultMap.get(SupportConstants.SUCCESS_LIST).add(new ObjectData(pid, null,srcFile.getName(),SupportConstants.SUCCESS));
							} catch (Throwable e) {
								resultMap.get(SupportConstants.FAILURE_LIST).add(new ObjectData(pid, null,supportFile.getSourceName(),e.getMessage()));
							}
						}else {
							//failure
							resultMap.get(SupportConstants.FAILURE_LIST).add(new ObjectData(pid, null, supportFile.getSourceName(), "File Not Found:"+paramStore.getCbfFilePath() + cbf));
						}
					}
				}else {
					//failure
//					resultMap.get(SupportConstants.FAILURE_LIST).add(new ObjectData(pid, null, supportFile.getSourceName(), "File Not Found:"+supportFile.getSourceFilePath()));
						
					if(!mode.equalsIgnoreCase("Regular") && null!=supportFile.getSourceFilePath()) {
						List<String> ecProduct = packageMfgMasterRepo.getECProducts();
						String sourceFilePath = supportFile.getSourceFilePath();
						// Compile all regex patterns
				        List<Pattern> patterns = ecProduct.stream()
				            .map(ec -> Pattern.compile(".*" + Pattern.quote(ec) + ".*"))
				            .collect(Collectors.toList());

				        // Check for matches
				        boolean flag = patterns.stream().noneMatch(pattern -> pattern.matcher(sourceFilePath).matches());
				       
				        if(flag) {
							logger.info("Part file is in Regular share "+sourceFilePath);
							String regex = ".*\\\\.*\\\\(.*?)\\\\.*"; //pattern is G\folder1\folder2\file
							Pattern pattern = Pattern.compile(regex);
							Matcher matcher = pattern.matcher(sourceFilePath);
							String extracted = "";
							if (matcher.matches()) {
					            extracted = matcher.group(1);
					        } 
							resultMap.get(SupportConstants.SUCCESS_LIST).add(new ObjectData(pid, null,supportFile.getSourceName(),SupportConstants.SUCCESS+", The part number belongs to regular share under "+extracted));
						}else {
							logger.info("Part file is not available in Export share for Export Product");
							resultMap.get(SupportConstants.FAILURE_LIST).add(new ObjectData(pid, null, supportFile.getSourceName(), "File Not Found:"+supportFile.getSourceFilePath()));
						}
					}else {						
						resultMap.get(SupportConstants.FAILURE_LIST).add(new ObjectData(pid, null, supportFile.getSourceName(), "File Not Found:"+supportFile.getSourceFilePath()));
					}

				}
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("Exceptin while copying:"+e.getMessage());
		}

		return resultMap;
	}

	private String deleteFileFromTemp(String pid, String mode, List<String> deletionSupportFileList,String origin, String destinationPath) {
		File directory = new File(destinationPath + SupportConstants.separator + pid);
		for (String deletefile : deletionSupportFileList) {
			logger.info("Delete request for : " + deletefile);
			// Check if the directory exists
			File[] files = directory.listFiles();
			if (directory.exists() && directory.isDirectory() && null!=files) {
				for (File file1 : files) {
					try {
						String fileName = file1.getName();
						int lastDotIndex = fileName.lastIndexOf('.');
						String baseName = (lastDotIndex >= 0) ? fileName.substring(0, lastDotIndex) : fileName;
						if (deletefile.startsWith(baseName)) {
							if (file1.delete()) {
								logger.info("Delete successfull for : " + deletefile);
							} else {
								logger.info("Delete failed for : " + deletefile);
								file1.delete();
							}
						}
					} catch (Exception e) {
						//file1.delete();
						logger.error("Exception in support delete:"+e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}
		return "Delete Completed";
	}

	private PackageSupportFileResponse callMultiThreadPool(int numOfThreads,
			List<AdditionListRequest> additionListRequests, String origin, String mode,
			List<DeletionListRequest> deletionListRequests, String destinationPath, String guid) throws Exception {
		PackageSupportFileResponse res = new PackageSupportFileResponse();
		CountAndData successResponse = new CountAndData();
		CountAndData failureResponse = new CountAndData();
		ExecutorService delegate = Executors.newFixedThreadPool(numOfThreads);
		MDCExecutorService<ExecutorService> pool=new MDCExecutorService<ExecutorService>(delegate);
		List<Callable<String>> deletiontasks = new ArrayList<>();
		List<Callable<Map<String, List<ObjectData>>>> additiontasks = new ArrayList<>();
		List<Map<String, List<ObjectData>>> allResults = new ArrayList<>();
		//delete activity
		if (mode.equalsIgnoreCase(SupportConstants.ALLMODE) || origin.equalsIgnoreCase(SupportConstants.SHOPORDER)) {
			boolean status=FileSystemUtils.deleteRecursively(new File(destinationPath));
			logger.info("Deleting folder :"+destinationPath+", status:"+status);
		} else {
			for (int i = 0; i < deletionListRequests.size(); i++) {
				DeletionListRequest deleteList = deletionListRequests.get(i);
				deletiontasks.add((Callable<String>) () -> {
					return deleteFileFromTemp(deleteList.getProductId(), mode, deleteList.getSupportFileList(), origin,
							destinationPath);
				});
			}
		}
		//addition
		for (int i = 0; i < additionListRequests.size(); i++) {

			AdditionListRequest pidList = additionListRequests.get(i);
			if(!"BHC".equals(pidList.getProductId())) {
				additiontasks.add((Callable<Map<String, List<ObjectData>>>) () -> {	return copyFileToTemp(pidList.getProductId(), pidList.getSupportFileList(), destinationPath);});
			}
		}
		try {
			List<Future<String>> deletionResults = pool.invokeAll(deletiontasks);
			for (Future<String> result : deletionResults) {
				logger.info(result.get());
			}
			List<Future<Map<String, List<ObjectData>>>> additionResults = pool.invokeAll(additiontasks);
			for (Future<Map<String, List<ObjectData>>> result : additionResults) {
				allResults.add(result.get());
			}
			for (Map<String, List<ObjectData>> results : allResults) {

				if (!results.isEmpty()) {
					if (!results.get(SupportConstants.SUCCESS_LIST).isEmpty()) {
						for (ObjectData successList : results.get(SupportConstants.SUCCESS_LIST)) {
							successResponse.getData().add(successList);
						}
					}
					if (!results.get(SupportConstants.FAILURE_LIST).isEmpty()) {
						for (ObjectData failureList : results.get(SupportConstants.FAILURE_LIST)) {
							failureResponse.getData().add(failureList);
						}
					}
				}
			}
			if (!successResponse.getData().isEmpty()) {
				successResponse.setCount(successResponse.getData().size());
			} else {
				successResponse.setCount(0);
			}
			if (!failureResponse.getData().isEmpty()) {
				failureResponse.setCount(failureResponse.getData().size());
			} else {
				failureResponse.setCount(0);
			}
			res.setCorrelationalGuid(guid);
			res.setSuccess(successResponse);
			res.setFailure(failureResponse);
		} catch (Exception e) {
			e.printStackTrace();
			throw new IOException(e.getMessage());
		} finally {
			pool.shutdown();
		}
		return res;
	}

}
