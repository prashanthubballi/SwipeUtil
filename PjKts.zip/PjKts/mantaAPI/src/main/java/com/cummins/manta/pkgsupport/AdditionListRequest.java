package com.cummins.manta.pkgsupport;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class AdditionListRequest {

	String productId;

	List<SupportFileListRequest> supportFileList=new ArrayList<>();
}
