package com.cummins.manta.model.key;


import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


import lombok.Data;
/**
 * The persistent class for the V_PARTLIST_SO_FILE database table.
 * 
 */
@Entity
@Data
@Table(name = "V_PARTLIST_SO_FILE")
@NamedQuery(name = "VPartlistSoFile.findAll", query = "SELECT v FROM VPartlistSoFile v")
public class VPartlistSoFile implements Serializable {
  private static final long serialVersionUID = 1L;

  @EmbeddedId
  private VPartlistSoFileKey id;
}
