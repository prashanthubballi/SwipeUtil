package com.cummins.manta.pkgcalibration;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;
@Data
public class PartNumberListing {
	private String ecmCode;
    private List<PartList> partList=new ArrayList<>();
}
