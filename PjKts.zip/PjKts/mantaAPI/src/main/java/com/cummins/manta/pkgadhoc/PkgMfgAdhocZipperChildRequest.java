package com.cummins.manta.pkgadhoc;

import lombok.Data;

@Data
public class PkgMfgAdhocZipperChildRequest {

	public String correlationGuid;
	public String plantId;
	
}
