package com.cummins.manta.model.key;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "ShopOrderVO")
@Table(name = "T_SHOP_FILE_GEN")
@Data
@NoArgsConstructor
public class ShopOrderVO {
  @Id
  @Column(name = "SEQ_NUMBER")
  Integer ID;
  @Column(name = "SFG_PLANT_ID")
  String plantId;
  @Column(name = "SFG_PRODUCT_ID")
  String productId;
  @Column(name = "SFG_ECM_CODE")
  String ecmCode;
  @Column(name = "SFG_MODEL_NAME")
  String modelName;
  @Column(name = "SFG_MOD_LOCATION")
  String modeLocation;
  @Column(name = "SFG_SCHEDULED_BUILD_DATE")
  String builDate;
  @Column(name = "SFG_SHOP_ORDER_NUMBER")
  String shopOrderNumber;
  @Column(name = "SFG_ENGINE_SERIAL_NUMBER")
  String serialNumber;
  @Column(name = "SFG_GIEA_NUMBER")
  String gieaNumber;
  @Column(name = "SFG_UNIT_NUMBER")
  String unitNumber;
  @Column(name = "SFG_OPTION")
  String ddOption;
  @Column(name = "SFG_OPTION_PREFIX")
  String optionPrefix;
  @Column(name = "SFG_TYPE")
  String ddType;
}
