package com.cummins.manta.model.key;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

@Data
@Entity(name = "TShopTempVO")
@Table(name = "T_SHOP_TEMP")
public class TShopTempVO implements Serializable {
	  private static final long serialVersionUID = 1L;
	  @Id
	  @GeneratedValue(generator = "generator")
	  @GenericGenerator(name = "generator", strategy = "increment")
	  @Column(name = "TST_SEQ_ID")
	  Long id;

	  @Column(name = "TST_PLANT_ID")
	  String plantId;

	  @Column(name = "TST_PROCESSED_FLAG")
	  String processdFlag;

	  @Column(name = "TST_LOAD_FLAG")
	  String loadFlag;

	  @Column(name = "TST_LAST_UPDATE_DATE")
	  Date lastUpdateDate;
	  
	  @Column(name = "TST_GUID")
	  String correlationGuid;
}
