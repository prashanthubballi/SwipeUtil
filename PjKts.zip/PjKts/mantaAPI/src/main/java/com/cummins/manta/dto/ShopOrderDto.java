package com.cummins.manta.dto;


public interface ShopOrderDto {
	public String getPLANT_ID();
	public String getPRODUCT_ID();
	public String getPRODUCT_TYPE();
	public String getECM_CODE();
	public String getPHASE_CODE();
	public String getEFFECT_CODE();
	public String getITEM_TYPE();
	public String getAFILE();
	public String getENC_REQUIRE();
	public String getECM_NAME();
	public String getSUP_FILE_PART();//additional for support 
	public String getSUP_FILE_NAME();//additional for support
	public String getINT_PATH();
	public String getEXT_PATH();
	}
