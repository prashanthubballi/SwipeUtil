package com.cummins.manta.pkgcalibration;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class AdditionList {
	
	private String productId;
	private List<String> fileName;
	private String productType;
	private List<PartNumberListing> partNumberListing=new ArrayList<>();
	
}
