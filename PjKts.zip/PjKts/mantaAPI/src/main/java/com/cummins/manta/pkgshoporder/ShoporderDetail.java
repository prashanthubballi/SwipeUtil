package com.cummins.manta.pkgshoporder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;
import java.util.Set;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class ShoporderDetail {
  private String shopOrderNumber;
  private String engineBuildDate;
  private String engineModelName;
  private Set<BuildInformation> buildInformation;
  private List<CalibrationDetails> calibrationList;
  private Set<ReconfigIODetail> reconfigIODetails;
}
