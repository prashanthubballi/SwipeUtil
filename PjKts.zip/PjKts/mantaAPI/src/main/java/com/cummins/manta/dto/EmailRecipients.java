package com.cummins.manta.dto;

public interface EmailRecipients {
public String gettiu_mail_id();
}
