package com.cummins.manta.service.impl;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.TimeZone;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cummins.manta.common.ChildAPI;
import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.common.Constants;
import com.cummins.manta.common.CountAndData;
import com.cummins.manta.common.ObjectData;
import com.cummins.manta.common.PackageMfgMasterRequest;
import com.cummins.manta.common.PackageMfgMasterResponse;
import com.cummins.manta.common.ResponseSummary;
import com.cummins.manta.dto.ApiResponse;
import com.cummins.manta.dto.ContentForEmail;
import com.cummins.manta.dto.EmailRecipients;
import com.cummins.manta.dto.ParamStore;
import com.cummins.manta.dto.RequestLambdaDTO;
import com.cummins.manta.dto.RequestPayload;
import com.cummins.manta.exception.BadRequestException;
import com.cummins.manta.pkgadhoczip.AdhocZipperParentRequest;
import com.cummins.manta.pkgadhoczip.AdhocZipperParentResponse;
import com.cummins.manta.pkgcalibration.CalibrationRequestDTO;
import com.cummins.manta.pkgcalibration.CommonResponseData;
import com.cummins.manta.pkgcontrolfile.ControlFileRequestDTO;
import com.cummins.manta.pkgcontrolfile.ControlFileResponseDTO;
import com.cummins.manta.pkgshoporder.ShopOrderRequest;
import com.cummins.manta.pkgshoporder.ShopOrderResponse;
import com.cummins.manta.pkgsupport.PackageSupportFileResponse;
import com.cummins.manta.pkgsupport.SupportRequestDTO;
import com.cummins.manta.repository.PackageMfgMasterRepo;
import com.cummins.manta.service.pkgchild.impl.PackageControlFileServiceImpl;
import com.cummins.manta.service.pkgchild.impl.PackageMfgCalibrationsImpl;
import com.cummins.manta.service.pkgchild.impl.PackageShopOrderPartLImpl;
import com.cummins.manta.service.pkgchild.impl.PackageSupportFileServiceImpl;
import com.cummins.manta.servicenow.ServiceNowRequestGenerationDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.ZipParameters;

@Service
public class CommonUtility {
	@Autowired
	private EntityManager em;

	@Autowired
	private RestUtility restUtility;

	@Autowired
	private ParamStore paramStore;

	@Autowired
	private PackageMfgMasterRepo repo;

	@Autowired
	private PackageMfgCalibrationsImpl calImpl;

	@Autowired
	private PackageSupportFileServiceImpl supImpl;

	@Autowired
	private PackageControlFileServiceImpl cntrlImpl;

	@Autowired
	private PackageShopOrderPartLImpl shopOrderImpl;

	ObjectMapper mapper = new ObjectMapper();

	private final Logger logger = LoggerFactory.getLogger(CommonUtility.class);

	public String loadDBAndProcedures(PackageMfgMasterRequest req) {
		// call load DB and process procedures
		if (Constants.PARTLISTS.equalsIgnoreCase(req.getOrigin())|| Constants.ADHOC.equalsIgnoreCase(req.getOrigin())) {
			String storeProc = req.getOrigin().equalsIgnoreCase(Constants.PARTLISTS) ? "SP_PART_LIST_REQ_REFRESH": "SP_ADHOC_REQ_REFRESH";
			StoredProcedureQuery storedProcedure = em.createStoredProcedureQuery(storeProc);

			storedProcedure.registerStoredProcedureParameter("RUNMODE", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("TRIG_METHOD", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("PLANTID", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("p_parent_prg_id", Integer.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("p_request_id", String.class, ParameterMode.IN);

			storedProcedure.registerStoredProcedureParameter("p_return_flag", String.class, ParameterMode.OUT);

			storedProcedure.setParameter("RUNMODE", req.getMode().toUpperCase());
			storedProcedure.setParameter("TRIG_METHOD", req.getTriggerType());
			storedProcedure.setParameter("PLANTID", req.getPlantId());
			storedProcedure.setParameter("p_parent_prg_id", null);
			storedProcedure.setParameter("p_request_id", req.getCorrelationGuid());

			storedProcedure.execute();

			String temp = storedProcedure.getOutputParameterValue("p_return_flag").toString();
			logger.info("StoredProcedure Result: " + temp);
			return "0".equals(temp) ? "Success" : "Failed";
		} else {
			StoredProcedureQuery storedProcedure = em.createStoredProcedureQuery("PKG_SHOP_ORDER_WRAPPER.SP_SHOP_ORDER_MAIN");

			storedProcedure.registerStoredProcedureParameter("P_Plant_Id", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_Parent_Prg_Id", Integer.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_Request_Id", String.class, ParameterMode.IN);

			storedProcedure.registerStoredProcedureParameter("G_Return_Flag", Integer.class, ParameterMode.OUT);

			storedProcedure.setParameter("P_Plant_Id", req.getPlantId());
			storedProcedure.setParameter("P_Parent_Prg_Id", null);
			storedProcedure.setParameter("P_Request_Id", req.getCorrelationGuid());

			storedProcedure.execute();

			String temp = storedProcedure.getOutputParameterValue("G_Return_Flag").toString();
			logger.info("StoredProcedure Result: " + temp);
			return "1".equals(temp) ? "Success" : "Failed";
		}

	}

	/**
	 * 
	 * @param req
	 * @param guid
	 * @param url
	 * @param api
	 * @param summary
	 * @return
	 */
	public ChildAPI callChildAPI(Object req, String guid, String url, String api) {
		logger.info("REQUEST:" + api + ":" + req);
		if(null==url) {
			if(Constants.CALIBRATION.equals(api)) {
				CommonResponse<CommonResponseData> response=calImpl.processMfgCalibrations((CalibrationRequestDTO) req);
				return processResults(response, api,guid);
			}else if (Constants.SUPPORT.equals(api)) {
				CommonResponse<PackageSupportFileResponse> response=supImpl.packageSupportFile((SupportRequestDTO) req);
				return processResults(response, api,guid);
			}else if (Constants.SHOPORDER.equals(api)) {
				CommonResponse<ShopOrderResponse> response=shopOrderImpl.packageShopOrderAndPartListFiles((ShopOrderRequest) req);
				return processResults(response, api,guid);
			} else if (Constants.CONTROL.equals(api)) {
				CommonResponse<ControlFileResponseDTO> response=cntrlImpl.packageControlFiles((ControlFileRequestDTO) req);
				return processResults(response, api,guid);
			}
		}else {
			try {
				String requestString = mapper.writeValueAsString(req);
				logger.info("REQUEST:" + api + ":" + requestString);
				String response = restUtility.callChildApi(requestString, guid, api, url);
				if (!response.startsWith("ERROR")) {
					return processResults(response, api,guid);
				} else {
					ChildAPI child = new ChildAPI();
					List<ObjectData> obj = new ArrayList<>();
					obj.add(new ObjectData(null, null, null, response));
					child.setFailure(new CountAndData(1, obj));
					child.setSuccess(new CountAndData(0, new ArrayList<>()));
					throw new BadRequestException(api + ":" + response);
				}

			} catch (JsonProcessingException e) {
				logger.error("PkgCalAPICall:" + e.getMessage());
				throw new BadRequestException(api + ":" + e.getMessage());
			}
		}
		return null;
	}

	
	@SuppressWarnings("unchecked")
	private ChildAPI processResults(Object response, String api,String guid) {
		logger.info("RESPONSE:" + api + ":" + response);
		
		// Object data=(Object) result.get(Constants.DATA);
		if (Constants.CALIBRATION.equals(api)) {
			CommonResponse<CommonResponseData> respObj = null;
			ChildAPI calibration = new ChildAPI();
			try {
				if(response instanceof String) {
					respObj = mapper.readValue((String)response, new TypeReference<CommonResponse<CommonResponseData>>() {});
				}else {
					respObj=(CommonResponse<CommonResponseData>) response;
				}
				CommonResponseData supResponse = respObj.getData();
				calibration.setSuccess(supResponse.getSuccess());
				calibration.setFailure(supResponse.getFailure());
			} catch (JsonProcessingException e) {
				List<ObjectData> obj = new ArrayList<>();
				obj.add(new ObjectData(null, null, null, e.getMessage()));
				calibration.setFailure(new CountAndData(1, obj));
				calibration.setSuccess(new CountAndData(0, new ArrayList<>()));
			}
			return calibration;
		} else if (Constants.SUPPORT.equals(api)) {
			CommonResponse<PackageSupportFileResponse> respObj = null;
			ChildAPI support = new ChildAPI();
			try {
				if(response instanceof String) {
					respObj = mapper.readValue((String)response, new TypeReference<CommonResponse<PackageSupportFileResponse>>() {	});
				}else {
					respObj=(CommonResponse<PackageSupportFileResponse>) response;
				}
				PackageSupportFileResponse supResponse = respObj.getData();
				support.setSuccess(supResponse.getSuccess());
				support.setFailure(supResponse.getFailure());
			} catch (JsonProcessingException e) {
				List<ObjectData> obj = new ArrayList<>();
				obj.add(new ObjectData(null, null, null, e.getMessage()));
				support.setFailure(new CountAndData(1, obj));
				support.setSuccess(new CountAndData(0, new ArrayList<>()));
			}
			return support;
		} else if (Constants.SHOPORDER.equals(api)) {
			CommonResponse<ShopOrderResponse> respObj = null;
			ChildAPI shopOrder = new ChildAPI();
			try {
				if(response instanceof String) {
					respObj = mapper.readValue((String)response, new TypeReference<CommonResponse<ShopOrderResponse>>() {});
				}else {
					respObj=(CommonResponse<ShopOrderResponse>) response;
				}
				ShopOrderResponse res = respObj.getData();
				List<ObjectData> obj = null;
				if (res.getResponse() == 0) {
					obj = new ArrayList<>();
					obj.add(new ObjectData(null, null, null,Constants.SHOPORDER + ":" + respObj.getData().getFilepath()));
					shopOrder.setSuccess(new CountAndData(1, obj));
					shopOrder.setFailure(new CountAndData(0, new ArrayList<>()));
				} else {
					obj = new ArrayList<>();
					obj.add(new ObjectData(null, null, null,Constants.SHOPORDER + ":" + respObj.getData().getErrorMsg()));
					shopOrder.setFailure(new CountAndData(1, obj));
					shopOrder.setSuccess(new CountAndData(0, new ArrayList<>()));
				}
			} catch (JsonProcessingException e) {
				List<ObjectData> obj = new ArrayList<>();
				obj.add(new ObjectData(null, null, null, Constants.SHOPORDER + ":" + e.getMessage()));
				shopOrder.setFailure(new CountAndData(1, obj));
				shopOrder.setSuccess(new CountAndData(0, new ArrayList<>()));
			}
			return shopOrder;
		} else if (Constants.CONTROL.equals(api)) {
			ChildAPI control = new ChildAPI();
			CommonResponse<ControlFileResponseDTO> respObj = null;
			try {
				if(response instanceof String) {
					respObj = mapper.readValue((String)response, new TypeReference<CommonResponse<ControlFileResponseDTO>>() {});
				}else {
					respObj=(CommonResponse<ControlFileResponseDTO>) response;
				}
				ControlFileResponseDTO controlFileResponseDTO = respObj.getData();
				List<ObjectData> obj = null;
				if (!controlFileResponseDTO.getMessage().startsWith("Error")) {
					obj = new ArrayList<>();
					obj.add(new ObjectData(null, null, null, controlFileResponseDTO.getMessage()));
					control.setSuccess(new CountAndData(1, obj));
					control.setFailure(new CountAndData(0, new ArrayList<>()));
				} else {
					obj = new ArrayList<>();
					obj.add(new ObjectData(null, null, null,Constants.CONTROL + ":" + controlFileResponseDTO.getMessage()));
					control.setSuccess(new CountAndData(0, new ArrayList<>()));
					control.setFailure(new CountAndData(1, obj));
				}

			} catch (JsonProcessingException e) {
				List<ObjectData> obj = new ArrayList<>();
				obj.add(new ObjectData(null, null, null, Constants.CONTROL + ":" + e.getMessage()));
				control.setFailure(new CountAndData(1, obj));
				control.setSuccess(new CountAndData(0, new ArrayList<>()));
			}
			return control;
		}
		logger.info("Completed Process Result:" + api);
		return null;
	}

	public String packageFiles(PackageMfgMasterRequest req, boolean isRegularPresent, boolean isExportPresent) {
		StringBuffer returnResponse = new StringBuffer();

		try {
			String requestString = mapper.writeValueAsString(new AdhocZipperParentRequest(req.getCorrelationGuid(), req.getPlantId()));
			logger.info("REQUEST:" + Constants.ADHOCZIP + ":" + requestString);
			CommonResponse<AdhocZipperParentResponse> respObj = null;
			logger.info("Regular:" + Constants.ADHOCZIP);
			Files.createDirectories(Paths.get(paramStore.getDestPath() + req.getPlantId()));
			String response = zipMainFolder(paramStore.getTempPath() + req.getPlantId() + "\\Extra",paramStore.getDestPath() + req.getPlantId() + "\\Extra.zip");
			returnResponse.append(req.getCorrelationGuid() + "Regular: " + response);
			if (isExportPresent) {
				response = restUtility.callChildApi(requestString, req.getCorrelationGuid(), Constants.ADHOCZIP,paramStore.getPkgExpControlAdhocAPI());
				logger.info("ADhoc zip response :" + response);
				if (!response.startsWith("ERROR")) {
					respObj = mapper.readValue(response,new TypeReference<CommonResponse<AdhocZipperParentResponse>>() {});
					returnResponse.append(" Export:" + respObj.getData().getFilePath() + "" + respObj.getData().getErrorMessage());
				} else {
					logger.error("ADhoc zip response :" + response);
					throw new BadRequestException(Constants.ADHOCZIP + ":" + response);
				}
			}
		} catch (Exception ex) {
			logger.error("Exception in adhoc:" + ex.getMessage());
			throw new BadRequestException(Constants.ADHOCZIP + ":" + ex.getMessage());
		}
		return returnResponse.toString();
	}

	public String processPkgErrors(PackageMfgMasterRequest req, Map<String, String> ecmPartMap,
			ResponseSummary responseSummary, PackageMfgMasterResponse response) {
		logger.info("Inside processPkgErrors");
		try {
			StringBuffer errorMessage = new StringBuffer();
			List<ObjectData> errList = new ArrayList<>();
			if (null != responseSummary.getCalibration() && null != responseSummary.getCalibration().getFailure()
					&& responseSummary.getCalibration().getFailure().getCount() > 0) {
				if (!Constants.SHOPORDER.equalsIgnoreCase(req.getOrigin())) {// only for partlist adhoc we need to pass
					// error to procedures
					String stringError = mapper.writeValueAsString((List<ObjectData>) responseSummary.getCalibration().getFailure().getData());
					if (!stringError.startsWith("ERROR")) {
						errList.addAll(mapper.readValue(stringError, new TypeReference<List<ObjectData>>() {}));
					}
				}
				errorMessage.append("Calibration,");
			}
			if (null != responseSummary.getSupport() && null != responseSummary.getSupport().getFailure()
					&& responseSummary.getSupport().getFailure().getCount() > 0) {
				if (!Constants.SHOPORDER.equalsIgnoreCase(req.getOrigin())) {// only for partlist adhoc we need to pass
					// error to procedures
					String stringError = mapper.writeValueAsString(responseSummary.getSupport().getFailure().getData());
					if (!stringError.startsWith("ERROR")) {
						List<ObjectData> rawRrrList = mapper.readValue(stringError,	new TypeReference<List<ObjectData>>() {	});
						for (ObjectData objectData : rawRrrList) {
							errList.add(new ObjectData(objectData.getProductId(),ecmPartMap.get(objectData.getProductId() + "-" + objectData.getPartNumber()),objectData.getPartNumber(), objectData.getMessage()));
						}
					}

				}
				errorMessage.append("Support,");
			}
			if (null != responseSummary.getShopOrder() && null != responseSummary.getShopOrder().getFailure()
					&& responseSummary.getShopOrder().getFailure().getCount() > 0) {
				errorMessage.append("ShopOrder,");
			}
			if (null != responseSummary.getControl() && null != responseSummary.getControl().getFailure()
					&& responseSummary.getControl().getFailure().getCount() > 0) {
				errorMessage.append("Control,");
			}
			if (errorMessage.length() > 0) {
				response.setErrorMessage("Package " + errorMessage.toString() + " has errors, please check summary for more details");
			}
			logger.info("calling LogErrorDB");
			logErrorToDB(req, errList);
			logger.info("plant Id:" + req.getPlantId());
			int updateStatus;
			if (Constants.SHOPORDER.equalsIgnoreCase(req.getOrigin()) && errorMessage.length() > 0) {
				if (repo.checkShopOrderError(req.getPlantId()) > 0) {
					sendEmail(req.getPlantId(), "error");
				}
				updateStatus = repo.updateTShopTempTable("X", req.getPlantId(), req.getSeqId());
				return 1 == updateStatus ? "Success" : "Failed to update DB";
			} else if (Constants.SHOPORDER.equalsIgnoreCase(req.getOrigin())) {
				if (repo.checkShopOrderError(req.getPlantId()) > 0) {
					sendEmail(req.getPlantId(), "error");
				}
				updateStatus = repo.updateTShopTempTable("P", req.getPlantId(), req.getSeqId());
				return 1 == updateStatus ? "Success" : "Failed to update DB";
			}

		} catch (JsonProcessingException e) {
			logErrorToDB(req, new ArrayList<ObjectData>());
			logger.error("Exception in Error handling" + e.getMessage());
			return "Failed:" + e.getMessage();
		}
		return "Completed";
	}

	private String logErrorToDB(PackageMfgMasterRequest req, List<ObjectData> errList) {
		logger.info("inside logErrorToDB");
		try {
			List<String> inputs = new ArrayList<>();
			boolean hasErrors = false;
			for (ObjectData error : errList) {
				hasErrors = true;
				try {
					// System.out.println(error);
					if (null != error.getEcmCode()) {
						String ecm_base = error.getEcmCode().contains(".") ? error.getEcmCode().split("\\.")[0]: error.getEcmCode();
						String partnumber = (null != error.getPartNumber()) ? error.getPartNumber(): error.getEcmCode();
						inputs.add(ecm_base + "- " + partnumber + " " + error.getMessage());
					} else {
						String ecm_base = error.getPartNumber().contains(".") ? error.getPartNumber().split("\\.")[0]: error.getPartNumber();
						String partnumber = error.getPartNumber();
						inputs.add(ecm_base + "- " + partnumber + " " + error.getMessage());
					}
				} catch (Exception e) {
					e.printStackTrace();
					inputs.add(e.getMessage());
					logger.error("Error while parsing error :" + e.getMessage());
				}
			}
			logger.info("errors " + inputs.toString());
			// splitting total error into batch of 35 as overall limit with partwitherror is
			// 4000chars
			Iterator<List<String>> it = batches(inputs, 35).iterator();
			while (it.hasNext() || !hasErrors) {
				String input = null;
				// if no error then calling procedure with null as input
				if (hasErrors) {
					List<String> li = it.next();
					input = li.toString().replace("[", "").replace("]", "");
					logger.info("Error String :" + input);
				}
				String storeProc = req.getOrigin().equalsIgnoreCase(Constants.PARTLISTS)? "SP_PART_LIST_HISTORY_REFRESH": "SP_ADHOC_HISTORY_REFRESH";

				StoredProcedureQuery storedProcedure = em.createStoredProcedureQuery(storeProc);

				storedProcedure.registerStoredProcedureParameter("RUNMODE", String.class, ParameterMode.IN);
				storedProcedure.registerStoredProcedureParameter("TRIG_METHOD", String.class, ParameterMode.IN);
				storedProcedure.registerStoredProcedureParameter("partwitherror", String.class, ParameterMode.IN);
				storedProcedure.registerStoredProcedureParameter("PLANTID", String.class, ParameterMode.IN);
				storedProcedure.registerStoredProcedureParameter("p_parent_prg_id", Integer.class, ParameterMode.IN);
				storedProcedure.registerStoredProcedureParameter("p_request_id", String.class, ParameterMode.IN);

				storedProcedure.registerStoredProcedureParameter("p_return_flag", String.class, ParameterMode.OUT);

				storedProcedure.setParameter("RUNMODE", req.getMode().toUpperCase());
				storedProcedure.setParameter("TRIG_METHOD", req.getTriggerType());
				storedProcedure.setParameter("partwitherror", input);
				storedProcedure.setParameter("PLANTID", req.getPlantId());
				storedProcedure.setParameter("p_parent_prg_id", null);
				storedProcedure.setParameter("p_request_id", req.getCorrelationGuid());

				storedProcedure.execute();

				String temp = storedProcedure.getOutputParameterValue("p_return_flag").toString();
				// logger.info(req.getCorrelationGuid()+":Input:"+input+"StoredProcedure Result:
				// "+storeProc+" , result" + temp);
				logger.info("Inputs:partwitherror" + input + ",PLANTID:" + req.getPlantId()	+ " StoredProcedure Result: " + storeProc + " , result:" + temp);
				hasErrors = true;
			}
			return "Success";
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception while executing DB procedure " + e.getMessage());
			
			return "Failed";
		}
	}

	

	public static <T> Stream<List<T>> batches(List<T> source, int length) {
		if (length <= 0) {
			throw new IllegalArgumentException("length = " + length);
		}
		int size = source.size();
		if (size <= 0) {
			return Stream.empty();
		}
		int fullChunks = (size - 1) / length;
		return IntStream.range(0, fullChunks + 1)
				.mapToObj(n -> source.subList(n * length, n == fullChunks ? size : (n + 1) * length));
	}

	public void sendEmail(String PlantId, String mode) {

		try {
			TimeZone estTimeZone = TimeZone.getTimeZone("America/New_York");
			Calendar estCalendar = Calendar.getInstance(estTimeZone);
			SimpleDateFormat dateFormat = new SimpleDateFormat("d MMM yyyy");
			dateFormat.setTimeZone(estTimeZone);
			String formattedDate = dateFormat.format(estCalendar.getTime());
			SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
			timeFormat.setTimeZone(estTimeZone);
			String formattedTime = timeFormat.format(estCalendar.getTime());
			List<EmailRecipients> emaillist = new ArrayList<>();
			if (mode.equalsIgnoreCase("Refresh")) {
				emaillist = repo.getEmailRecipientsForRefereshNotification(PlantId);
			} else if (mode.equalsIgnoreCase("Error")) {
				emaillist = repo.getEmailRecipientsForShopOrderError(PlantId);
			}

			if (emaillist.size() > 0) {
				if (emaillist.size() > 50) {
					Iterator<List<EmailRecipients>> chunks = batches(emaillist, 50).iterator();
					while (chunks.hasNext()) {
						emailDetailProcessing(PlantId, mode, formattedDate, formattedTime, chunks.next());
					}
				} else {
					emailDetailProcessing(PlantId, mode, formattedDate, formattedTime, emaillist);
				}
			}
		} catch (RestClientException e) {
			logger.error(e.getMessage());

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}

	private void emailDetailProcessing(String PlantId, String mode, String formattedDate, String formattedTime,
			List<EmailRecipients> emaillist) throws URISyntaxException {
		StringJoiner joiner = new StringJoiner(",");
		for (EmailRecipients item : emaillist) {
			joiner.add(item.gettiu_mail_id().toString());
		}
		RestTemplate restTemplate = new RestTemplate();
		ContentForEmail content = new ContentForEmail();
		List<Object> list = new ArrayList<>();
		list.add("");
		ResponseEntity<Object> result = null;
		URI uri;
		uri = new URI(paramStore.getCommonLambdaUrl());
		RequestPayload payload = new RequestPayload();
		payload.setTo(joiner.toString());
		payload.setFrom(paramStore.getSendersEmail());
		payload.setTemplate(paramStore.getEmailTemplateName());
		if (mode.equalsIgnoreCase("Refresh")) {
			payload.setSubject("Plant " + PlantId + " refresh completion notification");
		} else if (mode.equalsIgnoreCase("Error")) {
			payload.setSubject("Shop Order Error Report " + PlantId);
		}
		content.setUsername("Hi All,");
		if (mode.equalsIgnoreCase("Refresh")) {
			content.setContent("Plant " + PlantId + " was successfully processed in SPEED on " + formattedDate + " at "
					+ formattedTime + "(EST)");
		} else if (mode.equalsIgnoreCase("Error")) {

			content.setContent("Shoporders processed for plant " + PlantId + " on " + formattedDate + " at "
					+ formattedTime + "(EST) has error/warning. Please use following "
					+ "plant dashboard link for more details.<br>"
					+ "Interfaces -> Plant DashBorad -> PlantId ->Failed Unit hyperlink.<br>" + "<br>"
					+ paramStore.getPlantDashBoardLink()+"?plant="+PlantId + "<br>" + "<br>"
					+ "-------------------------------------------------------------<br>" + "<br>"
					+ "To report any problems<br>" + "Contact : " + paramStore.getEmailIdForSupport() + "<br>" + "<br>"
					+ "To request addition or removal from this mail notification<br>" + "Visit "
					+ paramStore.getUasLink());
		}

		content.setTableInformation(list);
		payload.setData(content);
		RequestLambdaDTO requestLambdaDTO = new RequestLambdaDTO();
		requestLambdaDTO.setFunctionName(paramStore.getLambdaFunctionforEmail());
		requestLambdaDTO.setPayload(payload);

		result = restTemplate.postForEntity(uri, requestLambdaDTO, Object.class);
		logger.info("## Param Store :" + result);
	}

	public String createServiceNowTicket(String shortError, String description, String guid) {
		ServiceNowRequestGenerationDTO dto = new ServiceNowRequestGenerationDTO();
		try {
			dto.setAssignment_group(paramStore.getServiceNowAssignmentGrp());
			dto.setDescription(description);
			dto.setImpact(paramStore.getServiceNowImpact());
			dto.setUrgency(paramStore.getServiceNowUrgency());
			dto.setShort_description(shortError);
			String requestString = mapper.writeValueAsString(dto);
			return restUtility.callChildApi(requestString, guid, Constants.SERVICENOW, paramStore.getServiceNowAPI());
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			logger.error("Error while creating service now request:" + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while creating service now request ex:" + e.getMessage());
		}
		return "Error while creating service now request";
	}

	public String doCFGTransfer(PackageMfgMasterRequest req) {
		String requestString = Constants.CFG_REQUEST;
		if (null != paramStore.getCfgTo() && null != paramStore.getCfgFrom()) {
			requestString = "{" + "\"fromPath\": \"" + paramStore.getCfgFrom() + "\"," + "\"toFolder\": \""	+ paramStore.getCfgTo() + "\"" + "}";
		}
		logger.info("CFG from Param URL:" + paramStore.getCfgTransferURL() + ", req:"+ requestString);
		StringBuffer returnResponse = new StringBuffer();
		CommonResponse<ApiResponse> respObj = null;

		// logger.info(req.getCorrelationGuid()+"REQUEST For
		// CFG:"+Constants.CFG_TRANSFER+":"+requestString);
		String response = null;
		try {
			response = restUtility.callChildApi(requestString, req.getCorrelationGuid(), Constants.CFG_TRANSFER,paramStore.getCfgTransferURL());
			logger.info("RESPONSE For CFG:" + Constants.CFG_TRANSFER + ":" + response);
			if (!response.startsWith("ERROR")) {
				respObj = mapper.readValue(response, new TypeReference<CommonResponse<ApiResponse>>() {	});
				returnResponse.append(respObj.getData().getResponse() + "" + respObj.getData().getMessage() + ""+ respObj.getData().getErrorMsg());
			} else {
				// throw new BadRequestException(Constants.CFG_TRANSFER+":"+response);
				// logger.error(req.getCorrelationGuid()+"Exception in CFG :"+response);
				String shortError = "CFG tranafer failed in MFG distributions: URL:" + paramStore.getCfgTransferURL();
				String description = req.getCorrelationGuid() + "\nRequest:" + requestString + "\nResponse:" + response;
				logger.info("SNOW:"	+ createServiceNowTicket(shortError, description, req.getCorrelationGuid()));
			}
		} catch (Exception e) {
			logger.error(req.getCorrelationGuid() + "Exception in  CFG :" + e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	private String zipMainFolder(String srcPath, String outputPath) {
		logger.info("Folder zip started:src" + srcPath + " dst:" + outputPath);
		if (new File(outputPath).exists()) {
			boolean status = new File(outputPath).delete();
			logger.info("Deleting existing zip in dst,status:" + status);
		}
		File dir = new File(srcPath);
		ZipParameters parameters = new ZipParameters();
		parameters.setIncludeRootFolder(false);
		try (ZipFile zipFile = new ZipFile(outputPath);) {
			zipFile.addFolder(dir, parameters);
		} catch (Exception e) {
			logger.error("Folder zip exception:" + e.getMessage());
			e.printStackTrace();
			throw new BadRequestException(e.getMessage());
		}
		logger.info("Folder zip completed:" + outputPath);
		return outputPath;
	}
}
