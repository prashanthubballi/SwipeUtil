package com.cummins.manta.model.key;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class TAuditKey implements Serializable  {

	private static final long serialVersionUID = 1L;
	@Column(name="AUD_ACTIVITY_ID")
	private String audActivitId;
	
	@Column(name="AUD_DATE")
	private LocalDateTime audDate;
	
	@Column(name="AUD_FUNCTION_ID")
	private String audFunctionId;
	
	@Column(name="AUD_SUB_ACTIVITY")
	private String audSubActivity;
	
	@Column(name="AUD_SUB_FUNCTION_ID")
	private String audSubFunctionId;
	
	@Column(name="AUD_ACTIVITY")
	private String audActivity;

	@Column(name="AUD_CODE")
	private String audCode;
	
	@Column(name="AUD_SUB_CODE")
	private String audSubCode;
	
	@Column(name="AUD_DETAILS")
	private String audDetails;
	
	@Column(name="AUD_LAST_UPDATE_DATE")
	private LocalDateTime audLastUpdateDate;
	
	@Column(name="AUD_LAST_UPDATE_USER")
	private String audLastUpdateUser;
	
	@Column(name="REQUEST_ID")
	private String audRequestId;
	
	@Column(name="STATUS")
	private int audStatus;
	
	
}

