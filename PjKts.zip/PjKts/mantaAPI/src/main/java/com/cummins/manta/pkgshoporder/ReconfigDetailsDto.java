package com.cummins.manta.pkgshoporder;

public interface ReconfigDetailsDto {
  String getId();

  String getSOOption();

  String getReconfigIndicator();

  String getSopNounName();

  String getTrsFeatureName();

  String getShopOrderNumber();

  String getBuildDate();

}
