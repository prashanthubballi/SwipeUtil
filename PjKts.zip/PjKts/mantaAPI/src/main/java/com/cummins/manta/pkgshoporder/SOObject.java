package com.cummins.manta.pkgshoporder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SOObject {

	   private String PlantId;

	   private String ShopOrderNumber;

	   private String BuildDate;

	   private String ModelName;

	   private String GieaNumber;

	   private String UnitNumber;

	   private String SerialNumber;

	   private String EcmCode;

	   private String SopOption;

	   private String ModLocation;

	   private String ProductId;

	   private String OptionPrefix;

	   private String OptionType;
}
