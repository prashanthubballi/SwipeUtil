package com.cummins.manta.pkgshoporder;

import java.util.List;
import lombok.Data;

@Data
public class ParentClassDto {

  String plantId;
  List<ShopOrderDetailsDto> shopOrderDetails;
}

