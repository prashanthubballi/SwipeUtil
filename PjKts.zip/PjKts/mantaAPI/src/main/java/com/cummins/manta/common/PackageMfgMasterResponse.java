package com.cummins.manta.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import org.springframework.stereotype.Component;


@JsonPropertyOrder({
    "correlationGuid",
    "plantId",
    "errorMessage",
    "summary"
   
})
@Data
@Component
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(Include.NON_NULL)
public class PackageMfgMasterResponse {

    @JsonProperty("correlationGuid")
    private String correlationGuid;
    @JsonProperty("plantId")
    private String plantId;
    @JsonProperty("errorMessage")
    private String errorMessage;
    @JsonProperty("summary")
    private ResponseSummary summary;
   
}
