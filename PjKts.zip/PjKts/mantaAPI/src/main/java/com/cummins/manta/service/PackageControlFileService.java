package com.cummins.manta.service;


import java.io.IOException;

import com.cummins.manta.common.CommonResponse;
import com.cummins.manta.pkgcontrolfile.ControlFileRequestDTO;
import com.cummins.manta.pkgcontrolfile.ControlFileResponseDTO;
public interface PackageControlFileService {
	
	CommonResponse<ControlFileResponseDTO> packageControlFiles(ControlFileRequestDTO dto) throws IOException;
}
