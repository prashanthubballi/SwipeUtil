package com.cummins.manta.exception;

public class BadRequestException extends RuntimeException {

	/**
	* 
	*/
	private static final long serialVersionUID = 8403434622963075770L;

	public BadRequestException(String message) {
		super(message);
	}

	public BadRequestException(String message, Throwable cause) {
		super(message, cause);
	}
	
}
