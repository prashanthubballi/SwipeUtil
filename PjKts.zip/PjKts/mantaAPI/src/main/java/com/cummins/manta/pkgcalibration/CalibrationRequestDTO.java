package com.cummins.manta.pkgcalibration;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;
@Data
public class CalibrationRequestDTO {

	private String correlationGuid;
	private String origin;
	private String mode;
	private String plantID;
	private List<AdditionList> additionList=new ArrayList<>();
	private List<DeletionList> deletionList=new ArrayList<>();
	

}
