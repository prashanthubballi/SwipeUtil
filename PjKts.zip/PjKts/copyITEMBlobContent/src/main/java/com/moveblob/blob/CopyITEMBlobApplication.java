package com.moveblob.blob;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class CopyITEMBlobApplication {

	public static void main(String[] args) throws Exception {
		//int a = Integer.parseInt(args[0]);
		int count = 0;
		int newcount = 0;
		String logLine = "";
		//SpringApplication.run(CopyITEMBlobApplication.class, args);
		String url = "jdbc:oracle:thin:@ftdcslddb656.ftiz.cummins.com:1527:Spdd2";
		String username = "speedadmin";
		String password = "newyork";

//		String query = "SELECT CASE WHEN INSTR(123456789,SUBSTR(ITM_NUMBER,1,1),1)> 0 "
//				+ "            THEN SUBSTR(ITM_NUMBER,1,7) " + "            ELSE SUBSTR(ITM_NUMBER,1,8) "
//				+ "            END ITM_NUMBER,ITM_REVISION_LEVEL as itemrl,ITM_PRODUCT_ID as itempid, "
//				+ "			   ITM_BLOB as itemblob, ROWNUM AS rn FROM T_ITEM_BLOB_SPEEDNG";
		
		String query = "select ITM_NUMBER, itemrl, itempid, itemblob, rn from "
				+ "(SELECT CASE WHEN INSTR(123456789,SUBSTR(ITM_NUMBER,1,1),1)> 0 "
				+ "THEN SUBSTR(ITM_NUMBER,1,7) ELSE SUBSTR(ITM_NUMBER,1,8) "
				+ "END ITM_NUMBER,ITM_REVISION_LEVEL as itemrl,ITM_PRODUCT_ID as itempid, "
				+ "ITM_BLOB as itemblob, row_number() OVER (ORDER BY ITM_PRODUCT_ID, ITM_NUMBER ) as rn "
				+ "FROM T_ITEM_BLOB_SPEEDNG) where rn=1";// > " +(a*40000) + " and rn <= " + ((a*40000)+40000);

		try (Connection connection = DriverManager.getConnection(url, username, password)) {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(query);
			System.out.println("DB connected");
			
			long start = System.currentTimeMillis();

			while (resultSet.next()) {
				long startTime = System.currentTimeMillis();
				
				String ITM_NUMBER = resultSet.getString("ITM_NUMBER");
				String itemrl = resultSet.getString("itemrl");
				String itempid = resultSet.getString("itempid");
				Blob itemblob = resultSet.getBlob("itemblob");
				System.out.println("PID: " + itempid + " | ItemNo.: " + ITM_NUMBER + " | revision: " + itemrl);

				if (itemrl.length() == 1) {
					itemrl = "0" + itemrl;
				}

				String filePath = "C:\\Users\\vw596\\OneDrive - Cummins\\Desktop\\Cummins\\" + itempid + "\\" + ITM_NUMBER + "." + itemrl;
				//String filePath = "G:\\ITEM\\" + itempid + "\\" + ITM_NUMBER + "." + itemrl;
				File file = new File(filePath);

				file.getParentFile().mkdirs();

//	        	InputStream inputStream = itemblob.getBinaryStream();
//           	BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
				if (!file.exists()) {
					file.createNewFile();
					newcount++;
					System.out.println(newcount);
					logLine = logLine + file.getName() + " NEWFILE\r\n";

				} else {
					System.out.println("ALREADY EXISTS :");
					count++;
					System.out.println(count);
					logLine = logLine + file.getName() + " ALREADYEXISTS\r\n";
					continue;
				}
				
				// Get the input stream from the Blob
				try (InputStream inputStream = itemblob.getBinaryStream();
						BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
						FileOutputStream fileOutputStream = new FileOutputStream(file);
						BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
						ZipInputStream zipInputStream = new ZipInputStream(bufferedInputStream)) {

					// Extract the first entry from the zip stream
					ZipEntry entry = zipInputStream.getNextEntry();
					if (entry != null) {

						byte[] buffer = new byte[2097152]; // 8KB buffer size (can be adjusted)
						int bytesRead;
						while ((bytesRead = zipInputStream.read(buffer)) != -1) {
							bufferedOutputStream.write(buffer, 0, bytesRead);
						}

						System.out.println("File unzipped successfully!");

					} else {
						System.out.println("No entries found in the zip stream!");

						try {
							// FileInputStream fis = null;
							// FileOutputStream fos = null;

							byte[] buf = new byte[1024];

							// destinationFile.getParentFile().mkdirs();

							// fis = new FileInputStream(inputStream);
							FileOutputStream fos = new FileOutputStream(file);
							int c;
							while ((c = bufferedInputStream.read(buf)) > 0) {

								// Writing to output file of the specified
								// directory
								fos.write(buf, 0, c);
							}

							// fis.close();
							fos.close();

						} catch (Exception e) {
							logLine = logLine + file.getName() + " FAILURE\r\n";
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					logLine = logLine + file.getName() + " FAILURE\r\n";
					e.printStackTrace();
				}
				
				long endTime = System.currentTimeMillis();
		        long elapsedTime = endTime - startTime;
		        System.out.println("Time taken to copy: " + elapsedTime + " milliseconds");
		        System.out.println("Total Time: "+ (endTime - start) + " milliseconds");
		        System.out.flush();
			}
			long totalTime = System.currentTimeMillis();
			
			resultSet.close();
			statement.close();
			System.out.println("already existing file count: " + count);
			System.out.println("newly created file count: " + newcount);
			try {

				String FileName = "LOGFORITEMFOLDERFORNDRIVE_"+ ".txt";

				File f1 = new File("G:\\Temp\\" + FileName);
//				File f1 = new File("C:\\Users\\ss586\\git\\sprint_3-7\\COE\\" + FileName);

				f1.createNewFile();

				FileWriter writer = new FileWriter(f1.getPath(), false);

				BufferedWriter bw = new BufferedWriter(writer);
				logLine = logLine + "Total files copied are: " + newcount +"\r\n";
				logLine = logLine + "Total time taken for copying all the file is: " + TimeUnit.MILLISECONDS.toMinutes(totalTime-start) + " minutes.\r\n";
				logLine = logLine + "Total time taken for copying all the file is: " + (totalTime-start) + " milliseconds.\r\n";


				bw.write(logLine);

				bw.close();


			} catch (IOException e) {

				e.getMessage();

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
}