package com.moveblob.blob;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.tika.Tika;

//@SpringBootApplication
public class CopyItemBlob {

	public static void main(String[] args) throws Exception {
		//int a = Integer.parseInt(args[0]);
		int count = 0;
		int newcount = 0;
		String logLine = "";
		//SpringApplication.run(CopyITEMBlobApplication.class, args);
		String url = "jdbc:oracle:thin:@ftdcslddb656.ftiz.cummins.com:1527:Spdd2";
		String username = "speedadmin";
		String password = "newyork";

//		String query = "SELECT CASE WHEN INSTR(123456789,SUBSTR(ITM_NUMBER,1,1),1)> 0 "
//				+ "            THEN SUBSTR(ITM_NUMBER,1,7) " + "            ELSE SUBSTR(ITM_NUMBER,1,8) "
//				+ "            END ITM_NUMBER,ITM_REVISION_LEVEL as itemrl,ITM_PRODUCT_ID as itempid, "
//				+ "			   ITM_BLOB as itemblob, ROWNUM AS rn FROM T_ITEM_BLOB_SPEEDNG";
		
		String query = "select ITM_NUMBER, itemrl, itempid, itemblob, rn from "
				+ "(SELECT CASE WHEN INSTR(123456789,SUBSTR(ITM_NUMBER,1,1),1)> 0 "
				+ "THEN SUBSTR(ITM_NUMBER,1,7) ELSE SUBSTR(ITM_NUMBER,1,8) "
				+ "END ITM_NUMBER,ITM_REVISION_LEVEL as itemrl,ITM_PRODUCT_ID as itempid, "
				+ "ITM_BLOB as itemblob, row_number() OVER (ORDER BY ITM_PRODUCT_ID, ITM_NUMBER ) as rn "
				+ "FROM T_ITEM_BLOB_SPEEDNG) where rn=1";// > " +(a*40000) + " and rn <= " + ((a*40000)+40000);

		try (Connection connection = DriverManager.getConnection(url, username, password)) {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(query);
			System.out.println("DB connected");
			
			long start = System.currentTimeMillis();

			while (resultSet.next()) {
				long startTime = System.currentTimeMillis();
				
				String ITM_NUMBER = resultSet.getString("ITM_NUMBER");
				String itemrl = resultSet.getString("itemrl");
				String itempid = resultSet.getString("itempid");
				Blob itemblob = resultSet.getBlob("itemblob");
				System.out.println("PID: " + itempid + " | ItemNo.: " + ITM_NUMBER + " | revision: " + itemrl);

				if (itemrl.length() == 1) {
					itemrl = "0" + itemrl;
				}

				String filePath = "C:\\Users\\vw596\\OneDrive - Cummins\\Desktop\\Cummins\\" + itempid + "\\" + ITM_NUMBER + "." + itemrl;
				//String filePath = "G:\\ITEM\\" + itempid + "\\" + ITM_NUMBER + "." + itemrl;
				File file = new File(filePath);

				//file.getParentFile().mkdirs();

//	        	InputStream inputStream = itemblob.getBinaryStream();
//           	BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
				System.out.println("******************************");
				//System.out.println(.);
				InputStream strm=itemblob.getBinaryStream();
				
				//ObjectInputStream ois = new ObjectInputStream(strm);
				//String retrieveBlobAsString = (String) ois.readObject();
				
				Files.copy(strm, file.toPath());
				//File file = new File("/path/to/file");
				Tika tika = new Tika();
				System.out.println(tika.detect(file));
				
				// Get the input stream from the Blob
				
				long endTime = System.currentTimeMillis();
		        long elapsedTime = endTime - startTime;
		        System.out.println("Time taken to copy: " + elapsedTime + " milliseconds");
		        System.out.println("Total Time: "+ (endTime - start) + " milliseconds");
		        System.out.flush();
			}
			long totalTime = System.currentTimeMillis();
			
			resultSet.close();
			statement.close();
			System.out.println("already existing file count: " + count);
			System.out.println("newly created file count: " + newcount);
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
}