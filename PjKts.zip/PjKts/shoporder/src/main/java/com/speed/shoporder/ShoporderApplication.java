package com.speed.shoporder;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoporderApplication {
	 static String pid = "";
	static String ecmerdate = "";
	public static void main(String[] args) {
		
		SpringApplication.run(ShoporderApplication.class, args);
	//	if (args.length != 3) {
	//		System.out.println("Usage: connect string, Valid Ecm code, Valid Plant Id, Location");
	//		System.exit(1);
	//	}
		String ecmCode ="AP90049.10";// args[0];
		String plantId = "CDC";//args[1];
		String location = "./";
		String url = "jdbc:oracle:thin:@speedrdsu.crdccmzu4qbl.us-east-1.rds.amazonaws.com:1521/SPDRDSU";
		String username = "SPEEDADMIN";
		String password = "newyork";
		try (Connection connection = DriverManager.getConnection(url, username, password);
				BufferedWriter reportFile = new BufferedWriter(new FileWriter(location + ecmCode + "_Output.cic"))) {
			
			List<String> optionList = new ArrayList<>();
			print00(reportFile, plantId);
        print01(reportFile, connection, plantId, ecmCode);
		optionList =	print02(reportFile, connection, plantId, ecmCode);
		print03(reportFile, connection, plantId, ecmCode, optionList);
		print91(reportFile, connection, plantId,ecmCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	private static void print00(BufferedWriter reportFile, String plantId) throws IOException {
		String reportData = "00;" + plantId + ";" + generateSpaces(3) + ";" + generateSpaces(11) + ";"
				+ generateSpaces(8) + ";" + generateSpaces(3) + ";" + generateSpaces(17) + ";" + generateSpaces(16)
				+ ";" + generateSpaces(5) + ";" + generateSpaces(81) + ";" + generateSpaces(8) + ";" + generateSpaces(8)
				+ ";" + generateSpaces(8) + ";" + generateSpaces(8) + ";" + generateSpaces(8) + ";"; // Construct the
																										// data for this
																										// section
		reportFile.write(reportData);
		reportFile.newLine();
	}

	private static void print01(BufferedWriter reportFile, Connection connection, String plantId,
			String ecmCode)
			throws SQLException, IOException {


		// Get the current system date and time
		LocalDateTime now = LocalDateTime.now();

		// Define the desired format
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");

		// Format the date and print it
		String formattedDate = now.format(formatter);
		// Use a PreparedStatement to retrieve data from the database
		String query = "SELECT DISTINCT ECM_PRODUCT_ID,to_char(ECM_ER_DATE,'yyyymmdd') as ecmerdate FROM T_ECM  "
				+ "	  WHERE ECM_CODE LIKE ? ";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1,ecmCode);

			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				// Process and format the data
				ecmerdate = resultSet.getString("ecmerdate");
				pid = resultSet.getString("ECM_PRODUCT_ID");
				String reportData = "01;" + plantId + ";" + resultSet.getString("ECM_PRODUCT_ID")+";" + "SO1234500  "+";"
						+ formattedDate + ";" + generateSpaces(3) + ";" + generateSpaces(17) + ";" + generateSpaces(16)
						+ ";" + generateSpaces(5) + ";" + generateSpaces(11) + ";" + generateSpaces(69) + ";"
						+ generateSpaces(8) + ";" + generateSpaces(8) + ";" + generateSpaces(8) + ";"
						+ generateSpaces(8) + ";" + generateSpaces(8) + ";";
				reportFile.write(reportData);
				reportFile.newLine();
			}
		}
	}
	private static List<String> print02(BufferedWriter reportFile, Connection connection, String plantId,
			String ecmCode)
			throws SQLException, IOException {
      List<String> optionList = new ArrayList<>();
		// Get the current system date and time
		LocalDateTime now = LocalDateTime.now();

		// Define the desired format
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");

		// Format the date and print it
		String formattedDate = now.format(formatter);
		// Use a PreparedStatement to retrieve data from the database
		String query = " SELECT DISTINCT PRS_OPTION_NUMBER, OPR_NOUN_NAME FROM T_PRODUCT_RELEASES, T_OPTIONS "
				+ "WHERE PRS_ECM_CODE LIKE ? AND PRS_OPTION_NUMBER = OPR_OPTION_NUMBER ";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1, "%" + ecmCode);

			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				// Process and format the data
				//ecmerdate = resultSet.getString("ECM_ER_DATE");
				int length = 25- resultSet.getString("OPR_NOUN_NAME").length();
				optionList.add(resultSet.getString("PRS_OPTION_NUMBER"));
				String reportData = "02;" + plantId + ";" +pid+ ";"+"SO1234500  "+";"
						+ formattedDate + ";" +resultSet.getString("PRS_OPTION_NUMBER") + ";" + generateSpaces(11) + ";" +
						resultSet.getString("OPR_NOUN_NAME")+generateSpaces(length)
						+ ";" + generateSpaces(11) + ";" + "N"+";"+generateSpaces(62) + ";" 
						+ generateSpaces(8) + ";" + generateSpaces(8) + ";" + generateSpaces(8) + ";"
						+ generateSpaces(8) + ";" + generateSpaces(8) + ";";
				reportFile.write(reportData);
				reportFile.newLine();
			}
		}
		return optionList;
	}
	private static void print03(BufferedWriter reportFile, Connection connection, String plantId,
			String ecmCode,List<String> optionList)
			throws SQLException, IOException {
 
		// Get the current system date and time
		LocalDateTime now = LocalDateTime.now();

		// Define the desired format
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");

		// Format the date and print it
		String formattedDate = now.format(formatter);
		// Use a PreparedStatement to retrieve data from the database
		for(String option:optionList) {
		String query = " SELECT DISTINCT  "
				+ "                     '03'||';'||?||';'||?||';'|| "
				+ "                     rpad('SO1234500', 11, ' ')||';'|| "
				+ "                     to_char(sysdate, 'yyyymmdd')||';'|| "
				+ "                     rpad(?, 11, ' ')||';'|| "
				+ "                     rpad(A1.OPS_ITEM_PART_NUMBER, 11, ' ')||';'|| "
				+ "                     rpad(A1.OPS_NOUN_NAME, 25, ' ')||';'|| "
				+ "                     rpad(' ', 76, ' ')||';'|| "
				+ "                     rpad(' ', 8, ' ')||';'|| "
				+ "                     rpad(' ', 8, ' ')||';'|| "
				+ "                     rpad(' ', 8, ' ')||';'|| "
				+ "                     rpad(' ', 8, ' ')||';'|| "
				+ "                     rpad(' ', 8, ' ')||';' "
				+ "                     FROM T_OPTION_STRUCTURE A, T_OPTION_STRUCTURE A1, T_PRODUCT_OPTION_STRUCTURE_MAP "
				+ "                     WHERE ( "
				+ "                     (A.OPS_OPTION_NUMBER = ?"
				+ "                     AND TO_CHAR(A.OPS_STOP_DATE, 'YYYYMMDD') > ? "
				+ "                     AND TO_CHAR(A1.OPS_STOP_DATE, 'YYYYMMDD') > ? "
				+ "                     AND TO_CHAR(A.OPS_START_DATE, 'YYYYMMDD') <= ? "
				+ "                     AND TO_CHAR(A1.OPS_START_DATE, 'YYYYMMDD') <= ? "
				+ "                     AND A1.OPS_OPTION_NUMBER = A.OPS_OPTION_NUMBER "
				+ "                     AND A1.OPS_ITEM_PART_NUMBER = A.OPS_ITEM_PART_NUMBER) "
				+ "                     OR  "
				+ "                     (A.OPS_OPTION_NUMBER = ?  "
				+ "                     AND TO_CHAR(A.OPS_STOP_DATE, 'YYYYMMDD') > ?  "
				+ "                     AND TO_CHAR(A1.OPS_STOP_DATE, 'YYYYMMDD') > ? "
				+ "                     AND TO_CHAR(A.OPS_START_DATE, 'YYYYMMDD') <= ?  "
				+ "                     AND TO_CHAR(A1.OPS_START_DATE, 'YYYYMMDD') <= ?  "
				+ "                     AND A1.OPS_OPTION_NUMBER = A.OPS_ITEM_PART_NUMBER))  "
				+ "                     AND POS_PRODUCT_ID = ?  "
				+ "                     AND A1.OPS_SUBFILE_CODE = POS_SUBFILE_CODE  "
				+ "                     AND A1.OPS_SUBFILE_SUBCODE = POS_SUBFILE_SUBCODE "
				+ "                     AND A1.OPS_FILE_TYPE != 'X' ";
		try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1, plantId);
            preparedStatement.setString(2, pid);
            preparedStatement.setString(3, option);
            preparedStatement.setString(4, option);
            preparedStatement.setString(5, ecmerdate);
            preparedStatement.setString(6, ecmerdate);
            preparedStatement.setString(7, ecmerdate);
            preparedStatement.setString(8, ecmerdate);
            preparedStatement.setString(9, option);
            preparedStatement.setString(10, ecmerdate);
            preparedStatement.setString(11, ecmerdate);
            preparedStatement.setString(12, ecmerdate);
            preparedStatement.setString(13, ecmerdate);
            preparedStatement.setString(14, pid );

			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				// Process and format the data
System.out.println(resultSet.getString(1));
				String reportData = resultSet.getString(1);
				reportFile.write(reportData);
				reportFile.newLine();
			}
		}
		}
		
	}
	private static void print91(BufferedWriter reportFile, Connection connection, String plantId,
			String ecmCode) throws IOException {
	    try {
	        String query = "SELECT '91'||';'||?||';'||"
	                + "rpad(?, 3, ' ')||';'||"
	                + "rpad('SO1234500', 11, ' ')||';'||"
	                + "to_char(sysdate, 'yyyymmdd')||';'||"
	                + "rpad('1234', 4, ' ')||';'||"
	                + "rpad('12345678', 8, ' ')||';'||"
	                + "rpad(' ', 10, ' ')||';'||"
	                + "rpad(' ', 101, ' ')||';'||"
	                + "rpad(' ', 8, ' ')||';'||"
	                + "rpad(' ', 8, ' ')||';'||"
	                + "rpad(' ', 8, ' ')||';'||"
	                + "rpad(' ', 8, ' ')||';'||"
	                + "rpad(' ', 8, ' ')||';'"
	                + " FROM DUAL";

	        // Create a prepared statement
	        PreparedStatement preparedStatement = connection.prepareStatement(query);

	        // Set parameters for the query
	        preparedStatement.setString(1, plantId);
	        preparedStatement.setString(2, pid);

	        // Execute the query and process the result
	        ResultSet resultSet = preparedStatement.executeQuery();
	        if (resultSet.next()) {
	            String gvcstr = resultSet.getString(1);
	            System.out.println("String length of 91: " + gvcstr.length());
	            System.out.println(gvcstr);

	            // Write to your reportfile (replace 'reportfile' with the appropriate FileWriter or other output stream)
	            reportFile.write(gvcstr);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	public static String generateSpaces(int count) {
		StringBuilder spaces = new StringBuilder();
		for (int i = 0; i < count; i++) {
			spaces.append(" ");
		}
		return spaces.toString();
	}
}
