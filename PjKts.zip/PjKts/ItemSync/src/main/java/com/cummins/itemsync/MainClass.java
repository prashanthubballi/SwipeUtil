package com.cummins.itemsync;

import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.cummins.itemsync.util.ItemSyncUtil;

@SpringBootApplication
@ComponentScan(basePackageClasses = com.cummins.itemsync.MainClass.class)
public class MainClass implements CommandLineRunner{

	@Autowired
	ItemSyncUtil util;

	static ApplicationContext context;
	private static final Logger logger = LogManager.getLogger(com.cummins.itemsync.MainClass.class);

	
	
	static {
		if(new File("./application-override.yml").exists()) {
			System.setProperty("spring.config.location", "./application-override.yml");
		}
	}

	public static void main(String[] args) {
		System.out.println("initilizing spring....");
		logger.info("Started...");
		context = (ApplicationContext)SpringApplication.run(com.cummins.itemsync.MainClass.class, args);

		SpringApplication.exit(context, new org.springframework.boot.ExitCodeGenerator[0]);

	}

	public void run(String... args)  {
		logger.info("Run Method Called");
		try {
		util.startProcess();
		}catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		System.out.println("Completed...");
	}	
}
