package com.cummins.itemsync.common;

import java.util.Calendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import lombok.Data;

@Data
public class AuthToken {
	private static final Logger logger = LogManager.getLogger(AuthToken.class);

	private AuthToken() {

	}
	static String authCode=null;
	static long createTime;


	public static String getToken(String client_id, String client_secret, String grant_type, String scope, String apiURL) {
		long currentTime=Calendar.getInstance().getTimeInMillis();
		if(null==authCode || currentTime>=createTime) {
			logger.info("Creating new token");
			try {
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

				MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();

				map.add("client_id",client_id);
				map.add("client_secret",client_secret);
				map.add("grant_type",grant_type);
				map.add("scope",scope);
				HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, headers);

				ResponseEntity<String> resp=new RestTemplate().postForEntity(apiURL, request, String.class);

				//System.out.println(resp.getBody());
				JSONObject jsonBody=new JSONObject(resp.getBody());
				authCode=jsonBody.getString("access_token");
				Calendar calDate=Calendar.getInstance();
				calDate.add(Calendar.MINUTE, 50);
				createTime=calDate.getTimeInMillis();
			}catch (Exception e) {
				logger.error(e.getMessage());

			}
		}
		return authCode;
	}




}
