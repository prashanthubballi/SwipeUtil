package com.cummins.itemsync.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CommonResponseHeader implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2323340964009768888L;

	@JsonProperty("success")
	private boolean success;

	@JsonProperty("code")
	private Integer code;

	@JsonProperty("message")
	private String message;

	public CommonResponseHeader(boolean success, Integer code, String message) {
		super();
		this.success = success;
		this.code = code;
		this.message = message;
	}

	public CommonResponseHeader() {

	}

	@Override
	public String toString() {
		return "CommonResponseHeader{" + "success=" + success + ", code=" + code + ", message='" + message + '\'' + '}';
	}
}