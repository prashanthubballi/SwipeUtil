package com.cummins.itemsync.common;

import java.io.File;

import org.springframework.core.io.FileSystemResource;

public class ModifiedFileSystemResource extends FileSystemResource {
	private String modifiedFilename;

	public ModifiedFileSystemResource(File file, String modifiedFilename) {
		super(file);
		this.modifiedFilename = modifiedFilename;
	}

	@Override
	public String getFilename() {
		return modifiedFilename;
	}

}
