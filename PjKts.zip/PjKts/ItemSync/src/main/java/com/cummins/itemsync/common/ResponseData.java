package com.cummins.itemsync.common;

import lombok.Data;

@Data
public class ResponseData {
	Integer response;
	String message;
}
