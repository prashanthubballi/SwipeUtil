package com.cummins.itemsync.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.cummins.itemsync.common.AuthToken;
import com.cummins.itemsync.common.FileUploadResponse;
import com.cummins.itemsync.common.ModifiedFileSystemResource;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
//@Component
public class ItemSyncUtil {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	PoolingHttpClientConnectionManager poolingHttpClientConnectionManager;



	@Value("${sharedloc}")
	String sharedloc;

	@Value("sharedlocoutbox")
	String sharedlocoutbox;

	@Value("${threadcount}")
	int threadcount;

	@Value("${uploadAPI}")
	String uploadAPI;

	@Value("${cdm.api}")
	private String apiURL;

	@Value("${cdm.client_id}")
	private String client_id;
	@Value("${cdm.client_secret}")
	private String client_secret;
	@Value("${cdm.grant_type}")
	private String grant_type;
	@Value("${cdm.scope}")
	private String scope;

	private static String resultFileName = "ItemSync_Result_" + (new SimpleDateFormat("MMM_dd_yyyy_hh_mm_sss")).format(new Date()) + ".csv";
	static {
		try {
			Files.createDirectories(new File("./resultFiles/").toPath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static final Logger logger = LogManager.getLogger(ItemSyncUtil.class);

	public void startProcess() throws IOException, InterruptedException, ExecutionException {
		List<String> allDirsList=new LinkedList<String>();
		logger.info("*************STARTED*****************");
		logger.info(poolingHttpClientConnectionManager.getTotalStats());

		logger.info("File Location:"+sharedloc);
		//add location access validation
		if(new File(sharedloc).exists() && new File(sharedloc).canWrite()) {
			logger.info("Reading Dir:");
			Path directory = Paths.get(sharedloc);
			Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
				@Override   public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
					allDirsList.add(file.toString());
					return FileVisitResult.CONTINUE;
				}
				@Override   public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
					return FileVisitResult.CONTINUE;
				}
			});
			logger.info("identified files to upload:"+allDirsList.size());
			if(!allDirsList.isEmpty()) {
				CustomLogger.result("FileDetail,EngUpload Status,Error details", resultFileName);
				String token=AuthToken.getToken(client_id, client_secret, grant_type, scope, apiURL);

				ExecutorService pool = Executors.newFixedThreadPool(threadcount);
				List<String> fileNameList=new ArrayList<String>();
				List<String> duplicateNameDirPath=new ArrayList<String>();
				List<Callable<String>> tasks = new ArrayList<>();
				for (String dirPath : allDirsList) {
					File file=new File(dirPath);
					String fileName=file.getName();
					if(!fileNameList.contains(fileName)) {
						fileNameList.add(fileName);
						tasks.add(() -> invokeUploadAPI(dirPath,token));
					}else {
						duplicateNameDirPath.add(dirPath);
					}
				}
				List<Future<String>> results = pool.invokeAll(tasks);
				for (Future<String> future : results) {
					CustomLogger.result(future.get(), resultFileName);
				}
				if(!duplicateNameDirPath.isEmpty()) {
					for (String dirPath : duplicateNameDirPath) {
						CustomLogger.result(invokeUploadAPI(dirPath,token), resultFileName);
					}
				}
				logger.info("*************Completed*****************");
				pool.shutdown();
			}
		}else {

			logger.info("unable to read write file directory:"+sharedloc);
			logger.info("*************Completed*****************");
		}
	}

	private String invokeUploadAPI(String filePath,String token) {
		try {
			//	PID/T.PARTNUM.CRNUM.filename.ext
			String splitPaths[]=filePath.split("\\\\");

			String productId=splitPaths[splitPaths.length - 2];
			String fileName=new File(filePath).getName();
			logger.info(productId);
			//String token=AuthToken.getToken(client_id, client_secret, grant_type, scope, apiURL);
			//System.out.println(token);
			String fileNameSplit[]=fileName.split("\\.");
			//check length here

			if(fileNameSplit.length==5) {
				String fileType = fileNameSplit[0];
				String partNumber = fileNameSplit[1];
				String cnNumber=fileNameSplit[2];
				StringBuilder sbFName=new StringBuilder( fileNameSplit[3]+"."+fileNameSplit[4]);
				sbFName.setLength(32);
				fileName=sbFName.toString();
				String extension = fileNameSplit[4];
				return uploadFileToS33(fileName,token, partNumber, productId, cnNumber, fileType, filePath, extension);
			}else {
				String fileType = fileNameSplit[0];
				String partNumber = fileNameSplit[1];
				String cnNumber=fileNameSplit[2];
				StringBuilder sbFName=new StringBuilder( fileName.split(cnNumber+".")[1]);
				sbFName.setLength(32);
				fileName=sbFName.toString();
				String extension = fileNameSplit[fileNameSplit.length-1];
				return uploadFileToS33(fileName,token, partNumber, productId, cnNumber, fileType, filePath, extension);
				//return productId+"//"+fileName+",Failure,File is not in correct format(PID/T.PARTNUM.CRNUM.filename.ext)";
			}
		}catch (Exception e) {
			e.printStackTrace();
			return filePath+",Failure,Could not read file path";
		}
	}

	public String uploadFileToS33(String fileName,String auth, String partNumber, String productId, String cnNumber,
			String fileType, String filePath, String extension)  {
		File file = new File(filePath);
		String desiredFileName = null;
		List<String> domProducts = new ArrayList<>();
		domProducts.add("DOV");
		domProducts.add("DOH");
		domProducts.add("DOX");
		// MultipartFile filetoupload = null;
		if (domProducts.contains(productId)) {
			desiredFileName = partNumber + "." + extension;
		} else {
			desiredFileName = file.getName();
		}


		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", auth);
		headers.set("partNumber", partNumber);
		headers.set("productId", productId);
		headers.set("cnNumber", cnNumber);
		headers.set("fileType", fileType);
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		headers.setContentDispositionFormData("file", desiredFileName);

		ModifiedFileSystemResource fileResource = new ModifiedFileSystemResource(file, desiredFileName);

		// Set up the request entity with headers and the file
		MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("file", fileResource);
		HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
		//logger.info("calling file upload API : " + requestEntity );

		// Make the request
		FileUploadResponse response = null;
		try {
			ResponseEntity<FileUploadResponse> responseEntity = restTemplate.exchange(uploadAPI, HttpMethod.POST,
					requestEntity, FileUploadResponse.class);
			response = responseEntity.getBody();
			logger.info("productId:"+productId+", FileName:"+filePath+", Response " + response);
			if (response.getHeader().getCode() == 200) {
				Files.createDirectories(new File(sharedlocoutbox).toPath());
				Files.copy(file.toPath(), new File(sharedlocoutbox+"/"+file.getName()).toPath(), StandardCopyOption.REPLACE_EXISTING);
				if(file.delete()) {
					return filePath+",Success,";
				}else {
					return filePath+",Failure, File loaded successfully but unable to delete.";
				}
			} else {
				return filePath+",Failure,"+response;
			}
		} catch (Exception e) {
			logger.error("productId:"+productId+", FileName:"+filePath+", Response: " + e.getMessage());
			e.getMessage();
			return fileName+",Failure,"+e.getMessage();
		}
	}
}
