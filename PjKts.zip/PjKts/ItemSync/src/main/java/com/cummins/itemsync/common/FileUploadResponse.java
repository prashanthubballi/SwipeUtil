package com.cummins.itemsync.common;

import lombok.Data;
@Data
public class FileUploadResponse {
	CommonResponseHeader header;
	ResponseData data;
}
