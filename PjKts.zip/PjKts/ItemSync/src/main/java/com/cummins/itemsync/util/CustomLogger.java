package com.cummins.itemsync.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;



public class CustomLogger
{
	//private static String fileName = "SystemValidation.log";
	//private static final Logger logger = LoggerFactory.getLogger(com.cummins.validation.util.CustomLogger.class);

	public static void result(String logText, String resultFileName) {
		
		try  (FileWriter fw = new FileWriter(new File("./resultFiles/"+resultFileName), true);
				BufferedWriter bw = new BufferedWriter(fw); 
				PrintWriter out = new PrintWriter(bw);){

			out.println(logText);
		} catch (IOException e)
		{ e.printStackTrace(); }

	}
}


