package com.cummins.itemsync;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.cummins.itemsync.util.ItemSyncUtil;

@Component
public class AppConfig {
	
	@Value("${threadcount}")
	int threadcount;
	
	@Bean 
	public ItemSyncUtil getutil() { 
		return new ItemSyncUtil(); 
	}

	@Bean(name = "connPool")
	public PoolingHttpClientConnectionManager getPool() {
		return new PoolingHttpClientConnectionManager();
	}
	
	@Bean
	@DependsOn("connPool")
	public RestTemplate pooledRestTemplate(@Autowired PoolingHttpClientConnectionManager connectionManager) {
	//	PoolingHttpClientConnectionManager connectionManager = 
	
		
			connectionManager.setMaxTotal(threadcount*5);
		connectionManager.setDefaultMaxPerRoute(threadcount);

		System.out.println(connectionManager.getTotalStats().toString());
		HttpClient httpClient = HttpClientBuilder.create()
				.setConnectionManager(connectionManager)
				.build();

		return new RestTemplateBuilder()
				//.rootUri("http://service-b-base-url:8080/")
				//.setConnectTimeout(Duration.ofMillis(1000))
				//.setReadTimeout(Duration.ofMillis(1000))
				//.messageConverters(new StringHttpMessageConverter(), new MappingJackson2HttpMessageConverter())
				.requestFactory(() -> new HttpComponentsClientHttpRequestFactory(httpClient))
				.build();
	}


}
