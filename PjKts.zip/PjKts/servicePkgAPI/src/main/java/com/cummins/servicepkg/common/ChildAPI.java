package com.cummins.servicepkg.common;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@JsonPropertyOrder({
    "success",
    "failure"
})
@Data
@Component
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class ChildAPI {

    @JsonProperty("success")
    private CountAndData success=new CountAndData();
    @JsonProperty("failure")
    private CountAndData failure=new CountAndData();
    

}