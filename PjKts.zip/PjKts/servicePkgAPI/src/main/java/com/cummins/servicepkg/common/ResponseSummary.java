package com.cummins.servicepkg.common;


import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Component
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class ResponseSummary {
	
    @JsonProperty("deletion")
    private ChildAPI deletion=new ChildAPI();
   
    @JsonProperty("addition")
    private ChildAPI addition=new ChildAPI();
   
    @JsonProperty("csarCsuDeletion")
    private ChildAPI csarCsuDeletion=new ChildAPI();
    
    @JsonProperty("csarCsuAddition")
    private ChildAPI csarCsuAddition=new ChildAPI();
  
}