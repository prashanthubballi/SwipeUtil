package com.cummins.servicepkg.meta.dto;

import java.util.ArrayList;
import java.util.List;

public class JsonDTO {

	private String productId;
	private List<ServiceAttributeDTO> calibrationMetadataList=new ArrayList<>();
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public List<ServiceAttributeDTO> getCalibrationMetadataList() {
		return calibrationMetadataList;
	}
	public void setCalibrationMetadataList(List<ServiceAttributeDTO> calibrationMetadataList) {
		this.calibrationMetadataList = calibrationMetadataList;
	}

	@Override
	public String toString() {
		return "{\n \"productId\": \"" + productId + "\",\n \"calibrationMetadataList\": " + calibrationMetadataList.toString() + " \n}";
	}
	
	public JsonDTO(String productId, List<ServiceAttributeDTO> calibrationMetadataList) {
		super();
		this.productId = productId;
		this.calibrationMetadataList = calibrationMetadataList;
	}
	
	public JsonDTO() {
		super();
	}
	
}
