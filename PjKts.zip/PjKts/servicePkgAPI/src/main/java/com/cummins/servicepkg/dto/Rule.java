package com.cummins.servicepkg.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Rule {

  @JsonProperty("field")
  private String field;
  @JsonProperty("operator")
  private String operator;

  @JsonProperty("value")
  private String value;
}
