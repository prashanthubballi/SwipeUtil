package com.cummins.servicepkg.service.child.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import com.cummins.servicepkg.child.dto.CsarCsuSupportFilesAdditionRequest;
import com.cummins.servicepkg.child.dto.EncryptionRequest;
import com.cummins.servicepkg.child.dto.ServicePkgCalAddByProductRequest;
import com.cummins.servicepkg.child.dto.ServicePkgCalibrationChildResponse;
import com.cummins.servicepkg.child.dto.SupportFilesPath;
import com.cummins.servicepkg.common.CommonResponse;
import com.cummins.servicepkg.common.CommonResponseHeader;
import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.common.CountAndData;
import com.cummins.servicepkg.common.ObjectData;
import com.cummins.servicepkg.dto.CommonParamStore;
import com.cummins.servicepkg.dto.CommonParamStore.Mode;
import com.cummins.servicepkg.dto.NamingConvention;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.dto.ServicePkgDto;
import com.cummins.servicepkg.dto.ServicePathData;
import com.cummins.servicepkg.exception.BadRequestException;
import com.cummins.servicepkg.meta.dto.CopyDTO;

import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;

@Service
public class ServicePackageChildAdditionImpl  {

	private static final Logger logger = LoggerFactory.getLogger(ServicePackageChildAdditionImpl.class);

	@Value("${mode}")
	private String mode;

	@Autowired
	private ParamStore paramStore;
	@Autowired
	private CommonParamStore commonParamStore;

	@Autowired
	private CalibrationCommonUtility commonUtility;

	private Retry retry=RetryRegistry.ofDefaults().retry("throwingException");

	private static String FOLDER_SEPERATOR = "\\";
	private static String FILE_EXENTION = ".";
	// private static String CALIBRATION = "CALIBRATIONS";

	private static String PCL = "PCL";
	private static String AFILE = "A_FILE";
	private static String MAF = "MAF";
	private static String EEL = "EEL";

	private static String SUCCESS="SUCCESS";
	private Mode currentMode =null;
	public CommonResponse<ServicePkgCalibrationChildResponse> executeServiceCalAddition(ServicePkgCalAddByProductRequest req) {
		//logger.info("Request:"+req);
		if (mode.equalsIgnoreCase("regular")) {
			currentMode = commonParamStore.getRegular();
		} else {
			currentMode = commonParamStore.getExportControl();
		}
		logger.info("Current mode : "+currentMode+","+mode);

		CommonResponse<ServicePkgCalibrationChildResponse> response = new CommonResponse<>();
		CommonResponseHeader responseHeader = new CommonResponseHeader();
		ServicePkgCalibrationChildResponse responseData = new ServicePkgCalibrationChildResponse();
		try {

			if("MAF".equalsIgnoreCase(req.getType()) || "BootSign".equalsIgnoreCase(req.getType())) {
				if(null!=req.getProducts() && !req.getProducts().isEmpty()) {
					List<ServicePkgDto> serviceDataList=req.getProducts();
					if("MAF".equalsIgnoreCase(req.getType())) {
						String finalEcmFilePath = null;
						try {
							//impl retry
							finalEcmFilePath=retry.executeCheckedSupplier(()->{ return commonUtility.zipECMFile(serviceDataList);});

						}catch ( Throwable e) {
							logger.error(e.getMessage());
						}
						ServicePkgDto productData =  serviceDataList.get(0);
						productData.setPartintpath(finalEcmFilePath);
						req.setProduct(productData);
						req.setProducts(null);
					}else {//boot sign
						ServicePkgDto productData =  serviceDataList.get(0);
						commonUtility.deleteJsonFile(productData.getProductid(), req.getCorrelationGuid());
						req.setProduct(productData);
						req.setProducts(null);
					}
				}
			}

			//main thread
			responseData=startProcess(req);

			responseHeader.setCode(HttpStatus.OK.value());
			responseHeader.setMessage("Success");
			responseHeader.setSuccess(true);
		}catch (BadRequestException e) {
			e.printStackTrace();
			commonUtility.handleExceptionResult(req, responseData, e.getMessage(),false);
			responseHeader.setCode(HttpStatus.BAD_REQUEST.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}catch (Exception e) {
			e.printStackTrace();
			commonUtility.handleExceptionResult(req, responseData, e.getMessage(),false);
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		} catch (Throwable e) {
			commonUtility.handleExceptionResult(req, responseData, e.getMessage(),false);
			e.printStackTrace();
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}

		responseData.setCorrelationGuid(req.getCorrelationGuid());
		response.setHeader(responseHeader);
		response.setData(responseData);

		return response;
	}
	
	
	
	private ServicePkgCalibrationChildResponse startProcess(ServicePkgCalAddByProductRequest request) {
		logger.info("Request:"+request);
		if (request != null && request.getProduct() != null) {
			deleteJsonFile(request);
//			if(request.getProduct().getProductid().equalsIgnoreCase("HPI")||request.getProduct().getProductid().equalsIgnoreCase("ENI")) {
//				return processForHPIandENI(request);
//			}
			return encryFile(request);
		}
		return new ServicePkgCalibrationChildResponse();
	}

	//commenting out HPI and ENI code
//	private ServicePkgCalibrationChildResponse processForHPIandENI(ServicePkgCalAddByProductRequest request)  {
//		String filePath = currentMode.getDrivePath() + "Naveen\\Workaround\\" + request.getProduct().getProductid()
//				+ "\\" + request.getProduct().getBaseecm().trim() + "." + request.getProduct().getProductid().toLowerCase();
//		File sourceFile = new File(filePath);
//		if(sourceFile.exists()) {
//			logger.info("File available in workaround folder for ProductId:{}",request.getProduct().getProductid());
//			return processSourceToDestination(filePath,request);
//		} else {
//			return encryFile(request);
//		}
//
//	}
//	private ServicePkgCalibrationChildResponse processSourceToDestination(String filePath, ServicePkgCalAddByProductRequest request) {
//		ServicePkgCalibrationChildResponse resp=new ServicePkgCalibrationChildResponse(request.getCorrelationGuid(), null, new CountAndData(), new CountAndData());
//		resp.setCorrelationGuid(request.getCorrelationGuid());
//		CountAndData success=new CountAndData();
//		CountAndData failure=new CountAndData();
//
//		try {
//			String serviceFilePath = getServiceFilePathforHPIandENI(request);
//			File calibrationFile = new File(filePath);
//			File serviceFile = new File(serviceFilePath);
//
//			FileUtils.copyFileToDirectory(calibrationFile, serviceFile); // .copyFile(calibrationFile, serviceFile);
//			String path = serviceFilePath+getFileName(request);
//			logger.info("File copied from source to destination ECM:{} ",request.getProduct().getBaseecm());
//			String url=currentMode.getHostName()+paramStore.getOutBoundSycUrl();
//			ResponseEntity<String> response=restTemplate.postForEntity(url, new CopyDTO(path.replace("G:\\", ""),false), String.class);
//			logger.info(response.getBody());
//			success.setCount(1);
//			success.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, SUCCESS));
//		} catch (Exception e) {
//			failure.setCount(1);
//			failure.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, e.getMessage()));
//		}
//		resp.setSuccess(success);
//		resp.setFailure(failure);
//		return resp;
//	}
//	private String getServiceFilePathforHPIandENI(ServicePkgCalAddByProductRequest request) throws BusinessException {
//		String returnString = getServiceFolderPath(request, null);
//		if (returnString.substring(returnString.length() - 1, returnString.length())
//				.equalsIgnoreCase(FOLDER_SEPERATOR)) {
//
//		} else {
//			returnString = returnString + FOLDER_SEPERATOR;
//		}
//		return returnString;
//	}
	private String getServiceFolderPath(ServicePkgCalAddByProductRequest request, String encryptionType) {
		ServicePathData servicePathData = null;
		if (request.getProduct().getCallgenpath().equalsIgnoreCase("Other")) {
			servicePathData = paramStore.getServicePathData().stream()
					.filter(n -> n.getCategory().equalsIgnoreCase(request.getProduct().getCallgenpath()))
					.filter(n -> n.getProduct().equalsIgnoreCase(request.getProduct().getProductid())).findAny()
					.orElse(null);
		} else if (request.getProduct().getCallgenpath().equalsIgnoreCase("DUAL")) {
			servicePathData = paramStore.getServicePathData().stream()
					.filter(n -> n.getCategory().equalsIgnoreCase(request.getProduct().getCallgenpath()))
					.filter(n -> n.getProduct().equalsIgnoreCase(encryptionType)).findAny().orElse(null);
		} else {
			servicePathData = paramStore.getServicePathData().stream()
					.filter(n -> n.getCategory().equalsIgnoreCase(request.getProduct().getCallgenpath())).findAny()
					.orElse(null);
		}

		return currentMode.getDrivePath()+servicePathData.getFolderPath().replace("PRODUCT_ID", request.getProduct().getProductid());

	}
	private String getFileName(ServicePkgCalAddByProductRequest request) {
		String returnString = "";

		System.out.println("CALIBRATION REQUEST:" + request);
		NamingConvention namingConvention = paramStore.getNamingConvention().stream()
				.filter(n -> n.getFileType().equalsIgnoreCase(request.getProduct().getCalgenname())).findAny()
				.orElse(null);

		if (namingConvention != null) {
			if (namingConvention.getNamingConvention().equalsIgnoreCase("ECMCode.ProductID")
					&& request.getProduct().getEncryptiontype().equalsIgnoreCase("N")) {
				returnString = request.getProduct().getEcmcode().trim();
			} else if (namingConvention.getNamingConvention().equalsIgnoreCase("ECMCode.ProductID")) {
				returnString = request.getProduct().getBaseecm().trim() + "." + request.getProduct().getProductid().toLowerCase();
			} else if (namingConvention.getNamingConvention().equalsIgnoreCase("PartList.ProductID")
					&& request.getProduct().getEncryptiontype().equalsIgnoreCase("N")) {
				returnString = request.getProduct().getAfile().trim();
			} else if (namingConvention.getNamingConvention().equalsIgnoreCase("PartList.ProductID")) {
				String aFile = request.getProduct().getAfile().trim();
				returnString = aFile.substring(0, aFile.length() - 3) + "." + request.getProduct().getProductid().toLowerCase();
			}
		}
		return returnString;
	}

	private ServicePkgCalibrationChildResponse encryFile(ServicePkgCalAddByProductRequest request) {
		ServicePkgCalibrationChildResponse resp=new ServicePkgCalibrationChildResponse(request.getCorrelationGuid(),"", "", new CountAndData(), new CountAndData());
		resp.setCorrelationGuid(request.getCorrelationGuid());
		CountAndData success=new CountAndData();
		CountAndData failure=new CountAndData();
		resp.setFailure(failure);
		resp.setSuccess(success);
		String calibrationFilePath = "";
		if (request.getProduct().getCalgenname().equalsIgnoreCase(AFILE)) {
			calibrationFilePath = request.getProduct().getPartintpath();
		} else if (request.getProduct().getCalgenname().equalsIgnoreCase(MAF)) {
			calibrationFilePath = request.getProduct().getPartintpath();
		}else if("BootSign".equalsIgnoreCase(request.getType())) {
			List<Integer> position =new ArrayList<>();

			for(int i =0;i<request.getProduct().getEcmcode().length();i++){
				if(request.getProduct().getEcmcode().charAt(i)=='.'){
					position.add(i);
				}
			}
			String requiredEcmCode=request.getProduct().getEcmcode().substring(0, position.get(position.size()-1)+1)+"*";
			calibrationFilePath = currentMode.getDrivePath() + paramStore.getEncryption().getCalibrationFolderName()
					+ FOLDER_SEPERATOR + request.getProduct().getProductid() + FOLDER_SEPERATOR
					+ requiredEcmCode;
		}
		else {
			if (request.getProduct().getProductcompliance().equalsIgnoreCase("CSAR")) {
				calibrationFilePath = currentMode.getDrivePath()
						+ paramStore.getEncryption().getCalibrationFolderName() + FOLDER_SEPERATOR
						+ request.getProduct().getProductid() + FOLDER_SEPERATOR
						+ request.getProduct().getEcmcode().trim() + FILE_EXENTION + "pdx";
			} else if (request.getProduct().getAfile() != null && request.getProduct().getPartintpath() != null
					&& !request.getProduct().getAfile().trim().isEmpty()
					&& !request.getProduct().getPartintpath().trim().isEmpty()) {
				calibrationFilePath = renameCalFile(request.getProduct().getPartintpath().trim(), request.getProduct().getEcmcode().trim(),
						request.getProduct().getProductid().trim());

			} else {
				calibrationFilePath = currentMode.getDrivePath()
						+ paramStore.getEncryption().getCalibrationFolderName() + FOLDER_SEPERATOR
						+ request.getProduct().getProductid() + FOLDER_SEPERATOR
						+ request.getProduct().getEcmcode().trim();
			}
		}
		logger.info("Calibration file Path:{}",calibrationFilePath);

		if (null!=calibrationFilePath && !calibrationFilePath.isEmpty()) {
			File calibrationFile = new File(calibrationFilePath);
			if (!"BootSign".equalsIgnoreCase(request.getType()) && !calibrationFile.exists()) {//skipping file check incase of bootsign
				logger.info("Calibration not available at file Path:{}",calibrationFilePath);
				logger.info("ECM_CODE : {} ",request.getProduct().getEcmcode());
				failure.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, "Calibration not available at file Path:"+calibrationFilePath));
				failure.setCount(1);
				resp.setFailure(failure);
				resp.setSuccess(success);
				return resp;
			}
			if (paramStore.getEncryption().getEncriptionType().contains(request.getProduct().getEncryptiontype())) {
				try {
					if (paramStore.getEncryption().getEncriptionType()
							.contains(request.getProduct().getEncryptiontype())
							&& "P".equalsIgnoreCase(request.getProduct().getEncryptiontype())) {
						return Encryption(request, calibrationFilePath,PCL);
					} else if (paramStore.getEncryption().getEncriptionType()
							.contains(request.getProduct().getEncryptiontype())
							&& "E".equalsIgnoreCase(request.getProduct().getEncryptiontype())) {
						return Encryption(request, calibrationFilePath,EEL);
					} else if (paramStore.getEncryption().getEncriptionType()
							.contains(request.getProduct().getEncryptiontype())
							&& "D".equalsIgnoreCase(request.getProduct().getEncryptiontype())) {
						ServicePkgCalibrationChildResponse encryptPCLResp=Encryption(request, calibrationFilePath,PCL);
						ServicePkgCalibrationChildResponse encryptEELResp=Encryption(request, calibrationFilePath,EEL);
						encryptPCLResp.getFailure().getData().addAll(encryptEELResp.getFailure().getData());
						encryptPCLResp.getSuccess().getData().addAll(encryptEELResp.getSuccess().getData());
						return encryptPCLResp;
					} else if (paramStore.getEncryption().getEncriptionType()
							.contains(request.getProduct().getEncryptiontype())
							&& "N".equalsIgnoreCase(request.getProduct().getEncryptiontype())) {
						return NoEncryption(request, calibrationFilePath);
					}
				} catch (Exception e) {
					logger.error("Error during encryption: {}", e.getMessage(), e);
					failure.setCount(1);
					failure.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, e.getMessage()));
					//success.setCount(1);
					//success.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, SUCCESS));
					resp.setFailure(failure);
					resp.setSuccess(success);
				}
			}
		}else {
			logger.info("Calibration is empty",calibrationFilePath);
			logger.info("ECM_CODE : {} ",request.getProduct().getEcmcode());
			failure.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, "Calibration not available at file Path:"+calibrationFilePath));
			failure.setCount(1);
			resp.setFailure(failure);
			resp.setSuccess(success);
			return resp;
		}
		return resp;
	}

	private ServicePkgCalibrationChildResponse Encryption(ServicePkgCalAddByProductRequest request,String calibrationfile,String type) throws IOException {
		ServicePkgCalibrationChildResponse resp=new ServicePkgCalibrationChildResponse(request.getCorrelationGuid(),null, null, new CountAndData(), new CountAndData());
		resp.setCorrelationGuid(request.getCorrelationGuid());
		CountAndData success=new CountAndData();
		CountAndData failure=new CountAndData();

		EncryptionRequest encriptionRequest = GenerateEncryptionRequest(request, calibrationfile, type);
		if(EEL.equalsIgnoreCase(type)) {
			encriptionRequest.setExecutableFilePath(paramStore.getEncryption().getEelEncryptor());
		}else {
			encriptionRequest.setExecutableFilePath(paramStore.getEncryption().getPclEncryptor());
		}
		logger.info("Encryption request: " + encriptionRequest);
		try {
			String url=currentMode.getHostName()+paramStore.getEncryptionApi();
			String encryptionResp=commonUtility.callChildAPI(encriptionRequest, request.getCorrelationGuid(), url, "PCLEncyrption");

			//			EncryptionMainResponse mainResp = restTemplate.postForObject(
			//					currentMode.getEncryptionApi(), encriptionRequest, EncryptionMainResponse.class);
			logger.info("Response from Encryptor : {}", encryptionResp);
			if (!encryptionResp.startsWith("ERROR")) {
				url=currentMode.getHostName()+paramStore.getOutBoundSycUrl();
				commonUtility.callChildAPI(new CopyDTO(encriptionRequest.getServiceFilePath().replace("G:\\", ""),false), request.getCorrelationGuid(), url, "SyncCopy");
				//for csar csu sn-3935
				if (request.getProduct().getProductcompliance().equalsIgnoreCase("CSAR")) {
					String csarOutPutPath = commonParamStore.getRegular().getDrivePath() + 
							paramStore.getCsarCsuCalFilesFolderPath().replace(Constants.PRODUCT_ID, request.getProduct().getProductid() +
									FOLDER_SEPERATOR + getFileName(request));
					File inputFile = new File(encriptionRequest.getServiceFilePath());
					File outputFile = new File(csarOutPutPath);
					
					FileCopyUtils.copy(inputFile, outputFile);
					commonUtility.callChildAPI(new CopyDTO(csarOutPutPath.replace("G:\\", ""),false), request.getCorrelationGuid(), url, "SyncCopy");
				}
				//sn-3935 ends here
				//failure.setCount(1);
				//failure.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, "Calibration not available at file Path:"+calibrationFilePath));
				success.setCount(1);
				success.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, SUCCESS));
				resp.setFailure(failure);
				resp.setSuccess(success);
				return resp;
			} else {
				failure.setCount(1);
				failure.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, encryptionResp));
				//success.setCount(1);
				//success.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, SUCCESS));
				resp.setFailure(failure);
				resp.setSuccess(success);
				return resp;
			}
		} catch (Exception e) {
			logger.info(" Error Response from Encryptor : {}", e);
			failure.setCount(1);
			failure.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, e.getMessage()));
			//success.setCount(1);
			//success.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, SUCCESS));
			resp.setFailure(failure);
			resp.setSuccess(success);
			return resp;
		}
	}
	private ServicePkgCalibrationChildResponse NoEncryption(ServicePkgCalAddByProductRequest request,String calibrationFilePath) {
		ServicePkgCalibrationChildResponse resp=new ServicePkgCalibrationChildResponse(request.getCorrelationGuid(),null, null, new CountAndData(), new CountAndData());
		resp.setCorrelationGuid(request.getCorrelationGuid());
		CountAndData success=new CountAndData();
		CountAndData failure=new CountAndData();

		try {
			String serviceFilePath = getServiceFilePath(request, null);
			File calibrationFile = new File(calibrationFilePath);
			File serviceFile = new File(serviceFilePath);

			FileCopyUtils.copy(calibrationFile, serviceFile);
			String url=currentMode.getHostName()+paramStore.getOutBoundSycUrl();
			commonUtility.callChildAPI(new CopyDTO(serviceFilePath.replace("G:\\", ""),false), request.getCorrelationGuid(), url, "SyncCopy");
			
			//for csar csu sn-3935
			if (request.getProduct().getProductcompliance().equalsIgnoreCase("CSAR")) {
				String csarOutPutPath = commonParamStore.getRegular().getDrivePath() + 
						paramStore.getCsarCsuCalFilesFolderPath().replace(Constants.PRODUCT_ID, request.getProduct().getProductid() +
								FOLDER_SEPERATOR + getFileName(request));
				File inputFile = new File(serviceFilePath);
				File outputFile = new File(csarOutPutPath);
				
				FileCopyUtils.copy(inputFile, outputFile);
				commonUtility.callChildAPI(new CopyDTO(csarOutPutPath.replace("G:\\", ""),false), request.getCorrelationGuid(), url, "SyncCopy");
				
			}
			success.setCount(1);
			success.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, SUCCESS+":"+calibrationFilePath));
			resp.setFailure(failure);
			resp.setSuccess(success);
		} catch (Exception e) {
			failure.setCount(1);
			failure.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, e.getMessage()));
			//success.setCount(1);
			//success.getData().add(new ObjectData(request.getProduct().getProductid(), request.getProduct().getEcmcode(), null, SUCCESS));
			resp.setFailure(failure);
			resp.setSuccess(success);
		}

		return resp;
	}
	private EncryptionRequest GenerateEncryptionRequest(ServicePkgCalAddByProductRequest request,String calibrationfile, String encryptionType) throws IOException  {
		String logFolderPath = currentMode.getDrivePath()+paramStore.getEncryption().getLogFilePath().replaceAll("ProductID",
				request.getProduct().getProductid());
		logger.info("{} Encryption Log Folder Path : {}", encryptionType, logFolderPath);
		File logFolder = new File(logFolderPath);
		if (!logFolder.exists()) {
			logFolder.mkdirs();
		}

		String tempLogFilePath = logFolderPath + request.getProduct().getProductid() + "_"
				+ request.getProduct().getBaseecm().trim() + "_" + request.getCorrelationGuid() + ".log";
		logger.info("{} Encryption Log File Path : {}", encryptionType, tempLogFilePath);
		Path logPath = Paths.get(tempLogFilePath);
		if (!logPath.toFile().exists()) {
			Files.createFile(logPath);
		}

		logger.info("Executable File Path : {}", paramStore.getEncryption().getExecutableFilePath());
		logger.info("Calibration File Path : {}", calibrationfile);
		logger.info("Log File Path : {}", tempLogFilePath);
		return new EncryptionRequest(paramStore.getEncryption().getExecutableFilePath(), calibrationfile,
				getServiceFilePath(request, encryptionType), tempLogFilePath, encryptionType);
	}
	
	public CommonResponse<ServicePkgCalibrationChildResponse> csarCsuAddition(CsarCsuSupportFilesAdditionRequest req) {
		CommonResponse<ServicePkgCalibrationChildResponse> response = new CommonResponse<>();
		CommonResponseHeader responseHeader = new CommonResponseHeader();
		ServicePkgCalibrationChildResponse responseData = new ServicePkgCalibrationChildResponse();
		try {

			responseData=callMultiThreadForCsarCsuFilesAddition(req);

			responseHeader.setCode(HttpStatus.OK.value());
			responseHeader.setMessage("Success");
			responseHeader.setSuccess(true);
		}catch (BadRequestException e) {
			commonUtility.handleExceptionResult(null, responseData, e.getMessage(),true);
			responseHeader.setCode(HttpStatus.BAD_REQUEST.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}catch (Exception e) {
			commonUtility.handleExceptionResult(null, responseData, e.getMessage(),true);
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		} catch (Throwable e) {
			commonUtility.handleExceptionResult(null, responseData, e.getMessage(),true);
			e.printStackTrace();
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}

		responseData.setCorrelationGuid(req.getCorrelationGuid());
		response.setHeader(responseHeader);
		response.setData(responseData);

		return response;	
	}
	private ServicePkgCalibrationChildResponse callMultiThreadForCsarCsuFilesAddition(CsarCsuSupportFilesAdditionRequest req) {
		ServicePkgCalibrationChildResponse responseData = new ServicePkgCalibrationChildResponse();
		CountAndData success=new CountAndData();
		CountAndData failure=new CountAndData();
		success.setData(new LinkedList<ObjectData>());
		failure.setData(new LinkedList<ObjectData>());
		responseData.setSuccess(success);
		responseData.setFailure(failure);
		ExecutorService pool = Executors.newFixedThreadPool(paramStore.getThreadLimit());
		List<Callable<Map<String, ObjectData>>> tasks = new ArrayList<>();
	
		List<SupportFilesPath> supportFilesPath = req.getData().stream()
				.flatMap(i -> i.getSupportFiles().stream()
						.map(j -> {
							SupportFilesPath child1 = new SupportFilesPath();
							SupportFilesPath child2 = new SupportFilesPath();
							SupportFilesPath child3 = new SupportFilesPath();
							SupportFilesPath child4 = new SupportFilesPath();
							child1.setProductId(i.getProductId());
							child1.setDestinationPath(getfileName(j.getA2l(), "A2L", i.getProductId()));
							child1.setSourcePath(getSourcePath(j.getA2l(), i.getProductId()));
							child2.setProductId(i.getProductId());
							child2.setDestinationPath(getfileName(j.getPcfg(), "PCFG", i.getProductId()));
							child2.setSourcePath(getSourcePath(j.getPcfg(), i.getProductId()));
							child3.setProductId(i.getProductId());
							child3.setDestinationPath(getfileName(j.getA2lCbf(), "A2L-CBF", i.getProductId()));
							child3.setSourcePath(getSourcePath(j.getA2lCbf(), i.getProductId()));
							child4.setProductId(i.getProductId());
							child4.setDestinationPath(getfileName(j.getPcfgCbf(), "PCFG-CBF", i.getProductId()));
							child4.setSourcePath(getSourcePath(j.getPcfgCbf(), i.getProductId()));
							return Stream.of(child1, child2, child3, child4);
						}))
				.flatMap(Function.identity()).distinct()
			    .collect(Collectors.toList());
		// here also need to modify
		
		for(SupportFilesPath child : supportFilesPath) {
			tasks.add((Callable<Map<String, ObjectData>>) () -> invokeAddForCsarCsu(child, req.getCorrelationGuid()));
		}
		
		if(!tasks.isEmpty()) {
			try {
				List<Future<Map<String, ObjectData>>> invokeResults=pool.invokeAll(tasks);
				for (Future<Map<String, ObjectData>> future : invokeResults) {
					logger.info("Processing results");
					Map<String, ObjectData> response=future.get();
					if(null!=response.get(Constants.SUCCESS)) {
						success.getData().add(response.get(Constants.SUCCESS));
					}
					if(null!=response.get(Constants.FAILURE)) {
						failure.getData().add(response.get(Constants.FAILURE));
					}
				}
				success.setCount(success.getData().size());
				failure.setCount(failure.getData().size());
				responseData.setSuccess(success);
				responseData.setFailure(failure);
				logger.info("Results fetched");
			} catch (InterruptedException | ExecutionException e) {
				logger.info("CSAR Add Error:"+e.getMessage());
				e.printStackTrace();
			}
		}else {
			logger.error("CSAR Add is empty list");
			success.setCount(0);
			failure.setCount(0);
			responseData.setSuccess(success);
			responseData.setFailure(failure);
		}
		pool.shutdown();
		logger.info("CSAR AddL completed:"+pool.isShutdown());
		return responseData;
	}
	
	private Map<String, ObjectData> invokeAddForCsarCsu(SupportFilesPath child, String guid) throws Exception {
		logger.info("inside invokeAddForCsarCsu method");
		Map<String, ObjectData> map=new HashMap<>();
		
		String productId = child.getProductId();
		String sourcePath = child.getSourcePath();
		String destinationPath = child.getDestinationPath();

		try {
			//impl retry
			logger.info("inside the tryCatch on invokeAddForCsarCsu");
			retry.executeCheckedSupplier(()->{ return commonUtility.addSupportFilesCsarCsu(sourcePath, destinationPath, productId, guid);});
			map.put(Constants.SUCCESS,new ObjectData(null, null,null,Constants.SUCCESS+":"+destinationPath));
		}catch ( Throwable e) {
			map.put(Constants.FAILURE,new ObjectData(null, null,null,Constants.ERROR+":"+e.getMessage()));
		}
		return map;
	}
	private String getfileName(String fileName, String fileType, String productID) {
		String extenstion = "";
		if (fileType.equalsIgnoreCase("A2L")) {
			extenstion = ".A2L";
		} else if (fileType.equalsIgnoreCase("PCFG")) {
			extenstion = ".ODX-D";
		} else {
			extenstion = ".CBF";
		}
		return commonParamStore.getRegular().getDrivePath() 
			+ paramStore.getCsarCsuSupportFilesFolderPath().replace(Constants.PRODUCT_ID, productID)
			+ Constants.Folder_Seperator 
			+ fileName.trim() + extenstion;
	}
	
	private String getSourcePath (String fileName, String productID){
		return commonParamStore.getRegular().getDrivePath() 
				+ paramStore.getItemFilePath().replace(Constants.PRODUCT_ID, productID)
				+ Constants.Folder_Seperator + fileName;
	}
	private String getServiceFilePath(ServicePkgCalAddByProductRequest request, String encryptionType) throws IOException {
		String returnString = getServiceFolderPath(request, encryptionType);
		if (!returnString.substring(returnString.length() - 1, returnString.length())
				.equalsIgnoreCase(FOLDER_SEPERATOR)) {
			returnString = returnString + FOLDER_SEPERATOR;
		}
		try {
		Files.createDirectories(Paths.get(returnString));
		}catch (Exception e) {
			logger.error("Exception in creating dir:"+e.getMessage());
		}
		returnString = returnString + getFileName(request);
		logger.info("Service File Path : {}", returnString);
		return returnString;
	}
	private String renameCalFile(String source, String renameTo, String pid) {
		String renamedFilePath = currentMode.getDrivePath() + "PROCESSING\\Service\\" + pid + "\\" + renameTo;
		File sourceFile = new File(source);
		File finalFile = new File(renamedFilePath);
		if(new File(source).exists())
		{
			try {
				FileUtils.copyFile(sourceFile, finalFile);
				return renamedFilePath;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		}
		return null;
	}

	private void deleteJsonFile(ServicePkgCalAddByProductRequest request)  {
		String deletePath = currentMode.getDrivePath() + FOLDER_SEPERATOR + "Service_Metadata" + FOLDER_SEPERATOR
				+ request.getProduct().getProductid();
		File deleteFile = new File(deletePath + "_ServiceMetadata.json");
		if (deleteFile.exists()) {
			logger.info("Delete Meta deta Json File : {}", deletePath);
			try {
				FileUtils.delete(new File(deletePath + "_ServiceMetadata.json"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}