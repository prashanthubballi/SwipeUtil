package com.cummins.servicepkg.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cummins.servicepkg.dto.BRERuleSetDetails;
import com.cummins.servicepkg.dto.ServicePkgDto;
import com.cummins.servicepkg.dto.TcalServiceDto;



@Service
@SuppressWarnings("unchecked")
public class ServiceRepoUtil {
	private static final Logger logger = LoggerFactory.getLogger(ServiceRepoUtil.class);

	@PersistenceContext
	private EntityManager em;

	@Transactional
	public List<ServicePkgDto> getDailyDeleteData(BRERuleSetDetails breRuleSetDetails) {
		String serviceDistributionCondition=breRuleSetDetails.getServiceDistributionRule();
		String powerMatchRule=breRuleSetDetails.getPowerMatchDistributionRule();
		String query="select TSL_PRODUCT_ID as productId, TSL_ECM_CODE as ecmCode, TSL_BASE_ECM as baseECM, TSL_PHASE_CODE as phaseCode, "
				+ " TSL_EFFECT_CODE as effectCode, TSL_ITEM_TYPE as itemType,TSL_CAL_GEN_PATH as callGenPath, TSL_CAL_GEN_NAME as calGenName, "
				+ " TSL_A_FILE_PART  as aFile,  TSL_PART_INT_PATH as partIntPath, TSL_PART_EXT_PATH as partExtPath, TSL_ENCRYPTION_TYPE as encryptionType, "
				+ " TSL_PRODUCT_COMPLIANCE as productCompliance, TSL_BOOT_FLAG as bootFlag from T_SERVICE_LASTRUN " + " MINUS "
				+ " ( SELECT PRODUCT_ID as productId, ECM_CODE as ecmCode, BASE_ECM as baseECM, PHASE_CODE as phaseCode, "
				+ " EFFECT_CODE as effectCode, ITEM_TYPE as itemType,CAL_GEN_PATH as callGenPath, CAL_GEN_NAME as calGenName, "
				+ " A_FILE_PART  as aFile,  PART_INT_PATH as partIntPath, PART_EXT_PATH as partExtPath, "
				+ " ENCRYPTION_TYPE as encryptionType, PRODUCT_COMPLIANCE as productCompliance, BOOT_FLAG as bootFlag  FROM V_SERVICE_ACTIVE_ONETIMEALL WHERE "
				+ serviceDistributionCondition
				+ " UNION  "
				+ " SELECT PRODUCT_ID as productId, ECM_CODE as ecmCode, BASE_ECM as baseECM, PHASE_CODE as phaseCode, "
				+ " EFFECT_CODE as effectCode, ITEM_TYPE as itemType,CAL_GEN_PATH as callGenPath, CAL_GEN_NAME as calGenName, "
				+ " A_FILE_PART  as aFile,  PART_INT_PATH as partIntPath, PART_EXT_PATH as partExtPath, ENCRYPTION_TYPE as encryptionType, "
				+ " PRODUCT_COMPLIANCE as productCompliance, BOOT_FLAG as bootFlag  FROM V_SERVICE_ACTIVE_ONETIMEALL WHERE CAL_GEN_PATH ='POWERMATCH' AND "
				+ powerMatchRule
				+ " ) ";
		
		
		
		logger.info("getDailyDeleteData:{}",query);
		
		Query typedQuery=em.createNativeQuery(query);
		typedQuery.setHint("org.hibernate.fetchSize", "1000");
		
		List<Object[]> dbResult=typedQuery.getResultList();
		if(!dbResult.isEmpty()) {
			return getDTOObjects(dbResult);
		}
		return new ArrayList<ServicePkgDto>();
	}

	@Transactional
	public List<String> getDailyActiveCalProductId(BRERuleSetDetails breRuleSetDetails) {
		String serviceDistributionCondition=breRuleSetDetails.getServiceDistributionRule();
		String powerMatchRule=breRuleSetDetails.getPowerMatchDistributionRule();

		String query="select distinct PRODUCT_ID as productId "
				+ " FROM V_SERVICE_DAILY_ACTIVE_CALS WHERE  "
				+ serviceDistributionCondition
				+ " UNION "
				+ " select distinct PRODUCT_ID as productId"
				+ " FROM V_SERVICE_DAILY_ACTIVE_CALS "
				+ " WHERE CAL_GEN_PATH ='POWERMATCH' AND "
				+ powerMatchRule;
		logger.info("getDailyActiveCalProductId:{}",query);
		
		Query typedQuery=em.createNativeQuery(query);
		typedQuery.setHint("org.hibernate.fetchSize", "300");
		List<Object> dbResult=typedQuery.getResultList();
		if(!dbResult.isEmpty()) {
			return getStringObjects(dbResult);
		}
		return new ArrayList<String>();
		
	}

	@Transactional
	public int executeLastRunInsert(BRERuleSetDetails breRuleSetDetails,List<String> productIds) {
		String serviceDistributionCondition=breRuleSetDetails.getServiceDistributionRule();
		String powerMatchRule=breRuleSetDetails.getPowerMatchDistributionRule();

		String includeProductId="";//for onetime all productId condition not required.
		//for daily, onetime productId required
		if(null!=productIds && !productIds.isEmpty()) {
			includeProductId=" AND PRODUCT_ID In(:productId)";
		}
		String query="INSERT INTO T_SERVICE_LASTRUN "
				+ "(select PRODUCT_ID as productId, ECM_CODE as ecmCode, BASE_ECM as baseECM, PHASE_CODE as phaseCode,  "
				+ "  EFFECT_CODE as effectCode, ITEM_TYPE as itemType,CAL_GEN_PATH as callGenPath, CAL_GEN_NAME as calGenName, "
				+ " A_FILE_PART  as aFile,  PART_INT_PATH as partIntPath, PART_EXT_PATH as partExtPath,"
				+ " ENCRYPTION_TYPE as encryptionType, PRODUCT_COMPLIANCE as productCompliance, BOOT_FLAG as bootFlag,"
				+ " SYSDATE as LAST_RUN FROM V_SERVICE_ACTIVE_ONETIMEALL WHERE "
				+ serviceDistributionCondition
				+ includeProductId
				+ " UNION  "
				+ " select PRODUCT_ID as productId, ECM_CODE as ecmCode, BASE_ECM as baseECM, PHASE_CODE as phaseCode,  "
				+ " EFFECT_CODE as effectCode, ITEM_TYPE as itemType,CAL_GEN_PATH as callGenPath, CAL_GEN_NAME as calGenName, "
				+ " A_FILE_PART  as aFile,  PART_INT_PATH as partIntPath, PART_EXT_PATH as partExtPath,"
				+ " ENCRYPTION_TYPE as encryptionType,  PRODUCT_COMPLIANCE as productCompliance, BOOT_FLAG as bootFlag,"
				+ " SYSDATE as LAST_RUN FROM V_SERVICE_ACTIVE_ONETIMEALL "
				+ " WHERE CAL_GEN_PATH ='POWERMATCH' AND "
				+ powerMatchRule
				+ includeProductId
				+ " )";
		logger.info("executeLastRunInsert:{}",query);
		if(null!=productIds && !productIds.isEmpty()) {
			return em.createNativeQuery(query).setParameter("productId", productIds).executeUpdate();
		}else {
			return em.createNativeQuery(query).executeUpdate();
		}
	}

	@Transactional
	public List<ServicePkgDto> getDailyServiceActiveCals(BRERuleSetDetails breRuleSetDetails) {
		String serviceDistributionCondition=breRuleSetDetails.getServiceDistributionRule();
		String powerMatchRule=breRuleSetDetails.getPowerMatchDistributionRule();

		String query="select PRODUCT_ID as productId, ECM_CODE as ecmCode, BASE_ECM as baseECM, PHASE_CODE as phaseCode, "
				+ " EFFECT_CODE as effectCode, ITEM_TYPE as itemType,CAL_GEN_PATH as callGenPath, CAL_GEN_NAME as calGenName,"
				+ " A_FILE_PART  as aFile,  PART_INT_PATH as partIntPath, PART_EXT_PATH as partExtPath,"
				+ " ENCRYPTION_TYPE as encryptionType, PRODUCT_COMPLIANCE as productCompliance, BOOT_FLAG as bootFlag "
				+ " FROM V_SERVICE_DAILY_ACTIVE_CALS WHERE  "
				+ serviceDistributionCondition
				+ " UNION "
				+ " select PRODUCT_ID as productId, ECM_CODE as ecmCode, BASE_ECM as baseECM, PHASE_CODE as phaseCode, "
				+ " EFFECT_CODE as effectCode, ITEM_TYPE as itemType,CAL_GEN_PATH as callGenPath, CAL_GEN_NAME as calGenName,"
				+ " A_FILE_PART  as aFile, PART_INT_PATH as partIntPath, PART_EXT_PATH as partExtPath, "
				+ " ENCRYPTION_TYPE as encryptionType, PRODUCT_COMPLIANCE as productCompliance, BOOT_FLAG as bootFlag "
				+ "  FROM V_SERVICE_DAILY_ACTIVE_CALS WHERE CAL_GEN_PATH ='POWERMATCH' AND "
				+ powerMatchRule;

		logger.info("getDailyServiceActiveCals:{}",query);
			
		Query typedQuery=em.createNativeQuery(query);
		typedQuery.setHint("org.hibernate.fetchSize", "3000");
		List<Object[]> dbResult=typedQuery.getResultList();
		if(!dbResult.isEmpty()) {
			return getDTOObjects(dbResult);
		}
		return new ArrayList<ServicePkgDto>();
	}

	
	
	@Transactional
	public List<ServicePkgDto> getOnetimeALLActiveCals(BRERuleSetDetails breRuleSetDetails,List<String> productIds) {
		String serviceDistributionCondition=breRuleSetDetails.getServiceDistributionRule();
		String powerMatchRule=breRuleSetDetails.getPowerMatchDistributionRule();

		String includeProductId="";//for onetime all productId condition not required.
		//for daily, onetime productId required
		if(null!=productIds && !productIds.isEmpty()) {
			includeProductId=" AND PRODUCT_ID In(:productId)";
		}
		String query=" select PRODUCT_ID as productId, ECM_CODE as ecmCode, BASE_ECM as baseECM, PHASE_CODE as phaseCode,  "
				+ "  EFFECT_CODE as effectCode, ITEM_TYPE as itemType,CAL_GEN_PATH as callGenPath, CAL_GEN_NAME as calGenName, "
				+ " A_FILE_PART  as aFile,  PART_INT_PATH as partIntPath, PART_EXT_PATH as partExtPath,"
				+ "  ENCRYPTION_TYPE as encryptionType, PRODUCT_COMPLIANCE as productCompliance, BOOT_FLAG as bootFlag "
				+ " FROM V_SERVICE_ACTIVE_ONETIMEALL WHERE "
				+ serviceDistributionCondition
				+ includeProductId
				+ " UNION  "
				+ " select PRODUCT_ID as productId, ECM_CODE as ecmCode, BASE_ECM as baseECM, PHASE_CODE as phaseCode,  "
				+ " EFFECT_CODE as effectCode, ITEM_TYPE as itemType,CAL_GEN_PATH as callGenPath, CAL_GEN_NAME as calGenName, "
				+ " A_FILE_PART  as aFile,  PART_INT_PATH as partIntPath, PART_EXT_PATH as partExtPath,"
				+ " ENCRYPTION_TYPE as encryptionType,  PRODUCT_COMPLIANCE as productCompliance, BOOT_FLAG as bootFlag  "
				+ " FROM V_SERVICE_ACTIVE_ONETIMEALL WHERE CAL_GEN_PATH ='POWERMATCH' AND "
				+ powerMatchRule
				+ includeProductId;
		logger.info("getOnetimeALLActiveCals:{}",query);
		
		
		Query typedQuery=em.createNativeQuery(query);
		if(null!= productIds && !productIds.isEmpty()) {
			typedQuery.setParameter("productId", productIds);
		}
		
		typedQuery.setHint("org.hibernate.fetchSize", "50000");
		List<Object[]> dbResult=typedQuery.getResultList();
		if(!dbResult.isEmpty()) {
			return getDTOObjects(dbResult);
		}
		
		return new ArrayList<ServicePkgDto>();
	}
	@Transactional
	public List<TcalServiceDto> getTcalData(BRERuleSetDetails breRuleSetDetails) {
		String serviceDistributionCondition=breRuleSetDetails.getServiceDistributionRule().replace("PHASE_CODE", " RELEASE_PHASE_CODE").replace("EffectCode", "EFFECT_CODE");
		//String powerMatchRule=breRuleSetDetails.getPowerMatchDistributionRule().replace("PHASE_CODE", " RELEASE_PHASE_CODE").replace("EffectCode", "EFFECT_CODE");
		//String powerMatchRule=breRuleSetDetails.getPowerMatchDistributionRule();

		String query=" SELECT PRODUCT_ID AS productId , ECMCODE AS ecmCode , OLD_ECMCODE AS oldEcmCode , E2M_ECFG_PART AS e2mEcfgPart , ESDN_FLAG AS esdnFlag, "
				+ " NPBU_FLAG AS npbuFlag , A_FILE AS aFile "
				+ " FROM v_service_tcal_report "
				+ " WHERE  "
				+ serviceDistributionCondition;

		logger.info("getTcalData:{}",query);
		Query typedQuery=em.createNativeQuery(query);
		typedQuery.setHint("org.hibernate.fetchSize", "5000");
		List<Object[]> dbResult=typedQuery.getResultList();
		if(!dbResult.isEmpty()) {
			return getTcalObjects(dbResult);
		}
		
		return new ArrayList<TcalServiceDto>();
	}
	private List<TcalServiceDto> getTcalObjects(List<Object[]> dbResults) {
		List<TcalServiceDto> tcalDtos=new ArrayList<>();
		for (Object[] object : dbResults) {
			TcalServiceDto dto=new TcalServiceDto();
			if(null!=object[0]) {
				dto.setProductid(object[0].toString());
			}
			if(null!=object[1]) {
				dto.setEcmcode(object[1].toString());
			}
			if(null!=object[2]) {
				dto.setOldecmcode(object[2].toString());
			}
			if(null!=object[3]) {
				dto.setE2mecfgpart(object[3].toString());
			}
			if(null!=object[4]) {
				dto.setEsdnflag(object[4].toString());
			}
			if(null!=object[5]) {
				dto.setNpbuflag(object[5].toString());
			}
			if(null!=object[6]) {
				dto.setAfile(object[6].toString());
			}
			if(null!=object[3]) {
				dto.setPhasecode(object[3].toString());
			}
			if(null!=object[4]) {
				dto.setEffectcode(object[4].toString());
			}
			tcalDtos.add(dto);
		}
		return tcalDtos;
	}
	private List<ServicePkgDto> getDTOObjects(List<Object[]> dbResults) {
		List<ServicePkgDto> servicepkgdtos=new ArrayList<>();
		for (Object[] object : dbResults) {
			ServicePkgDto dto=new ServicePkgDto();
			if(null!=object[0]) {
				dto.setProductid(object[0].toString());
			}
			if(null!=object[1]) {
				dto.setEcmcode(object[1].toString());
			}
			if(null!=object[2]) {
				dto.setBaseecm(object[2].toString());
			}
			if(null!=object[3]) {
				dto.setPhasecode(object[3].toString());
			}
			if(null!=object[4]) {
				dto.setEffectcode(object[4].toString());
			}
			if(null!=object[5]) {
				dto.setItemtype(object[5].toString());
			}
			if(null!=object[6]) {
				dto.setCallgenpath(object[6].toString());
			}
			if(null!=object[7]) {
				dto.setCalgenname(object[7].toString());
			}
			if(null!=object[8]) {
				dto.setAfile(object[8].toString());
			}
			if(null!=object[9]) {
				dto.setPartintpath(object[9].toString());
			}
			if(null!=object[10]) {
				dto.setPartextpath(object[10].toString());
			}
			if(null!=object[11]) {
				dto.setEncryptiontype(object[11].toString());
			}
			if(null!=object[12]) {
				dto.setProductcompliance(object[12].toString());
			}
			if(null!=object[13]) {
				dto.setBootflag(object[13].toString());
			}
			
		servicepkgdtos.add(dto);
		}
		return servicepkgdtos;
	}
	private List<String> getStringObjects(List<Object> dbResults) {
		List<String> productIds=new ArrayList<>();
		for (Object object : dbResults) {
			productIds.add(object.toString());
		}
		return productIds;
	}
}
