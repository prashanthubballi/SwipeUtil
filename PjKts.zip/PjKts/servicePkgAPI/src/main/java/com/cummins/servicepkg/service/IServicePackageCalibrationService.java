package com.cummins.servicepkg.service;

import java.io.IOException;

import com.cummins.servicepkg.common.CommonResponse;
import com.cummins.servicepkg.dto.ServicePkgCalibrationRequest;
import com.cummins.servicepkg.dto.ServicePkgCalibrationResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public interface IServicePackageCalibrationService {

	CommonResponse<ServicePkgCalibrationResponse> executeServiceClibration(ServicePkgCalibrationRequest request) 
    throws InterruptedException, JsonMappingException, JsonProcessingException, IOException;
}
