package com.cummins.servicepkg.service.cal.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.cummins.servicepkg.child.dto.CsarCsuSupportFilesAdditionRequest;
import com.cummins.servicepkg.child.dto.ServicePkgCalibrationDelRequest;
import com.cummins.servicepkg.child.dto.SupportFileDetailChild;
import com.cummins.servicepkg.child.dto.SupportFileDetailParent;
import com.cummins.servicepkg.common.ChildAPI;
import com.cummins.servicepkg.common.CommonResponse;
import com.cummins.servicepkg.common.CommonResponseHeader;
import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.common.CountAndData;
import com.cummins.servicepkg.common.ResponseSummary;
import com.cummins.servicepkg.config.AmazonS3Config;
import com.cummins.servicepkg.dto.BRERuleSetDetails;
import com.cummins.servicepkg.dto.CommonParamStore;
import com.cummins.servicepkg.dto.CsarCsuSupportFilesDetails;
import com.cummins.servicepkg.dto.CsarCsuSupportFilesDetailsDTO;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.dto.ServicePathData;
import com.cummins.servicepkg.dto.ServicePkgCalibrationRequest;
import com.cummins.servicepkg.dto.ServicePkgCalibrationResponse;
import com.cummins.servicepkg.exception.BadRequestException;
import com.cummins.servicepkg.meta.dto.CopyDTO;
import com.cummins.servicepkg.model.TAuditKey;
import com.cummins.servicepkg.model.TAuditTable;
import com.cummins.servicepkg.repository.ICsarCsuQuerys;
import com.cummins.servicepkg.repository.ITAuditRepository;
import com.cummins.servicepkg.repository.IVServiceActiveOneTimeAllRepo;
import com.cummins.servicepkg.service.IServicePackageCalibrationService;
import com.cummins.servicepkg.service.child.impl.ServicePackageActiveCalUtil;
import com.cummins.servicepkg.service.child.impl.ServicePackageAddUtil;
import com.cummins.servicepkg.service.child.impl.ServicePackageDelUtil;
import com.cummins.servicepkg.service.child.impl.ServicePackageMetaDataUtil;

@Service
public class ServicePackageCalibrationServiceImpl implements IServicePackageCalibrationService {

	private static final Logger logger = LoggerFactory.getLogger(ServicePackageCalibrationServiceImpl.class);

	@PersistenceContext
	EntityManager em;

	@Autowired
	private ParamStore paramStore;
	@Autowired
	private CommonParamStore commonParamStore;
	@Autowired
	private AmazonS3Config amazonS3Config;

	@Autowired
	private CommonUtility commonUtility;

	@Autowired
	private ServicePackageDelUtil delUtil;

	@Autowired
	private ServicePackageActiveCalUtil actCal;

	@Autowired
	private ServicePackageAddUtil addUtil;

	@Autowired
	private ServicePackageMetaDataUtil metaUtil;

	@Autowired
	private ITAuditRepository itAuditRepository;
	
	@Autowired
	private IVServiceActiveOneTimeAllRepo iVServiceActiveOneTimeAllRepo;
	
	@Autowired
	private ICsarCsuQuerys iCsarCsuQuerys;
	
	@Autowired
	private RestTemplate restTemplate;
	

	@SuppressWarnings("unchecked")
	public CommonResponse<ServicePkgCalibrationResponse> executeServiceClibration(ServicePkgCalibrationRequest req) {
		CommonResponse<ServicePkgCalibrationResponse> response = new CommonResponse<>();
		CommonResponseHeader responseHeader = new CommonResponseHeader();

		ServicePkgCalibrationResponse pkgCalibrationResponse = new ServicePkgCalibrationResponse();
		pkgCalibrationResponse.setCorrelationGuid(req.getCorrelationGuid());
		pkgCalibrationResponse.setMode(req.getMode());
		ResponseSummary responseSummary = new ResponseSummary();
		storeAudits(req.getCorrelationGuid(), "SERVICE_PKG_CAL", "SERVICE_PKG_CAL STARTED", 0, "regular");
		logger.info("Service Distribution Master started entry done");
		boolean isProductBasedAndCSAR = false;
		List<String> productIdList = new ArrayList<>();
		try {
			BRERuleSetDetails ruleSetConfig = commonUtility.getBRERuleSetDetails();
			
			// Step:1 Perform Delete (servicepkg del util)
			logger.info("Started delete Calibration");
			Map<String, ServicePkgCalibrationDelRequest> allProductsDTO = delUtil.generateDelRequest(ruleSetConfig,req);
			ServicePkgCalibrationDelRequest regularCalDelRequestDTO = null;
			ServicePkgCalibrationDelRequest exportControlCalDelRequestDTO = null;
			List<String> csarProducts = iVServiceActiveOneTimeAllRepo.getCSARProducts();
			if (null != allProductsDTO) {
				regularCalDelRequestDTO = allProductsDTO.get(Constants.REQUESTREGULAR);
				exportControlCalDelRequestDTO = allProductsDTO.get(Constants.REQUESTEXPORTCONTROL);
				if (null != regularCalDelRequestDTO) {
					regularCalDelRequestDTO.setCsarProductList(csarProducts);
				}
				if (null != exportControlCalDelRequestDTO) {
					exportControlCalDelRequestDTO.setCsarProductList(csarProducts);					
				}
			}
			if (null != regularCalDelRequestDTO) {
				//String url = commonParamStore.getRegular().getHostName()+ paramStore.getServicePkgCalibrationDeletionAPI();
				//for regular products it will be internal method call so not passing url
				ChildAPI calReguar = commonUtility.callChildAPI(regularCalDelRequestDTO, req.getCorrelationGuid(), null,Constants.DELETION);
				responseSummary.setDeletion(calReguar);
				if (Constants.DAILY.equalsIgnoreCase(req.getMode())) {
					if (null != regularCalDelRequestDTO.getProductIdList()) {
						productIdList.addAll(regularCalDelRequestDTO.getProductIdList());
					}
				}
			}
			if (null != exportControlCalDelRequestDTO) {
				String url = commonParamStore.getExportControl().getHostName()	+ paramStore.getServicePkgCalibrationDeletionAPI();
				ChildAPI calExport = commonUtility.callChildAPI(exportControlCalDelRequestDTO, req.getCorrelationGuid(),url, Constants.DELETION);
				if (null != regularCalDelRequestDTO) {
					ChildAPI calRegular = responseSummary.getDeletion();
					CountAndData regularSCountAData = calRegular.getSuccess();
					regularSCountAData.setCount(regularSCountAData.getCount() + calExport.getSuccess().getCount());
					regularSCountAData.getData().addAll(calExport.getSuccess().getData());
					CountAndData regularFCountAData = calRegular.getFailure();
					regularFCountAData.setCount(regularFCountAData.getCount() + calExport.getFailure().getCount());
					regularFCountAData.getData().addAll(calExport.getFailure().getData());

					responseSummary.setDeletion(new ChildAPI(regularSCountAData, regularFCountAData));
				} else {
					responseSummary.setDeletion(calExport);
				}
				if (Constants.DAILY.equalsIgnoreCase(req.getMode())) {
					if (null != exportControlCalDelRequestDTO.getProductIdList()) {
						productIdList.addAll(exportControlCalDelRequestDTO.getProductIdList());
					}
				}
			}
			logger.info("Completed delete Calibration");
			// Step 2 call activeCalSnapshot (service pkg actCalUtil)
			Map<String, Object> respActCal = actCal.generateActiveCalRequest(ruleSetConfig,req, productIdList);
			pkgCalibrationResponse.setActiveCalStatus((String) respActCal.get("Response"));

			logger.info("Started package Calibration");
			// Step 3 service package calibration (service pkg Add Util)
			if (Constants.DAILY.equalsIgnoreCase(req.getMode())) {
				productIdList.clear();
				productIdList.addAll((List<String>) respActCal.get("ProductList"));
			}
			ChildAPI additionChild = addUtil.processServicePkgAddition(ruleSetConfig,req, productIdList);
			responseSummary.setAddition(additionChild);
			//supportfile generation code for CSAR sn-3935 -- starts here(ss586)
			if ((regularCalDelRequestDTO != null && csarProducts != null && csarProducts.stream().anyMatch(regularCalDelRequestDTO.getProductIdList()::contains))
					|| (productIdList != null && csarProducts != null && csarProducts.stream().anyMatch(productIdList::contains))) {
				List<CsarCsuSupportFilesDetailsDTO> csarCsuSupportFilesDetailsOld = iCsarCsuQuerys.getCsarCsuOneTimeAll();
				List<CsarCsuSupportFilesDetailsDTO> csarCsuSupportFilesDetails = filterSupportFilesWithBRE(csarCsuSupportFilesDetailsOld,ruleSetConfig);
				List<CsarCsuSupportFilesDetails> csarCsuSupportFiles = new ArrayList<>();
				if (csarCsuSupportFilesDetails != null && csarCsuSupportFilesDetails.size()>0) {					
					csarCsuSupportFiles = csarCsuSupportFilesDetails.stream()
							.map(i -> {
								CsarCsuSupportFilesDetails dto = new CsarCsuSupportFilesDetails();
								dto.setA2L(i.getA2L());
								dto.setEcmCode(i.getecmCode());
								dto.setEcmEffectCode(i.getecmEffectCode());
								dto.setEcmProductId(i.getecmProductId());
								dto.setEcmReleasePhaseCode(i.getecmReleasePhaseCode());
								dto.setPCFG(i.getPCFG());
								dto.setA2LCBF(i.getA2LCBF());
								dto.setPCFGCBF(i.getPCFGCBF());
								
								return dto;
							})
							.collect(Collectors.toList());
				}
				if(Constants.ALL.equalsIgnoreCase(req.getMode())) {
					//call deletion
					List<String> csarCsuProductList = csarCsuSupportFiles.stream().map(CsarCsuSupportFilesDetails::getEcmProductId)
                            .distinct()
                            .collect(Collectors.toList()); //take distinct productsID
					ChildAPI calCsarCsuDel = CsarCsuSupportFilesDeletions(csarCsuProductList, req, Constants.ALL);
					responseSummary.setCsarCsuDeletion(calCsarCsuDel);
					//deletion ends here
					//addition starts
					ChildAPI calCsarCsuAdd = CsarCsuSupportFilesAdditions(csarCsuProductList, csarCsuSupportFiles, req, Constants.ALL);
					responseSummary.setCsarCsuAddition(calCsarCsuAdd);
					//addition ends here;
					
					
				} else if (Constants.DAILY.equalsIgnoreCase(req.getMode())) {
					//deletion starts here
					List<String> csarCsuProductList = new ArrayList<>();
					csarCsuProductList = iCsarCsuQuerys.dailyAffectedProductsId();
					logger.info("csarCsuProductList line 235: " + csarCsuProductList.toString());
					
					if(csarCsuProductList.size() > 0) {
						ChildAPI calCsarCsuDel = CsarCsuSupportFilesDeletions(csarCsuProductList, req, Constants.DAILY);
						responseSummary.setCsarCsuDeletion(calCsarCsuDel);
						//deletion ends here
						//addition starts here
						ChildAPI calCsarCsuAdd = CsarCsuSupportFilesAdditions(csarCsuProductList, csarCsuSupportFiles, req, Constants.DAILY);
						responseSummary.setCsarCsuAddition(calCsarCsuAdd);
						//addition ends here
					}
					
				} else if (Constants.ONETIME.equalsIgnoreCase(req.getMode())) {
					
					List<String> csarCsuProductList = csarCsuSupportFiles.stream().map(CsarCsuSupportFilesDetails::getEcmProductId)
                            .distinct()
                            .collect(Collectors.toList());
					
					csarCsuProductList.retainAll(req.getProductIdList());
					
					if(csarCsuProductList.size() > 0) {
						isProductBasedAndCSAR = true;
						ChildAPI calCsarCsuDel = CsarCsuSupportFilesDeletions(csarCsuProductList, req, Constants.ONETIME);
						responseSummary.setCsarCsuDeletion(calCsarCsuDel);
						//deletion ends here
						//addition starts here
						ChildAPI calCsarCsuAdd = CsarCsuSupportFilesAdditions(csarCsuProductList, csarCsuSupportFiles, req, Constants.ONETIME);
						responseSummary.setCsarCsuAddition(calCsarCsuAdd);
						//addition ends here
					}
				}
				
				//csv file creation
				if(Constants.ALL.equalsIgnoreCase(req.getMode()) || Constants.DAILY.equalsIgnoreCase(req.getMode()) || isProductBasedAndCSAR) {	
					String directoryPath = commonParamStore.getRegular().getDrivePath() + paramStore.getCsarCsuCsvFilePath() + Constants.Folder_Seperator;
			        File directory = new File(directoryPath);
					File[] files = directory.listFiles((dir, name) -> name.endsWith(".csv"));
					if (files != null) {
						for (File file : files) {
							if (file.delete()) {
								logger.info("Existing file deleted successfully: " + file.getName());
							} else {
								logger.info( "Failed to delete the existing file: " + file.getName());
					        }
			            }
			        }
					String key = directoryPath.replace(commonParamStore.getRegular().getDrivePath(), "").replace(Constants.Folder_Seperator, "/");
					String bucket=commonParamStore.getRegular().getS3Bucket();
					AmazonS3 s3 = amazonS3Config.configAmazonS3();
					for (S3ObjectSummary file : s3.listObjects(bucket, key).getObjectSummaries()) {
						if(file.getKey().endsWith(".csv")) {
							s3.deleteObject(bucket, file.getKey());
						}
					}
					
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss");
					String fileName = directoryPath + "CSAR_CSU_" + dateFormat.format(new Date()) + ".csv";
					try (PrintWriter writer = new PrintWriter(new File(fileName))) {
					    StringBuilder sb = new StringBuilder();
					    sb.append("Product Id, Ecm Code, A2L, A2L CBF, ODX-D, ODX-CBF\n");
					    for (CsarCsuSupportFilesDetailsDTO row : csarCsuSupportFilesDetails) {
					        sb.append(row.getecmProductId()).append(",")
					          .append(row.getecmCode()).append(",")
//					          .append(row.getecmReleasePhaseCode()).append(",")
//					          .append(row.getecmEffectCode()).append(",")
					          .append(row.getA2L()).append(",")
					          .append(row.getA2LCBF()).append(",")
					          .append(row.getPCFG()).append(",")
					          .append(row.getPCFGCBF()).append("\n");
					    }
					    writer.write(sb.toString());
					    writer.close();
					    
					    String urlOutBoundSync=commonParamStore.getRegular().getHostName()+paramStore.getOutBoundSycUrl();
						ResponseEntity<String> responseForCsv=restTemplate.postForEntity(urlOutBoundSync, new CopyDTO(fileName.replace(commonParamStore.getRegular().getDrivePath(), ""),false), String.class);
						logger.info("CSV file created successfully: "+ fileName);
					} catch (FileNotFoundException e) {
					    // Handle file not found exception
						logger.info("CSV file creation failed");
					}
				}
				
			}
			
			// step 4 meta data
			/// metaData
			logger.info("Completed package Calibration");
			List<String> calChildproduct = additionChild.getSuccess().getData().stream().map(m -> m.getProductId()).distinct().collect(Collectors.toList());
			calChildproduct.addAll(additionChild.getFailure().getData().stream().map(m -> m.getProductId()).distinct().collect(Collectors.toList()));

			productIdList = Stream.concat(productIdList.stream(), calChildproduct.stream()).collect(Collectors.toList());
			productIdList = productIdList.stream().distinct().collect(Collectors.toList());
			String metaDataResponse = metaUtil.generateMetaData(ruleSetConfig, productIdList, req.getCorrelationGuid());
			pkgCalibrationResponse.setMetaDataStatus(metaDataResponse);
			logger.info(" Response from MetaDataGenerator : {}", metaDataResponse);
			updateSupportingFiles();

			pkgCalibrationResponse.setSummary(responseSummary);
			// identify error in childAPI and create SNOW
			identifyErrorInChild(req, pkgCalibrationResponse);
			responseHeader.setCode(HttpStatus.OK.value());
			responseHeader.setMessage("Success");
			responseHeader.setSuccess(true);
		} catch (BadRequestException e) {
			responseHeader.setCode(HttpStatus.BAD_REQUEST.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
			logger.error(req.getCorrelationGuid() + ":" + req + ",Error:" + e.getMessage());
			pkgCalibrationResponse.setErrorMessage(req.getCorrelationGuid() + ":" + req + ",Error:" + e.getMessage());
			e.printStackTrace();
			commonUtility.createServiceNowTicket(req.getCorrelationGuid() + "-Exception in Service Package Calibration",req.getCorrelationGuid() + ":" + req + ",Error:" + e.getMessage(), req.getCorrelationGuid());
		} catch (Exception e) {
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
			logger.error(req.getCorrelationGuid() + ":" + req + ",Error:" + e.getMessage());
			pkgCalibrationResponse.setErrorMessage(req.getCorrelationGuid() + ":" + req + ",Error:" + e.getMessage());
			e.printStackTrace();
			commonUtility.createServiceNowTicket(req.getCorrelationGuid() + "-Exception in Service Package Calibration",req.getCorrelationGuid() + ":" + req + ",Error:" + e.getMessage(), req.getCorrelationGuid());

		}
		storeAudits(req.getCorrelationGuid(), "SERVICE_PKG_CAL", "SERVICE_PKG_CAL COMPLETED", 1, "regular");
		logger.info("Service Distribution Master complete entry done");

		try {
			String parentPrgId = "";
			String reqId = "";
			//Integer returnFlag = null;
			executeStoredProcedure(parentPrgId, reqId,   req.getCorrelationGuid());

		} catch (Exception e) {
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
			logger.error(req.getCorrelationGuid() + ":" + req + ",Error:" + e.getMessage());
			pkgCalibrationResponse.setErrorMessage(req.getCorrelationGuid() + ":" + req + ",Error:" + e.getMessage());
			e.printStackTrace();
			commonUtility.createServiceNowTicket(req.getCorrelationGuid() + "-Exception in Calling StoredProcedure SP_SERVICE_DAILY_CAL_RPT ",req.getCorrelationGuid() + ":" + req + ",Error:" + e.getMessage(), req.getCorrelationGuid());

		}

		pkgCalibrationResponse.setSummary(responseSummary);
		response.setHeader(responseHeader);
		response.setData(pkgCalibrationResponse);
		return response;

	}

	public List<CsarCsuSupportFilesDetailsDTO> filterSupportFilesWithBRE(List<CsarCsuSupportFilesDetailsDTO> data, BRERuleSetDetails ruleSetConfig) {
		List<CsarCsuSupportFilesDetailsDTO> result = new ArrayList<>();
		
		try {
			//ruleSetConfig = commonUtility.GetBRERuleSetDetails();
			if (ruleSetConfig.getCondition().equalsIgnoreCase("and")) {
				result = data.stream()
					    .filter(csar -> ruleSetConfig.getPhaseCode().contains(csar.getecmReleasePhaseCode()) 
					    		&& ruleSetConfig.getEffectCode().contains(csar.getecmEffectCode()))
					    .collect(Collectors.toList());
			} else if (ruleSetConfig.getCondition().equalsIgnoreCase("or")) {
				result = data.stream()
					    .filter(csar -> ruleSetConfig.getPhaseCode().contains(csar.getecmReleasePhaseCode()) 
					    		|| ruleSetConfig.getEffectCode().contains(csar.getecmEffectCode()))
					    .collect(Collectors.toList());
			}
			
			return result;			
		} catch (Exception e) {
			throw new BadRequestException("Error in performing support files for CSAR:"+e.getMessage());	
		}
	}
	
	private ChildAPI CsarCsuSupportFilesDeletions(List<String> csarCsuProductList, ServicePkgCalibrationRequest req, String mode) {
		ServicePkgCalibrationDelRequest csarCsuSupportFilesDelRequestDTO = new ServicePkgCalibrationDelRequest();
		csarCsuSupportFilesDelRequestDTO.setCorrelationGuid(req.getCorrelationGuid());
		csarCsuSupportFilesDelRequestDTO.setProductIdList(csarCsuProductList);
		csarCsuSupportFilesDelRequestDTO.setMode(mode);
//		String url = commonParamStore.getRegular().getHostName()
//				+ paramStore.getCsarCsuSupportFilesDeletionAPI();
////		String url = "http://localhost:7002/servicePackageCalibrationChild/csarCsuDeletion";
		//As per merged code url is passed as null so that method will be called instead of service
		ChildAPI calCsarCsuDel = commonUtility.callChildAPI(csarCsuSupportFilesDelRequestDTO, req.getCorrelationGuid(), null,Constants.CSAR_DELETION);
		return calCsarCsuDel;
	}
	private ChildAPI CsarCsuSupportFilesAdditions(List<String> csarCsuProductList, List<CsarCsuSupportFilesDetails> csarCsuSupportFiles, ServicePkgCalibrationRequest req, String mode) {
		try {
			CsarCsuSupportFilesAdditionRequest csarCsuSupportFilesAdditionRequestDTO = new CsarCsuSupportFilesAdditionRequest();
			List<SupportFileDetailParent> supportFileDetailParentDTO = new ArrayList<>();
			
			for (String pid : csarCsuProductList) {
				List<CsarCsuSupportFilesDetails> csarCsuSupportFilesFilterByProducts = new ArrayList<>();
				csarCsuSupportFilesFilterByProducts = csarCsuSupportFiles.stream()
						.filter(i -> i.getEcmProductId().equals(pid))
						.collect(Collectors.toList());
	
				List<SupportFileDetailChild> supportFileDetailChildDTO = csarCsuSupportFilesFilterByProducts.stream()
				    .map(i -> {
				        SupportFileDetailChild childDTO = new SupportFileDetailChild();
				        childDTO.setA2l(i.getA2L());
				        childDTO.setPcfg(i.getPCFG());
				        childDTO.setA2lCbf(i.getA2LCBF());
				        childDTO.setPcfgCbf(i.getPCFGCBF());
				        return childDTO;
				    })
				    .collect(Collectors.toList());
	
				SupportFileDetailParent parentDTO = new SupportFileDetailParent();
				parentDTO.setProductId(pid);
				parentDTO.setSupportFiles(supportFileDetailChildDTO);
				supportFileDetailParentDTO.add(parentDTO);
			}
			
			csarCsuSupportFilesAdditionRequestDTO.setCorrelationGuid(req.getCorrelationGuid());
			csarCsuSupportFilesAdditionRequestDTO.setMode(mode);
			csarCsuSupportFilesAdditionRequestDTO.setData(supportFileDetailParentDTO);
	
		//	String url = commonParamStore.getRegular().getHostName()+ paramStore.getCsarCsuSupportFilesAdditionAPI();
//			String url = "http://localhost:7002/servicePackageCalibrationChild/csarCsuAddition";
			//As per merged code url is passed as null so that method will be called instead of service
			ChildAPI calCsarCsuAdd = commonUtility.callChildAPI(csarCsuSupportFilesAdditionRequestDTO, req.getCorrelationGuid(), null,Constants.CSAR_ADDITION);
			return calCsarCsuAdd;
		} catch (Exception e) {
			logger.info("Issue happening while adding the CSAR CSU support Files.");
			return new ChildAPI();
		}
	}
	public void executeStoredProcedure(String parentPrgId, String reqId,
			String CorrelationGuid) {

		String storeProcSpsd = "SP_SERVICE_DAILY_CAL_RPT";
		logger.info(" Inside calling Stored Procedure", storeProcSpsd);

		logger.info("SP execution starting ");

		StoredProcedureQuery storedProcedure = em.createStoredProcedureQuery(storeProcSpsd);

		storedProcedure.registerStoredProcedureParameter("P_Parent_Prg_Id", Integer.class, ParameterMode.IN);
		storedProcedure.registerStoredProcedureParameter("P_Request_Id", String.class, ParameterMode.IN);

		storedProcedure.registerStoredProcedureParameter("P_Return_Flag", Integer.class, ParameterMode.OUT);

		storedProcedure.setParameter("P_Parent_Prg_Id", null);
		storedProcedure.setParameter("P_Request_Id", reqId);

		storedProcedure.execute();
		Integer returnFlag = (Integer) storedProcedure.getOutputParameterValue("P_Return_Flag");

		logger.info("SP return flag :"+storedProcedure.getOutputParameterValue("P_Return_Flag"));
		
		System.out.println(returnFlag+"--------------");
		
		logger.info("SP name : {} ", storeProcSpsd);
		logger.info("SP execution completed ");

		//return returnFlag;
	}

	private void updateSupportingFiles() throws IOException {
		
//		long julianDate = today.getLong(JulianFields.JULIAN_DAY);
		Date jd = new Date();

		// Convert LocalDate to Julian date (5 digits)
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(jd);

		int year = calendar.get(Calendar.YEAR) % 1000; // Keep only the last 3 digits of the year
		int dayOfYear = calendar.get(Calendar.DAY_OF_YEAR);

		// Combine year and day of the year to get the 5-digit Julian date
		int julianDate = year * 1000 + dayOfYear;
		String servicepath = null;
		try {
			String DAT_FILE_NAME = "esdninfo.dat";
			Optional<ServicePathData> ebudetails = paramStore.getServicePathData().stream()
					.filter(n -> n.getCategory().equalsIgnoreCase("EBU")).findFirst();
			servicepath = ebudetails.get().getFolderPath().substring(0,
					ebudetails.get().getFolderPath().indexOf("data"));
			String esdninfo = commonParamStore.getRegular().getDrivePath() + servicepath + DAT_FILE_NAME;
			File esdninfoFile = new File(esdninfo);
			if (esdninfoFile.exists()) {
				BufferedReader reader = new BufferedReader(new FileReader(esdninfoFile));
				StringBuilder stringBuilder = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					if (line.contains("Date=")) {
						line = "Date=" + julianDate;
					}
					stringBuilder.append(line).append("\n");
				}
				reader.close();
				BufferedWriter writer = new BufferedWriter(new FileWriter(esdninfo));
				writer.write(stringBuilder.toString());
				writer.close();
				writer.close();
				String key = esdninfo.replace("G:\\", "");
				AmazonS3 s3 = amazonS3Config.configAmazonS3();
				s3.putObject(commonParamStore.getRegular().getS3Bucket(), key.replace("\\", "/"), esdninfoFile);
				logger.info("esdninfo file uploaded succesfully");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		servicepath = servicepath.substring(0, servicepath.indexOf("esdn"));
		File folder = new File(commonParamStore.getRegular().getDrivePath() + servicepath);
		if (folder.exists() && folder.isDirectory()) {
			File[] files = folder.listFiles();
			if (files != null) {
				for (File file : files) {
					Date date;
					try {
						date = sdf.parse(file.getName().toLowerCase());
						if (file.isFile() && sdf.format(date).equals(file.getName().toLowerCase())) {
							retryDelete(file);
							String temp = file.getPath().replace("G:\\", "");
							String key = temp.replace("\\", "/");
							System.out.println(key);
							AmazonS3 s3 = amazonS3Config.configAmazonS3();
							for (S3ObjectSummary obj : s3.listObjects(commonParamStore.getRegular().getS3Bucket(), key).getObjectSummaries()) {
								System.out.println("Deleting file from s3");
								s3.deleteObject(commonParamStore.getRegular().getS3Bucket(), obj.getKey());
							}
						}
					} catch (ParseException e) {
					}
				}
			}
		}
		Date currentDate = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date currentDateTime = new Date();
		SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss");
		String formattedDateTime = dateTimeFormat.format(currentDateTime);
		String formattedDate = dateFormat.format(currentDate);
		String fileName = commonParamStore.getRegular().getDrivePath() + servicepath + formattedDate;
		String content = formattedDateTime;
		Path path = Paths.get(fileName);
		Files.createFile(path);
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
			writer.write(content);
			String key = fileName.replace("G:\\", "");
			AmazonS3 s3 = amazonS3Config.configAmazonS3();
			s3.putObject(commonParamStore.getRegular().getS3Bucket(), key.replace("\\", "/"), new File(fileName));
			System.out.println("File '" + fileName + "' created successfully.");
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	}
	private boolean retryDelete(File file) {
		int count=0;
		boolean status;
		while(!(status=file.delete()) && count<3) {
			logger.info("Deleting file in :"+file.getAbsolutePath()+",status:"+status+", count:"+count);
			count++;
		}
		if(file.exists()) {
			return false;
		}
		return true;
	}
	private String identifyErrorInChild(ServicePkgCalibrationRequest req,
			ServicePkgCalibrationResponse pkgCalibrationResponse) {
		String activeCalStatus = pkgCalibrationResponse.getActiveCalStatus();
		if (activeCalStatus.startsWith("ERROR")) {
			commonUtility.createServiceNowTicket(req.getCorrelationGuid() + "-Exception in ActiveCalStatus",pkgCalibrationResponse.getCorrelationGuid() + ":" + req + ",Error:" + activeCalStatus,req.getCorrelationGuid());
			return "Created";
		}
		if (null != pkgCalibrationResponse.getSummary()
				&& null != pkgCalibrationResponse.getSummary().getAddition().getFailure()
				&& null != pkgCalibrationResponse.getSummary().getAddition().getFailure().getData()
				&& !pkgCalibrationResponse.getSummary().getAddition().getFailure().getData().isEmpty()) {
			commonUtility.createServiceNowTicket(	req.getCorrelationGuid() + "-Exception in Additions", pkgCalibrationResponse.getCorrelationGuid()+ ":" + req + ",Error:" + pkgCalibrationResponse.getSummary().getAddition().getFailure(),req.getCorrelationGuid());
			return "Created";
		}
		// if(null!=pkgCalibrationResponse.getSummary().getDeletion().getFailure() &&
		// pkgCalibrationResponse.getSummary().getAddition().getFailure().getCount()>0)
		// {
		// createServiceNowTicket(req.getCorrelationGuid()+"-Exception in Additions",
		// pkgCalibrationResponse.getCorrelationGuid()+":"+req+",Error:"+pkgCalibrationResponse,
		// req.getCorrelationGuid());
		// return "Created";
		// }
		return "";
	}

	private void storeAudits(String guid, String audActivity, String audSubActivity, int audStatus, String mode) {
		String dbData = "";
		if (mode.contains(",")) {
			dbData = "ProductMode";
		} else {
			dbData = mode;
		}
		TAuditTable auditEntity = new TAuditTable();
		TAuditKey key = new TAuditKey();
		key.setAudActivitId("SD");
		key.setAudDate(LocalDateTime.now());
		key.setAudSubActivity(audSubActivity);
		key.setAudFunctionId("SD");
		key.setAudSubCode(dbData);
		key.setAudSubFunctionId(" ");
		key.setAudCode(" ");
		key.setAudDetails(" ");
		key.setAudActivity(audActivity);
		key.setAudLastUpdateUser(itAuditRepository.getUserFromDB());
		key.setAudLastUpdateDate(LocalDateTime.now());
		key.setAudRequestId(guid);
		key.setAudStatus(audStatus);
		auditEntity.setKey(key);
		itAuditRepository.save(auditEntity);
	}

	
}
