package com.cummins.servicepkg.dto;

public interface ServicePkgCalibrationRequestDTO {

  String getproductId();

  String getecmCode();

  String getbaseECM();

  String getphaseCode();

  String geteffectCode();

  String getitemType();

  String getcallGenPath();

  String getcalGenName();

  String getaFile();

  String getpartIntPath();

  String getpartExtPath();

  String getencryptionType();

  String getproductCompliance();
  
  String getbootFlag();

}
