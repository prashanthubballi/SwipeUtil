package com.cummins.servicepkg.dto;




public interface ITcalServiceDTO {

	String getproductId();
	String getecmCode();
	String getoldEcmCode();
	String gete2mEcfgPart();
	String getesdnFlag();
	String getnpbuFlag();
	String getaFile();
	String getphaseCode();
	String geteffectCode();
	
	Object getInt(String string);
	void setproductId(Object int1);
	String getString(String string);
	
}
