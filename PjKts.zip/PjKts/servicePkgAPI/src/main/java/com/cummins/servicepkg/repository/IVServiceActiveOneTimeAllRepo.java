package com.cummins.servicepkg.repository;

import java.util.List;

import javax.persistence.QueryHint;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import com.cummins.servicepkg.dto.ServicePkgCalibrationRequestDTO;
import com.cummins.servicepkg.model.VServiceActiveOneTimeAllKey;
import com.cummins.servicepkg.model.VServiceActiveOnetimeall;

@Repository
@Transactional
public interface IVServiceActiveOneTimeAllRepo extends JpaRepository<VServiceActiveOnetimeall, VServiceActiveOneTimeAllKey> {

	
	@Modifying
	@Query(value = "DELETE FROM T_SERVICE_LASTRUN WHERE TSL_PRODUCT_ID In (?1)", nativeQuery = true)
	void deleteFromTServiceActiveAllLastrunForProductID(List<String> productIds);
	

	@Modifying
	@Query(value = "DELETE FROM T_SERVICE_LASTRUN", nativeQuery = true)
	void deleteFromTServiceActiveAllLastrun();	
	
	@Query(value=" select distinct PRODUCT_ID productId, PRODUCT_COMPLIANCE productCompliance from V_SERVICE_ACTIVE_ONETIMEALL",nativeQuery = true )
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500000"))
	List<ServicePkgCalibrationRequestDTO> getServiceActiveOneTimeAllProductId();
	
	
	@Query(value=" select distinct PRODUCT_ID productId, PRODUCT_COMPLIANCE productCompliance from V_SERVICE_ACTIVE_ONETIMEALL where PRODUCT_ID in (?1)",nativeQuery = true )
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500000"))
	List<ServicePkgCalibrationRequestDTO> getServiceActiveOneTimeProductId(List<String> pid);
	
	@Query(value = "select distinct PRODUCT_ID from V_SERVICE_ACTIVE_ONETIMEALL where PRODUCT_COMPLIANCE = 'CSAR'", nativeQuery = true)
	  List<String> getCSARProducts();
}
