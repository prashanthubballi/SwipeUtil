package com.cummins.servicepkg.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ServicePkgDto  {

	private String productid;
	private String ecmcode;
	private String baseecm;
	private String phasecode;
	private String effectcode;
	private String itemtype;
	private String callgenpath;
	private String calgenname;
	private String afile;
	private String partintpath;
	private String partextpath;
	private String encryptiontype;
	private String productcompliance;
	private String bootflag;

}
