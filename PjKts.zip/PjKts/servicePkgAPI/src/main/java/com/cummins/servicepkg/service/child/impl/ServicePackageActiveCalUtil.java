package com.cummins.servicepkg.service.child.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.dto.BRERuleSetDetails;
import com.cummins.servicepkg.dto.ServicePkgCalibrationRequest;
import com.cummins.servicepkg.repository.IVServiceActiveOneTimeAllRepo;
import com.cummins.servicepkg.repository.ServiceRepoUtil;
@Service
public class ServicePackageActiveCalUtil {

	

	@Autowired
	private ServiceRepoUtil serviceRepoUtil;

	@Autowired
	private IVServiceActiveOneTimeAllRepo iVServiceActiveOneTimeAllRepo;

	private static final Logger logger = LoggerFactory.getLogger(ServicePackageActiveCalUtil.class);

	public Map<String ,Object> generateActiveCalRequest(BRERuleSetDetails ruleSetConfig,ServicePkgCalibrationRequest request,List<String> productList) {
		ServicePkgCalibrationRequest activeCalRequest=new ServicePkgCalibrationRequest();
		Map<String, Object> resp=new HashMap<>();
		List<String> productIdList = null;
		activeCalRequest.setCorrelationGuid(request.getCorrelationGuid());
		activeCalRequest.setMode(request.getMode());
		if(Constants.DAILY.equalsIgnoreCase(request.getMode()) || Constants.ONETIME.equalsIgnoreCase(request.getMode())) {
			if (Constants.DAILY.equalsIgnoreCase(request.getMode())) {
				List<String> productIdforDaily =new ArrayList<>();
				if(null!=productList) {
					productIdforDaily= productList.stream().distinct().collect(Collectors.toList());
				}
				productIdforDaily.addAll(serviceRepoUtil.getDailyActiveCalProductId(ruleSetConfig));

				productIdList = productIdforDaily.stream().map(m -> m).distinct().collect(Collectors.toList());
				activeCalRequest.setProductIdList(productIdList);
				request.setProductIdList(productIdforDaily);
				resp.put("ProductList", productIdList);
			}else if (Constants.ONETIME.equalsIgnoreCase(request.getMode())) {
				activeCalRequest.setProductIdList(request.getProductIdList());
			}
			if(request != null && !request.getProductIdList().isEmpty()) {//vw596
				iVServiceActiveOneTimeAllRepo.deleteFromTServiceActiveAllLastrunForProductID(request.getProductIdList());
				int result=serviceRepoUtil.executeLastRunInsert(ruleSetConfig, request.getProductIdList());
				logger.info("Successfully executed Service Active Cal Snapshot: "+result);
				resp.put("Response","Successfully executed Service Active Cal Snapshot:"+result);
			}else {
				logger.info("There is no productId to update in LASTRUN table");
				resp.put("Response","There is no productId to update in LASTRUN table");
			}
		}else if(Constants.ALL.equalsIgnoreCase(request.getMode())) {
			iVServiceActiveOneTimeAllRepo.deleteFromTServiceActiveAllLastrun();

			int result=serviceRepoUtil.executeLastRunInsert(ruleSetConfig, null);//passing product ids as null for all mode
			logger.info("Successfully executed Service Active Cal Snapshot: "+result);
			resp.put("Response","Successfully executed Service Active Cal Snapshot:"+result);
			
		}
		return resp;
	}
}
