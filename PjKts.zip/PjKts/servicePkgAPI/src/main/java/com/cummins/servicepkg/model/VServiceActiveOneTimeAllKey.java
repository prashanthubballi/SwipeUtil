package com.cummins.servicepkg.model;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class VServiceActiveOneTimeAllKey implements Serializable{

 
  /**
   * 
   */
  private static final long serialVersionUID = 8546272039830315953L;

  @Column(name="A_FILE")
  private String aFile;

  @Column(name="BASE_ECM")
  private String baseEcm;

  @Column(name="CAL_GEN_NAME")
  private String calGenName;

  @Column(name="CAL_GEN_PATH")
  private String calGenPath;

  @Column(name="ECM_CODE")
  private String ecmCode;

  @Column(name="EFFECT_CODE")
  private BigDecimal effectCode;

  @Column(name="ITEM_TYPE")
  private String itemType;

  @Column(name="PHASE_CODE")
  private String phaseCode;

  @Column(name="PRODUCT_ID")
  private String productId;

  @Column(name="PRODUCT_TYPE")
  private String productType;

  public VServiceActiveOneTimeAllKey() {
  }

  public String getAFile() {
    return this.aFile;
  }

  public void setAFile(String aFile) {
    this.aFile = aFile;
  }

  public String getBaseEcm() {
    return this.baseEcm;
  }

  public void setBaseEcm(String baseEcm) {
    this.baseEcm = baseEcm;
  }

  public String getCalGenName() {
    return this.calGenName;
  }

  public void setCalGenName(String calGenName) {
    this.calGenName = calGenName;
  }

  public String getCalGenPath() {
    return this.calGenPath;
  }

  public void setCalGenPath(String calGenPath) {
    this.calGenPath = calGenPath;
  }

  public String getEcmCode() {
    return this.ecmCode;
  }

  public void setEcmCode(String ecmCode) {
    this.ecmCode = ecmCode;
  }

  public BigDecimal getEffectCode() {
    return this.effectCode;
  }

  public void setEffectCode(BigDecimal effectCode) {
    this.effectCode = effectCode;
  }

  public String getItemType() {
    return this.itemType;
  }

  public void setItemType(String itemType) {
    this.itemType = itemType;
  }

  public String getPhaseCode() {
    return this.phaseCode;
  }

  public void setPhaseCode(String phaseCode) {
    this.phaseCode = phaseCode;
  }

  public String getProductId() {
    return this.productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public String getProductType() {
    return this.productType;
  }

  public void setProductType(String productType) {
    this.productType = productType;
  }

}
