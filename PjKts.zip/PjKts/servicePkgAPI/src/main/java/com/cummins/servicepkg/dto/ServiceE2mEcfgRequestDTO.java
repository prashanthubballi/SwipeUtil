package com.cummins.servicepkg.dto;

import java.util.List;
import lombok.Data;
import lombok.Getter;

@Data
@Getter
public class ServiceE2mEcfgRequestDTO {

//	@NotNull(message = "GUID value must not be null")
//	@NotBlank(message = "GUID value must not be blank")
//	@Pattern(regexp = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", message = "The value does not match GUID pattern")
	private String correlationGuid;

  /*
   * @NotNull(message = "Mode value must not be null")
   * 
   * @NotBlank(message = "Mode value must not be blank")
   */
	private String mode;

	private List<String> productIDList;

	public String getCorrelationGuid() {
		return correlationGuid;
	}

	public String getMode() {
		return mode;
	}

	public List<String> getProductIDList() {
		return productIDList;
	}

}
