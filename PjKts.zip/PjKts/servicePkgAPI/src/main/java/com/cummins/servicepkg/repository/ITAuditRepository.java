package com.cummins.servicepkg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cummins.servicepkg.model.TAuditKey;
import com.cummins.servicepkg.model.TAuditTable;

@Repository
public interface ITAuditRepository extends JpaRepository<TAuditTable, TAuditKey> {

  @Query(value = "select user from dual", nativeQuery = true)
  String getUserFromDB();
}
