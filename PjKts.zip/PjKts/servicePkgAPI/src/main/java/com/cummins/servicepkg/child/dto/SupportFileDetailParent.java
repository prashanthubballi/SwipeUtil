package com.cummins.servicepkg.child.dto;

import java.util.List;

import lombok.Data;

@Data
public class SupportFileDetailParent {
	private String productId;
	private List<SupportFileDetailChild> supportFiles;
}
