package com.cummins.servicepkg.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="V_SERVICE_E2M_ECFG_ONETIMEALL")
@NamedQuery(name="VServiceE2mEcfgOnetimeall.findAll", query="SELECT v FROM VServiceE2mEcfgOnetimeall v")
public class VServiceE2mEcfgOnetimeall implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId VServiceE2mEcfgOneTimeallKey id;
}
