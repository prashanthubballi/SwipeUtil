package com.cummins.servicepkg.dto;

import lombok.Data;

@Data
public class CsarCsuSupportFilesDetails {
	
	private String ecmProductId;
	private String ecmCode;
	private String ecmReleasePhaseCode;
	private String ecmEffectCode;
	private String A2L;
	private String PCFG;
	private String A2LCBF;
	private String PCFGCBF;

}
