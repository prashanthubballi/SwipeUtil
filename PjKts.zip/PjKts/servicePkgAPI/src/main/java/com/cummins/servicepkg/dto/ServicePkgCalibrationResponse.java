package com.cummins.servicepkg.dto;

import java.util.List;

import com.cummins.servicepkg.common.ResponseSummary;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(Include.NON_NULL)
public class ServicePkgCalibrationResponse {

  private String correlationGuid;
  private String mode;  
  private List<String> productIDList;
  
  @JsonProperty("ActiveCalStatus")
  private String activeCalStatus;
  
  @JsonProperty("MetaDataStatus")
  private String MetaDataStatus;
  
  @JsonProperty("errorMessage")
  private String errorMessage;
  @JsonProperty("summary")
  private ResponseSummary summary;

}
