package com.cummins.servicepkg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cummins.servicepkg.dto.CsarCsuSupportFilesDetailsDTO;
import com.cummins.servicepkg.model.VServiceActiveOneTimeAllKey;
import com.cummins.servicepkg.model.VServiceActiveOnetimeall;

@Repository
public interface ICsarCsuQuerys extends
JpaRepository<VServiceActiveOnetimeall, VServiceActiveOneTimeAllKey> {
	
	
	@Query(value="select  "
			+ "ECM_PRODUCT_ID AS ecmProductId, "
			+ "ECM_CODE As ecmCode, "
			+ "ECM_RELEASE_PHASE_CODE AS ecmReleasePhaseCode, "
			+ "ECM_EFFECT_CODE AS ecmEffectCode, "
			+ "REGEXP_SUBSTR(LISTAGG(DISTINCT ITM_NUMBER,',') WITHIN GROUP (ORDER BY POS_SUBFILE_SUBCODE), '[^,]+',1,1) A2L, "
			+ "REGEXP_SUBSTR(LISTAGG(DISTINCT ITM_NUMBER,',') WITHIN GROUP (ORDER BY POS_SUBFILE_SUBCODE), '[^,]+',1,2) A2LCBF, "
			+ "REGEXP_SUBSTR(LISTAGG(DISTINCT ITM_NUMBER,',') WITHIN GROUP (ORDER BY POS_SUBFILE_SUBCODE), '[^,]+',1,3) PCFG, "
			+ "REGEXP_SUBSTR(LISTAGG(DISTINCT ITM_NUMBER,',') WITHIN GROUP (ORDER BY POS_SUBFILE_SUBCODE), '[^,]+',1,4) PCFGCBF "
			+ "from "
			+ "( "
			+ "  SELECT DISTINCT  ECM_PRODUCT_ID, "
			+ "                    ECM_CODE, "
			+ "                    ECM_RELEASE_PHASE_CODE, "
			+ "                    ECM_EFFECT_CODE, "
			+ "                    DDO_OPTION||'.'|| LPAD(A.ITM_REVISION_LEVEL,2,0) ITM_NUMBER "
			+ "                    ,POS_SUBFILE_SUBCODE "
			+ "  FROM T_PRODUCT_OPTION_STRUCTURE_MAP , "
			+ "       T_D1D2_OPTIONS, "
			+ "       T_ITEM A, "
			+ "       T_ECM , "
			+ "       T_COMPAT_LEVEL_2 "
			+ "  WHERE POS_PRODUCT_ID         =  DDO_PRODUCT_ID "
			+ "  AND DDO_PRODUCT_ID           IN (SELECT PRM_PRODUCT_ID FROM T_PRODUCT_MASTER WHERE PRM_GROUP_TYPE ='CSAR') "
			+ "  AND DDO_ECM_CODE             =  ECM_CODE "
			+ "  AND ECM_CODE                 =  CL2_ECM_CODE "
			+ "  AND DDO_PRINTED_FLAG         =  'Y' "
			+ "  AND DDO_ENG_GROUP            =  'Y' "
			+ "  AND POS_SUBFILE_CODE         =  65  "
			+ "  AND (POS_SUBFILE_SUBCODE     =  5  "
			+ "        OR POS_SUBFILE_SUBCODE =  7 "
			+ "        OR POS_SUBFILE_SUBCODE =  6 "
			+ "        OR POS_SUBFILE_SUBCODE =  4 "
			+ "        ) "
			+ "  AND DDO_LINK_SUBFILE_CODE    =  POS_SUBFILE_CODE "
			+ "  AND DDO_LINK_SUBFILE_SUBCODE =  POS_SUBFILE_SUBCODE "
			+ "  AND DDO_OPTION               =  TRIM(A.ITM_NUMBER) "
			+ "  AND ITM_EFFECT_CODE          <> '40' "
			+ "  AND A.ITM_REVISION_LEVEL     =  (SELECT MAX(B.ITM_REVISION_LEVEL) "
			+ "                                    FROM T_ITEM B "
			+ "                                    WHERE B.ITM_NUMBER = A.ITM_NUMBER "
			+ "                                    AND B.ITM_STATUS   = 'Y' "
			+ "                                    ) "
			+ "ORDER BY 1,2,6 "
			+ ") "
			+ "GROUP BY ECM_PRODUCT_ID , "
			+ "         ECM_CODE, "
			+ "         ECM_RELEASE_PHASE_CODE, "
			+ "         ECM_EFFECT_CODE", nativeQuery = true)
	List<CsarCsuSupportFilesDetailsDTO> getCsarCsuOneTimeAll();
	
	
	@Query(value = "SELECT ECM_PRODUCT_ID as ecmProductId, "
			+ "       ECM_CODE as ecmCode, "
			+ "       ECM_RELEASE_PHASE_CODE as ecmReleasePhaseCode, "
			+ "       ECM_EFFECT_CODE as ecmEffectCode, "
			+ "       REGEXP_SUBSTR(LISTAGG(DISTINCT ITM_NUMBER,',') WITHIN GROUP (ORDER BY ECM_CODE), '[^,]+',1,1) A2L , "
			+ "       REGEXP_SUBSTR(LISTAGG(DISTINCT ITM_NUMBER,',') WITHIN GROUP (ORDER BY ECM_CODE), '[^,]+',1,2) PCFG "
			+ "FROM "
			+ "  (SELECT DISTINCT  ECM_PRODUCT_ID, "
			+ "                    ECM_CODE, "
			+ "                    ECM_RELEASE_PHASE_CODE, "
			+ "                    ECM_EFFECT_CODE, "
			+ "                    DDO_OPTION||'.'|| LPAD(A.ITM_REVISION_LEVEL,2,0) ITM_NUMBER "
			+ "  FROM T_PRODUCT_OPTION_STRUCTURE_MAP , "
			+ "       T_D1D2_OPTIONS, "
			+ "       T_ITEM A, "
			+ "       T_ECM , "
			+ "       T_COMPAT_LEVEL_2 "
			+ "  WHERE POS_PRODUCT_ID         =  DDO_PRODUCT_ID "
			+ "  AND DDO_PRODUCT_ID           IN (SELECT PRM_PRODUCT_ID FROM T_PRODUCT_MASTER WHERE PRM_GROUP_TYPE ='CSAR') "
			+ "  AND DDO_ECM_CODE             =  ECM_CODE "
			+ "  AND ECM_CODE                 =  CL2_ECM_CODE "
			+ "  AND DDO_PRINTED_FLAG         =  'Y' "
			+ "  AND DDO_ENG_GROUP            =  'Y' "
			+ "  AND POS_SUBFILE_CODE         =  65  "
			+ "  AND (POS_SUBFILE_SUBCODE     =  5  "
			+ "        OR POS_SUBFILE_SUBCODE =  7) "
			+ "  AND DDO_LINK_SUBFILE_CODE    =  POS_SUBFILE_CODE "
			+ "  AND DDO_LINK_SUBFILE_SUBCODE =  POS_SUBFILE_SUBCODE "
			+ "  AND DDO_OPTION               =  TRIM(A.ITM_NUMBER) "
			+ "  AND ITM_EFFECT_CODE          <> '40' "
			+ "  AND A.ITM_REVISION_LEVEL     =  (SELECT MAX(B.ITM_REVISION_LEVEL) "
			+ "                                    FROM T_ITEM B "
			+ "                                    WHERE B.ITM_NUMBER = A.ITM_NUMBER "
			+ "                                    AND B.ITM_STATUS   = 'Y' "
			+ "                                    ) "
			+ "  AND (TO_CHAR(ECM_ER_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS') "
			+ "                                      								  FROM T_ER_LIST where ERL_RELEASE_STATUS = 'Y') "
			+ "        OR 		 "
			+ "	   TO_CHAR(ECM_RELEASE_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS') "
			+ "                                                            FROM T_ER_LIST where ERL_RELEASE_STATUS = 'Y') "
			+ "      	OR 	    "
			+ "		TO_CHAR(CL2_LAST_UPDATE_DATE,'YYYYMMDD HH24:MI:SS') >= (SELECT TO_CHAR(MAX(ERL_RELEASE_DATE), 'YYYYMMDD HH24:MI:SS') "
			+ "                                                                FROM T_ER_LIST where ERL_RELEASE_STATUS = 'Y') "
			+ "     )														                                     "
			+ "  ) "
			+ "GROUP BY ECM_PRODUCT_ID , "
			+ "         ECM_CODE, "
			+ "         ECM_RELEASE_PHASE_CODE, "
			+ "         ECM_EFFECT_CODE", nativeQuery = true)
	List<CsarCsuSupportFilesDetailsDTO> getCsarCsuDaily();
	
	@Query(value="select distinct PRODUCT_ID from V_SERVICE_DAILY_ACTIVE_CALS "
			+ "where PRODUCT_ID in (SELECT PRM_PRODUCT_ID FROM T_PRODUCT_MASTER WHERE PRM_GROUP_TYPE ='CSAR')", nativeQuery = true)
	List<String> dailyAffectedProductsId();
	
}
