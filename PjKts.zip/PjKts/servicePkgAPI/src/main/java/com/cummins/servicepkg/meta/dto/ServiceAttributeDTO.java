package com.cummins.servicepkg.meta.dto;

public class ServiceAttributeDTO {

	private String ECM_CODE;
	private String BASE_ECM;
	private String Category;
	
	public String getECM_CODE() {
		return ECM_CODE;
	}

	public void setECM_CODE(String eCM_CODE) {
		ECM_CODE = eCM_CODE;
	}

	public String getBASE_ECM() {
		return BASE_ECM;
	}

	public void setBASE_ECM(String bASE_ECM) {
		BASE_ECM = bASE_ECM;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public ServiceAttributeDTO(String eCM_CODE, String bASE_ECM, String category) {
		super();
		ECM_CODE = eCM_CODE;
		BASE_ECM = bASE_ECM;
		Category = category;
	}

	@Override
	public String toString() {
		return "\n  {\n    \"ECM_CODE\": \"" + ECM_CODE + "\",\n    \"BASE_ECM\": \"" + BASE_ECM + "\",\n    \"Category\": \"" + Category
				+ "\"\n  }";
	}
	
}
