package com.cummins.servicepkg.model;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class TDistributionRuleSetKey implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -9183303082145489031L;

 
  @Column(name = "BRE_ID")
  private BigDecimal breId;

  @Column(name = "BRE_JSON")
  private String breJson;

  @Column(name = "BRE_MODE_FLG")
  private String breModeFlg;

  @Column(name = "BRE_RULE_DIST_SET")
  private String breRuleDistSet;

  @Column(name = "BRE_RULE_NAME")
  private String breRuleName;

  @Column(name = "BRE_SEQID")
  private BigDecimal breSeqid;
 
  public BigDecimal getBreId() {
    return this.breId;
  }

  public void setBreId(BigDecimal breId) {
    this.breId = breId;
  }

  public String getBreJson() {
    return this.breJson;
  }

  public void setBreJson(String breJson) {
    this.breJson = breJson;
  }

  public String getBreModeFlg() {
    return this.breModeFlg;
  }

  public void setBreModeFlg(String breModeFlg) {
    this.breModeFlg = breModeFlg;
  }

  public String getBreRuleDistSet() {
    return this.breRuleDistSet;
  }

  public void setBreRuleDistSet(String breRuleDistSet) {
    this.breRuleDistSet = breRuleDistSet;
  }

  public String getBreRuleName() {
    return this.breRuleName;
  }

  public void setBreRuleName(String breRuleName) {
    this.breRuleName = breRuleName;
  }

  public BigDecimal getBreSeqid() {
    return this.breSeqid;
  }

  public void setBreSeqid(BigDecimal breSeqid) {
    this.breSeqid = breSeqid;
  }

  public TDistributionRuleSetKey() {
    super();
  }
}
