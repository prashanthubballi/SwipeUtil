package com.cummins.servicepkg.config;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AmazonS3Config {
	@Value("${region}")
	Regions region;

	public AmazonS3 configAmazonS3() {
		Regions clientRegion = region;

		AmazonS3 s3Client = null;
		try {
			s3Client = AmazonS3ClientBuilder.standard().withRegion(clientRegion).build();
			System.out.println("AWS S3 Instance  : " + s3Client.toString());
			return s3Client;
		} catch (AmazonServiceException execption) {
			// The call was transmitted successfully, but Amazon S3 couldn't process
			// it, so it returned an error response.
			execption.printStackTrace();
		} catch (SdkClientException ex) {
			// Amazon S3 couldn't be contacted for a response, or the client
			// couldn't parse the response from Amazon S3.
			ex.printStackTrace();
		}
		return s3Client;
	}

}
