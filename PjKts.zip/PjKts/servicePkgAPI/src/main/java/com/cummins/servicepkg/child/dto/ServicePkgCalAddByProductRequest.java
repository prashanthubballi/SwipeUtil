package com.cummins.servicepkg.child.dto;

import java.util.LinkedList;
import java.util.List;

import com.cummins.servicepkg.dto.ServicePkgDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ServicePkgCalAddByProductRequest {

	private String type;
	private String correlationGuid;
	private ServicePkgDto product;
	private List<ServicePkgDto> products=new LinkedList<>();

}
