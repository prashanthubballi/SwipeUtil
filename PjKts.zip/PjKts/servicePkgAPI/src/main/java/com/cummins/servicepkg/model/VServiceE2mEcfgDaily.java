package com.cummins.servicepkg.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;
/**
 * The persistent class for the V_SERVICE_E2M_ECFG_DAILY database table.
 * 
 */
@Data
@Entity
@Table(name="V_SERVICE_E2M_ECFG_DAILY")
@NamedQuery(name="VServiceE2mEcfgDaily.findAll", query="SELECT v FROM VServiceE2mEcfgDaily v")
public class VServiceE2mEcfgDaily implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId VServiceE2mEcfgDailyKey id;
	


}
