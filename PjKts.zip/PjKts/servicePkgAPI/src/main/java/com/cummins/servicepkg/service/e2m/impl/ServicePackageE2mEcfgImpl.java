package com.cummins.servicepkg.service.e2m.impl;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.cummins.servicepkg.child.dto.ServiceE2mResponse;
import com.cummins.servicepkg.common.CommonResponse;
import com.cummins.servicepkg.common.CommonResponseHeader;
import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.common.CountAndData;
import com.cummins.servicepkg.common.ECMCodeandFile;
import com.cummins.servicepkg.common.FileListJson;
import com.cummins.servicepkg.common.ObjectData;
import com.cummins.servicepkg.common.PIDandFiles;
import com.cummins.servicepkg.config.AmazonS3Config;
import com.cummins.servicepkg.dto.CommonParamStore;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.dto.ServiceE2mEcfgDTO;
import com.cummins.servicepkg.dto.ServiceE2mEcfgRequestDTO;
import com.cummins.servicepkg.exception.BadRequestException;
import com.cummins.servicepkg.model.TAuditKey;
import com.cummins.servicepkg.model.TAuditTable;
import com.cummins.servicepkg.repository.ITAuditRepository;
import com.cummins.servicepkg.repository.ServiceE2mEcfgDailyRepo;
import com.cummins.servicepkg.repository.ServiceE2mEcfgOneTimeAllRepo;
import com.cummins.servicepkg.service.cal.impl.CommonUtility;
import com.cummins.servicepkg.service.cal.impl.MDCExecutorService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import io.github.resilience4j.retry.Retry;

@Service
public class ServicePackageE2mEcfgImpl  {

	private static final Logger logger = LoggerFactory.getLogger(ServicePackageE2mEcfgImpl.class);

	ObjectMapper mapper = new ObjectMapper();

	@Autowired
	private Retry retry;


	@Autowired
	private CommonParamStore commonPS;

	@Autowired
	private ParamStore paramStore;

	@Autowired
	private ServiceE2mEcfgOneTimeAllRepo onetimeAllRepo;

	@Autowired
	private ServiceE2mEcfgDailyRepo dailyRepo;

	@Autowired
	private CommonUtility commonUtility;

	@Autowired
	AmazonS3Config amazonS3Config;

	@Autowired
	private ITAuditRepository itAuditRepository;

	private static String FOLDER_SEPERATOR = "\\";

	public CommonResponse<ServiceE2mResponse> executeServicePkgE2mEcfg(ServiceE2mEcfgRequestDTO req) {
		logger.info("Request Info : {}", req);

		CommonResponse<ServiceE2mResponse> response = new CommonResponse<>();
		CommonResponseHeader responseHeader = new CommonResponseHeader();
		ServiceE2mResponse responseData = new ServiceE2mResponse();
		try {
			storeAudits(req.getCorrelationGuid(), "SERVICE_PACKAGE_E2M-ECFG","SERVICE_PACKAGE_E2M-ECFG STARTED", 0, "regular");
			logger.info("Service Distribution Master started entry done");
			//copy file to temp folder with encryption etc
			responseData=startE2mProcess(req);
			//create calibration.zip if all goes well.

			if(null!=responseData.getFailure() && null!=responseData.getFailure().getData() && !responseData.getFailure().getData().isEmpty()) {
				logger.error("There are failures in e2mecfg, creating SNOW: {}",responseData.getFailure().getData().toString());
				commonUtility.createServiceNowTicket("Service_Package_E2m-ECFG failed for CorrelationGuID : "+req.getCorrelationGuid(), responseData.getFailure().getData().toString(), req.getCorrelationGuid());
	
			}
			
			responseHeader.setCode(HttpStatus.OK.value());
			responseHeader.setMessage("Success");
			responseHeader.setSuccess(true);
		}catch (BadRequestException e) {
			responseHeader.setCode(HttpStatus.OK.value()); // updated to OK to avoid causing exception in parent
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
			commonUtility.createServiceNowTicket("Service_Package_E2m-ECFG failed for CorrelationGuID : "+req.getCorrelationGuid(), e.getMessage(), req.getCorrelationGuid());
			
		}catch (Exception e) {
			responseHeader.setCode(HttpStatus.OK.value());// updated to OK to avoid causing exception in parent
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
			commonUtility.createServiceNowTicket("Service_Package_E2m-ECFG failed for CorrelationGuID : "+req.getCorrelationGuid(), e.getMessage(), req.getCorrelationGuid());
			
		} catch (Throwable e) {
			e.printStackTrace();
			responseHeader.setCode(HttpStatus.OK.value());// updated to OK to avoid causing exception in parent
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
			commonUtility.createServiceNowTicket("Service_Package_E2m-ECFG failed for CorrelationGuID : "+req.getCorrelationGuid(), e.getMessage(), req.getCorrelationGuid());
			
		}
		
		
		responseData.setCorrelationGuid(req.getCorrelationGuid());
		response.setHeader(responseHeader);
		response.setData(responseData);
		storeAudits(req.getCorrelationGuid(), "SERVICE_PACKAGE_E2M-ECFG","SERVICE_PACKAGE_E2M-ECFG COMPLETED", 1, "regular");
		return response;
	}

	private ServiceE2mResponse startE2mProcess(ServiceE2mEcfgRequestDTO req) throws IOException,  BadRequestException, InterruptedException, ExecutionException {
		ServiceE2mResponse responseData = new ServiceE2mResponse();
		CountAndData success=new CountAndData();
		CountAndData failure=new CountAndData();
		success.setData(new LinkedList<ObjectData>());
		failure.setData(new LinkedList<ObjectData>());
		List<ServiceE2mEcfgDTO> e2mDBDataList =null;
		if (Constants.DAILY.equalsIgnoreCase(req.getMode())) {
			e2mDBDataList = dailyRepo.getDaily();
		}else if (Constants.ONETIME.equalsIgnoreCase(req.getMode())) {
			req.getProductIDList().removeAll(Collections.singletonList(null));
			req.getProductIDList().removeAll(Collections.singletonList(""));
			List<String> productIds = req.getProductIDList();
			e2mDBDataList = onetimeAllRepo.getOntimeAllByProductId(productIds);
		}else if (Constants.ALL.equalsIgnoreCase(req.getMode())) {
			e2mDBDataList = onetimeAllRepo.getOntimeAll();
		}else {
			logger.info("Invalid Mode");
			throw new BadRequestException("Invalid Mode");
		}
		//processing DB results
		if (e2mDBDataList != null && !e2mDBDataList.isEmpty()) {
			Map<String, List<ServiceE2mEcfgDTO>> mapE2mDbList=e2mDBDataList.stream().collect(Collectors.groupingBy(ServiceE2mEcfgDTO::getDdo_Product_id));
			processForFlushFolder(mapE2mDbList.keySet()); //deleting the folders

			ExecutorService delegate = Executors.newFixedThreadPool(paramStore.getThreadLimit());
			MDCExecutorService<ExecutorService> pool=new MDCExecutorService<ExecutorService>(delegate);
			
			List<Callable<Map<String, List<ObjectData>>>> tasks = new ArrayList<>();

			mapE2mDbList.entrySet().forEach(mapE2mDb -> {
				try {
					String dstFolder =commonPS.getRegular().getDrivePath() + paramStore.getE2m_EcfgPath()+ mapE2mDb.getKey() + FOLDER_SEPERATOR;
					if (!new File(dstFolder).exists()) {
						Files.createDirectories(new File(dstFolder).toPath()); //creating directory if not exist
					}
					tasks.add((Callable<Map<String, List<ObjectData>>>) () -> invokeProductCopy(mapE2mDb.getValue(),dstFolder));
				}catch (IOException e) {
					throw new BadRequestException(e.getMessage());
				}
			});
			//logger.info("Invoking copy and encrypt");
			List<Future<Map<String, List<ObjectData>>>> invokeResults=pool.invokeAll(tasks);
			for (Future<Map<String, List<ObjectData>>> future : invokeResults) {
				//logger.info("Processing results");
				Map<String, List<ObjectData>> response=future.get();
				if(!response.get(Constants.SUCCESS).isEmpty()) {
					success.getData().addAll(response.get(Constants.SUCCESS));
				}
				if(!response.get(Constants.FAILURE).isEmpty()) {
					failure.getData().addAll(response.get(Constants.FAILURE));
				}
			}
			success.setCount(success.getData().size());
			failure.setCount(failure.getData().size());
			responseData.setSuccess(success);
			responseData.setFailure(failure);
			logger.info("Results fetched:"+req.getCorrelationGuid());
			//if its not all mode then query DB again to all data.
			if(!Constants.ALL.equalsIgnoreCase(req.getMode())) {
				e2mDBDataList = onetimeAllRepo.getOntimeAll();
			}
			createE2MECFGMetaData(e2mDBDataList);//creating e2m meta data json

		} else {
			logger.info("No data for E2mEcfg");
			throw new BadRequestException("No data for E2mEcfg");
		}
		return responseData;
	}

	private Map<String, List<ObjectData>> invokeProductCopy(List<ServiceE2mEcfgDTO> productE2mDB,String dstFolder){
		logger.info("invokeProductCopy: {}",productE2mDB);
		Map<String, List<ObjectData>> map=new HashMap<>();
		map.put(Constants.SUCCESS, new LinkedList<ObjectData>());
		map.put(Constants.FAILURE, new LinkedList<ObjectData>());
		
		for (ServiceE2mEcfgDTO serviceE2mEcfgDTO : productE2mDB) {
			if ((null == serviceE2mEcfgDTO.getInt_Path()) || serviceE2mEcfgDTO.getInt_Path().isEmpty()) {
				map.get(Constants.FAILURE).add(new ObjectData(serviceE2mEcfgDTO.getDdo_Product_id(), serviceE2mEcfgDTO.getConfig_Part(),null, "File Not Found SourcePath is null"));
			}else {
				try {
					retry.executeCheckedSupplier(()->{ return commonUtility.copyFileToE2M(serviceE2mEcfgDTO.getInt_Path(),dstFolder+serviceE2mEcfgDTO.getCONFIG_EXTN());});
					map.get(Constants.SUCCESS).add(new ObjectData(serviceE2mEcfgDTO.getDdo_Product_id(), serviceE2mEcfgDTO.getConfig_Part(),null,Constants.SUCCESS));
				}catch ( Throwable e) {
					map.get(Constants.FAILURE).add(new ObjectData(serviceE2mEcfgDTO.getDdo_Product_id(), serviceE2mEcfgDTO.getConfig_Part(),null,e.getMessage()));
				}
			}
		}
		return map;
	}

	private void createE2MECFGMetaData(List<ServiceE2mEcfgDTO> e2mDBDataList) throws IOException {
		FileListJson json = new FileListJson();
		List<PIDandFiles> fileList = new ArrayList<PIDandFiles>();
		Map<String, List<ServiceE2mEcfgDTO>> mapE2mDbList=e2mDBDataList.stream().collect(Collectors.groupingBy(ServiceE2mEcfgDTO::getDdo_Product_id));
		mapE2mDbList.entrySet().forEach(mapE2mDb -> {
			PIDandFiles pidandfile = new PIDandFiles();
			List<ECMCodeandFile> ecm = new ArrayList<ECMCodeandFile>();
			pidandfile.setProductId(mapE2mDb.getKey());
			for (ServiceE2mEcfgDTO serviceE2mEcfgDTO : mapE2mDb.getValue()) {
				ECMCodeandFile detailsJson = new ECMCodeandFile();
				detailsJson.setEcmCode(serviceE2mEcfgDTO.getECM_CODE());
				detailsJson.setE2m_ecfg(serviceE2mEcfgDTO.getCONFIG_EXTN());
				ecm.add(detailsJson);
			}
			pidandfile.setFileList(ecm);
			fileList.add(pidandfile);
		});
		json.setE2mecfgmetadata(fileList);
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		String content = ow.writeValueAsString(json);
		if (!Files.exists(Paths.get(commonPS.getRegular().getDrivePath() + paramStore.getE2m_EcfgPath() + "\\E2MECFGMetadata.json"))) {
			Files.createFile(Paths.get(commonPS.getRegular().getDrivePath() + paramStore.getE2m_EcfgPath() + "\\E2MECFGMetadata.json"));
		}
		Files.write(Paths.get(commonPS.getRegular().getDrivePath() + paramStore.getE2m_EcfgPath() + "\\E2MECFGMetadata.json"),
				content.getBytes(StandardCharsets.UTF_8), StandardOpenOption.TRUNCATE_EXISTING);
		AmazonS3 s3 = amazonS3Config.configAmazonS3();
		//String key=paramStore.getE2m_EcfgPath()+"/"+"E2MECFGMetadata.json";
		s3.putObject(commonPS.getRegular().getS3Bucket(),"E2M_ECFG/E2MECFGMetadata.json",new File(commonPS.getRegular().getDrivePath() + paramStore.getE2m_EcfgPath() + "\\E2MECFGMetadata.json"));
		logger.info("uploaded successfully");	
	}

	private void processForFlushFolder(Set<String> productIds) throws IOException {
		try {
			String destinationFolderPath = "";
			// List<CompletableFuture<Void>> completableFutures = new ArrayList<>();
			for (String productId : productIds) {
				destinationFolderPath =commonPS.getRegular().getDrivePath() + paramStore.getE2m_EcfgPath()+ productId + FOLDER_SEPERATOR;
				Path destinationPath = Paths.get(destinationFolderPath);
				if (!Files.exists(destinationPath)) {
					Files.createDirectories(destinationPath);
				}
				File deleteFolderPath = new File(destinationFolderPath);
				FileUtils.cleanDirectory(deleteFolderPath);
				String key = "E2M_ECFG/" + productId + "/";
				AmazonS3 s3 = amazonS3Config.configAmazonS3();
				for (S3ObjectSummary file : s3.listObjects(commonPS.getRegular().getS3Bucket(), key).getObjectSummaries()) {
					s3.deleteObject(commonPS.getRegular().getS3Bucket(), file.getKey());
				}
				logger.info("folder flush operation succesfull for ProductId:{}-", productId);
			}
		} catch (IOException e) {
			logger.info("folder flush operation failed :{}",e.getMessage());
		}
	}

	private void storeAudits(String guid, String audActivity, String audSubActivity, int audStatus, String mode) {
		String dbData = "";
		if (mode.contains(",")) {
			dbData = "ProductMode";
		} else {
			dbData = mode;
		}
		TAuditTable auditEntity = new TAuditTable();
		TAuditKey key = new TAuditKey();
		key.setAudActivitId("SD");
		key.setAudDate(LocalDateTime.now());
		key.setAudSubActivity(audSubActivity);
		key.setAudFunctionId("SD");
		key.setAudSubCode(dbData);
		key.setAudSubFunctionId(" ");
		key.setAudCode(" ");
		key.setAudDetails(" ");
		key.setAudActivity(audActivity);
		key.setAudLastUpdateUser(itAuditRepository.getUserFromDB());
		key.setAudLastUpdateDate(LocalDateTime.now());
		key.setAudRequestId(guid);
		key.setAudStatus(audStatus);
		auditEntity.setKey(key);
		itAuditRepository.save(auditEntity);
	}
}
