package com.cummins.servicepkg.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonPropertyOrder({
  "fileType",
  "namingConvention"
})
@Data
public class NamingConvention {

  @JsonProperty("fileType")
  private String fileType;

  @JsonProperty("namingConvention")
  private String namingConvention;
}
