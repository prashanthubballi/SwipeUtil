package com.cummins.servicepkg.dto;

public interface ServiceE2mEcfgDTO {

	public String getDdo_Product_id();
	public String getConfig_Part();
	public String getCONFIG_EXTN();
	public String getExt_Path();
	public String getInt_Path();
	public String getProduct_Compliance();
	public String getECM_CODE();
	
}
