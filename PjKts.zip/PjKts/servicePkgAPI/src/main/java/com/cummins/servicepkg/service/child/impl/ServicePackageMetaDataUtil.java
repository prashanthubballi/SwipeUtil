package com.cummins.servicepkg.service.child.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cummins.servicepkg.dto.BRERuleSetDetails;
import com.cummins.servicepkg.dto.CommonParamStore;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.dto.ServicePkgDto;
import com.cummins.servicepkg.meta.dto.CopyDTO;
import com.cummins.servicepkg.meta.dto.JsonDTO;
import com.cummins.servicepkg.meta.dto.ServiceAttributeDTO;
import com.cummins.servicepkg.repository.ServiceRepoUtil;
import com.cummins.servicepkg.service.cal.impl.MDCExecutorService;

@Service
public class ServicePackageMetaDataUtil {

	@Autowired
	private ParamStore paramStore;
	@Autowired
	private CommonParamStore commonParamStore;
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ServiceRepoUtil serviceRepoUtil;

	
	private static final Logger logger = LoggerFactory.getLogger(ServicePackageMetaDataUtil.class);


	public String generateMetaData(BRERuleSetDetails ruleSetConfig,List<String> productIds,String guid) {
		List<String> results=new LinkedList<String>();
		
		try {
			
			List<ServicePkgDto> convertedResultSet=serviceRepoUtil.getOnetimeALLActiveCals(ruleSetConfig, productIds);
			//List<ServicePkgDto> convertedResultSet=commonUtility.setServiceDownloadDataList(resultSet);
			Map<String, List<ServicePkgDto>> productWiseData=convertedResultSet.stream().collect(Collectors.groupingBy(ServicePkgDto::getProductid));
			ExecutorService delegate = Executors.newFixedThreadPool(20);
			MDCExecutorService<ExecutorService> pool=new MDCExecutorService<ExecutorService>(delegate);
			List<Callable<String>> tasks=new ArrayList<>();
			for (String productId : productWiseData.keySet()) {
				tasks.add((Callable<String>) () -> processAsPerProduct(productWiseData.get(productId),productId, guid));
			}
			List<Future<String>> invokeResults=pool.invokeAll(tasks);
			for (Future<String> future : invokeResults) {
				results.add(future.get());
			}
			return results.toString();
		}catch (InterruptedException e) {
			e.printStackTrace();
			return "Error:MetaData generation failed:"+e.getMessage();
		} catch (Exception e) {
			e.printStackTrace();
			return "Error:MetaData generation failed:"+e.getMessage();
		}
	}


	private String processAsPerProduct(List<ServicePkgDto> productData,String productId,String guid) {
		List<ServiceAttributeDTO> serviceAttribute = new ArrayList<>();

		JsonDTO json = null;

		if (!productData.isEmpty()) {

			serviceAttribute = productData.stream().filter(i -> !i.getCalgenname().equalsIgnoreCase("A_FILE"))
					.map(i -> new ServiceAttributeDTO(i.getEcmcode(), i.getBaseecm(), i.getCallgenpath()))
					.collect(Collectors.toList());
			serviceAttribute.addAll(productData.stream().filter(i -> i.getCalgenname().equalsIgnoreCase("A_FILE"))
					.map(i -> new ServiceAttributeDTO(i.getAfile(), format(i.getAfile()),
							i.getCallgenpath()))
					.collect(Collectors.toList()));
			json = new JsonDTO(productId, serviceAttribute);
			logger.info("JSON data preparation done for productId:"+productId);
			return processForJsonFile(json, guid,productId);
		}
		return "Product List is empty";
	}
	private String format(String a_FILE_PART) {
		return a_FILE_PART.contains(".") ? a_FILE_PART.substring(0, a_FILE_PART.indexOf(".")) : a_FILE_PART;
	}

	private <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor)
	{
		Map<Object, Boolean> map = new ConcurrentHashMap<>();
		return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}

	private String processForJsonFile(JsonDTO json, String productCorrelationId,String productId) {
		try {
			String filepath =commonParamStore.getRegular().getDrivePath() + paramStore.getServiceMetadataPath() + json.getProductId() + "_ServiceMetadata.json";
			JsonDTO data= new JsonDTO();
			data.setProductId(json.getProductId());
			data.setCalibrationMetadataList(json.getCalibrationMetadataList().stream().filter(distinctByKey(p->p.getECM_CODE())).collect(Collectors.toList()));
			//	      System.out.println(data);
			File f = new File(filepath);
			f.createNewFile();
			Path filename = Path.of(filepath);
			Files.writeString(filename, data.toString());
			logger.info("file operation succesful for :" + productId);
			logger.info("Reverse Sync Started.");
			String url=commonParamStore.getRegular().getHostName()+paramStore.getOutBoundSycUrl();
			ResponseEntity<String> response=restTemplate.postForEntity(	url, new CopyDTO(filepath.replace("G:\\", ""),false), String.class);
			logger.info(response.getBody());
			return "file operation succesful for product: " +productId;
		} catch (IOException e) {
			logger.info("file operation failed for " + productId);
			logger.error("reason for failure - " + e.toString());
			return "file operation failed for " + productId+":"+e.getMessage();
		} catch (Exception e) {
			logger.info("file operation failed for :  " + productId);
			logger.error("reason for failure - " + e.toString());
			return "file operation failed for " + productId+":"+e.getMessage();
		}
	}

}
