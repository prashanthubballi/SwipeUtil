package com.cummins.servicepkg.child.dto;

import lombok.Data;

@Data
public class SupportFilesPath {
	private String productId;
	private String destinationPath;
	private String sourcePath;
}
