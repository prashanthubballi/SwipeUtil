package com.cummins.servicepkg.repository;

import java.util.List;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import com.cummins.servicepkg.dto.ServiceE2mEcfgDTO;
import com.cummins.servicepkg.model.VServiceE2mEcfgOneTimeallKey;
import com.cummins.servicepkg.model.VServiceE2mEcfgOnetimeall;

@Repository
public interface ServiceE2mEcfgOneTimeAllRepo
		extends JpaRepository<VServiceE2mEcfgOnetimeall, VServiceE2mEcfgOneTimeallKey> {

	@Query(value = "select DISTINCT v.PRODUCT_ID as DDO_PRODUCT_ID ,v.CONFIG_PART as CONFIG_PART,"
			+ " v.CONFIG_EXTN as CONFIG_EXTN,v.INT_PATH as INT_PATH from V_SERVICE_E2M_ECFG_ONETIMEALL v where PRODUCT_COMPLIANCE='R' "
			+ " order by DDO_PRODUCT_ID", nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "50000"))
	List<ServiceE2mEcfgDTO> getOntimeAll();

	@Query(value = "select DISTINCT v.PRODUCT_ID as DDO_PRODUCT_ID ,v.CONFIG_PART as CONFIG_PART,"
			+ " v.CONFIG_EXTN as CONFIG_EXTN,v.INT_PATH as INT_PATH from V_SERVICE_E2M_ECFG_ONETIMEALL v where PRODUCT_COMPLIANCE='R' "
			+ " and v.PRODUCT_ID IN (?1) order by DDO_PRODUCT_ID", nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500000"))
	List<ServiceE2mEcfgDTO> getOntimeAllByProductId(List<String> PIDs);
}
