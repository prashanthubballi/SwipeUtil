package com.cummins.servicepkg.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ParamStore {

	@JsonProperty("serviceNowAPI")
	private String serviceNowAPI;
	@JsonProperty("serviceNowAssignmentGrp")
	private String serviceNowAssignmentGrp;
	@JsonProperty("serviceNowImpact")
	private String serviceNowImpact;
	@JsonProperty("serviceNowUrgency")
	private String serviceNowUrgency;
	
	@JsonProperty("tcalUrl")
	private String tcalUrl;
	
	@JsonProperty("e2m_EcfgPath")
	private String e2m_EcfgPath;
	
	@JsonProperty("tcalPath")
	private String tcalPath;
	
	@JsonProperty("threadLimit")
	private int threadLimit;
	
	@JsonProperty("delThreadLimit")
	private int delThreadLimit;

	@JsonProperty("servicePkgCalibrationDeletionAPI")
	private String servicePkgCalibrationDeletionAPI;
	
	@JsonProperty("servicePkgCalibrationAdditionAPI")
	private String servicePkgCalibrationAdditionAPI;

	@JsonProperty("outBoundSycUrl")
	private String outBoundSycUrl;

	@JsonProperty("encryptionApi")
	private String encryptionApi;

	@JsonProperty("encryption")
	private Encryption encryption;

	@JsonProperty("serviceMetadataPath")
	private String serviceMetadataPath;

	@JsonProperty("namingConvention")
	private List<NamingConvention> namingConvention;

	@JsonProperty("servicePathData")
	private List<ServicePathData> servicePathData;

	@JsonProperty("reverseSyncFolderPath")
	private List<String> reverseSyncFolderPath;
	
	@JsonProperty("csarCsuCalFilesFolderPath")
	private String csarCsuCalFilesFolderPath;
	@JsonProperty("csarCsuSupportFilesFolderPath")
	private String csarCsuSupportFilesFolderPath;
	@JsonProperty("csarCsuCsvFilePath")
	private String csarCsuCsvFilePath;
	@JsonProperty("itemFilePath")
	private String itemFilePath;
	

	@JsonProperty("resilience4j")
	private Resilience4j resilience4j;
}
