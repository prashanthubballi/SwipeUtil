package com.cummins.servicepkg.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="T_DISTRIBUTION_RULE_SET")
@NamedQuery(name="TDistributionRuleSet.findAll", query="SELECT t FROM TDistributionRuleSet t")
public class TDistributionRuleSet implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId private TDistributionRuleSetKey Id;

}