package com.cummins.servicepkg.child.dto;

import lombok.Data;

@Data

public class EncryptionRequest {
  public String executableFilePath;
  public String calibrationFilePath;
  public String serviceFilePath;
  public String logFilePath;
  public String encryptionType;

  public EncryptionRequest(String executableFilePath, String calibrationFilePath, String serviceFilePath,
    String logFilePath, String encryptionType) {

    this.executableFilePath = executableFilePath;
    this.calibrationFilePath = calibrationFilePath;
    this.serviceFilePath = serviceFilePath;
    this.logFilePath = logFilePath;
    this.encryptionType = encryptionType;
  }

  public String getExecutableFilePath() {
    return executableFilePath;
  }

  public void setExecutableFilePath(String executableFilePath) {
    this.executableFilePath = executableFilePath;
  }

  public String getCalibrationFilePath() {
    return calibrationFilePath;
  }

  public void setCalibrationFilePath(String calibrationFilePath) {
    this.calibrationFilePath = calibrationFilePath;
  }

  public String getServiceFilePath() {
    return serviceFilePath;
  }

  public void setServiceFilePath(String serviceFilePath) {
    this.serviceFilePath = serviceFilePath;
  }

  public String getLogFilePath() {
    return logFilePath;
  }

  public void setLogFilePath(String logFilePath) {
    this.logFilePath = logFilePath;
  }

  public String getEncryptionType() {
    return encryptionType;
  }

  public void setEncryptionType(String encryptionType) {
    this.encryptionType = encryptionType;
  }

}
