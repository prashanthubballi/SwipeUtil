package com.cummins.servicepkg.dto;

import java.util.List;

import lombok.Data;

@Data
public class RequestServiceLayoutDistribution {

	
	private String mode;
	
	private String correlationGuid;
	private List<String> productIDList;

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getCorrelationGuid() {
		return correlationGuid;
	}

	public void setCorrelationGuid(String correlationGuid) {
		this.correlationGuid = correlationGuid;
	}

	

}
