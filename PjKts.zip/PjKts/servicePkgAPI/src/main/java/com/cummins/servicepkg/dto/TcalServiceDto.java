package com.cummins.servicepkg.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TcalServiceDto {

	private String productid;
	private String ecmcode;
	private String oldecmcode;
	private String e2mecfgpart;
	private String esdnflag;
	private String npbuflag;
	private String afile;
	private String phasecode;
	private String effectcode;
}
