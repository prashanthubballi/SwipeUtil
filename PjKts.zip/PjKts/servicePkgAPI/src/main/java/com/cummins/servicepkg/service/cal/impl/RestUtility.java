package com.cummins.servicepkg.service.cal.impl;

import java.util.Date;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.github.resilience4j.retry.annotation.Retry;

@Service
public class RestUtility {

	@Autowired
	private RestTemplate restTemplate;

	

	private static final Logger logger = LoggerFactory.getLogger(RestUtility.class);
	ObjectMapper mapper=new ObjectMapper();

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Retry(name = "throwingException", fallbackMethod = "getFallBack")
	public String callChildApi(String requestDTO,String guid,String api,String url)  {
		ResponseEntity<Object> apiResponse = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity requestEntity = new HttpEntity(requestDTO, headers);
		logger.info("Requesting url : "+url);
		apiResponse= restTemplate.postForEntity(url,requestEntity,Object.class,guid);
		logger.info(new Date()+"##Thread Completed: ");
		// Check the response and increment success count if needed
		if (apiResponse != null && apiResponse.getStatusCode().is2xxSuccessful()) {
			String responseString=null;
			try {
				responseString = mapper.writeValueAsString(apiResponse.getBody());
			} catch (JsonProcessingException e) {
				responseString="ERROR:"+e.getMessage();
				logger.error(e.getMessage());
			}
			logger.info("RESPONSE1:"+api+":"+responseString);
			return responseString;
		}
		return "ERROR:";
	}
	public String getFallBack(String requestDTO,String guid,String api,String url,Exception e) {
		return handleExeptions(requestDTO,guid,api,url,e);
	}

	private String handleExeptions(String requestDTO,String guid,String api,String url,Exception e) {
		logger.info("inside fallback method");
		if (e instanceof HttpStatusCodeException) {
			String childResponseData=((HttpStatusCodeException) e).getResponseBodyAsString();
			logger.info("RESPONSE1:"+api+":"+childResponseData);
			if(((HttpStatusCodeException) e).getStatusCode().is5xxServerError() ||
					((HttpStatusCodeException) e).getStatusCode().is4xxClientError()) {
				return "ERROR:Service Error:"+((HttpStatusCodeException) e).getStatusCode().toString()+":"+childResponseData;
			}
			return childResponseData;
		}else {
			return "ERROR:"+e.getMessage();
		}
		
	}
	public void reverseSync(String url,String path) {
	/*	try {
			logger.info("Reverse Sync Started.");
			restTemplate.getForEntity(url+"/"+path, String.class);
		} catch (Exception e) {
			logger.error("Exception in reverse sync:" + e.getMessage());
		} */
		
		//below code uses copy command.
		try {
		//	CopyDTO req=new CopyDTO(path, false);
		
		//	logger.info("Reverse Sync Started:"+req);
		//	ResponseEntity<String> response=new RestTemplate().postForEntity(url, req, String.class);
		//	logger.info(response.getBody());
			
			
		} catch (Exception e) {
			logger.error("Exception in reverse sync:" + e.getMessage());
		}
	}
}
