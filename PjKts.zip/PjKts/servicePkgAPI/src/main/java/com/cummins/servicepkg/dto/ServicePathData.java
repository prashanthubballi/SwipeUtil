package com.cummins.servicepkg.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonPropertyOrder({
  "category",
  "product",
  "folderPath"
})
@Data
public class ServicePathData {

  @JsonProperty("category")
  private String category;

  @JsonProperty("product")
  private String product;

  @JsonProperty("folderPath")
  private String folderPath;

}
