package com.cummins.servicepkg.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * The persistent class for the T_PRODUCT_LIST database table.
 * 
 */

@Entity
@Table(name = "T_PRODUCT_LIST")
 
public class TProductList implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private TProductListTableKey id;

	public void save(String mode) {
		 
		
	}
}
