package com.cummins.servicepkg.service.child.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.servicepkg.child.dto.ServicePkgCalAddByProductRequest;
import com.cummins.servicepkg.common.ChildAPI;
import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.common.CountAndData;
import com.cummins.servicepkg.dto.BRERuleSetDetails;
import com.cummins.servicepkg.dto.CommonParamStore;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.dto.ServicePkgCalibrationRequest;
import com.cummins.servicepkg.dto.ServicePkgDto;
import com.cummins.servicepkg.exception.BadRequestException;
import com.cummins.servicepkg.repository.ServiceRepoUtil;
import com.cummins.servicepkg.service.cal.impl.CommonUtility;
import com.cummins.servicepkg.service.cal.impl.MDCExecutorService;

@Service
public class ServicePackageAddUtil {

	@Autowired
	private ParamStore paramStore;
	
	@Autowired
	private CommonParamStore commonParamStore;

	@Autowired
	private CommonUtility commonUtility;

	@Autowired
	private ServiceRepoUtil serviceRepoUtil;


	private static final Logger logger = LoggerFactory.getLogger(ServicePackageAddUtil.class);


	public ChildAPI processServicePkgAddition(BRERuleSetDetails ruleSetConfig,ServicePkgCalibrationRequest req,List<String> productIdList) {

		
		List<ServicePkgDto> convertedResultSet =null;
		try {
			
			if (Constants.DAILY.equalsIgnoreCase(req.getMode())) {
				convertedResultSet=serviceRepoUtil.getDailyServiceActiveCals(ruleSetConfig);
				logger.info("Running mode:"+req.getMode()+",resultSetSize:"+convertedResultSet.size());
				//List<ServicePkgDto> convertedResultSet=commonUtility.setServiceDownloadDataList(resultSet);
				return ProcessMainCollection(req, convertedResultSet, productIdList);
			}else if (Constants.ONETIME.equalsIgnoreCase(req.getMode())) {
				convertedResultSet=serviceRepoUtil.getOnetimeALLActiveCals(ruleSetConfig, req.getProductIdList());
				logger.info("Running mode:"+req.getMode()+",resultSetSize:"+convertedResultSet.size());
				//List<ServicePkgDto> convertedResultSet=commonUtility.setServiceDownloadDataList(resultSet);
				return ProcessMainCollection(req, convertedResultSet, null);
			}else if (Constants.ALL.equalsIgnoreCase(req.getMode())) {
				convertedResultSet=serviceRepoUtil.getOnetimeALLActiveCals(ruleSetConfig, null); // for all more passing product id as null
				logger.info("Running mode:"+req.getMode()+",resultSetSize:"+convertedResultSet.size());
				//List<ServicePkgDto> convertedResultSet=commonUtility.setServiceDownloadDataList(resultSet);
				return ProcessMainCollection(req, convertedResultSet, null);
			}   
			throw new BadRequestException("In valid request mode:"+req.getMode());
		}catch (Exception e) {
			logger.error(e.getMessage());
			throw new BadRequestException("Exception in BRE rulSet"+e.getMessage());
		}
	}

	private List<ServicePkgDto> removeDuplicateAFile(List<ServicePkgDto> serviceDownloadDataList) {
		List<ServicePkgDto> AfileList = serviceDownloadDataList.stream()
	            .filter(data -> data.getCalgenname().equalsIgnoreCase("A_FILE"))
	            .collect(Collectors.toList());
		List<ServicePkgDto> nonAfileList = serviceDownloadDataList.stream()
				.filter(data -> !data.getCalgenname().equalsIgnoreCase("A_FILE"))
				.collect(Collectors.toList());

        Map<String, ServicePkgDto> uniqueAfileMap = AfileList.stream()
            .collect(Collectors.toMap(
                ServicePkgDto::getAfile,Function.identity(),
                (existing, replacement) -> existing // Keep the existing entry if a duplicate is found
            ));

        List<ServicePkgDto> uniqueNonNullAfileList = uniqueAfileMap.values().stream().collect(Collectors.toList());
        
        return Stream.concat(uniqueNonNullAfileList.stream(), nonAfileList.stream())
                .collect(Collectors.toList());
    }

	private ChildAPI ProcessMainCollection(ServicePkgCalibrationRequest request,List<ServicePkgDto> resultSet, List<String> productIdListForMETADATA){
		ChildAPI childCalibration=new ChildAPI();
		CountAndData success=new CountAndData();
		CountAndData failure=new CountAndData();
		childCalibration.setFailure(failure);
		childCalibration.setSuccess(success);
		List<ChildAPI> allResult=new LinkedList<>();
		System.out.println(resultSet.size());
		List<ServicePkgDto> filteredResultSet = removeDuplicateAFile(resultSet);
		System.out.println(filteredResultSet.size());
		
		logger.info("Number of records to add Converted:"+filteredResultSet.size());
		List<ServicePkgDto> resultSetNonMAF = filteredResultSet.stream().filter(m -> !m.getCalgenname().equalsIgnoreCase("MAF") && !m.getBootflag().equalsIgnoreCase("Y")).collect(Collectors.toList());

		List<ServicePkgDto> resultSetMAF = filteredResultSet.stream().filter(m -> m.getCalgenname().equalsIgnoreCase("MAF")).collect(Collectors.toList());

		List<ServicePkgDto> resultSetBootSign = filteredResultSet.stream().filter(m -> m.getBootflag().equalsIgnoreCase("Y")).collect(Collectors.toList());

		//Normal products
		if (resultSetNonMAF != null && !resultSetNonMAF.isEmpty()) {
			logger.info("Number of records to add Normal:"+resultSetNonMAF.size());
			ChildAPI productResult= processCollection(resultSetNonMAF, request,"Other");
			allResult.add(productResult);
		}
		//MAF products
		if (resultSetMAF != null && !resultSetMAF.isEmpty()) {
			logger.info("Number of records to add MAF:"+resultSetMAF.size());
			ChildAPI productResult= processCollection(resultSetMAF, request,"MAF");//forMAF pass false as boolean value
			allResult.add(productResult);
		}
		//processBootSignFlow
		if (resultSetBootSign != null && !resultSetBootSign.isEmpty()) {
			logger.info("Number of records to add Boot:"+resultSetBootSign.size());
			ChildAPI productResult= processCollection(resultSetBootSign, request,"BootSign");
			allResult.add(productResult);
		}
		for (ChildAPI childApi : allResult) {
			if(null!=childApi.getFailure() && !childApi.getFailure().getData().isEmpty()) {
				childCalibration.getFailure().getData().addAll(childApi.getFailure().getData());
				childCalibration.getFailure().setCount(childCalibration.getFailure().getData().size());
			}
			if(null!=childApi.getSuccess() && !childApi.getSuccess().getData().isEmpty()) {
				childCalibration.getSuccess().getData().addAll(childApi.getSuccess().getData());
				childCalibration.getSuccess().setCount(childCalibration.getSuccess().getData().size());
			}
		}

		return childCalibration;
	}

	private ChildAPI processCollection(List<ServicePkgDto> dataList,ServicePkgCalibrationRequest request,String type) {
		ChildAPI childCalibration=new ChildAPI();
		logger.info("Received Product List size: " + dataList.size()+",Type:"+type);
		if (dataList != null && !dataList.isEmpty()) {
			List<ServicePkgCalAddByProductRequest> regCalAddRequest=new LinkedList<>();
			List<ServicePkgCalAddByProductRequest> expCalAddRequest=new LinkedList<>();
			ExecutorService delegate = Executors.newFixedThreadPool(2);
			MDCExecutorService<ExecutorService> pool=new MDCExecutorService<ExecutorService>(delegate);
			List<Callable<List<ChildAPI>>> servicePkgCalAddList=new LinkedList<>();
			int count=1;
			//true contains exportControl products, false contains regular products
			Map<Boolean, List<ServicePkgDto>> allAddProducts =dataList.stream().collect(Collectors.partitioningBy(dto -> Constants.EXPORT.equalsIgnoreCase(dto.getProductcompliance())));
			for (boolean isECProducts : allAddProducts.keySet()) {
				List<ServicePkgDto> splitAddProducts=allAddProducts.get(isECProducts);
				if(null!=splitAddProducts && !splitAddProducts.isEmpty()) {
					logger.info("Received Product List size:" + splitAddProducts.size()+",Type:"+type+",isExport:"+isECProducts);
					Map<String, List<ServicePkgDto>> productWiseData=splitAddProducts.stream().collect(Collectors.groupingBy(ServicePkgDto::getProductid));
					for (String productId : productWiseData.keySet()) {
						List<ServicePkgDto> productData= productWiseData.get(productId);

						if(!"Other".equalsIgnoreCase(type)) {
							Map<String, List<ServicePkgDto>> ecmDetails=null;
							//boot sign and MAF processed here
							if("BootSign".equalsIgnoreCase(type)) {
								ecmDetails=productData.stream().collect(Collectors.groupingBy(ServicePkgDto::getBaseecm));
							}else {
								ecmDetails=productData.stream().filter(dto-> null!=dto.getPartintpath()).collect(Collectors.groupingBy(ServicePkgDto::getEcmcode));
							}
							//filter by ecm here and then call child
							for (String ecmCode : ecmDetails.keySet()) {
								List<ServicePkgDto> ecmwiseData=ecmDetails.get(ecmCode);
								if(isECProducts) {
									expCalAddRequest.add(new ServicePkgCalAddByProductRequest(type,request.getCorrelationGuid()+"#"+count,null, ecmwiseData));

								}else {
									regCalAddRequest.add(new ServicePkgCalAddByProductRequest(type,request.getCorrelationGuid()+"#"+count,null, ecmwiseData));
								}
								count++;
							}
						}else {
							//other products processed here
							if(!isECProducts) {
								deleteJsonFile(productId);
							}
							for (ServicePkgDto data : productData) {
								if(isECProducts) {
									expCalAddRequest.add(new ServicePkgCalAddByProductRequest("Other",request.getCorrelationGuid()+"#"+count, data,null));
								}else {
									regCalAddRequest.add(new ServicePkgCalAddByProductRequest("Other",request.getCorrelationGuid()+"#"+count, data,null));
								}	
								count++;
							}
						}
					}
					if(isECProducts) {
						servicePkgCalAddList.add((Callable<List<ChildAPI>>) () -> invokeChild(expCalAddRequest,isECProducts));
						logger.info("Received Task size: " + expCalAddRequest.size()+",Type:"+type+",isExport:"+isECProducts);
					}else {
						servicePkgCalAddList.add((Callable<List<ChildAPI>>) () -> invokeChild(regCalAddRequest,isECProducts));
						logger.info("Received Task size: " + regCalAddRequest.size()+",Type:"+type+",isExport:"+isECProducts);
					}
				}
			}
			if(!servicePkgCalAddList.isEmpty()) {
				try {
					List<Future<List<ChildAPI>>> invokeResults=pool.invokeAll(servicePkgCalAddList);
					for (Future<List<ChildAPI>> future : invokeResults) {
						List<ChildAPI> childAPIList=future.get();
						for (ChildAPI childApi : childAPIList) {
							if(null!=childApi.getFailure() && !childApi.getFailure().getData().isEmpty()) {
								childCalibration.getFailure().getData().addAll(childApi.getFailure().getData());
								childCalibration.getFailure().setCount(childCalibration.getFailure().getData().size());
							}
							if(null!=childApi.getSuccess() && !childApi.getSuccess().getData().isEmpty()) {
								childCalibration.getSuccess().getData().addAll(childApi.getSuccess().getData());
								childCalibration.getSuccess().setCount(childCalibration.getSuccess().getData().size());
							}
						}
					}
				} catch (InterruptedException | ExecutionException e) {
					e.printStackTrace();
					logger.error("Exception in Threadpool :"+request+","+e.getMessage());
				}
			}
			pool.shutdown();
			logger.info("Pool shutdown status:"+pool.isShutdown());
		}
		return childCalibration; 
	}	

	private List<ChildAPI> invokeChild(List<ServicePkgCalAddByProductRequest> req,boolean isExport) {
		List<ChildAPI> calibrationChildApis=new LinkedList<>();
		logger.info("Thread pool size:"+paramStore.getThreadLimit());
		ExecutorService delegate = Executors.newFixedThreadPool(paramStore.getThreadLimit());
		MDCExecutorService<ExecutorService> pool=new MDCExecutorService<ExecutorService>(delegate);
		List<Callable<ChildAPI>> tasks=new ArrayList<>();
		logger.info("Invoke Child :isExport:"+isExport+", Size:"+req.size());
		for (ServicePkgCalAddByProductRequest data : req) {
			if("Other".equalsIgnoreCase(data.getType())) {
				logger.info("Executing for ,Product:"+data.getProduct().getProductid()+",EcmCode:"+data.getProduct().getEcmcode());
				if(isExport) {
					String url=commonParamStore.getExportControl().getHostName()+paramStore.getServicePkgCalibrationAdditionAPI();
					tasks.add((Callable<ChildAPI>) () -> commonUtility.callChildAPI(data, data.getCorrelationGuid(), url, Constants.ADDITION));
				}else {
					//String url=commonParamStore.getRegular().getHostName()+paramStore.getServicePkgCalibrationAdditionAPI();
					//for regular passing url as null so that internal method will be called.
					tasks.add((Callable<ChildAPI>) () -> commonUtility.callChildAPI(data, data.getCorrelationGuid(), null, Constants.ADDITION) );
				}
			}else {
				logger.info("Executing for ,Product:"+data.getProducts().get(0).getProductid()+",EcmCode:"+data.getProducts().get(0).getEcmcode());
				if(isExport) {
					String url=commonParamStore.getExportControl().getHostName()+paramStore.getServicePkgCalibrationAdditionAPI();
					tasks.add((Callable<ChildAPI>) () -> commonUtility.callChildAPI(data, data.getCorrelationGuid(),url, Constants.ADDITION));
				}else {
					//String url=commonParamStore.getRegular().getHostName()+paramStore.getServicePkgCalibrationAdditionAPI();
					//for regular passing url as null so that internal method will be called.
					tasks.add((Callable<ChildAPI>) () -> commonUtility.callChildAPI(data, data.getCorrelationGuid(), null, Constants.ADDITION) );
				}
			}

		}
		logger.info("Number of Cals:"+tasks.size()+",isExport:"+isExport);
		List<Future<ChildAPI>> invokeResults;
		try {
			invokeResults = pool.invokeAll(tasks);
			for (Future<ChildAPI> future : invokeResults) {
				try {
					calibrationChildApis.add(future.get());
				} catch (InterruptedException e) {
					e.printStackTrace();
					logger.error("Error in Getting child result:"+e.getMessage());
				} catch (ExecutionException e) {
					e.printStackTrace();
					logger.error("Error in Getting child result:"+e.getMessage());
				}			
			}
		} catch (InterruptedException e1) {
			e1.printStackTrace();
			logger.error("Error in threadpool:"+e1.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("Error in threadpool:"+e.getMessage());
		}

		pool.shutdown();
		logger.info("Pool shutdown status:"+pool.isShutdown());
		return calibrationChildApis;
	}


	private void deleteJsonFile(String productId) {
		String FOLDER_SEPERATOR = "\\";
		try {
			String deletePath = commonParamStore.getRegular().getDrivePath()+ "Service_Metadata" + FOLDER_SEPERATOR
					+ productId;
			File deleteFile = new File(deletePath + "_ServiceMetadata.json");
			if (deleteFile.exists()) {
				logger.info("Delete Meta deta Json File : {}", deletePath);
				FileUtils.delete(new File(deletePath + "_ServiceMetadata.json"));
			}
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	}
}
