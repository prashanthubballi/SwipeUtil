package com.cummins.servicepkg.service.child.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.cummins.servicepkg.child.dto.ServicePkgCalAddByProductRequest;
import com.cummins.servicepkg.child.dto.ServicePkgCalibrationChildResponse;
import com.cummins.servicepkg.child.dto.ServicePkgCalibrationDelRequest;
import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.common.CountAndData;
import com.cummins.servicepkg.common.ObjectData;
import com.cummins.servicepkg.config.AmazonS3Config;
import com.cummins.servicepkg.dto.CommonParamStore;
import com.cummins.servicepkg.dto.CommonParamStore.Mode;
import com.cummins.servicepkg.dto.NamingConvention;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.dto.ServicePkgDto;
import com.cummins.servicepkg.dto.ServicePathData;
import com.cummins.servicepkg.exception.BadRequestException;
import com.cummins.servicepkg.exception.BusinessException;
import com.cummins.servicepkg.meta.dto.CopyDTO;
import com.cummins.servicepkg.service.cal.impl.RestUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.ZipParameters;

@Service
public class CalibrationCommonUtility {

	@Autowired
	private ParamStore paramStore;

	@Autowired
	private CommonParamStore commonParamStore;
	
	@Value("${mode}")
	private String mode;
	
	

	@Autowired
	private RestUtility restUtility;

	@Autowired
	private AmazonS3Config amazonS3Config;
	
	@Autowired
	private RestTemplate restTemplate;

	private static final Logger logger = LoggerFactory.getLogger(CalibrationCommonUtility.class);

	private static final String Folder_Seperator = "\\";

	ObjectMapper mapper=new ObjectMapper();



	public String callChildAPI(Object req, String guid, String url, String api) {
		try {
			String requestString = mapper.writeValueAsString(req);
			logger.info("REQUEST:" + api + ":" + requestString);
			String response = restUtility.callChildApi(requestString, guid, api, url);
			return response;
		} catch (JsonProcessingException e) {
			logger.error("PkgCalAPICall:" + e.getMessage());
			return "ERROR:"+guid + "PkgCalAPICall:" + e.getMessage();
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("PkgCalAPICall:" + e.getMessage());
			return "ERROR:"+guid + "PkgCalAPICall:" + e.getMessage();
		}
	}

	public String zipECMFile(List<ServicePkgDto> list) throws IOException {
		Mode currentMode=null;
		if (mode.equalsIgnoreCase("regular")) {
			currentMode = commonParamStore.getRegular();
		} else {
			currentMode = commonParamStore.getExportControl();
		}
		logger.info("Folder zip started:"+list);
		String outPutFileDir = currentMode.getDrivePath() + "PROCESSING\\Service\\"
				+ list.get(0).getProductid() + Folder_Seperator + list.get(0).getBaseecm().trim() + Folder_Seperator;
		Files.createDirectories(Paths.get(outPutFileDir));

		String outPutFileName = currentMode.getDrivePath() + "PROCESSING\\Service\\"
				+ list.get(0).getProductid() + Folder_Seperator + list.get(0).getEcmcode().trim();
		List<File> filesToAdd=new ArrayList<>();
		for (ServicePkgDto data : list) {
			File sourceFile = new File(data.getPartintpath());
			if(sourceFile.exists()) {
				filesToAdd.add(sourceFile);
			}else {
				throw new BadRequestException("Source file not found at:"+sourceFile);
			}
		}

		if(new File(outPutFileName).exists()) {
			boolean status=new File(outPutFileName).delete();
			logger.info("Deleting existing zip in "+outPutFileName+",status:"+status);
		}
		ZipParameters parameters = new ZipParameters();
		parameters.setIncludeRootFolder(false);
		try (ZipFile zipFile = new ZipFile(outPutFileName); ) {
			zipFile.addFiles(filesToAdd, parameters);
		}
		logger.info("Folder zip completed:"+outPutFileName);
		return outPutFileName;
	}


	public String delFolder(String path,String guid, boolean isCsarProduct, String csarPath) throws IOException {
		Mode currentMode=null;
		if("regular".equalsIgnoreCase(mode)) {
			currentMode=commonParamStore.getRegular();
		}else {
			currentMode=commonParamStore.getExportControl();
		}

		String destination = currentMode.getDrivePath() + path + Constants.Folder_Seperator;
		Path destinationPath = Paths.get(destination);
		if (Files.exists(destinationPath)) {
			boolean status=FileSystemUtils.deleteRecursively(new File(destination));
			logger.info("Deleting folder :"+destinationPath+", status:"+status);
			Files.createDirectories(destinationPath);
		}

		String destinationkey = path + Constants.Folder_Seperator;
		String key = destinationkey.replace(Constants.Folder_Seperator, "/");

		String bucket=currentMode.getS3Bucket();
		AmazonS3 s3 = amazonS3Config.configAmazonS3();
		logger.info("Started deleting files in s3");
		for (S3ObjectSummary file : s3.listObjects(bucket, key).getObjectSummaries()) {
			s3.deleteObject(bucket, file.getKey());
		}
		//csar CSU changes
		if(isCsarProduct) {
			String csarDestination = currentMode.getDrivePath() + csarPath + Constants.Folder_Seperator;
			logger.info("csarDestination : " + csarDestination);
			Path casrDestinationPath = Paths.get(csarDestination);
			if (Files.exists(casrDestinationPath)) {
				boolean status=FileSystemUtils.deleteRecursively(new File(csarDestination));
				logger.info("Deleting folder :"+casrDestinationPath+", status:"+status);
				Files.createDirectories(casrDestinationPath);
			} else {
				Files.createDirectories(casrDestinationPath);
			}
			String csarDestinationkey = csarPath + Constants.Folder_Seperator;
			String csarKey = csarDestinationkey.replace(Constants.Folder_Seperator, "/");
			logger.info("csarDestinationkey : " + csarDestinationkey);
			logger.info("csarKey : " + csarKey);
			
			logger.info("Started deleting files in csu s3");
			for (S3ObjectSummary file : s3.listObjects(bucket, csarKey).getObjectSummaries()) {
				s3.deleteObject(bucket, file.getKey());
			}
		}
		logger.info("Completed deleting files in s3 folder deleted:"+ destination);
		return path;
	}
	public String delByProduct(ServicePkgDto req,String guid) throws BusinessException, IOException {

		if(req.getCallgenpath().equals("DUAL")) {
			return forDualPath(req,guid);
		}else {
			String serviceFilePath=getServiceFilePath(req);
			if(serviceFilePath!=null) {
				logger.info(" file path "+serviceFilePath);
				File serviceFile = new File(serviceFilePath);
				if(serviceFile.exists()) {
					serviceFile.delete();
					String destinationkey=serviceFilePath.substring(3);
					String Folder_Seperator="\\";
					String key=destinationkey.replace(Folder_Seperator, "/");
					String bucket="";
					if(req.getProductcompliance().equalsIgnoreCase("EXPORT")) {
						bucket=commonParamStore.getExportControl().getS3Bucket();
					} else {
						bucket=commonParamStore.getRegular().getS3Bucket();
					}	        
					logger.info(" key "+key);
					AmazonS3 s3 = amazonS3Config.configAmazonS3();
					logger.info("Started deleting files in s3");
					for (S3ObjectSummary file : s3.listObjects(bucket, key).getObjectSummaries()){
						s3.deleteObject(bucket, file.getKey());
					}
					if ("CSAR".equalsIgnoreCase(req.getProductcompliance())) {
						String csarFilePath = getCSARFilePath(req);
						File csarServiceFile = new File(csarFilePath);
						if(csarServiceFile.exists()) {
							csarServiceFile.delete();
							String csarDestinationkey=csarFilePath.substring(3);
							String csarkey=csarDestinationkey.replace(Folder_Seperator, "/");
							logger.info("Started deleting files in csu s3");
							for (S3ObjectSummary file : s3.listObjects(bucket, csarkey).getObjectSummaries()){
								s3.deleteObject(bucket, file.getKey());
							}
						}
					}
					logger.info("Completed deleting files in s3:"+ key);
					//	logger.info("File deleted for CorrelationId : {}", req.getCorrelationGuid());
					logger.info("ProductId : {} "+req.getProductid()+" ECM Code : {} "+req.getEcmcode());
					return serviceFilePath;
				}else {
					logger.info("ProductId : {} "+req.getProductid()+" ECM Code : {} "+req.getEcmcode());
					logger.info("File Path : {}", serviceFilePath);
					// return generateResponse(request, false);
					throw new BusinessException("File doen't exist on Service Path Folder:"+serviceFilePath); 
				}
			}else {
				throw new BusinessException("Service Path not found"+serviceFilePath);
			}
		}
	}





	private String forDualPath(ServicePkgDto request,String guid) throws BusinessException, IOException {
		Mode currentMode=null;
		if("regular".equalsIgnoreCase(mode)) {
			currentMode=commonParamStore.getRegular();
		}else {
			currentMode=commonParamStore.getExportControl();
		}

		request.setCallgenpath("EBU");
		String serviceFilePath1=getServiceFilePath(request);
		request.setCallgenpath("NPBU");
		String serviceFilePath2=getServiceFilePath(request);
		if(serviceFilePath1!=null && serviceFilePath2!=null) {
			logger.info(" file paths are "+serviceFilePath1+" and "+serviceFilePath2);
			File serviceFile = new File(serviceFilePath1);
			File serviceFile2 = new File(serviceFilePath2);
			if(serviceFile.exists() && serviceFile2.exists()) {
				serviceFile.delete();
				serviceFile2.delete();
				String destinationkey1=serviceFilePath1.substring(3);
				String destinationkey2=serviceFilePath2.substring(3);
				String Folder_Seperator="\\";
				String key1=destinationkey1.replace(Folder_Seperator, "/");
				String key2=destinationkey2.replace(Folder_Seperator, "/");
				logger.info(" key "+key1);

				String bucket=currentMode.getS3Bucket();
				AmazonS3 s3 = amazonS3Config.configAmazonS3();

				for (S3ObjectSummary file : s3.listObjects(bucket, key1).getObjectSummaries()) {
					s3.deleteObject(bucket, file.getKey());	        	
				}
				for (S3ObjectSummary file : s3.listObjects(bucket, key2).getObjectSummaries()) {
					s3.deleteObject(bucket, file.getKey());	        	
				}
				if ("CSAR".equalsIgnoreCase(request.getProductcompliance())) {
					String csarFilePath = getCSARFilePath(request);
					File csarServiceFile = new File(csarFilePath);
					if(csarServiceFile.exists()) {
						csarServiceFile.delete();
						String csarDestinationkey=csarFilePath.substring(3);
						String csarkey=csarDestinationkey.replace(Folder_Seperator, "/");
						logger.info("Started deleting files in csu s3");
						for (S3ObjectSummary file : s3.listObjects(bucket, csarkey).getObjectSummaries()){
							s3.deleteObject(bucket, file.getKey());
						}
					}
				}
				logger.info("ProductId : {} "+request.getProductid()+" ECM Code : {} "+request.getEcmcode());
				return serviceFilePath1+"  "+serviceFilePath2;
			}else {

				logger.info("ProductId : {} "+request.getProductid()+" ECM Code : {} "+request.getEcmcode());
				logger.info("File Path : {}", serviceFilePath1+"  "+serviceFilePath2);
				//  return serviceFilePath1+"  "+serviceFilePath2;
				throw new BusinessException("File doen't exist on Service Path Folder:"+serviceFilePath1+"  "+serviceFilePath2); 
			}
		}else {
			throw new BusinessException("Service Path not found"+serviceFilePath1+"  "+serviceFilePath2); 

		}
	}
	private String getCSARFilePath(ServicePkgDto request) {
		return commonParamStore.getRegular().getDrivePath() + 
				paramStore.getCsarCsuCalFilesFolderPath().replace("PRODUCT_ID", request.getProductid()) + Constants.Folder_Seperator + getFileName(request);
	}
	private String getServiceFilePath(ServicePkgDto request) throws BusinessException {
		String FOLDER_SEPERATOR = "\\";
		String returnString = getServiceFolderPath(request);
		if(returnString!=null) {
			if (returnString.substring(returnString.length() - 1, returnString.length()).equalsIgnoreCase(FOLDER_SEPERATOR)) {
				returnString = returnString + getFileName(request);
			} else {
				returnString = returnString + FOLDER_SEPERATOR + getFileName(request);
			}
			logger.info("Service File Path : {}", returnString);
			String mappedDrive="";
			if(request.getProductcompliance().equalsIgnoreCase("EXPORT")) {
				mappedDrive = commonParamStore.getExportControl().getDrivePath();
			}else {
				mappedDrive = commonParamStore.getRegular().getDrivePath();
			}
			return mappedDrive+returnString;
		} else {
			logger.info("Service Folder Path is emplty : {}", returnString);
			return null;
		}


	}
	private String getFileName(ServicePkgDto request) {
		String returnString = "";
		NamingConvention namingConvention = paramStore.getNamingConvention().stream()
				.filter(n -> n.getFileType().equalsIgnoreCase(request.getCalgenname())).findAny()
				.orElse(null);
		if (namingConvention != null) {
			if (namingConvention.getNamingConvention().equalsIgnoreCase("ECMCode.ProductID")
					&& request.getEncryptiontype().equalsIgnoreCase("N")) {
				returnString = request.getEcmcode().trim();
			} else if (namingConvention.getNamingConvention().equalsIgnoreCase("ECMCode.ProductID")) {
				returnString = request.getBaseecm().trim() + "." + request.getProductid().toLowerCase();
			} else if (namingConvention.getNamingConvention().equalsIgnoreCase("PartList.ProductID")
					&& request.getEncryptiontype().equalsIgnoreCase("N")) {
				returnString = request.getAfile().trim();
			} else if (namingConvention.getNamingConvention().equalsIgnoreCase("PartList.ProductID")) {
				String aFile = request.getAfile().trim();
				returnString = aFile.substring(0, aFile.length() - 3) + "." + request.getProductid().toLowerCase();
			}
		}
		return returnString;
	}
	private String getServiceFolderPath(ServicePkgDto request) throws BusinessException {
		ServicePathData servicePathData = null;
		if (request.getCallgenpath().equalsIgnoreCase("Other")) {
			servicePathData = paramStore.getServicePathData().stream()
					.filter(n -> n.getCategory().equalsIgnoreCase(request.getCallgenpath()))
					.filter(n -> n.getProduct().equalsIgnoreCase(request.getProductid())).findAny()
					.orElse(null);
		} else {
			servicePathData = paramStore.getServicePathData().stream()
					.filter(n -> n.getCategory().equalsIgnoreCase(request.getCallgenpath())).findAny()
					.orElse(null);
		}
		if (servicePathData != null) {
			return servicePathData.getFolderPath().replace("PRODUCT_ID", request.getProductid());
		} else {
			logger.info("ServicePathData is null from ParamStore  ServicePathData : {}", servicePathData);
			return null;
		}
	}
	public void deleteJsonFile(String productId, String correlationGuid) {
		try{
			Mode currentMode=null;
			if (mode.equalsIgnoreCase("regular")) {
				currentMode = commonParamStore.getRegular();
			} else {
				currentMode = commonParamStore.getExportControl();
			}
			String deletePath = currentMode.getDrivePath() + "Service_Metadata" + Folder_Seperator+productId;

			File deleteFile = new File(deletePath + "_ServiceMetadata.json");
			if (deleteFile.exists()) {
				logger.info("Delete Meta deta Json File : {}", deletePath);
				FileUtils.delete(new File(deletePath + "_ServiceMetadata.json"));
			}
		} catch(IOException e) {
			logger.info(" Delete Meta Data Json file failed correlationGuid: {}", correlationGuid);
			logger.info(" ProductId: {}",productId);
			logger.info(e.getMessage());
		}
	}
	public void handleExceptionResult(ServicePkgCalAddByProductRequest req,ServicePkgCalibrationChildResponse responseData,String msg,boolean isDelete) {
		try {
			if(null!=responseData.getFailure() && null!= responseData.getFailure().getData()) {
				if(!isDelete) {
					if(null!=req.getProduct()) {
						responseData.getFailure().getData().add(new ObjectData(req.getProduct().getProductid(), req.getProduct().getEcmcode(), null, msg));
						responseData.getFailure().setCount(1);
					}else if(null!=req.getProducts()) {
						responseData.getFailure().getData().add(new ObjectData(req.getProducts().get(0).getProductid(), req.getProducts().get(0).getEcmcode(), null, msg));
						responseData.getFailure().setCount(1);
					}
				}else {
					responseData.getFailure().getData().add(new ObjectData(null,null, null, msg));
					responseData.getFailure().setCount(1);
				}
			}else {
				List<ObjectData> data=new LinkedList<>();
				if(!isDelete) {
					if(null!=req.getProduct()) {
						data.add(new ObjectData(req.getProduct().getProductid(), req.getProduct().getEcmcode(), null, msg));
					}else if(null!=req.getProducts()) {
						data.add(new ObjectData(req.getProducts().get(0).getProductid(), req.getProducts().get(0).getEcmcode(), null, msg));
					}
				}else {
					responseData.getFailure().getData().add(new ObjectData(null,null, null, msg));
					responseData.getFailure().setCount(1);
				}
				responseData.setFailure(new CountAndData(1, data));

			}
		}catch (Exception e) {
			logger.error("Exception while handling result:"+e.getMessage());
		}
		responseData.setSuccess(new CountAndData(0, new LinkedList<ObjectData>()));
	}

	public String processforHPIandENI(ServicePkgCalibrationDelRequest req) {
		logger.info("Process started for HPI and ENI");
		Mode currentMode = commonParamStore.getRegular();
		List<ServicePathData> servicePathDataList = paramStore.getServicePathData();
		ServicePathData servicePathData = servicePathDataList.stream().filter(m -> "EBU".equalsIgnoreCase(m.getCategory())).findAny().orElse(null);
		if(servicePathData != null && servicePathData.getFolderPath()!=null && !servicePathData.getFolderPath().isEmpty()) {
			String destinationPath = currentMode.getDrivePath() + servicePathData.getFolderPath() +"\\";
			String workAroundpath = currentMode.getDrivePath()+"Naveen\\Workaround\\" +"PRODUCT_ID" +"\\";
			if(req.getMode().equalsIgnoreCase("ONETIME") && (req.getProductIdList().contains("HPI") || req.getProductIdList().contains("ENI"))) {
				logger.info("ONETIME mode for HPI or ENI");
				if (req.getProductIdList().contains("HPI")) {
					String filePath = workAroundpath.replace("PRODUCT_ID", "HPI");
					String destination = destinationPath.replace("PRODUCT_ID", "HPI");
					copyFileforHPIandENI(filePath,destination);
				}
				if (req.getProductIdList().contains("ENI")) {
					String filePath = workAroundpath.replace("PRODUCT_ID", "ENI");
					String destination = destinationPath.replace("PRODUCT_ID", "ENI");
					copyFileforHPIandENI(filePath,destination);
				}
			} else if(req.getMode().equalsIgnoreCase("all")) {
				String filePath = workAroundpath.replace("PRODUCT_ID", "HPI");
				String destination = destinationPath.replace("PRODUCT_ID", "HPI");
				copyFileforHPIandENI(filePath,destination);
				String eniFilePath = workAroundpath.replace("PRODUCT_ID", "ENI");
				String enidestination = destinationPath.replace("PRODUCT_ID", "ENI");
				copyFileforHPIandENI(eniFilePath,enidestination);
			}			
			return "success";
		}
		return "failed";
	}
	
	

	private void copyFileforHPIandENI(String filePath, String destination) {
		try {
			Mode currentMode = commonParamStore.getRegular();
			logger.info("Process started for : "+filePath);
			File source = new File(filePath);
			if(source.exists()) {
				File target = new File(destination);
				if(!target.exists()) {
					target.mkdirs();
				}
				FileUtils.copyDirectory(source, target, false);	
				String url=currentMode.getHostName()+paramStore.getOutBoundSycUrl();
				String path = destination.substring(0, destination.length()-1);
				ResponseEntity<String> response=restTemplate.postForEntity(url, new CopyDTO(path.replace("G:\\", ""),false), String.class);
				logger.info(" Response from outbound "+response);
			}
			
		} catch(Exception e) {
			logger.info("Exception occure when copying file for : "+destination);
			e.printStackTrace();
		}
	}
	public String delFolderCsarCsu(String path, String guid) throws IOException {
		Mode currentMode = commonParamStore.getRegular();
		
		String destination = currentMode.getDrivePath() + path + Constants.Folder_Seperator;
		Path destinationPath = Paths.get(destination);
		if (Files.exists(destinationPath)) {
			boolean status=FileSystemUtils.deleteRecursively(new File(destination));
			logger.info("Deleting folder :"+destinationPath+", status:"+status);
			Files.createDirectories(destinationPath);
		} else {
			Files.createDirectories(destinationPath);
		}

		String destinationkey = path + Constants.Folder_Seperator;
		String key = destinationkey.replace(Constants.Folder_Seperator, "/");

		String bucket=currentMode.getS3Bucket();
		AmazonS3 s3 = amazonS3Config.configAmazonS3();
		
		for (S3ObjectSummary file : s3.listObjects(bucket, key).getObjectSummaries()) {
			s3.deleteObject(bucket, file.getKey());
		}
		
		logger.info("Completed deleting files in s3 folder for CSAR CSU deleted:"+ destination);
		return path;
	}
	
	public String addSupportFilesCsarCsu(String source, String destination, String pID, String guid) throws IOException {
		Mode currentMode = commonParamStore.getRegular();
//        try {
        	String destinationFolderPath = destination.substring(0, destination.lastIndexOf(File.separator));
        	File destinationFolder = new File(destinationFolderPath);
	        if (!destinationFolder.exists()) {
	            destinationFolder.mkdirs();
	            logger.info("Destination folder created: " + destinationFolder);
	        }
        	File inputFile = new File(source);
    		File outputFile = new File(destination);
    		FileCopyUtils.copy(inputFile, outputFile);
    		String url=currentMode.getHostName()+paramStore.getOutBoundSycUrl();
    		callChildAPI(new CopyDTO(destination.replace(currentMode.getDrivePath(), ""),false), guid, url, "SyncCopy");

            logger.info("File copied successfully from " + source + " to " + destination);
//        } catch (IOException e) {
//        	logger.info("Error copying the file: " + e.getMessage());
//        }

		logger.info("Completed copying files in s3 folder for CSAR CSU. added:"+ destination);
		return destination;
	}
}
