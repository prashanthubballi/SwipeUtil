package com.cummins.servicepkg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cummins.servicepkg.model.TDistributionRuleSet;
import com.cummins.servicepkg.model.TDistributionRuleSetKey;

@Repository
public interface TDistributionRuleSetRepository extends JpaRepository<TDistributionRuleSet, TDistributionRuleSetKey> {

	@Query(value = "Select * from T_DISTRIBUTION_RULE_SET where BRE_RULE_NAME IN ( ?1)", nativeQuery = true)
	  List<TDistributionRuleSet> getDistributionRuleSetByName(List<String> ruleNames);
}
