package com.cummins.servicepkg.common;

import java.util.List;
import lombok.Data;

@Data
public class FileListJson {

	public List<PIDandFiles> e2mecfgmetadata;

}
