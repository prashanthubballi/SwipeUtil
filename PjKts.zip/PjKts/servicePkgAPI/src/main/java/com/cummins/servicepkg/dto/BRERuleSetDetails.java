package com.cummins.servicepkg.dto;

import java.util.List;

import lombok.Data;

@Data
public class BRERuleSetDetails {
	private String serviceDistributionRule;
	private String powerMatchDistributionRule;
	
	private List<String> phaseCode ;
	private List<String> effectCode  ;
	private String condition;
	private List<String> phaseCodeSecond  ;
	private List<String> effectCodeSecond  ;
	private String conditionSecond;
}
