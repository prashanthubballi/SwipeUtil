package com.cummins.servicepkg.service.child.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.cummins.servicepkg.child.dto.ServicePkgCalibrationChildResponse;
import com.cummins.servicepkg.child.dto.ServicePkgCalibrationDelRequest;
import com.cummins.servicepkg.common.CommonResponse;
import com.cummins.servicepkg.common.CommonResponseHeader;
import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.common.CountAndData;
import com.cummins.servicepkg.common.ObjectData;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.dto.ServicePathData;
import com.cummins.servicepkg.dto.ServicePkgDto;
import com.cummins.servicepkg.exception.BadRequestException;
import com.cummins.servicepkg.service.cal.impl.MDCExecutorService;

import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;

@Service
public class ServicePackageChildDeletionImpl {

	private static final Logger logger = LoggerFactory.getLogger(ServicePackageChildDeletionImpl.class);

	@Autowired
	private ParamStore paramStore;
	
	

	@Autowired
	private CalibrationCommonUtility commonUtility;

	///@Autowired
	Retry retry=RetryRegistry.ofDefaults().retry("throwingException");
	//	https://resilience4j.readme.io/docs/retry



	public CommonResponse<ServicePkgCalibrationChildResponse> executeServiceCalDelete(ServicePkgCalibrationDelRequest req) {

		CommonResponse<ServicePkgCalibrationChildResponse> response = new CommonResponse<>();
		CommonResponseHeader responseHeader = new CommonResponseHeader();
		ServicePkgCalibrationChildResponse responseData = new ServicePkgCalibrationChildResponse();
		try {

			responseData=callMultiThread(req);

			responseHeader.setCode(HttpStatus.OK.value());
			responseHeader.setMessage("Success");
			responseHeader.setSuccess(true);
		}catch (BadRequestException e) {
			commonUtility.handleExceptionResult(null, responseData, e.getMessage(),true);
			responseHeader.setCode(HttpStatus.BAD_REQUEST.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}catch (Exception e) {
			commonUtility.handleExceptionResult(null, responseData, e.getMessage(),true);
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		} catch (Throwable e) {
			commonUtility.handleExceptionResult(null, responseData, e.getMessage(),true);
			e.printStackTrace();
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}

		responseData.setCorrelationGuid(req.getCorrelationGuid());
		response.setHeader(responseHeader);
		response.setData(responseData);

		return response;
	}
	private ServicePkgCalibrationChildResponse callMultiThread(ServicePkgCalibrationDelRequest req) {
		ServicePkgCalibrationChildResponse responseData = new ServicePkgCalibrationChildResponse();

		CountAndData success=new CountAndData();
		CountAndData failure=new CountAndData();
		success.setData(new LinkedList<ObjectData>());
		failure.setData(new LinkedList<ObjectData>());
		responseData.setSuccess(success);
		responseData.setFailure(failure);
		ExecutorService delegate = Executors.newFixedThreadPool(paramStore.getThreadLimit());
		MDCExecutorService<ExecutorService> pool=new MDCExecutorService<ExecutorService>(delegate);
		
		List<Callable<Map<String, ObjectData>>> tasks = new ArrayList<>();
		List<String> csarProductList = req.getCsarProductList();
		List<ServicePathData> servicePathDataList = paramStore.getServicePathData();
		logger.info("Del ALL distinct List:"+req.getProductIdList());
		if(Constants.ALL.equalsIgnoreCase(req.getMode()) || Constants.ONETIME.equalsIgnoreCase(req.getMode())) {
			for (ServicePathData servicePathData : servicePathDataList) {
				if(Constants.ALL.equalsIgnoreCase(req.getMode())) {
					tasks.add((Callable<Map<String, ObjectData>>) () -> invokeDelALL(servicePathData,req.getCorrelationGuid(),req.getProductIdList(), csarProductList));
				}else if(Constants.ONETIME.equalsIgnoreCase(req.getMode()) && req.getProductIdList().contains(servicePathData.getProduct())) {
					tasks.add((Callable<Map<String, ObjectData>>) () -> invokeDelALL(servicePathData,req.getCorrelationGuid(),req.getProductIdList(), csarProductList));
				}else if(Constants.ONETIME.equalsIgnoreCase(req.getMode()) && ("ALL".equalsIgnoreCase(servicePathData.getProduct()) && !"Configfile".equalsIgnoreCase(servicePathData.getCategory()))) {
					tasks.add((Callable<Map<String, ObjectData>>) () -> invokeDelALL(servicePathData,req.getCorrelationGuid(),req.getProductIdList(), csarProductList));
				}
			}
		}else if(Constants.DAILY.equalsIgnoreCase(req.getMode()) && null!=req.getServiceDownloadDataList() && !req.getServiceDownloadDataList().isEmpty()) {

			if(!req.getServiceDownloadDataList().isEmpty()) {
				for (ServicePkgDto data : req.getServiceDownloadDataList()) {
					tasks.add((Callable<Map<String,ObjectData>>) () -> invokeDelDaily(data, req.getCorrelationGuid()));
				}
			}
		}

		if(!tasks.isEmpty()) {
			try {
				List<Future<Map<String, ObjectData>>> invokeResults=pool.invokeAll(tasks);
				for (Future<Map<String, ObjectData>> future : invokeResults) {
					logger.info("Processing results");
					Map<String, ObjectData> response=future.get();
					if(null!=response.get(Constants.SUCCESS)) {
						success.getData().add(response.get(Constants.SUCCESS));
					}
					if(null!=response.get(Constants.FAILURE)) {
						failure.getData().add(response.get(Constants.FAILURE));
					}
				}
				success.setCount(success.getData().size());
				failure.setCount(failure.getData().size());
				responseData.setSuccess(success);
				responseData.setFailure(failure);
				logger.info("Results fetched");
			} catch (InterruptedException | ExecutionException e) {
				logger.info("Del ALL Error:"+e.getMessage());
				e.printStackTrace();
			}
		}else {
			logger.error("Del ALL is empty list");
			success.setCount(0);
			failure.setCount(0);
			responseData.setSuccess(success);
			responseData.setFailure(failure);
		}
		pool.shutdown();
		//HPI and ENI product specific process
		if((Constants.ONETIME.equalsIgnoreCase(req.getMode()) && (req.getProductIdList().contains("HPI") || req.getProductIdList().contains("ENI")))
				|| Constants.ALL.equalsIgnoreCase(req.getMode())) {
			commonUtility.processforHPIandENI(req);
			//String HPIandENI = commonUtility.processforHPIandENI(req);
		}
		logger.info("Del ALL completed:"+pool.isShutdown());
		return responseData;
	}

	private Map<String, ObjectData> invokeDelALL(ServicePathData servicePathData, String guid, List<String> distinctProductIdList, List<String> csarProductList) throws Exception {
		logger.info("inside invokeDelALL method");
		Map<String, ObjectData> map=new HashMap<>();
		distinctProductIdList=distinctProductIdList.stream().filter(pid-> null!=pid && !"null".equals(pid)).collect(Collectors.toList());
		if (Constants.OTHER.equalsIgnoreCase(servicePathData.getCategory())) {
			String path = servicePathData.getFolderPath().replace(Constants.PRODUCT_ID, servicePathData.getProduct());
			boolean isCsarProduct;
			if(csarProductList != null && csarProductList.size()>0) {
				isCsarProduct = csarProductList.contains(servicePathData.getProduct());
			} else {
				isCsarProduct = false;
			}
			String csarPath = paramStore.getCsarCsuCalFilesFolderPath().replace(Constants.PRODUCT_ID, servicePathData.getProduct());
			try {
				//impl retry
				retry.executeCheckedSupplier(()->{ return commonUtility.delFolder(path, guid, isCsarProduct, csarPath);});
				map.put(Constants.SUCCESS,new ObjectData(null, null,null,Constants.SUCCESS+":"+path));
			}catch ( Throwable e) {
				map.put(Constants.FAILURE,new ObjectData(null, null,null,Constants.ERROR+":"+e.getMessage()));
			}
		} else if (servicePathData.getCategory().equalsIgnoreCase(Constants.configFile)) {
			return map;
		} else {
			ExecutorService delegate = Executors.newFixedThreadPool(paramStore.getDelThreadLimit());
			MDCExecutorService<ExecutorService> pool2=new MDCExecutorService<ExecutorService>(delegate);
			List<Callable<String>> tasks = new ArrayList<>();
			for (String productId : distinctProductIdList) {
				String path = servicePathData.getFolderPath().replace(Constants.PRODUCT_ID, productId);
				boolean isCsarProduct = csarProductList.contains(productId);
				String csarPath = paramStore.getCsarCsuCalFilesFolderPath().replace(Constants.PRODUCT_ID, productId);
				tasks.add((Callable<String>) () -> delByProduct(path, guid, isCsarProduct, csarPath));
			}
			try {
				List<Future<String>> results=pool2.invokeAll(tasks);
				for (Future<String> future : results) {
					String resultString=future.get();
					if(resultString.startsWith(Constants.ERROR)) {
						map.put(Constants.FAILURE,new ObjectData(null, null,null,resultString));
					}else {
						map.put(Constants.SUCCESS,new ObjectData(null, null,null,resultString));
					}
				}
			}catch (Exception e) {
				map.put(Constants.FAILURE,new ObjectData(null, null,null,Constants.ERROR+":"+e.getMessage()));
			}
			pool2.shutdown();
			return map;
		}
		return map;
	}

	private String delByProduct(String path,String guid, boolean isCsarProduct, String csarPath) {
		try {
			//impl retry
			retry.executeCheckedSupplier(()->{ return commonUtility.delFolder(path, guid, isCsarProduct, csarPath);});
			return Constants.SUCCESS+":"+path;
		}catch ( Throwable e) {
			return Constants.ERROR+":"+e.getMessage();
		}
	}
	private Map<String, ObjectData> invokeDelDaily(ServicePkgDto serviceDownload, String guid){ 
		logger.info("inside invokeDelALL method");
		Map<String, ObjectData> map=new HashMap<>();

		try {
			//impl retry
			retry.executeCheckedSupplier(()->{ return commonUtility.delByProduct(serviceDownload, guid);});
			map.put(Constants.SUCCESS,new ObjectData(serviceDownload.getProductid(), serviceDownload.getEcmcode(),null,Constants.SUCCESS));
		}catch ( Throwable e) {
			map.put(Constants.FAILURE,new ObjectData(serviceDownload.getProductid(), serviceDownload.getEcmcode(),null,Constants.ERROR+":"+e.getMessage()));
		}
		return map;
	}
	
	public CommonResponse<ServicePkgCalibrationChildResponse> csarCsuDeletion(ServicePkgCalibrationDelRequest req) {
		CommonResponse<ServicePkgCalibrationChildResponse> response = new CommonResponse<>();
		CommonResponseHeader responseHeader = new CommonResponseHeader();
		ServicePkgCalibrationChildResponse responseData = new ServicePkgCalibrationChildResponse();
		try {

			responseData=callMultiThreadForCsarCusFilesDeletion(req);

			responseHeader.setCode(HttpStatus.OK.value());
			responseHeader.setMessage("Success");
			responseHeader.setSuccess(true);
		}catch (BadRequestException e) {
			commonUtility.handleExceptionResult(null, responseData, e.getMessage(),true);
			responseHeader.setCode(HttpStatus.BAD_REQUEST.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}catch (Exception e) {
			commonUtility.handleExceptionResult(null, responseData, e.getMessage(),true);
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		} catch (Throwable e) {
			commonUtility.handleExceptionResult(null, responseData, e.getMessage(),true);
			e.printStackTrace();
			responseHeader.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			responseHeader.setMessage(e.getMessage());
			responseHeader.setSuccess(false);
		}

		responseData.setCorrelationGuid(req.getCorrelationGuid());
		response.setHeader(responseHeader);
		response.setData(responseData);

		return response;
		
	}
	private ServicePkgCalibrationChildResponse callMultiThreadForCsarCusFilesDeletion(ServicePkgCalibrationDelRequest req) {
		ServicePkgCalibrationChildResponse responseData = new ServicePkgCalibrationChildResponse();

		CountAndData success=new CountAndData();
		CountAndData failure=new CountAndData();
		success.setData(new LinkedList<ObjectData>());
		failure.setData(new LinkedList<ObjectData>());
		responseData.setSuccess(success);
		responseData.setFailure(failure);
		ExecutorService pool = Executors.newFixedThreadPool(paramStore.getThreadLimit());
		List<Callable<Map<String, ObjectData>>> tasks = new ArrayList<>();
		
		List<String> productsIdList = req.getProductIdList();
		
		for(String productId : productsIdList) {
			tasks.add((Callable<Map<String, ObjectData>>) () -> invokeDelForCsarCsu(productId, req.getCorrelationGuid()));
		}
		
		if(!tasks.isEmpty()) {
			try {
				List<Future<Map<String, ObjectData>>> invokeResults=pool.invokeAll(tasks);
				for (Future<Map<String, ObjectData>> future : invokeResults) {
					logger.info("Processing results");
					Map<String, ObjectData> response=future.get();
					if(null!=response.get(Constants.SUCCESS)) {
						success.getData().add(response.get(Constants.SUCCESS));
					}
					if(null!=response.get(Constants.FAILURE)) {
						failure.getData().add(response.get(Constants.FAILURE));
					}
				}
				success.setCount(success.getData().size());
				failure.setCount(failure.getData().size());
				responseData.setSuccess(success);
				responseData.setFailure(failure);
				logger.info("Results fetched");
			} catch (InterruptedException | ExecutionException e) {
				logger.info("Del ALL Error:"+e.getMessage());
				e.printStackTrace();
			}
		}else {
			logger.error("Del ALL is empty list");
			success.setCount(0);
			failure.setCount(0);
			responseData.setSuccess(success);
			responseData.setFailure(failure);
		}
		pool.shutdown();
		logger.info("Del ALL completed:"+pool.isShutdown());
		return responseData;
	}
	
	
	private Map<String, ObjectData> invokeDelForCsarCsu(String productId, String guid) throws Exception {
		logger.info("inside invokeDelALL method");
		Map<String, ObjectData> map=new HashMap<>();
		
		String path = paramStore.getCsarCsuSupportFilesFolderPath().replace(Constants.PRODUCT_ID, productId);

		try {
			//impl retry
			retry.executeCheckedSupplier(()->{ return commonUtility.delFolderCsarCsu(path, guid);});
			map.put(Constants.SUCCESS,new ObjectData(null, null,null,Constants.SUCCESS+":"+path));
		}catch ( Throwable e) {
			map.put(Constants.FAILURE,new ObjectData(null, null,null,Constants.ERROR+":"+e.getMessage()));
		}
		return map;
	}
	
	

	
	
	
	
}





