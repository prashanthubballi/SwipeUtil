package com.cummins.servicepkg.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.List;
import lombok.Data;

@JsonPropertyOrder({
  "executableFilePath",
  "logFilePath",
  "calibrationFolderName",
  "encriptionType",
  "pclEncryptor",
  "eelEncryptor"
})
@Data
public class Encryption {

  @JsonProperty("executableFilePath")
  private String executableFilePath;
  @JsonProperty("logFilePath")
  private String logFilePath;
  @JsonProperty("calibrationFolderName")
  private String calibrationFolderName;
  
  @JsonProperty("encriptionType")
  private List<String> encriptionType;
  
  @JsonProperty("pclEncryptor")
  private String pclEncryptor;
  @JsonProperty("eelEncryptor")
  private String eelEncryptor;
}
