package com.cummins.servicepkg.common;

public interface Constants {
	String Folder_Seperator = "\\";

	public static final  String storeProcSpsd = "SPSD_WRAPPER_PKG.SPSD_WRAPPER";
	public static final  String storeProcSpsn = "SPSN_WRAPPER_PKG.SPSN_WRAPPER";
	public static final String REQUESTEXPORTCONTROL="RequestExportControl";
	public static final String REQUESTREGULAR="RequestRegular";
	
	public static final String EXPORT="EXPORT";
	
	public static final String SUCCESS="SUCCESS";
	public static final String FAILURE="FAILURE";
	public static final String ERROR="ERROR";


	String ALL = "all";
	String DAILY = "daily";
	String ONETIME = "onetime";
	//  String ECM = "ecm";
	
	String OTHER="other";
	String PRODUCT_ID="PRODUCT_ID";
	
	String configFile="Configfile";


	public static final String DELETION = "DELETION";
	public static final String ADDITION = "ADDITION";
	public static final String CSAR_DELETION = "CSAR_DELETION";
	public static final String CSAR_ADDITION = "CSAR_ADDITION";

}
