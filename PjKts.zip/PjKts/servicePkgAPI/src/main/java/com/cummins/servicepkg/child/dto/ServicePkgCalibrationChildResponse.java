package com.cummins.servicepkg.child.dto;

import com.cummins.servicepkg.common.CountAndData;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServicePkgCalibrationChildResponse {

	private String correlationGuid;
	private String mode;  
	@JsonProperty("response")
	private String response;

	@JsonProperty("failure")
	private CountAndData failure;

	@JsonProperty("success")
	private CountAndData success;

}
