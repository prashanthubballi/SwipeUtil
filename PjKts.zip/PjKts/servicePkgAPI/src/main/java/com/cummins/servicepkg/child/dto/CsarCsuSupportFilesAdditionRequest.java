package com.cummins.servicepkg.child.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CsarCsuSupportFilesAdditionRequest {
	private String correlationGuid;
	private String mode;
	private List<SupportFileDetailParent> data;
}
