package com.cummins.servicepkg.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RuleList {
	
	@JsonProperty("field")
	private String field;

	@JsonProperty("operator")
	private String operator;

	@JsonProperty("value")
	private List<String> value;

}
