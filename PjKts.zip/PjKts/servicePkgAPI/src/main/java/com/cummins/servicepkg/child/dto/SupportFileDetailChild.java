package com.cummins.servicepkg.child.dto;

import lombok.Data;

@Data
public class SupportFileDetailChild {
	private String a2l;
	private String pcfg;
	private String a2lCbf;
	private String pcfgCbf;
}
