package com.cummins.servicepkg.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class VServiceE2mEcfgDailyKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "CONFIG_EXTN")
	private String configExtn;

	@Column(name = "CONFIG_PART")
	private String configPart;

	@Column(name = "DDO_PRODUCT_ID")
	private String ddoProductId;

	public VServiceE2mEcfgDailyKey() {
	}

	public String getConfigExtn() {
		return this.configExtn;
	}

	public void setConfigExtn(String configExtn) {
		this.configExtn = configExtn;
	}

	public String getConfigPart() {
		return this.configPart;
	}

	public void setConfigPart(String configPart) {
		this.configPart = configPart;
	}

	public String getDdoProductId() {
		return this.ddoProductId;
	}

	public void setDdoProductId(String ddoProductId) {
		this.ddoProductId = ddoProductId;
	}

}
