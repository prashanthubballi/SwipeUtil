package com.cummins.servicepkg.repository;

import java.util.List;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cummins.servicepkg.model.TProductList;
import com.cummins.servicepkg.model.TProductListTableKey;

@Repository
public interface ITProductListRepository extends JpaRepository<TProductList, TProductListTableKey> {

	@Modifying
	@Query(value = " INSERT INTO T_PRODUCT_LIST SELECT DISTINCT PRM_PRODUCT_ID FROM T_PRODUCT_MASTER ORDER BY PRM_PRODUCT_ID ", nativeQuery = true)
	void updateAllMode();

	@Modifying
	@Query(value = "INSERT INTO T_PRODUCT_LIST SELECT DISTINCT PRODUCT_ID FROM V_SERVICE_DAILY_ACTIVE_CALS ORDER BY PRODUCT_ID ", nativeQuery = true)
	void updateDailyMode();

	@Modifying
	@Query(value = "INSERT INTO T_PRODUCT_LIST "
	       + "SELECT DISTINCT PRM_PRODUCT_ID FROM T_PRODUCT_MASTER WHERE PRM_PRODUCT_ID IN :productIdList "
	       + "ORDER BY PRM_PRODUCT_ID", nativeQuery = true)
	void updateOnetimeMode(@Param("productIdList") List<String> productIdList);

	@Query(value = " SELECT DISTINCT SPP_PRODUCT_ID "
			+ " FROM  T_SERVICE_PRODUCT_PROFILE "
			+ " UNION "
			+ " SELECT DECODE (SPP_PRODUCT_ID,'APX','ISX','DEL','ISM','VEN','QST',SPP_PRODUCT_ID) SPP_PRODUCT_ID "
			+ " FROM T_SERVICE_PRODUCT_PROFILE", nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500"))
	List<String> getproductListforALL();
	
	@Query(value = " SELECT DISTINCT SPP_PRODUCT_ID "
			+ " FROM  T_SERVICE_PRODUCT_PROFILE where SPP_PRODUCT_ID IN (?1) "
			+ " UNION "
			+ " SELECT DECODE (SPP_PRODUCT_ID,'APX','ISX','DEL','ISM','VEN','QST',SPP_PRODUCT_ID) SPP_PRODUCT_ID "
			+ " FROM T_SERVICE_PRODUCT_PROFILE where SPP_PRODUCT_ID IN (?1)", nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "500000"))
	List<String> getproductListforOnetime(List<String> productIds);

	@Modifying
	@Query(value = "insert into T_SERVICE_DOWNLOAD values "
			+ "('SERVICE','SERVICE_DOWNLOAD',?1,'LIST OF PRODUCTS FOR ONETIME ACTIVITY',user,sysdate)", nativeQuery = true)
	void updateTServiceDownload(String productId);
	
	@Modifying
	@Query(value = "DELETE FROM T_SERVICE_DOWNLOAD WHERE TSD_MODULE = 'SERVICE' "
			+ "AND TSD_PROCESS = 'SERVICE_DOWNLOAD'", nativeQuery = true)
	void updateForDaily();
	
	@Modifying
	@Query(value = "DELETE FROM T_SERVICE_DOWNLOAD WHERE TSD_MODULE = 'SERVICE' AND "
			+ "TSD_PROCESS = 'SERVICE_DOWNLOAD'", nativeQuery = true)
	void updateForAllandOnetime();
	
	@Modifying
	@Query(value = " Insert into T_AUDIT "
			+ " (AUD_ACTIVITY_ID,AUD_DATE,AUD_FUNCTION_ID,AUD_SUB_ACTIVITY,AUD_SUB_FUNCTION_ID,AUD_ACTIVITY,AUD_CODE, "
			+ " AUD_SUB_CODE,AUD_DETAILS,AUD_LAST_UPDATE_DATE,AUD_LAST_UPDATE_USER,STATUS,REQUEST_ID)  "
			+ " values ('SD',SYSDATE,'N','SERVICE GUIDANZ TRIGGER',' ','TRIGGER FOR SERVICE GUIDANZ',' ',' ',' ',SYSDATE,'SPEEDADMIN',0, ?1)", nativeQuery = true)
	void updateTAudit(String correlationGuid);
}
