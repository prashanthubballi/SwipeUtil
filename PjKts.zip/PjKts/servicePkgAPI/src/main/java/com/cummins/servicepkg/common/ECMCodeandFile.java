package com.cummins.servicepkg.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ECMCodeandFile {
	public String ecmCode;
	public String e2m_ecfg;
}
