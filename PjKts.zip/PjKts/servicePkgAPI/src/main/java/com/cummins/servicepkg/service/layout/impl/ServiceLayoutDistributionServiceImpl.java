package com.cummins.servicepkg.service.layout.impl;

import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.config.AmazonS3Config;
import com.cummins.servicepkg.dto.BRERuleSetDetails;
import com.cummins.servicepkg.dto.CommonParamStore;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.dto.RequestServiceLayoutDistribution;
import com.cummins.servicepkg.dto.TcalServiceDto;
import com.cummins.servicepkg.exception.BadRequestException;
import com.cummins.servicepkg.meta.dto.CopyDTO;
import com.cummins.servicepkg.model.TAuditKey;
import com.cummins.servicepkg.model.TAuditTable;
import com.cummins.servicepkg.repository.ITAuditRepository;
import com.cummins.servicepkg.repository.ITProductListRepository;
import com.cummins.servicepkg.repository.ServiceRepoUtil;
import com.cummins.servicepkg.service.cal.impl.CommonUtility;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ServiceLayoutDistributionServiceImpl  {

	private static final Logger logger = LoggerFactory.getLogger(ServiceLayoutDistributionServiceImpl.class);
	public static final String SERVICENOW = "ServiceNow";
	ObjectMapper mapper = new ObjectMapper();

	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	public ITProductListRepository itProductListRepository;

	@Autowired
	private ITAuditRepository itAuditRepository;

	@Autowired
	private ParamStore paramStore;
	
	@Autowired
	private CommonParamStore commonParamStore;
	
	@Autowired
	private AmazonS3Config amazonS3Config;

	@Autowired
	private CommonUtility commonUtility;
	
	@Autowired
	private ServiceRepoUtil serviceRepoUtil;


	@Transactional
	public String callStoredProcedure(RequestServiceLayoutDistribution request)
			throws Exception {

		try {
			
			storeAudits(request.getCorrelationGuid(), "SERVICE_LAYOUT_DISTRIBUTION","SERVICE_LAYOUT_DISTRIBUTION STARTED", 0, "regular");
			logger.info("Service Distribution Master started entry done");
			if(request.getMode().equalsIgnoreCase("all") || request.getMode().equalsIgnoreCase("onetime")) {
				itProductListRepository.updateForAllandOnetime();
			}

			if (request.getMode().equalsIgnoreCase("ALL")) {
				List<String> productList = itProductListRepository.getproductListforALL();
				processForAllAndOnetimeMode(productList);
				
			} else if (request.getMode().equalsIgnoreCase("DAILY")) {
				itProductListRepository.updateForDaily();
				
			} else if (request.getMode().equalsIgnoreCase("ONETIME")) {
				if(request.getProductIDList()==null || request.getProductIDList().isEmpty()) {
					logger.info("ProductIdList can be null or empty for mode ONETIME, correlationId :{}",request.getCorrelationGuid());
					throw new BadRequestException("ProductIdList can not be null or empty for mode as ONETIME");
				}
				else {
					List<String> listofProduct = itProductListRepository.getproductListforOnetime(request.getProductIDList());
					processForAllAndOnetimeMode(listofProduct);
				
				}
			} else {
				throw new BadRequestException("Invalid Mode");
			}
			List<String> procedureNames = new ArrayList<>();
			procedureNames.clear();
			procedureNames.add(Constants.storeProcSpsn);
			procedureNames.add(Constants.storeProcSpsd);
			//procedure called here
			for(String procedureName:procedureNames) {
				executeStoredProcedure(procedureName, request.getCorrelationGuid(),request.getCorrelationGuid());
			}

			logger.info("SP execution completed");
			//vw596 Tcal file will be generated here.
			tcalFileGenerator();
			storeAudits(request.getCorrelationGuid(), "SERVICE_LAYOUT_DISTRIBUTION","SERVICE_LAYOUT_DISTRIBUTION COMPLETED", 1, "regular");

			itProductListRepository.updateTAudit(request.getCorrelationGuid());
			return "Completed";
		} catch (Exception e) {
			e.printStackTrace();
			storeAudits(request.getCorrelationGuid(), "SERVICE_LAYOUT_DISTRIBUTION","SERVICE_LAYOUT_DISTRIBUTION COMPLETED", 1, "regular");

			if (e instanceof BadRequestException) {
				logger.error("Exception occured  {}",e.getMessage());
				throw new BadRequestException(e.getMessage());
			}
			else {
				logger.error("Exception occured  {}",e.getMessage());
				throw new Exception("Internal Server Error:"+e.getMessage());
			}

		}

	}

	
		public String tcalFileGenerator() throws Exception {
			String csvFilePath = commonParamStore.getRegular().getDrivePath()+paramStore.getTcalPath();
			try {
				String directoryPath = csvFilePath;
				File directory = new File(directoryPath);
				AmazonS3 s3 = amazonS3Config.configAmazonS3();
				if (directory.exists() && directory.isDirectory()) {
					File[] files = directory.listFiles();
					for (File file : files) {
						if (file.isFile() && file.getName().endsWith(".csv")) {
							file.delete();
							String temp = file.getPath().replace("G:\\", "");
							String key = temp.replace("\\","/");
							
							for (S3ObjectSummary obj : s3.listObjects(commonParamStore.getRegular().getS3Bucket(),key).getObjectSummaries()) {
								System.out.println(obj.getKey());
								s3.deleteObject(commonParamStore.getRegular().getS3Bucket(), obj.getKey());
							}
						}
					}
				}

				DateFormat dateFormatter = new SimpleDateFormat("dd_MMM_yyyy_hh_mm_ss");
				String currentDateTime = dateFormatter.format(new Date());
				String fileName = "TCAL_" + currentDateTime + ".csv";
				logger.info(fileName + " is generating in path " + csvFilePath);
				File f1 = new File(csvFilePath + fileName);
				f1.createNewFile();
				FileWriter csvWriter = new FileWriter(csvFilePath + fileName);
				csvWriter.append("Product_ID,ECMCODE,Old_ECM_base,E2m_or_Ecfg,ESDN,NPBU,A_FILE_PART");
				BRERuleSetDetails ruleSetConfig = commonUtility.getBRERuleSetDetails();
				
				
				logger.info("Getting data from DB");
				List<TcalServiceDto> resultSet =serviceRepoUtil.getTcalData(ruleSetConfig);
				
				logger.info("Data feached from DB");
				
				// resultSet.parallelStream()
				for (TcalServiceDto viewData : resultSet) {
					csvWriter.append("\n");
					csvWriter.append(viewData.getProductid());
					csvWriter.append(",");
					csvWriter.append(viewData.getEcmcode());
					csvWriter.append(",");
					if(viewData.getOldecmcode()!=null) {
						csvWriter.append(viewData.getOldecmcode());					
					} else {
						csvWriter.append("");
					}
					csvWriter.append(",");
					csvWriter.append(viewData.getE2mecfgpart());
					csvWriter.append(",");
					csvWriter.append(viewData.getEsdnflag());
					csvWriter.append(",");
					csvWriter.append(viewData.getNpbuflag());
					csvWriter.append(",");
					if(viewData.getAfile()!=null) {	
						csvWriter.append(viewData.getAfile());
//					csvWriter.append("=\"" + viewData.getA_FILE_PART() + "\"");
					} else {
						csvWriter.append("");
//					csvWriter.append("=\"" + "" + "\"");
					}

				}
				csvWriter.close();
				logger.info("Csv File Exported SuccessFully");
				
				String filePath = csvFilePath + fileName;
				commonUtility.reverseSyncCopy(commonParamStore.getRegular().getHostName()+paramStore.getOutBoundSycUrl(), new CopyDTO(filePath.replace("G:\\", ""),false));
				
				return filePath;

			} catch (Exception e) {
				// System.out.println("File IO Error:");
				e.printStackTrace();
				throw new Exception("Unable to generate T cal :Internal Server Error"+e.getMessage());
			}
			// return res;
		}
		

	private void processForAllAndOnetimeMode(List<String> productIds) {
		if(productIds != null && !productIds.isEmpty()) {
			for(String productID:productIds) {
				itProductListRepository.updateTServiceDownload(productID);
			}
			logger.info("ProductIDs inserted into Service Download");
		} else {
			logger.info("No productId received from Service Product profile");
		}		
	}

	private void executeStoredProcedure(String name, String requestId, String correlationGuid) {


		String storeProcSpsd = name;
		logger.info("SP execution starting  for : {}",name);

		StoredProcedureQuery storedProcedure = em.createStoredProcedureQuery(storeProcSpsd);

		storedProcedure.registerStoredProcedureParameter("p_parent_prg_id", Integer.class, ParameterMode.IN);
		storedProcedure.registerStoredProcedureParameter("p_request_id", String.class, ParameterMode.IN);
		//
		storedProcedure.registerStoredProcedureParameter("g_return_flag", Integer.class, ParameterMode.OUT);
		//
		// null is hard coded here as SP expect null to mark it started
		storedProcedure.setParameter("p_parent_prg_id", null);
		storedProcedure.setParameter("p_request_id", requestId);

		storedProcedure.execute();
		Integer returnFlag=(Integer) storedProcedure.getOutputParameterValue("g_return_flag");
		logger.info("SP returned : {}",returnFlag);
	}


	private void storeAudits(String guid, String audActivity, String audSubActivity, int audStatus, String mode) {
		String dbData = "";
		if (mode.contains(",")) {
			dbData = "ProductMode";
		} else {
			dbData = mode;
		}
		TAuditTable auditEntity = new TAuditTable();
		TAuditKey key = new TAuditKey();
		key.setAudActivitId("SD");
		key.setAudDate(LocalDateTime.now());
		key.setAudSubActivity(audSubActivity);
		key.setAudFunctionId("SD");
		key.setAudSubCode(dbData);
		key.setAudSubFunctionId(" ");
		key.setAudCode(" ");
		key.setAudDetails(" ");
		key.setAudActivity(audActivity);
		key.setAudLastUpdateUser(itAuditRepository.getUserFromDB());
		key.setAudLastUpdateDate(LocalDateTime.now());
		key.setAudRequestId(guid);
		key.setAudStatus(audStatus);
		auditEntity.setKey(key);
		itAuditRepository.save(auditEntity);
	}

}
