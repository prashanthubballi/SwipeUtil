package com.cummins.servicepkg;

import java.net.URISyntaxException;
import java.time.Duration;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cummins.servicepkg.dto.CommonParamStore;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.service.cal.impl.CommonUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.github.resilience4j.common.retry.configuration.RetryConfigCustomizer;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;

@SpringBootApplication
@EntityScan(basePackageClasses = { ServicePackage.class, Jsr310JpaConverters.class })
@ComponentScan({"com.cummins.servicepkg"})
public class ServicePackage extends SpringBootServletInitializer {
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(ServicePackage.class);
	}

	@Value("${param.value}")
	private String paramValue;

	@Autowired
	private RetryRegistry registry;
	
	//private static final Logger logger = LoggerFactory.getLogger(ServicePackageCalibrationApplication.class);
	private static final Logger logger = LoggerFactory.getLogger(ServicePackage.class);
	private ParamStore paramStore = new ParamStore();
	private CommonParamStore commonParamStore = new CommonParamStore();
	ObjectMapper objectMapper = new ObjectMapper();

	//private int threadcount;

	public static void main(String[] args) {
		
		SpringApplication.run(ServicePackage.class, args);
	}
	@Bean
	public RestTemplate restTemp() {
		return new RestTemplate();
	}

	@Bean
	public CommonUtility getcomUtil() {
		return new CommonUtility();
	}



	@SuppressWarnings("unchecked")
	@Bean(name = "retryConfig")
	public RetryConfigCustomizer getCentralizedData(@Value("${spring.common}") String commonValue) throws URISyntaxException, RestClientException, JSONException {
		Class<?>[] classes = null;
		try {
			logger.info("CommonParamStore:"+commonValue);
			this.paramStore = objectMapper.readValue(paramValue, ParamStore.class);
			logger.info("Parameter store "+paramStore);
			this.commonParamStore=objectMapper.readValue(commonValue, CommonParamStore.class);
			//	paramStore.getRegular().setServicePkgCalibrationAdditionAPI("http://localhost:7002/servicePackageCalibrationChild/addition");
			//	paramStore.getRegular().setServicePkgCalibrationDeletionAPI("http://localhost:7002/servicePackageCalibrationChild/deletion");
			List<String> exptnclses = paramStore.getResilience4j().getRetry().getRetryExceptions();
			classes = new Class<?>[exptnclses.size()];
			for (int i = 0; i < exptnclses.size(); i++) {
				classes[i] = Class.forName(exptnclses.get(i));
			}
		} catch (RestClientException | JsonProcessingException | ClassNotFoundException e) {
			logger.error("Exception:while mapping paramstore values," + e.getMessage());
		}
		final Class<?>[] exptnclasses = classes;
		return RetryConfigCustomizer.of("throwingException", builder -> builder
				.maxAttempts(paramStore.getResilience4j().getRetry().getMaxRetryAttempts())
				.waitDuration(Duration.ofSeconds(
						Integer.parseInt(paramStore.getResilience4j().getRetry().getWaitDuration().replace("s", ""))))
				.retryExceptions(exptnclasses));
	}

	@Bean
	@DependsOn("retryConfig")
	public ParamStore getParam() {
		return paramStore;
	}
	@Bean
	@DependsOn("retryConfig")
	public CommonParamStore getCommonParam() {
		return commonParamStore;
	}

	@Bean
	public ObjectMapper getObjectMapper() {
		return objectMapper;
	}
	@Bean
	public Retry retryBean() {
		return registry.retry("throwingException");
	}

	@PostConstruct
	public void postConstruct() {
		retryBean().getEventPublisher().onRetry(ev -> logger.info("RetryRegistryEventListener: {}", ev));
	}
}
