package com.cummins.servicepkg.service.child.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cummins.servicepkg.child.dto.ServicePkgCalibrationDelRequest;
import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.dto.BRERuleSetDetails;
import com.cummins.servicepkg.dto.ServicePkgCalibrationRequest;
import com.cummins.servicepkg.dto.ServicePkgCalibrationRequestDTO;
import com.cummins.servicepkg.dto.ServicePkgDto;
import com.cummins.servicepkg.exception.BadRequestException;
import com.cummins.servicepkg.repository.IVServiceActiveOneTimeAllRepo;
import com.cummins.servicepkg.repository.ServiceRepoUtil;


@Service
public class ServicePackageDelUtil {

	@Autowired
	private IVServiceActiveOneTimeAllRepo serviceActiveOneTimeAllRepo;

	@Autowired
	private ServiceRepoUtil serviceRepoUtil;

	private static final Logger logger = LoggerFactory.getLogger(ServicePackageDelUtil.class);

	public Map<String,ServicePkgCalibrationDelRequest> generateDelRequest(BRERuleSetDetails ruleSetConfig,ServicePkgCalibrationRequest req) {
		if (Constants.ALL.equalsIgnoreCase(req.getMode())) {
			//ALL Mode
			List<ServicePkgCalibrationRequestDTO> productIdList = serviceActiveOneTimeAllRepo.getServiceActiveOneTimeAllProductId();
			if(!productIdList.isEmpty()) {
				List<String> regularProducts=productIdList.stream().filter(dto -> !Constants.EXPORT.equalsIgnoreCase(dto.getproductCompliance())).map(ServicePkgCalibrationRequestDTO::getproductId) .collect(Collectors.toList());
				List<String> exportProducts=productIdList.stream().filter(dto -> Constants.EXPORT.equalsIgnoreCase(dto.getproductCompliance())).map(ServicePkgCalibrationRequestDTO::getproductId) .collect(Collectors.toList());
				return 	generateDelALLRequest(req,regularProducts,exportProducts);
			}else {
				logger.error("getServiceActiveOneTimeAllProductId is Empty:mode="+req.getMode());
				throw new BadRequestException("Error in generateDelALLRequest:getServiceActiveOneTimeAllProductId is Empty");
			}
		} else if (Constants.DAILY.equalsIgnoreCase(req.getMode())) {		
			List<ServicePkgDto> resultSetDaily = serviceRepoUtil.getDailyDeleteData(ruleSetConfig);

			if(!resultSetDaily.isEmpty()) {
				List<ServicePkgDto> regularProducts=resultSetDaily.stream().filter(dto -> !Constants.EXPORT.equalsIgnoreCase(dto.getProductcompliance())).collect(Collectors.toList());
				List<ServicePkgDto> exportProducts=resultSetDaily.stream().filter(dto -> Constants.EXPORT.equalsIgnoreCase(dto.getProductcompliance())).collect(Collectors.toList());
				return 	generateDelDailyRequest(req,regularProducts,exportProducts);
			}else {
				logger.error("getServiceActiveAllLastrun is Empty:mode="+req.getMode());
				//throw new BadRequestException("Error in generateDelALLRequest:getServiceActiveOneTimeAllProductId is Empty");
				return null;
			}

		} else if (Constants.ONETIME.equalsIgnoreCase(req.getMode())) {
			//Onetime Mode
			List<ServicePkgCalibrationRequestDTO> productIdList = serviceActiveOneTimeAllRepo.getServiceActiveOneTimeProductId(req.getProductIdList());
			if(!productIdList.isEmpty()) {
				List<String> regularProducts=productIdList.stream().filter(dto -> !Constants.EXPORT.equalsIgnoreCase(dto.getproductCompliance())).map(ServicePkgCalibrationRequestDTO::getproductId) .collect(Collectors.toList());
				List<String> exportProducts=productIdList.stream().filter(dto -> Constants.EXPORT.equalsIgnoreCase(dto.getproductCompliance())).map(ServicePkgCalibrationRequestDTO::getproductId) .collect(Collectors.toList());
				return 	generateDelALLRequest(req,regularProducts,exportProducts);
			}else {
				return 	generateDelALLRequest(req,req.getProductIdList(),req.getProductIdList());
			}
		}
		return null;
	}	
	private Map<String,ServicePkgCalibrationDelRequest> generateDelALLRequest(ServicePkgCalibrationRequest req,List<String> regularProducts,List<String> exportProducts){
		Map<String,ServicePkgCalibrationDelRequest> requestDtos=new HashMap<>();
		logger.info("Generating Del Request:mode="+req.getMode());
		if(!regularProducts.isEmpty()) {
			ServicePkgCalibrationDelRequest request=new ServicePkgCalibrationDelRequest();
			request.setCorrelationGuid(req.getCorrelationGuid());
			request.setMode(req.getMode());
			request.setProductIdList(regularProducts);
			requestDtos.put(Constants.REQUESTREGULAR, request);
		}
		if(!exportProducts.isEmpty()) {
			ServicePkgCalibrationDelRequest request=new ServicePkgCalibrationDelRequest();
			request.setCorrelationGuid(req.getCorrelationGuid());
			request.setMode(req.getMode());
			request.setProductIdList(regularProducts);
			requestDtos.put(Constants.REQUESTEXPORTCONTROL, request);
		}
		return requestDtos;
	}

	private Map<String,ServicePkgCalibrationDelRequest> generateDelDailyRequest(ServicePkgCalibrationRequest req,List<ServicePkgDto> regularProducts,List<ServicePkgDto> exportProducts){
		Map<String,ServicePkgCalibrationDelRequest> requestDtos=new HashMap<>();
		logger.info("Generating Del Request:mode="+req.getMode());
		if(!regularProducts.isEmpty()) {
			ServicePkgCalibrationDelRequest request=new ServicePkgCalibrationDelRequest();
			List<ServicePkgDto>	lists=processResultSet(regularProducts);
			request.setCorrelationGuid(req.getCorrelationGuid());
			request.setMode(req.getMode());
			request.setServiceDownloadDataList(lists);
			request.setProductIdList(lists.stream().map(ServicePkgDto::getProductid).collect(Collectors.toList()));
			requestDtos.put(Constants.REQUESTREGULAR, request);
		}
		if(!exportProducts.isEmpty()) {
			ServicePkgCalibrationDelRequest request=new ServicePkgCalibrationDelRequest();
			List<ServicePkgDto>	lists=processResultSet(exportProducts);
			request.setCorrelationGuid(req.getCorrelationGuid());
			request.setMode(req.getMode());
			request.setServiceDownloadDataList(lists);
			request.setProductIdList(lists.stream().map(ServicePkgDto::getProductid).collect(Collectors.toList()));

			requestDtos.put(Constants.REQUESTEXPORTCONTROL, request);
		}
		return requestDtos;
	}

	private List<ServicePkgDto>  processResultSet(List<ServicePkgDto> resultSets) {
		List<ServicePkgDto>  allData=new LinkedList<>();
		List<ServicePkgDto>  filteredData=new LinkedList<>();
		allData.addAll(resultSets);
//		for (ServicePkgCalibrationRequestDTO data : resultSets) {
//			allData.add(commonUtility.setServiceDownloadData(data));
//		}

		List<ServicePkgDto> resultSetWithoutMAF = allData.stream().filter(m -> !m.getCalgenname().equalsIgnoreCase("MAF") && m.getBootflag().equalsIgnoreCase("N")).collect(Collectors.toList());//boot falg N
		List<ServicePkgDto> resultSetOnlyMAF = allData.stream().filter(m -> m.getCalgenname().equalsIgnoreCase("MAF")).collect(Collectors.toList());
		List<ServicePkgDto> resultSetForBootSignature = allData.stream().filter(m -> m.getBootflag().equalsIgnoreCase("Y")).collect(Collectors.toList());
		if(!resultSetWithoutMAF.isEmpty()) {
			filteredData.addAll(resultSetWithoutMAF);
		}
		if(!resultSetOnlyMAF.isEmpty()) {
			Map<String, List<ServicePkgDto>> productWiseData=resultSetOnlyMAF.stream().collect(Collectors.groupingBy(ServicePkgDto::getProductid));

			List<ServicePkgDto> dataList = new ArrayList<>();
			for (String productId : productWiseData.keySet()) {
				List<ServicePkgDto> productData=productWiseData.get(productId);
				Map<String, List<ServicePkgDto>> ecmData=	productData.stream().collect(Collectors.groupingBy(ServicePkgDto::getEcmcode));
				for (String ecmCode : ecmData.keySet()) {
					dataList.add(ecmData.get(ecmCode).get(0));
					break;
				}
			}
			filteredData.addAll(dataList);
		}
		if(!resultSetForBootSignature.isEmpty()) {
			Map<String, List<ServicePkgDto>> productWiseData=resultSetForBootSignature.stream().collect(Collectors.groupingBy(ServicePkgDto::getProductid));

			List<ServicePkgDto> dataList = new ArrayList<>();
			for (String productId : productWiseData.keySet()) {
				List<ServicePkgDto> productData=productWiseData.get(productId);
				Map<String, List<ServicePkgDto>> ecmData=	productData.stream().collect(Collectors.groupingBy(ServicePkgDto::getBaseecm));
				for (String ecmCode : ecmData.keySet()) {
					dataList.add(ecmData.get(ecmCode).get(0));
					break;
				}
			}
			filteredData.addAll(dataList);
		}

		return filteredData;
	}	
}
