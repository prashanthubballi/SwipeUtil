package com.cummins.servicepkg.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="T_Audit")
public class TAuditTable  implements Serializable {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	private TAuditKey key;
}
