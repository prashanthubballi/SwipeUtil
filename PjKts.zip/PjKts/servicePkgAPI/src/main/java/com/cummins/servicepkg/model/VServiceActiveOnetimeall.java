package com.cummins.servicepkg.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;

/**
 * The persistent class for the V_SERVICE_ACTIVE_ONETIMEALL database table.
 * 
 */
@Data
@Entity
@Table(name = "V_SERVICE_ACTIVE_ONETIMEALL")
@NamedQuery(name = "VServiceActiveOnetimeall.findAll", query = "SELECT v FROM VServiceActiveOnetimeall v")
public class VServiceActiveOnetimeall implements Serializable {
  private static final long serialVersionUID = 1L;

  @EmbeddedId
  VServiceActiveOneTimeAllKey id;

}
