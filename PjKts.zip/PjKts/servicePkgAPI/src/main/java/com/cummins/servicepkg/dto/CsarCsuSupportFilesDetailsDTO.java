package com.cummins.servicepkg.dto;

public interface CsarCsuSupportFilesDetailsDTO {
	
	String getecmProductId();
	String getecmCode();
	String getecmReleasePhaseCode();
	String getecmEffectCode();
	String getA2L();
	String getPCFG();
	String getA2LCBF();
	String getPCFGCBF();

}
