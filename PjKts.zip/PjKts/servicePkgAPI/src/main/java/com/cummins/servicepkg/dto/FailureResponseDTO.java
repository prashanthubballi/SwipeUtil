package com.cummins.servicepkg.dto;

import java.util.ArrayList;
import java.util.List;

public class FailureResponseDTO {
	
	private String productID;
	private List<String> fileName=new ArrayList<>();
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public List<String> getFileName() {
		return fileName;
	}
	public void setFileName(List<String> fileName) {
		this.fileName = fileName;
	}
	public FailureResponseDTO(String productID, List<String> fileName) {
		super();
		this.productID = productID;
		this.fileName = fileName;
	}

}
