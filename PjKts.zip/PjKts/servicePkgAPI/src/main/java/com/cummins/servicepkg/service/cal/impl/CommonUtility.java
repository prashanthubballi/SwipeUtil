package com.cummins.servicepkg.service.cal.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cummins.servicepkg.child.dto.CsarCsuSupportFilesAdditionRequest;
import com.cummins.servicepkg.child.dto.ServicePkgCalAddByProductRequest;
import com.cummins.servicepkg.child.dto.ServicePkgCalibrationChildResponse;
import com.cummins.servicepkg.child.dto.ServicePkgCalibrationDelRequest;
import com.cummins.servicepkg.common.ChildAPI;
import com.cummins.servicepkg.common.CommonResponse;
import com.cummins.servicepkg.common.Constants;
import com.cummins.servicepkg.common.CountAndData;
import com.cummins.servicepkg.common.ObjectData;
import com.cummins.servicepkg.dto.BRERuleSetDetails;
import com.cummins.servicepkg.dto.CommonParamStore;
import com.cummins.servicepkg.dto.ParamStore;
import com.cummins.servicepkg.dto.ServiceNowRequestGenerationDTO;
import com.cummins.servicepkg.dto.ServicePkgCalibrationRequestDTO;
import com.cummins.servicepkg.dto.ServicePkgDto;
import com.cummins.servicepkg.exception.BadRequestException;
import com.cummins.servicepkg.exception.ResourceNotFoundException;
import com.cummins.servicepkg.meta.dto.CopyDTO;
import com.cummins.servicepkg.model.TDistributionRuleSet;
import com.cummins.servicepkg.repository.TDistributionRuleSetRepository;
import com.cummins.servicepkg.service.child.impl.ServicePackageChildAdditionImpl;
import com.cummins.servicepkg.service.child.impl.ServicePackageChildDeletionImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class CommonUtility {
	
	@Autowired
	private CommonParamStore commonPS;
	
	@Autowired
	private ParamStore paramStore;
	
	@Autowired
	private RestUtility restUtility;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private ServicePackageChildDeletionImpl delImpl;

	@Autowired
	private ServicePackageChildAdditionImpl addImpl;

	@Autowired
	private TDistributionRuleSetRepository tDistributionRuleSetRepository;



	private ObjectMapper mapper = new ObjectMapper();

	private static final Logger logger = LoggerFactory.getLogger(CommonUtility.class);

	public ChildAPI callChildAPI(Object req, String guid, String url, String api) {
		if(null==url) {
			CommonResponse<ServicePkgCalibrationChildResponse>  response=null;
			if(Constants.DELETION.equals(api)) {
				 response=delImpl.executeServiceCalDelete((ServicePkgCalibrationDelRequest) req);
			}else if (Constants.ADDITION.equals(api)) {
				 response=addImpl.executeServiceCalAddition((ServicePkgCalAddByProductRequest) req);
			}else if(Constants.CSAR_ADDITION.equals(api)) {
				response = addImpl.csarCsuAddition((CsarCsuSupportFilesAdditionRequest)req);
			}else if(Constants.CSAR_DELETION.equals(api)) {
				response = delImpl.csarCsuDeletion((ServicePkgCalibrationDelRequest)req);
			}
			return processResults(response, api,guid);
		}else {
			try {
				String requestString = mapper.writeValueAsString(req);
				logger.info("REQUEST:" + api + ":" + requestString);
				String response = restUtility.callChildApi(requestString, guid, api, url);
				if (!response.startsWith("ERROR")) {
					return processResults(response, api,guid);
				} else if (response.startsWith("ERROR:Service Error:")) {
					logger.info("RESPONSE2:"+api+":"+response);
					throw new ResourceNotFoundException("guid:"+guid+"\n"+api + " Service returned error, URL:"+url+"Details:\nRequest:"+requestString+"\nResponse:"+response);
				} else {
					logger.info("RESPONSE2:"+api+":"+response);
					throw new BadRequestException(api + ":" + response);
				}
			} catch (JsonProcessingException e) {
				logger.error(guid + "PkgCalAPICall:" + e.getMessage());
				throw new BadRequestException(api + ":" + e.getMessage());
			}catch (Exception e) {
				logger.error(guid + "PkgCalAPICall:" + e.getMessage());
				throw new BadRequestException(api + ":" + e.getMessage());
			}
		}
	}

	@SuppressWarnings("unchecked")
	public ChildAPI processResults(Object response, String api,String guid) {

		logger.info(guid+"Started:Process Results:" + api);
		if (Constants.DELETION.equalsIgnoreCase(api) || Constants.ADDITION.equalsIgnoreCase(api)
				|| Constants.CSAR_DELETION.equalsIgnoreCase(api) || Constants.CSAR_ADDITION.equalsIgnoreCase(api)) {
			CommonResponse<ServicePkgCalibrationChildResponse> respObj = null;
			ChildAPI calibration = new ChildAPI();
			try {
				if(response instanceof String) {
					respObj = mapper.readValue((String)response, new TypeReference<CommonResponse<ServicePkgCalibrationChildResponse>>() {	});
				}else {
					respObj=(CommonResponse<ServicePkgCalibrationChildResponse>) response;
				}

				ServicePkgCalibrationChildResponse supResponse = respObj.getData();
				calibration.setSuccess(supResponse.getSuccess());
				calibration.setFailure(supResponse.getFailure());
			} catch (JsonProcessingException e) {
				List<ObjectData> obj = new ArrayList<>();
				obj.add(new ObjectData(null, null, null, e.getMessage()));
				calibration.setFailure(new CountAndData(1, obj));
				calibration.setSuccess(new CountAndData(0, new ArrayList<>()));
			}catch (Exception e) {
				List<ObjectData> obj = new ArrayList<>();
				obj.add(new ObjectData(null, null, null, e.getMessage()));
				calibration.setFailure(new CountAndData(1, obj));
				calibration.setSuccess(new CountAndData(0, new ArrayList<>()));
			}
			return calibration;
		}else {
			ChildAPI calibration=new ChildAPI();
			CountAndData success=new CountAndData();
			success.getData().add(new ObjectData(null, null, null, response.toString()));
			CountAndData failure=new CountAndData();
			calibration.setFailure(failure);
			calibration.setSuccess(success);
			return calibration;
		}

	}

	public BRERuleSetDetails getBRERuleSetDetails() throws JsonMappingException, JsonProcessingException {
		BRERuleSetDetails ruleSetConfig = new BRERuleSetDetails();

		List<TDistributionRuleSet> serviceDistributionRuleSet = tDistributionRuleSetRepository.getDistributionRuleSetByName(Arrays.asList("ServiceDistributionRule","PowerMatchDistribution"));
		for (TDistributionRuleSet tDistributionRuleSet : serviceDistributionRuleSet) {
			if(tDistributionRuleSet.getId().getBreRuleDistSet().contains("ReleasePhaseCode") || tDistributionRuleSet.getId().getBreRuleDistSet().contains("EffectCode")) {
				if("ServiceDistributionRule".equals(tDistributionRuleSet.getId().getBreRuleName())) {
					String serviceDistributionCondition=tDistributionRuleSet.getId().getBreRuleDistSet().replace("ReleasePhaseCode", "PHASE_CODE").replace("EffectCode", "EFFECT_CODE");
					ruleSetConfig.setServiceDistributionRule(serviceDistributionCondition);
					
					org.json.JSONObject breJson = new org.json.JSONObject(tDistributionRuleSet.getId().getBreJson());
					List<String> phaseCode = new ArrayList<>();
					List<String> effectCode = new ArrayList<>();
					org.json.JSONArray rules = breJson.getJSONArray("rules");
					ruleSetConfig.setCondition(breJson.getString("condition"));
					for(int i = 0; i < rules.length(); i++) {
						String result = rules.getJSONObject(i).toString();
						if(result.contains("[")) {
							com.cummins.servicepkg.dto.RuleList rule=new ObjectMapper().readValue(result, com.cummins.servicepkg.dto.RuleList.class);
							if (rule.getField().equalsIgnoreCase("ReleasePhaseCode")) {
								phaseCode.addAll(rule.getValue());
							} else if (rule.getField().equalsIgnoreCase("EffectCode")) {
								effectCode.addAll(rule.getValue());
							}
						}else {
							com.cummins.servicepkg.dto.Rule rule=new ObjectMapper().readValue(result, com.cummins.servicepkg.dto.Rule.class);
							if (rule.getField().equalsIgnoreCase("ReleasePhaseCode")) {
								phaseCode.add(rule.getValue());
							} else if (rule.getField().equalsIgnoreCase("EffectCode")) {
								effectCode.add(rule.getValue());
							}
						}			
					}
					ruleSetConfig.setPhaseCode(phaseCode);
					ruleSetConfig.setEffectCode(effectCode);
					
				}else if("PowerMatchDistribution".equals(tDistributionRuleSet.getId().getBreRuleName())) {
					String powerMatchRule=tDistributionRuleSet.getId().getBreRuleDistSet().replace("ReleasePhaseCode", "PHASE_CODE").replace("EffectCode", "EFFECT_CODE");
					ruleSetConfig.setPowerMatchDistributionRule(powerMatchRule);
					org.json.JSONObject breJson1 = new org.json.JSONObject(tDistributionRuleSet.getId().getBreJson());
					
					org.json.JSONArray rules1 = breJson1.getJSONArray("rules");
					ruleSetConfig.setConditionSecond(breJson1.getString("condition"));
					List<String> phaseCodeSecond = new ArrayList<>();
					List<String> effectCodeSecond = new ArrayList<>();
					
					for(int i = 0; i < rules1.length(); i++) {
						String result = rules1.getJSONObject(i).toString();
						if(result.contains("[")) {
							com.cummins.servicepkg.dto.RuleList rule=new ObjectMapper().readValue(result, com.cummins.servicepkg.dto.RuleList.class);
							if (rule.getField().equalsIgnoreCase("ReleasePhaseCode")) {
								phaseCodeSecond.addAll(rule.getValue());
							} else if (rule.getField().equalsIgnoreCase("EffectCode")) {
								effectCodeSecond.addAll(rule.getValue());
							}
						}else {
							com.cummins.servicepkg.dto.Rule rule=new ObjectMapper().readValue(result, com.cummins.servicepkg.dto.Rule.class);
							if (rule.getField().equalsIgnoreCase("ReleasePhaseCode")) {
								phaseCodeSecond.add(rule.getValue());
							} else if (rule.getField().equalsIgnoreCase("EffectCode")) {
								effectCodeSecond.add(rule.getValue());
							}
						}			
					}		
					ruleSetConfig.setPhaseCodeSecond(phaseCodeSecond);
					ruleSetConfig.setEffectCodeSecond(effectCodeSecond);
				}
			}
		}
		logger.info("BRE details : "+ruleSetConfig);
		return ruleSetConfig;
	}

	public ServicePkgDto setServiceDownloadData(ServicePkgCalibrationRequestDTO data) {
		ServicePkgDto res=new ServicePkgDto();
		res.setProductid(data.getproductId());
		res.setEcmcode(data.getecmCode());
		res.setBaseecm(data.getbaseECM());
		res.setPhasecode(data.getphaseCode());
		res.setEffectcode(data.geteffectCode());
		res.setItemtype(data.getitemType());
		res.setCallgenpath(data.getcallGenPath());
		res.setCalgenname(data.getcalGenName());
		res.setAfile(data.getaFile());
		res.setPartintpath(data.getpartIntPath());
		res.setPartextpath(data.getpartExtPath());
		res.setEncryptiontype(data.getencryptionType());
		res.setProductcompliance(data.getproductCompliance());
		res.setBootflag(data.getbootFlag());
		return res;
	}
	public List<ServicePkgDto> setServiceDownloadDataList(List<ServicePkgCalibrationRequestDTO> dataList) {
		List<ServicePkgDto> returnList=new LinkedList<>();
		for (ServicePkgCalibrationRequestDTO data : dataList) {
			ServicePkgDto res=new ServicePkgDto();
			res.setProductid(data.getproductId());
			res.setEcmcode(data.getecmCode());
			res.setBaseecm(data.getbaseECM());
			res.setPhasecode(data.getphaseCode());
			res.setEffectcode(data.geteffectCode());
			res.setItemtype(data.getitemType());
			res.setCallgenpath(data.getcallGenPath());
			res.setCalgenname(data.getcalGenName());
			res.setAfile(data.getaFile());
			res.setPartintpath(data.getpartIntPath());
			res.setPartextpath(data.getpartExtPath());
			res.setEncryptiontype(data.getencryptionType());
			res.setProductcompliance(data.getproductCompliance());
			res.setBootflag(data.getbootFlag());
			returnList.add(res);
		}

		return returnList;
	}
	public void reverseSyncCopy(String url,CopyDTO req) {
		try {
			logger.info("Reverse Sync Started.");
			ResponseEntity<String> response=restTemplate.postForEntity(url, req, String.class);
			logger.info(response.getBody());
			//restTemplate.getForEntity(url+"/"+path, String.class);
		} catch (Exception e) {
			logger.error("Exception in reverse sync:" + e.getMessage());
		}

	}
	public  String copyFileToE2M(String srcPath,String dstPath) throws IOException {
		// copy files from source to target folder
		Files.copy(Path.of(srcPath), Path.of(dstPath), StandardCopyOption.REPLACE_EXISTING);
		reverseSyncCopy(commonPS.getRegular().getHostName()+paramStore.getOutBoundSycUrl(),	new CopyDTO(dstPath.replace("G:\\", ""),false));
		return dstPath;

	}
	public void createServiceNowTicket(String shortError, String description, String guid) {
		ServiceNowRequestGenerationDTO dto = new ServiceNowRequestGenerationDTO();
		try {
			dto.setAssignment_group(paramStore.getServiceNowAssignmentGrp());
			dto.setDescription(description);
			dto.setImpact(paramStore.getServiceNowImpact());
			dto.setUrgency(paramStore.getServiceNowUrgency());
			dto.setShort_description(shortError);
			//String requestString = new ObjectMapper().writeValueAsString(dto);
			 callChildAPI(dto, guid,commonPS.getRegular().getHostName() + paramStore.getServiceNowAPI(), "ServiceNow");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while creating service now request:" + e.getMessage());
		}
	}
}
