package com.cummins.servicepkg.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cummins.servicepkg.child.dto.CsarCsuSupportFilesAdditionRequest;
import com.cummins.servicepkg.child.dto.ServiceE2mResponse;
import com.cummins.servicepkg.child.dto.ServicePkgCalAddByProductRequest;
import com.cummins.servicepkg.child.dto.ServicePkgCalibrationChildResponse;
import com.cummins.servicepkg.child.dto.ServicePkgCalibrationDelRequest;
import com.cummins.servicepkg.common.CommonResponse;
import com.cummins.servicepkg.common.ResponseUtility;
import com.cummins.servicepkg.dto.RequestServiceLayoutDistribution;
import com.cummins.servicepkg.dto.ServiceE2mEcfgRequestDTO;
import com.cummins.servicepkg.dto.ServicePkgCalibrationRequest;
import com.cummins.servicepkg.dto.ServicePkgCalibrationResponse;
import com.cummins.servicepkg.service.cal.impl.ServicePackageCalibrationServiceImpl;
import com.cummins.servicepkg.service.child.impl.ServicePackageChildAdditionImpl;
import com.cummins.servicepkg.service.child.impl.ServicePackageChildDeletionImpl;
import com.cummins.servicepkg.service.e2m.impl.ServicePackageE2mEcfgImpl;
import com.cummins.servicepkg.service.layout.impl.ServiceLayoutDistributionServiceImpl;

@RestController
@RequestMapping("serviceinterface")
public class ServicePackageCalibrationController {

	@Autowired 
	private ServicePackageCalibrationServiceImpl impl;

	@Autowired
	private ServicePackageE2mEcfgImpl servicePkgE2mEcfgService;

	@Autowired
	private ServiceLayoutDistributionServiceImpl serviceLayoutDistributionService;

	@Autowired 
	private ServicePackageChildDeletionImpl delImpl;

	@Autowired 
	private ServicePackageChildAdditionImpl addImpl;

	private static final Logger logger = LoggerFactory.getLogger(ServicePackageCalibrationServiceImpl.class);

	@PostMapping("/executeServiceCalibration")
	public ResponseEntity<CommonResponse<ServicePkgCalibrationResponse>> executeServiceClibration(@RequestBody ServicePkgCalibrationRequest req){
		logger.info("Started Service Pkg Clibration:REQUEST {}"+ req);
		MDC.put("uuid", req.getCorrelationGuid());
		CommonResponse<ServicePkgCalibrationResponse> response= impl.executeServiceClibration(req);
		logger.info("Complete Service Pkg Clibration:"+ response);
		MDC.remove("uuid");
		if (response.getHeader().isSuccess()) {
			return ResponseEntity.ok(response);
		} else {
			return new ResponseEntity<CommonResponse<ServicePkgCalibrationResponse>>(response, HttpStatus.valueOf(response.getHeader().getCode()));
		}
	}

	@PostMapping("/servicePkgE2mECFG")
	private ResponseEntity<CommonResponse<ServiceE2mResponse>> ServicePackageE2mEcfg( @RequestBody ServiceE2mEcfgRequestDTO request) throws IOException {
		MDC.put("uuid", request.getCorrelationGuid());
		CommonResponse<ServiceE2mResponse> response = servicePkgE2mEcfgService.executeServicePkgE2mEcfg(request);
		MDC.remove("uuid");
		if (response.getHeader().isSuccess()) {
			return ResponseEntity.ok(response);
		} else {
			return new ResponseEntity<CommonResponse<ServiceE2mResponse>>(response, HttpStatus.valueOf(response.getHeader().getCode()));
		}
	}


	@PostMapping("/callStoredProcedure")
	public  ResponseEntity<CommonResponse<String>> callStoredProcedure(@RequestBody RequestServiceLayoutDistribution dto) {
		MDC.put("uuid", dto.getCorrelationGuid());
		try {
			String response=serviceLayoutDistributionService.callStoredProcedure(dto);
			MDC.remove("uuid");
			return ResponseUtility.generateResponse(response,HttpStatus.OK);
		} catch (Exception e) {
			MDC.remove("uuid");
			return  ResponseUtility.generateResponse(e.getMessage(),HttpStatus.OK);
		}

	}

	@PostMapping("/tcalFileGenerator")
	public  ResponseEntity<CommonResponse<String>> tcalGen(@RequestBody RequestServiceLayoutDistribution dto) {
		MDC.put("uuid", dto.getCorrelationGuid());
		try {
			String response=serviceLayoutDistributionService.tcalFileGenerator( );
			MDC.remove("uuid");
			return ResponseUtility.generateResponse(response,
					HttpStatus.OK);
		} catch (Exception e) {
			MDC.remove("uuid");
			return  ResponseUtility.generateResponse(e.getMessage(),HttpStatus.OK);
		}

	}
	

	@PostMapping("/deletion")
	public ResponseEntity<CommonResponse<ServicePkgCalibrationChildResponse>> executeServiceClibration(@RequestBody ServicePkgCalibrationDelRequest req){
		logger.info("Executing Service Pkg Clibration deletion {}", req);
		//ThreadContext.put("uuid", req.getCorrelationGuid());
		CommonResponse<ServicePkgCalibrationChildResponse> response = delImpl.executeServiceCalDelete(req);
		logger.info("Completed Service Pkg Clibration deletion {}", response);
		//ThreadContext.clearAll();
		if (response.getHeader().isSuccess()) {
			return ResponseEntity.ok(response);
		} else {
			return new ResponseEntity<CommonResponse<ServicePkgCalibrationChildResponse>>(response, HttpStatus.valueOf(response.getHeader().getCode()));
		}
	}

	@PostMapping("/addition")
	public ResponseEntity<CommonResponse<ServicePkgCalibrationChildResponse>> executeServiceCalAddition(@RequestBody ServicePkgCalAddByProductRequest req){
		logger.info("Executing Service Pkg Clibration Addition {}", req);
		//  ThreadContext.put("uuid", req.getCorrelationGuid());
		CommonResponse<ServicePkgCalibrationChildResponse> response = addImpl.executeServiceCalAddition(req);
		logger.info("Completed Service Pkg Clibration Addition {}", response);
		// ThreadContext.clearAll();
		if (response.getHeader().isSuccess()) {
			return ResponseEntity.ok(response);
		} else {
			return new ResponseEntity<CommonResponse<ServicePkgCalibrationChildResponse>>(response, HttpStatus.valueOf(response.getHeader().getCode()));
		}
	}
	 @PostMapping("/csarCsuDeletion")
	  public ResponseEntity<CommonResponse<ServicePkgCalibrationChildResponse>> csarCsuDeletion(@RequestBody ServicePkgCalibrationDelRequest req){
	    logger.info("Executing CSAR CSU Support Files deletion {}", req);
	    //ThreadContext.put("uuid", req.getCorrelationGuid());
	    CommonResponse<ServicePkgCalibrationChildResponse> response = delImpl.csarCsuDeletion(req);
	    logger.info("Completed CSAR CSU Support Files deletion {}", response);
		//ThreadContext.clearAll();
	    if (response.getHeader().isSuccess()) {
				return ResponseEntity.ok(response);
		} else {
				return new ResponseEntity<CommonResponse<ServicePkgCalibrationChildResponse>>(response, HttpStatus.valueOf(response.getHeader().getCode()));
		}
	  }
	  
	  @PostMapping("/csarCsuAddition")
	  public ResponseEntity<CommonResponse<ServicePkgCalibrationChildResponse>> csarCsuAddition(@RequestBody CsarCsuSupportFilesAdditionRequest req){
	    logger.info("Executing CSAR CSU Support Files Addition {}", req);
	    //ThreadContext.put("uuid", req.getCorrelationGuid());
	    CommonResponse<ServicePkgCalibrationChildResponse> response = addImpl.csarCsuAddition(req);
	    logger.info("Completed CSAR CSU Support Files Addition {}", response);
		//ThreadContext.clearAll();
	    if (response.getHeader().isSuccess()) {
				return ResponseEntity.ok(response);
		} else {
				return new ResponseEntity<CommonResponse<ServicePkgCalibrationChildResponse>>(response, HttpStatus.valueOf(response.getHeader().getCode()));
		}
	  }
}
