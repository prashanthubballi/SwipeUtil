package com.cummins.servicepkg.repository;

import java.util.List;

import javax.persistence.QueryHint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import com.cummins.servicepkg.dto.ServiceE2mEcfgDTO;
import com.cummins.servicepkg.model.VServiceE2mEcfgDaily;
import com.cummins.servicepkg.model.VServiceE2mEcfgDailyKey;

@Repository
public interface ServiceE2mEcfgDailyRepo extends JpaRepository<VServiceE2mEcfgDaily, VServiceE2mEcfgDailyKey> {

	@Query(value = "select DISTINCT DDO_PRODUCT_ID ,CONFIG_PART as CONFIG_PART, CONFIG_EXTN as CONFIG_EXTN,INT_PATH as INT_PATH "
			+ "from V_SERVICE_E2M_ECFG_DAILY where PRODUCT_COMPLIANCE='R' order by DDO_PRODUCT_ID", nativeQuery = true)
	@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "50000"))
	List<ServiceE2mEcfgDTO> getDaily();
}
