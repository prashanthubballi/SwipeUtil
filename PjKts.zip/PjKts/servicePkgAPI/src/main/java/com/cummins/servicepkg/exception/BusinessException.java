package com.cummins.servicepkg.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
public class BusinessException extends Exception {
  /**
   * 
   */
  private static final long serialVersionUID = -1945159325904217326L;

  public BusinessException(String msg) {
    super(msg);

  }

  public BusinessException(String msg, Throwable t) {
    super(msg, t);
  }
}
